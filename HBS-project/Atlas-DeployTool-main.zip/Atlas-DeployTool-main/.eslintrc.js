module.exports = {
  root: true,
  parser: 'babel-eslint',
  parserOptions: {
    sourceType: 'module'
  },
  env: {
    browser: true,
    node: true
  },
  extends: 'standard',
  // extends: [
  //   // add more generic rulesets here, such as:
  //   'eslint:recommended',
  //   'plugin:vue/vue3-recommended'
  // ],
  globals: {
    __static: true,
    "$": true,
    "jQuery": true
  },
  plugins: [
    'html'
  ],
  'rules': {
    // allow paren-less arrow functions
    'arrow-parens': 0,
    // allow async-await
    'generator-star-spacing': 0,
    "node/no-deprecated-api": ["error", {
      "ignoreModuleItems": [],
      "ignoreGlobalItems": ["new Buffer()"]
    }],
    // allow debugger during development
    'no-debugger': process.env.NODE_ENV === 'production' ? 2 : 0
  }
}
