'use strict'

import { app, BrowserWindow, dialog, ipcMain } from 'electron'

/**
 * Set `__static` path to static files in production
 * https://simulatedgreg.gitbooks.io/electron-vue/content/en/using-static-assets.html
 */
if (process.env.NODE_ENV !== 'development') {
  global.__static = require('path').join(__dirname, '/static').replace(/\\/g, '\\\\')
}

const fs = require('fs')
const ini = require('ini')
const http = require('http')
const configFile = './config.ini'
const spawn = require('child_process').spawn

const devices = []

// read config.ini file
if (!fs.existsSync(configFile)) {
  dialog.showErrorBox('エラー', 'コンフィグファイルは見つかりませんでした。アプリが起動できません。')
  app.quit()
} else {
  const config = ini.parse(fs.readFileSync(configFile, 'utf-8'))
  if (config.atlas_face) {
    for (const key of Object.keys(config.atlas_face)) {
      let item = {
        name: key,
        address: config.atlas_face[key].trim(),
        type: 'face'
      }
      if (item.address) {
        devices.push(item)
      }
    }
  }

  let numFloors = 64
  let numCameras = 4

  if (config.crowd_elevator) {
    for (const key of Object.keys(config.crowd_elevator)) {
      if (key === 'NumFloors') {
        numFloors = config.crowd_elevator[key].trim()
      }
      if (key === 'NumCameras') {
        numCameras = config.crowd_elevator[key].trim()
      }
    }
  }
  if (config.atlas_crowd) {
    for (const key of Object.keys(config.atlas_crowd)) {
      let item = {
        name: key,
        address: config.atlas_crowd[key].trim(),
        type: 'crowd',
        floors: numFloors,
        cameraNo: numCameras
      }
      if (item.address) {
        devices.push(item)
      }
    }
  }
}

// read crowd elevator config file

let mainWindow
const winURL = process.env.NODE_ENV === 'development'
  ? `http://localhost:9080`
  : `file://${__dirname}/index.html`

function createWindow () {
  /**
   * Initial window options
   */
  mainWindow = new BrowserWindow({
    useContentSize: true,
    maximizable: true,
    webPreferences: {
      webSecurity: false,
      nodeIntegration: true
    },
    show: false
  })

  mainWindow.setMenu(null)

  mainWindow.maximize()

  mainWindow.loadURL(winURL)

  mainWindow.show()

  mainWindow.on('closed', () => {
    mainWindow = null
  })
}

app.on('ready', () => {
  if (devices.length === 0) {
    dialog.showErrorBox('エラー', 'コンフィグファイルにはAtlas装置が見つかりませんでした。')
    app.quit()
  } else {
    createWindow()
  }
})

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit()
  }
})

app.on('activate', () => {
  if (mainWindow === null) {
    createWindow()
  }
})

app.on('certificate-error', function (event, webContents, url, error, certificate, callback) {
  event.preventDefault()
  const rst = true
  callback(rst)
})

// Web Server
http.createServer((req, res) => {
  if (req.method === 'POST' && req.url === '/deploy/upload') {
    req.setEncoding('utf8')
    let buffer = ''
    req.on('data', (chunk) => {
      buffer += chunk
    })
    req.on('end', () => {
      try {
        const jsonData = JSON.parse(buffer)
        mainWindow.webContents.send('upload', jsonData)
        res.end('{}')
      } catch (err) {
        res.end('{"code": -1}')
      }
    })
  } else {
    res.end('404 not found')
  }
}).listen(5000, '0.0.0.0')

// Local API
ipcMain.on('readDevices', (event, arg) => {
  event.returnValue = devices
})

ipcMain.handle('readCapture', async (event, arg) => {
  let result = ''
  if (!arg) {
    return {data: result}
  }

  let promise = new Promise(resolve => {
    let ops = [
      '-i', arg,
      '-vframes', '1',
      '-f', 'image2pipe',
      '-'
    ]
    let chunks = Buffer.from([])
    let ffmpeg = spawn('ffmpeg', ops)

    ffmpeg.stdout.on('data', chunk => {
      chunks = Buffer.concat([chunks, chunk])
    })
    ffmpeg.stdout.on('end', () => {
      let imgBase64 = chunks.toString('base64')
      result = 'data:image/jpeg;base64,' + imgBase64
      resolve({data: result})
    })
    ffmpeg.stdout.on('error', () => {
      resolve({data: result})
    })
    setTimeout(() => { ffmpeg.kill() }, 15000)
  })

  result = await promise
  return result
})
