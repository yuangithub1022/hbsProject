<style scoped>
.box-body {
  min-height: 30vh;
}
.modal-form {
  margin-top: 15px;
}
.desc {
  margin-top: 20px;
}
.noBottom{
  margin-bottom: 0px;
}
.setStyle{
  font-size: 11px;
}
</style>
<template>
  <div class="wrapper">
    <pageHeader></pageHeader>
    <pageAside></pageAside>
    <div class="content-wrapper">
      <section class="content">
        <div class="box box-default">
          <div class="box-header">
            <h4>{{ $t("task.mps") }}</h4>
          </div>
          <div class="box-body">
            <input type='file' ref='file' @change="loadTextFromFile" accept=".json" style="display:none" />
            <table id="mps-tasks" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.url") }}</th>
                  <th>{{ $t("task.score") }}</th>
                  <th>{{ $t("task.library") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th>{{ $t("task.roi") }}</th>
                  <th>{{ $t("task.tmode") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
        <div class="box box-default">
          <div class="box-header">
            <h4>{{ $t("task.acs") }}</h4>
          </div>
          <div class="box-body">
            <!-- <input type='file' ref='file' @change="loadTextFromFile" accept=".json" style="display:none" /> -->
            <table id="acs-tasks" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.device") }}</th>
                  <th>{{ $t("task.score") }}</th>
                  <th>{{ $t("task.library") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
        <pageModal :show.sync="showModal" :footer="editable">
          <div slot="header">
            <span v-if="showObject.task_id && editable">{{ $t("common.edit") }} ({{ showObject.extra_info.task_name }})</span>
            <span v-if="showObject.task_id && !editable">{{ $t("common.detail") }} ({{ showObject.extra_info.task_name }}) </span>
            <span v-if="!showObject.task_id && editable">{{ $t("common.create") }} </span>
          </div>
          <div slot="body">
            <form class="form-horizontal" v-if="showObject.task">
              <div class="modal-form">
                <div class="form-group">
                  <label class="col-xs-4 control-label">
                    {{ $t("task.name") }}
                  </label>
                  <div class="col-xs-8">
                    <input type="text" class="form-control" v-model="showObject.extra_info.task_name" placeholder="Device Name" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-4 control-label">
                    {{ $t("task.stype") }}
                  </label>
                  <div class="col-sm-8">
                    <select v-model="showObject.source.type" class="form-control" :disabled="!editable">
                      <option value="FC_SENSEPASS" v-if="showObject.source.type==='FC_SENSEPASS'">TABLET CAMERA</option>
                      <option value="VN_RTSP" v-if="showObject.source.type==='VN_RTSP'">RTSP CAMERA</option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='VN_RTSP'">
                  <label class="col-sm-4 control-label">
                    {{ $t("task.tmode") }}
                  </label>
                  <div class="col-sm-8">
                    <select v-model="showObject.task.parameter.face.track_mode" class="form-control" :disabled="!editable">
                      <option value="VIDEO_TRACK_MODE_ENTER">{{ $t("task.mode_enter") }}</option>
                      <option value="VIDEO_TRACK_MODE_OPTIMAL">{{ $t("task.mode_optimal") }}</option>
                      <option value="VIDEO_TRACK_MODE_PERIODIC">{{ $t("task.mode_periodic") }}</option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='FC_SENSEPASS'">
                  <label class="col-xs-4 control-label">
                    {{ $t("task.device") }}
                  </label>
                  <div class="col-xs-8">
                    <input type="text" class="form-control" v-model="showObject.source.parameter.sensepass.device_sn" placeholder="Device SN" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='VN_RTSP'">
                  <label class="col-xs-4 control-label">
                    {{ $t("task.url") }}
                  </label>
                  <div class="col-xs-8">
                    <input type="text" class="form-control" v-model="showObject.source.parameter.rtsp.url" placeholder="RTSP URL" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-xs-4 control-label">
                    {{ $t("task.score") }}
                  </label>
                  <div class="col-xs-8">
                    <input type="number" min="0" max="1" oninput="validity.valid||(value='');" step="0.01" class="form-control" v-model="showObject.task.parameter.face.min_score" placeholder="Min Score" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-xs-4 control-label">
                    {{ $t("task.library") }}
                  </label>
                  <div class="col-xs-8">
                    <select v-model="showObject.task.parameter.face.id_array" v-select2 :disabled="!editable" class="form-control select2" multiple="multiple" data-placeholder="Select Libraries" style="width: 100%;">
                      <option v-for="item of libraries" :key="item.id" :value="item.id">{{ item.name }}</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                    <div class="col-xs-4"></div>
                    <div class="col-xs-8">
                      <input type="checkbox" v-model="showObject.extra_info.adam_use" true-value="yes" false-value="no" :disabled="!editable || showObject.extra_info.adam_elevator_use === 'yes'">
                      <label class="control-label">{{ $t("task.adam_use") }}</label>
                    </div>
                </div>
                <div class="form-group">
                  <div class="col-xs-4"></div>
                    <div class="col-xs-8">
                      <input type="checkbox" v-model="showObject.extra_info.adam_elevator_use" true-value="yes" false-value="no" :disabled="!editable || showObject.extra_info.adam_use === 'yes'">
                      <label class="control-label">{{ $t("task.elevator_use") }}</label>
                    </div>
                </div>
                <div v-if="showObject.extra_info.adam_use === 'yes'">
                  <div class="form-group">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.adam_config") }}
                    </label>
                    <div class="col-xs-8">
                        <input type="text" class="form-control" v-model="showObject.extra_info.adam_config" placeholder="ADAM装置のIP:PORT" :disabled="!editable">
                    </div>
                  </div>
                  <div class="form-group" v-if="showObject.source.type==='FC_SENSEPASS'">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.device_ip") }}
                    </label>
                    <div class="col-xs-8">
                      <input type="text" class="form-control" v-model="showObject.extra_info.camera_config" placeholder="Device IP" :disabled="!editable">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.adam_do1") }}
                    </label>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> DO </span>
                        <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.extra_info.adam_do1" :disabled="!editable">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-xs-4"></div>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> {{ $t("task.adam_output_time") }} </span>
                        <input type="number" min="1" max="180" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.extra_info.adam_do1_time" :disabled="!editable"/>
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.adam_do2") }}
                    </label>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> DO </span>
                        <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.extra_info.adam_do2" :disabled="!editable">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-xs-4"></div>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> {{ $t("task.adam_output_time") }} </span>
                        <input type="number" min="1" max="180" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.extra_info.adam_do2_time" :disabled="!editable"/>
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>                  
                  <div class="form-group">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.adam_do3") }}
                    </label>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> DO </span>
                        <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.extra_info.adam_do3" :disabled="!editable">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-xs-4"></div>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> {{ $t("task.adam_output_time") }} </span>
                        <input type="number" min="1" max="180" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.extra_info.adam_do3_time" :disabled="!editable"/>
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.adam_do4") }}
                    </label>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <span class="input-group-addon"> DO </span>
                        <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.extra_info.adam_do4" placeholder="ADAM装置、カメラ故障時通知先のADAM番号" :disabled="!editable">
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-xs-4"></div>
                    <div class="col-xs-8">
                      <label class="control-label">{{ $t("task.do_relay") }}</label>
                    </div>
                  </div>
                </div>
                <div v-if="showObject.extra_info.adam_elevator_use === 'yes'">
                  <div class="form-group" v-if="showObject.source.type==='FC_SENSEPASS'">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.device_ip") }}
                    </label>
                    <div class="col-xs-8">
                      <input type="text" class="form-control" v-model="showObject.extra_info.camera_config" placeholder="Device IP" :disabled="!editable">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-4 control-label">
                      {{ $t("task.adam_output_time") }}
                    </label>
                    <div class="col-xs-8">
                      <div class="input-group">
                        <!-- <span class="input-group-addon"> {{ $t("task.adam_output_time") }} </span> -->
                        <input type="number" min="1" max="180" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.extra_info.adam_do_time" :disabled="!editable"/>
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.task_id && !editable">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.status") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-if="showObject.status" :value="showObject.status.status" disabled>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.task_id && !editable">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.created") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" :value="showObject.create_time" disabled>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='VN_RTSP' && editable">
                  <hr>
                  <label class="col-xs-12 control-label" style="margin-bottom: 5px;">
                    <p class="text-center bold">{{ $t("task.roi_config") }}</p>
                  </label>
                  <div class="col-xs-12 btn-group" style="margin-bottom: 5px;">
                    <a @click="updateRoiStage(false)" v-if="showObject.task_id" class="btn btn-info btn-xs pull-left">{{ $t("task.capture_from_history") }}</a>
                    <a @click="updateRoiStage(true)" class="btn btn-info btn-xs pull-right">{{ $t("task.capture_from_rtsp") }}</a>
                  </div>
                  <div class="col-xs-12">
                    <v-stage ref="stage" :config="roiStageConfig">
                      <v-layer ref="layer">
                        <v-image :config="roiImageConfig"/>
                        <v-rect ref="rectangle" :config="roiRectConfig" @transform="handleRectChange" />
                        <v-transformer ref="transformer" :config="roiTransformerConfig" />
                      </v-layer>
                    </v-stage>
                    <div class="desc">
                      <p class="text-muted">
                        <span v-if="showObject.task && showObject.task.parameter.face.roi">
                          {{ $t("message.task_roi_currentvalue") }}
                          {{ showObject.task.parameter.face.roi.vertices }}
                        </span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showModal=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="updateTask">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>

        <pageModal :show.sync="showTableModal" :footer="true">
          <div slot="header">
            {{ $t("common.import") }}
          </div>
          <div slot="body" v-if="position == 'Top'">
            <table class="table table-bordered table-striped">
              <tr>
                <th>{{ $t("task.name") }}</th>
                <th>{{ $t("task.stype") }}</th>
                <th>{{ $t("task.score") }}</th>
                <th>{{ $t("task.created") }}</th>
              </tr>
              <tr v-for="(item, index) in tableList_Top.tasks" :key="index">
                <td>{{item.extra_info.task_name}}</td>
                <td>{{item.source.type}}</td>
                <td>{{item.task.parameter.face.min_score}}</td>
                <td>{{item.create_time | formatDate}}</td>
              </tr>
            </table>
          </div>
          <div slot="body" v-if="position == 'Bottom'">
            <table class="table table-bordered table-striped">
              <tr>
                <th>{{ $t("task.name") }}</th>
                <th>{{ $t("task.stype") }}</th>
                <th>{{ $t("task.device") }}</th>
                <th>{{ $t("task.score") }}</th>
                <th>{{ $t("task.created") }}</th>
              </tr>
              <tr v-for="(item, index) in tableList_Bottom.tasks" :key="index">
                <td>{{item.extra_info.task_name}}</td>
                <td>{{item.source.type}}</td>
                <td>{{item.source.parameter.sensepass.device_sn}}</td>
                <td>{{item.task.parameter.face.min_score}}</td>
                <td>{{item.create_time | formatDate}}</td>
              </tr>
            </table>
          </div>
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showTableModal=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="importTasks">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>
      </section>
    </div>
    <!-- <pageFooter></pageFooter> -->
  </div>
</template>
<script>
import * as moment from 'moment';
import * as util from '../assets/js/util';
import api from '../api/api'; 

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      device: this.$root.deviceData,
      libraries: [],
      showModal: false,
      showTableModal:false,
      showObject: {},
      showRoiDialog: false,
      roiStageConfig: {width: 560, height: 315},
      roiImageConfig: {x: 0, y: 0, image: null},
      roiRectConfig: null,
      roiTransformerConfig: null,
      roiScaleRatio: 1,
      editable: false,
      dataTableAcs: null,
      dataTableMps: null,
      tableList_Top: [],
      tableList_Bottom: [],
      taskList: [],
      file: null,

      baseStr:'{"mode":5,"open_door_type":0,"liveness":true,"liveness_threshold":0.98,"verify_threshold":0.83,"face_update_threshold":9.9,"admin_pwd":"123","device_run_type":1,'+
        '"language_type":2,"yaw":30,"pitch":30,"roll":30,"recognition_distance":1.0,"hack_no_pass_count_threshold":10,"stranger_count_threshold":5,"network_relay_address":"",' +
        '"use_mode":3,"ntp_server_address":"","logo":true,"welcome_tip":"","verify_success_tip":"","verify_fault_tip":"","use_show_avatar":true,"show_user_name":true,'+
        '"auto_reboot":true,"reboot_time":"06:00:00","wait_time":5}',
      extraStr:'{}',

      bodyObj:{},
      position:''
    };
  },
  methods: {
    initTimer() {
      this.timer = setInterval(() => {
        const tasksMps = this.dataTableMps ? this.dataTableMps.data() : [];
        if (tasksMps.length > 0) {
          let refresh = false;
          for (let i = 0; i < tasksMps.length; i++) {
            if (tasksMps[i][7] === 'PENDING') {
              refresh = true;
              break;
            }
          }
          if (refresh) {
            this.dataTableMps.ajax.reload();
          }
        }
        const tasksAcs = this.dataTableAcs ? this.dataTableAcs.data() : [];
        if (tasksAcs.length > 0) {
          let refresh = false;
          for (let i = 0; i < tasksAcs.length; i++) {
            if (tasksAcs[i][7] === 'PENDING') {
              refresh = true;
              break;
            }
          }
          if (refresh) {
            this.dataTableAcs.ajax.reload();
          }
        }
      }, 3000);
    },
    updateTask() {
      const vm = this;

      if (!vm.showObject.extra_info.task_name || !vm.showObject.source.type || vm.showObject.task.parameter.face.id_array.length < 1
          || vm.showObject.task.parameter.face.min_score < 0 || vm.showObject.task.parameter.face.min_score > 1
          || (vm.showObject.source.type === 'FC_SENSEPASS' && !vm.showObject.source.parameter.sensepass.device_sn)
          || (vm.showObject.source.type === 'VN_RTSP' && !vm.showObject.source.parameter.rtsp.url)) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      if((vm.showObject.source.type === 'FC_SENSEPASS' && vm.showObject.extra_info.adam_elevator_use === 'yes' && !vm.showObject.extra_info.camera_config) ||
        (vm.showObject.extra_info.adam_elevator_use === 'yes' && !vm.showObject.extra_info.adam_do_time)){
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      if(
        (vm.showObject.extra_info.adam_use === 'yes') 
        && (!vm.showObject.extra_info.adam_config 
         || (vm.showObject.extra_info.adam_do1 && !vm.showObject.extra_info.adam_do1_time ) 
         || (vm.showObject.extra_info.adam_do2 && !vm.showObject.extra_info.adam_do2_time )
         || (vm.showObject.extra_info.adam_do3 && !vm.showObject.extra_info.adam_do3_time )
         || (vm.showObject.source.type === 'FC_SENSEPASS' && vm.showObject.extra_info.adam_do4 && !vm.showObject.extra_info.camera_config )
         )
      ) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      if(/\s/.test(vm.showObject.extra_info.substream) || /[\\"']/g.test(vm.showObject.extra_info.substream)){
        vm.$toastr.i(vm.$i18n.t('message.task_formatStream_error'));       
        return;
      }
      
      if(vm.showObject.extra_info.adam_use !== 'yes') {
        delete vm.showObject.extra_info.adam_config;
        delete vm.showObject.extra_info.device_ip;
        delete vm.showObject.extra_info.adam_do1;
        delete vm.showObject.extra_info.adam_do2;
        delete vm.showObject.extra_info.adam_do3;
        delete vm.showObject.extra_info.adam_do1_time;
        delete vm.showObject.extra_info.adam_do2_time;
        delete vm.showObject.extra_info.adam_do3_time;
        delete vm.showObject.extra_info.adam_do4;
      }

      if(vm.showObject.extra_info.adam_elevator_use !== 'yes') {
        delete vm.showObject.extra_info.adam_do_time;
        if (vm.showObject.source.type === 'FC_SENSEPASS') {
          delete vm.showObject.extra_info.camera_config;
        }
      }

      // MIN_SCORE will be used by uploadCaptureResult
      vm.showObject.extra_info.min_score = String(vm.showObject.task.parameter.face.min_score);

      vm.showObject.extra_info.task_version = parseInt(vm.showObject.extra_info.task_version) + 1;
      vm.showObject.extra_info.task_version = String(vm.showObject.extra_info.task_version)

      if (vm.showObject.task_id) {
        if (vm.showObject.source.type === 'FC_SENSEPASS') {
          api.taskUpdateAcs(vm.showObject).then(() => {
            vm.showModal = false;
            vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
          });
        } else {
          api.taskUpdateMps(vm.showObject).then(() => {
            vm.showModal = false;
            vm.showRoiDialog = false;
            vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
            vm.dataTableMps.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
          });
        }
      } else {
        if (vm.showObject.source.type === 'FC_SENSEPASS') {
          api.taskNewAcs(vm.showObject).then(() => {
            vm.showModal = false;
            vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
          });
        } else {
          api.taskNewMps(vm.showObject).then(() => {
            vm.showModal = false;
            vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
            vm.dataTableMps.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
          });
        }
      }
    },
    async importTasks() {
      const vm = this;
      vm.$emit('loading', true);

      // get dataList and taskList based on the position
      let dataList;
      let taskList;

      if(vm.position == 'Top') {
        dataList = vm.dataTableMps.data();
        taskList  = vm.tableList_Top;
      } else {
        dataList = vm.dataTableAcs.data()
        taskList  = vm.tableList_Bottom;
      }

      // only import task list that has the existing libraries
      for (let taskListLibrary of taskList.libraries) {
        let flagLib = false;
        for (let vmLibrary of vm.libraries) {
          if (taskListLibrary.name === vmLibrary.name) {
            flagLib = true;
            break;
          }
        }

        if(!flagLib){
          await api.dBNew(taskListLibrary).then(res => {  
            vm.libraries.push(res.data); 
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
          });
        }
      }
      
      if(taskList.tasks.length >0) {
        for(let task of taskList.tasks){
          let flag = true;

          if (!task.extra_info.task_name || !task.source.type || task.task.parameter.face.id_array.length < 1
              || task.task.parameter.face.min_score < 0 || task.task.parameter.face.min_score > 1
              || (task.source.type === 'FC_SENSEPASS' && !task.source.parameter.sensepass.device_sn)
              || (task.source.type === 'VN_RTSP' && !task.source.parameter.rtsp.url)) {
            vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
            return;
          }

          for(let i = 0; i < dataList.length; i++){
            if(dataList[i][0] === task.task_id){
              if (task.source.type === 'FC_SENSEPASS') {
                await api.taskUpdateAcs(task).then(() => {
                  vm.showTableModal = false;
                  vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
                }).catch(err => {
                  vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
                });
              } else {
                await api.taskUpdateMps(task).then(() => {
                  vm.showTableModal = false;
                  vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
                }).catch(err => {
                  vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
                });
              }
              flag = false;
              break;
            }
          }
          if(flag){
            let newIdArray = [];
            let oldIdArray = task.task.parameter.face.id_array;
            oldIdArray.forEach(itemId => {
              let itemName = '';

              for(let taskListLib of taskList.libraries) {
                if (taskListLib.id === itemId) {
                  itemName = taskListLib.name;
                  break;
                }
              }
              for(let vmLib of vm.libraries){
                if (vmLib.name === itemName) {
                  newIdArray.push(vmLib.id);
                  break;
                }
              }
            });
            
            task.task.parameter.face.id_array = newIdArray;
            if (task.source.type === 'FC_SENSEPASS') {
              await api.taskNewAcs(task).then(() => {
                vm.showTableModal = false;
                vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
              }).catch(err => {
                vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
              });
            } else {
              await api.taskNewMps(task).then(() => {
                vm.showTableModal = false;
                vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
              }).catch(err => {
                vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
              });
            }
          }
        }

        await api.dBList({}).then(res => {
          if (res.data.databases) {
            vm.libraries = res.data.databases;
          }
        }).catch(() => {
          vm.libraries = [];
        })
        vm.dataTableAcs.ajax.reload();
        vm.dataTableMps.ajax.reload();
      }
      vm.showTableModal = false;
      vm.$refs.file.value = null;
      vm.$emit('loading', false);
    },
    clearRoiStage() {
      const vm = this;
      vm.roiStageConfig = {width: 560, height: 315};
      vm.roiImageConfig = {x: 0, y: 0, image: null};
      vm.roiRectConfig = null;
      vm.roiTransformerConfig = null;
      vm.roiScaleRatio = 1;
    },
    async updateRoiStage(isRealtime) {
      const vm = this;
      vm.$emit('loading', true);
      let task_id = vm.showObject.task_id;
      let roi_data = vm.showObject.task.parameter.face.roi;
      let capture;
      if (isRealtime) {
        let rtsp = vm.showObject.source.parameter.rtsp.url;
        let res = await vm.$electron.ipcRenderer.invoke('readCapture', rtsp);
        capture = res.data;
      } else {
        let res = await api.getLatestCaptureResult(task_id).catch(() => {
          return '';
        });
        if (res) {
          capture = await api.downloadObject(res.panorama.url).catch(() => {
            return '';
          });
        }
      }

      if (!capture) {
        vm.$toastr.e(vm.$i18n.t('message.capture_no_result'));
        vm.$emit('loading', false);
        return;
      }

      const image = new window.Image();
      const fixWidth = 560;
      const minRectSize = 50;

      image.src = capture;
      image.onload = () => {
        vm.roiScaleRatio = fixWidth / image.width;
        vm.roiImageConfig.image = image;
        vm.roiImageConfig.width = fixWidth;
        vm.roiImageConfig.height = image.height * vm.roiScaleRatio;
        vm.roiStageConfig.width = fixWidth;
        vm.roiStageConfig.height = image.height * vm.roiScaleRatio;
        vm.roiRectConfig = {
          fill: 'green',
          opacity: 0.4,
          stroke: 'black',
          name: 'rect',
          draggable: false
        }

        if (roi_data && roi_data.vertices && roi_data.vertices.length >= 2) {
          let vertices = roi_data.vertices;
          vm.roiRectConfig.x = vertices[0].x * vm.roiScaleRatio;
          vm.roiRectConfig.y = vertices[0].y * vm.roiScaleRatio;
          vm.roiRectConfig.width = (vertices[1].x - vertices[0].x) * vm.roiScaleRatio;
          vm.roiRectConfig.height = (vertices[1].y - vertices[0].y) * vm.roiScaleRatio;
        } else {
          vm.roiRectConfig.x = 0;
          vm.roiRectConfig.y = 0;
          vm.roiRectConfig.width = fixWidth;
          vm.roiRectConfig.height = image.height * vm.roiScaleRatio;
        }
        const transformerNode = vm.$refs.transformer.getStage();
        const rectNode = vm.$refs.rectangle.getStage();
        transformerNode.attachTo(rectNode);
        vm.roiTransformerConfig = {
          rotateEnabled: false,
          boundBoxFunc: function(oldBoundBox, newBoundBox) {
            if (newBoundBox.x < 0) {
              newBoundBox.x = 0;
            }
            if (newBoundBox.y < 0) {
              newBoundBox.y = 0;
            }
            if (newBoundBox.x > vm.roiStageConfig.width - minRectSize) {
              newBoundBox.x = vm.roiStageConfig.width - minRectSize;
            }
            if (newBoundBox.y > vm.roiStageConfig.height - minRectSize) {
              newBoundBox.y = vm.roiStageConfig.height - minRectSize;
            }
            if (newBoundBox.width < minRectSize) {
              newBoundBox.width = minRectSize;
            }
            if (newBoundBox.height < minRectSize) {
              newBoundBox.height = minRectSize;
            }
            if (newBoundBox.x + newBoundBox.width > vm.roiStageConfig.width) {
              newBoundBox.width = vm.roiStageConfig.width - newBoundBox.x;
            }
            if (newBoundBox.y + newBoundBox.height > vm.roiStageConfig.height) {
              newBoundBox.height = vm.roiStageConfig.height - newBoundBox.y;
            }

            return newBoundBox;
          }
        }
      };
      vm.$emit('loading', false);
    },
    handleRectChange() {
      const vm = this;
      const rectNode = vm.$refs.rectangle.getStage();
      const imageWidth = Math.round(vm.roiImageConfig.width/vm.roiScaleRatio);
      const imageHeight = Math.round(vm.roiImageConfig.height/vm.roiScaleRatio);

      let realLx = Math.floor(Math.floor(rectNode.x())/vm.roiScaleRatio);
      if (realLx <= 4) {
        realLx = 0;
      }
      let realLy = Math.floor(Math.floor(rectNode.y())/vm.roiScaleRatio);
      if (realLy <= 4) {
        realLy = 0;
      }
      let realRx = Math.ceil(Math.ceil((rectNode.x() + rectNode.width()*rectNode.scaleX()))/vm.roiScaleRatio);
      if (realRx >= imageWidth - 4) {
        realRx = imageWidth;
      }
      let realRy = Math.ceil(Math.ceil((rectNode.y() + rectNode.height()*rectNode.scaleY()))/vm.roiScaleRatio);
      if (realRy >= imageHeight - 4) {
        realRy = imageHeight;
      }
      
      vm.showObject.task.parameter.face.roi = {
        vertices: [{x: realLx, y: realLy}, {x: realRx, y: realRy}]
      }
    },
    renderLibraries(id_array) {
      let ret = '';
      id_array.forEach(obj => {
        this.libraries.forEach(element => {
          if(obj === element.id){
            ret += '<span class="badge bg-light-blue">' + element.name + '</span>';
          }
        }) 
      });
      return ret;
    },
    download (data) {
      if (!data) {
          return;
      }
      const url = window.URL.createObjectURL(new Blob([data]));
      const link = document.createElement('a');
      link.style.display = 'none';
      link.href = url;
      link.setAttribute('download', `tasks_${this.device.name}_${this.device.type}_${this.device.address}.json`);

      document.body.appendChild(link);
      link.click();
    },
    loadTextFromFile(e){
      const vm = this;
      try{
        if(e.target.files[0] !== null){
          let reader = new FileReader()
          reader.readAsText(e.target.files[0], 'UTF-8')
          reader.onload = function (e) {
            let fileContent = e.target.result
            if(vm.position == 'Top'){
              vm.tableList_Top = JSON.parse(fileContent);
            }else if(vm.position == 'Bottom'){
              vm.tableList_Bottom = JSON.parse(fileContent);
            }
            vm.showTableModal = true;
          }
        }else{
          vm.$toastr.e(vm.$i18n.t('message.task_select_file'));
        }
      }catch(e){
        vm.$toastr.e(vm.$i18n.t('message.task_data_format'));
      }
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    this.initTimer();
  },
  filters: {
    formatDate(val){
      return moment(val).format('YYYY-MM-DD HH:mm:ss')
    },
  },
  beforeDestroy: function() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  },
  mounted: function() {
    const vm = this;
    api.dBList({}).then(res => {
      if (res.data.databases) {
        vm.libraries = res.data.databases;
      }
    }).catch(() => {
      vm.libraries = [];
    }).finally(() => {
      // ACS DEVICES
      vm.dataTableAcs = $('#acs-tasks').DataTable({
        paging: true,
        pageLength: 10,
        lengthChange: false,
        searching: false,
        ordering: false,
        responsive: true,
        info: true,
        autoWidth: true,
        serverSide: true,
        order: [],
        dom: 'Bfrtip',
        buttons: [
          {
            text: vm.$i18n.t('common.create'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {
              if((vm.dataTableMps.data().length*2 + (vm.dataTableAcs.data().length+1)) > 8){
                vm.$toastr.e(vm.$i18n.t('message.task_morethan_failure'));
                return;
              }
              vm.showObject = {
                source: {type: 'FC_SENSEPASS', parameter: {sensepass: {device_sn: ''}}},
                task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: 0.8, id_array: []}}},
                extra_info: {task_name: '', output_type: 'NONE', output_value: '', min_score: '', adam_config:'', adam_do1: '', 
                  adam_do2: '', adam_do3: '', adam_do4: '', adam_use: '', adam_do1_time: '', adam_do2_time: '', adam_do3_time: '', task_version: '0',
                  adam_elevator_use: 'no'}
              };
              vm.editable = true;
              vm.showModal = true;
            }
          },
          {
            text: vm.$i18n.t('common.export'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {   
              let libList = [];
              for(var i = 0;i < vm.libraries.length; i++){
                libList.push({
                  'id':vm.libraries[i].id,
                  'name':vm.libraries[i].name,
                  }
                )
              }
              let obj  = JSON.stringify({'tasks': vm.tableList_Bottom, 'libraries': libList}) 
              vm.download(obj);
            }
          },
          {
            text: vm.$i18n.t('common.import'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {
              vm.$refs.file.dispatchEvent(new MouseEvent('click'));
              vm.position = 'Bottom';
            }
          }
        ],
        columnDefs: [
          { 
            "width": "200px", 
            "targets": -1
          },
          {
            orderable: false,
            targets: [1, 5, -1]
          },
          {
            targets: [0],
            visible: false,
            searchable: false
          },
          {
            targets: 1,
            render: function(url, type, row) {
              return row[1].task_name;
            }
          },
          {
            targets: 2,
            render: function(url, type, row) {
              if(row[2] === 'FC_SENSEPASS'){
                return 'TABLET CAMERA';
              }else{
                return 'RTSP CAMERA';
              }
            }
          },
          {
            targets: 5,
            render: function(url, type, row) {
              return vm.renderLibraries(row[5]);
            }
          },
          {
            targets: -1,
            data: null,
            render: function() {
              return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;' 
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;' 
                      + vm.$i18n.t('common.delete') + '</a>'
                      ;
            },
          }
        ],
        ajax(data, callback) {
          api.taskListAcs({'page_request.offset': data.start, 'page_request.limit': data.length})
            .then(res => {
              let result = res.data;
              let records = {draw: new Date().getTime(), data: []};
              if (result.page_response.total >= 0) {
                records.recordsTotal = result.page_response.total;
                records.recordsFiltered = result.page_response.total;
                result.tasks.forEach(element => {
                  records.data.push([
                    element.task_id,
                    element.extra_info,
                    element.source.type,
                    element.source.parameter.sensepass.device_sn,
                    element.task.parameter.face.min_score,
                    element.task.parameter.face.id_array,
                    moment(element.create_time).format('YYYY-MM-DD HH:mm:ss'),
                    element.status.status]);
                });
                vm.tableList_Bottom  = result.tasks;
              }
              callback(records);
            }).catch(() => {
              callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
            });
        }
      });
      vm.dataTableAcs.on('click', '.detail', async function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        let res = await api.taskStatusAcs(rowData[0]);
        if (res.data && res.data.status.status) {
          rowData[7] = res.data.status.status;
          vm.dataTableAcs.draw();
        }
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {sensepass: {device_sn: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: rowData[4], id_array: rowData[5]}}},
          extra_info: rowData[1],
          create_time: rowData[6],
          status: {status: rowData[7]}
        };
        vm.editable = false;
        vm.showModal = true;
      });
      vm.dataTableAcs.on('click', '.edit', function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {sensepass: {device_sn: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: rowData[4], id_array: rowData[5]}}},
          extra_info: rowData[1],
        };
        vm.editable = true;
        vm.showModal = true;
      });
      vm.dataTableAcs.on('click', '.delete', function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        if (util.showConfirmDialog(vm.$i18n.t('message.item_delete_confirm')) === 0) {
          api.taskDeleteAcs(rowData[0]).then(() => {
            vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err.response.data.message);
          });
        }
      });
      // MPS DEVICES
      vm.dataTableMps = $('#mps-tasks').DataTable({
        paging: true,
        pageLength: 10,
        lengthChange: false,
        searching: false,
        ordering: false,
        responsive: true,
        info: true,
        autoWidth: true,
        serverSide: true,
        order: [],
        dom: 'Bfrtip',
        buttons: [
          {
            text: vm.$i18n.t('common.create'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {
              if(((vm.dataTableMps.data().length+1)*2 +vm.dataTableAcs.data().length) > 8){
                vm.$toastr.e(vm.$i18n.t('message.task_morethan_failure'));
                return;
              }
              vm.showObject = {
                source: {type: 'VN_RTSP', parameter: {rtsp: {url: ''}}},
                task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: 'VIDEO_TRACK_MODE_ENTER', min_score: 0.8, id_array: []}}},
                extra_info: {task_name: '', output_type: 'NONE', output_value: '', min_score: '', adam_config: '', adam_do1: '', 
                  adam_do2: '', adam_do3: '', adam_do4: '', adam_use: '', device_ip: '', adam_do1_time: '', adam_do2_time: '', adam_do3_time: '', task_version: '0',
                  adam_elevator_use: 'no'}
              };
              vm.clearRoiStage();
              vm.editable = true;
              vm.showModal = true;
            }
          },
          {
            text: vm.$i18n.t('common.export'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {   
              let libList = [];
              for(var i = 0;i < vm.libraries.length; i++){
                libList.push({
                  'id':vm.libraries[i].id,
                  'name':vm.libraries[i].name,
                  }
                )
              }
              let obj  = JSON.stringify({'tasks': vm.tableList_Top, 'libraries': libList}) 
              vm.download(obj);
            }
          },
          {
            text: vm.$i18n.t('common.import'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {
              vm.$refs.file.dispatchEvent(new MouseEvent('click'))
              vm.position = 'Top';
            }
          }
        ],
        columnDefs: [
          { 
            "width": "200px", 
            "targets": -1
          },
          {
            orderable: false,
            targets: [1, 5, -1]
          },
          {
            targets: [0, 3, 8, 9],
            visible: false,
            searchable: false
          },
          {
            targets: 1,
            render: function(url, type, row) {
              return row[1].task_name;
            }
          },
          {
            targets: 2,
            render: function(url, type, row) {
              if(row[2] === 'VN_RTSP'){
                return 'RTSP CAMERA';
              }else{
                return 'TABLET CAMERA';
              }
            }
          },
          {
            targets: 5,
            render: function(url, type, row) {
              return vm.renderLibraries(row[5]);
            }
          },
          {
            targets: -1,
            data: null,
            render: function() {
              return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;' 
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;' 
                      + vm.$i18n.t('common.delete') + '</a>';
            },
          }
        ],
        ajax(data, callback) {
          api.taskListMps({'page_request.offset': data.start, 'page_request.limit': data.length})
            .then(res => {
              let result = res.data;
              let records = {draw: new Date().getTime(), data: []};
              if (result.page_response.total >= 0) {
                records.recordsTotal = result.page_response.total;
                records.recordsFiltered = result.page_response.total;
                result.tasks.forEach(element => {
                  records.data.push([
                    element.task_id,
                    element.extra_info,
                    element.source.type,
                    element.source.parameter.rtsp.url,
                    element.task.parameter.face.min_score,
                    element.task.parameter.face.id_array,
                    moment(element.create_time).format('YYYY-MM-DD HH:mm:ss'),
                    element.status.status,
                    element.task.parameter.face.roi,
                    element.task.parameter.face.track_mode]);
                });
                vm.tableList_Top  = result.tasks;
              }
              callback(records);
            }).catch(() => {
              callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
            });
        }
      });
      vm.dataTableMps.on('click', '.detail', async function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        let res = await api.taskStatusMps(rowData[0]);
        if (res.data && res.data.status.status) {
          rowData[7] = res.data.status.status;
          vm.dataTableMps.draw();
        }
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
          extra_info: rowData[1],
          create_time: rowData[6],
          status: {status: rowData[7]}
        };
        vm.editable = false;
        vm.showModal = true;
      });
      vm.dataTableMps.on('click', '.edit', function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
          extra_info: rowData[1]
        };
        vm.editable = true;
        vm.showModal = true;
        vm.clearRoiStage();
        vm.updateRoiStage(true);
      });
      vm.dataTableMps.on('click', '.delete', function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        if (util.showConfirmDialog(vm.$i18n.t('message.item_delete_confirm')) === 0) {
          api.taskDeleteMps(rowData[0]).then(() => {
            vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
            vm.dataTableMps.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err.response.data.message);
          });
        }
      });
    });
  }
};
</script>
