<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.modal-form {
  margin-top: 15px;
}
.desc {
  margin-top: 20px;
}
.paddingStyle{
  padding: 0;
}
.marginLeft{
  margin: 0;
}
</style>

<template>
  <div class="wrapper">
    <pageHeader />
    <pageAside />
    <div class="content-wrapper">
      <section class="content">
        <div class="box box-default">
          <div class="box-header">
            <h4>{{ $t("task.mps") }}</h4>
          </div>
          <div class="box-body">
            <input
              type='file'
              ref='file'
              @change="loadTextFromFile"
              accept=".json"
              style="display:none"
            />
            <table
              id="mps-tasks"
              class="table table-bordered table-striped"
              width="100%"
            >
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.camera") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th></th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>

        <!--pageModal for checking, creating and editing a task-->
        <pageModal
          :show.sync="showModal"
          :footer="editable"
        >
          <!--header-->
          <div
            slot="header"
            v-if="showObject.json"
          >
            <span v-if="showObject.json.task_id && editable">{{ $t("common.edit") }} ({{ showObject.json.extra_info.task_name }})</span>
            <span v-if="showObject.json.task_id && !editable">{{ $t("common.detail") }} ({{ showObject.json.extra_info.task_name }}) </span>
            <span v-if="!showObject.json.task_id && editable">{{ $t("common.create") }} </span>
          </div>
          <!--body-->
          <div slot="body">
            <form class="form-horizontal">
              <div class="modal-form" v-if="showObject.json">
                <!-- task_name-->
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.name") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.json.extra_info.task_name" placeholder="" :disabled="!editable">
                  </div>
                </div>
                <!-- rtsp_url -->
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.url") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.json.source.parameter.rtsp.url" placeholder="CAMERA RTSP URL" :disabled="!editable">
                  </div>
                </div>

                <!-- task type -->
                <div class="form-group">
                  <label class="col-sm-3 control-label">
                    {{ $t("task.stype") }}
                  </label>
                  <div class="col-sm-9">
                    <select v-model="showObject.task_type" @change="changeTaskType" class="form-control" :disabled="showObject.json.task_id || showObject.json.extra_info.enable_crowd_elevator">
                      <option value="LINE">{{ $t("task.type_line") }}</option>
                      <option value="AREA">{{ $t("task.type_area") }}</option>
                    </select>
                  </div>
                </div>

                <!-- crowd elevator enable-->
                <div class="form-group">
                  <div class="col-xs-3"></div>
                  <div class="col-xs-9">
                    <input type="checkbox" v-model="showObject.json.extra_info.enable_crowd_elevator"  :disabled="!editable"  @change="updateCheckBox('enable_crowd_elevator')">
                    <label class="control-label">{{ $t("task.enable_crowd_elevator") }}</label>
                  </div>
                </div>
                <!-- crowd elevator setting: floor, camera_no -->
                <div v-if="showObject.json.extra_info.enable_crowd_elevator">
                  <div class="form-group">
                    <label class="col-xs-3 control-label">
                      {{ $t("task.floor") }}
                    </label>
                    <div class="col-xs-9">
                      <input type="number" min="1" :max="device.floors" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.extra_info.floor" :placeholder="$t('task.floor')" :disabled="!editable">
                    </div>
                  </div>

                  <div class="form-group">
                    <label class="col-xs-3 control-label">
                      {{ $t("task.camera_no") }}
                    </label>
                    <div class="col-xs-9">
                      <input type="number" min="1" :max="device.cameraNo" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.extra_info.camera_no" :placeholder="$t('task.camera_no')" :disabled="!editable">
                    </div>
                  </div>
                </div>

                <!-- adam config-->
                <div class="form-group" v-if="!showObject.json.extra_info.enable_crowd_elevator">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.adam_config") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.json.extra_info.adam_config" placeholder="ADAM装置のIP:PORT" :disabled="!editable">
                  </div>
                </div>

                <div class="form-group" v-if="showObject.task_type==='AREA' && !showObject.json.extra_info.enable_crowd_elevator">
                  <div class="col-xs-3">
                    &nbsp;
                  </div>
                  <div class="col-xs-9">
                    &nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="radio" name="adam_output" v-model="showObject.json.extra_info.adam_always_on" value="0" :disabled="!editable" @change="updateCheckBox('radio')">
                    <label class="control-label">{{ $t("task.adam_output") }}</label>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <input type="radio" name="adam_output" v-model="showObject.json.extra_info.adam_always_on" value="1" :disabled="!editable" @change="updateCheckBox('radio')">
                    <label class="control-label">{{ $t("task.adam_all_output_time") }}</label>
                  </div>
                  </div>
                <div class="form-group" v-if="!showObject.json.extra_info.enable_crowd_elevator">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.adam_output_time") }}
                  </label>
                  <div class="col-xs-9">
                    <div class="row marginLeft">
                      <div class="input-group" style="margin-top: 5px;">
                        <input type="number" min="1" max="180" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.extra_info.high_to_low_delay" placeholder="パルス出力時間" :disabled="!editable || showObject.json.extra_info.adam_always_on ==='1'">
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- LINE task-->
                <template v-if="showObject.task_type==='LINE'">
                  <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.task.parameter.crowd.segmentation.enable" :disabled="!editable">
                      <label class="control-label">{{ $t("task.regular") }}</label>
                    </div>
                  </div>
                  <div class="form-group" v-if="showObject.json.task.parameter.crowd.segmentation.enable">
                    <label class="col-sm-3 control-label">
                      {{ $t("task.regular_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="input-group">
                        <span class="input-group-addon">{{ $t("task.interval") }}</span>
                        <input type="number" min="1" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.task.parameter.crowd.segmentation.interval" placeholder="Interval seconds" :disabled="!editable">
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>
                  <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.task.parameter.crowd.intrusion.enable" :disabled="!editable">
                      <label class="control-label">{{ $t("task.intrusion") }}</label>
                    </div>
                  </div>
                  <div class="form-group" v-if="showObject.json.task.parameter.crowd.intrusion.enable">
                    <label class="col-sm-3 control-label">
                      {{ $t("task.intrusion_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="col-xs-7 paddingStyle">
                        <div class="input-group">
                          <span class="input-group-addon">{{ $t("task.intrusion_forward") }}</span>
                          <input type="number" min="0" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.task.parameter.crowd.intrusion.interests[0].count" placeholder="Forward threshold" :disabled="!editable">
                          <span class="input-group-addon">{{ $t("common.person") }}</span>
                        </div>
                        <div class="input-group" style="margin-top: 5px;">
                          <span class="input-group-addon">{{ $t("task.intrusion_reverse") }}</span>
                          <input type="number" min="0" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.task.parameter.crowd.intrusion.interests[1].count" placeholder="Reverse threshold" :disabled="!editable">
                          <span class="input-group-addon">{{ $t("common.person") }}</span>
                        </div>
                      </div>
                      <div class="col-xs-5 paddingStyle">
                        <div class="input-group">
                          <span class="input-group-addon"> {{ $t("task.adam_do") }} </span>
                          <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.json.extra_info_temp.interests_adam_do_in" placeholder="ADAM番号" :disabled="!editable">
                        </div>
                        <div class="input-group" style="margin-top: 5px;">
                          <span class="input-group-addon"> {{ $t("task.adam_do") }} </span>
                          <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.json.extra_info_temp.interests_adam_do_out" placeholder="ADAM番号" :disabled="!editable">
                        </div>
                      </div>
                    </div>
                  </div>

                  <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.extra_info_temp.line_trouble_enable" :disabled="!editable" @change="updateCheckBox('line_trouble')">
                      <label class="control-label">{{ $t("task.malfunction") }}</label>
                    </div>
                  </div>
                  <div class="form-group" v-if="showObject.json.extra_info_temp.line_trouble_enable">
                    <label class="col-xs-3 control-label">
                      {{ $t("task.malfunction_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="input-group">
                        <span class="input-group-addon"> {{ $t("task.adam_do") }} </span>
                        <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.json.extra_info_temp.line_adam_do" :disabled="!editable">
                      </div>
                    </div>
                  </div>
                  <div class="form-group" v-if="showObject.json.task.parameter.crowd.intrusion.enable || showObject.json.extra_info_temp.line_trouble_enable">
                    <div class="col-xs-3"></div>
                    <div class="col-xs-9">
                      <label class="control-label">{{ $t("task.do_relay") }}</label>
                    </div>
                  </div>
                  <div class="form-group" v-if="editable">
                    <hr>
                    <label class="col-xs-12 control-label" style="margin-bottom: 5px;">
                      <p class="text-center bold">{{ $t("task.line_config") }}</p>
                    </label>
                    <div class="col-xs-12 btn-group" style="margin-bottom: 5px;">
                      <a @click="updateLineStage" class="btn btn-info btn-xs pull-right">{{ $t("task.capture_from_rtsp") }}</a>
                    </div>
                    <div class="col-xs-12">
                      <v-stage ref="stage" :config="lineStageConfig">
                        <v-layer ref="layer">
                          <v-image :config="lineImageConfig"/>
                          <v-line ref="line" :config="lineConfig"/>
                          <v-circle ref="lineStart" :config="lineStartConfig" @dragmove="updateLine(true)"/>
                          <v-circle ref="lineEnd" :config="lineEndConfig" @dragmove="updateLine(true)"/>
                          <v-arrow v-if="lineImageConfig.image" ref="arrow" :config="lineArrowConfig"/>
                        </v-layer>
                      </v-stage>
                      <div class="desc">
                        <p class="text-muted">
                          {{ $t("task.line_config_desc") }}
                        </p>
                      </div>
                    </div>
                  </div>
                </template>

                <!-- AREA task-->
                <template v-if="showObject.task_type==='AREA'">
                  <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.task.parameter.crowd.headcount.enable" :disabled="!editable || checkboxDis">
                      <label class="control-label">{{ $t("task.regular") }}</label>
                    </div>
                  </div>

                  <!-- headcount-->
                  <div class="form-group" v-if="showObject.json.task.parameter.crowd.headcount.enable">
                    <label class="col-sm-3 control-label">
                      {{ $t("task.regular_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="input-group">
                        <span class="input-group-addon">{{ $t("task.interval") }}</span>
                        <input type="number" min="1" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.task.parameter.crowd.headcount.interval" placeholder="Interval seconds" :disabled="!editable">
                        <span class="input-group-addon">{{ $t("common.second") }}</span>
                      </div>
                    </div>
                  </div>

                  <!-- adam retention setting-->
                  <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.task.parameter.crowd.retention.enable" :disabled="!editable || retentionCheckDisable" @change="resetSetLevel('retention')">
                      <label class="control-label">{{ $t("task.retention") }}</label>

                      <!-- buttons for adding or deleting levels-->
                      &nbsp;&nbsp;&nbsp;&nbsp;
                      <a class="btn btn-info btn-xs" v-if="!showObject.json.extra_info.enable_crowd_elevator && showObject.json.task.parameter.crowd.retention.enable && editable" @click="addSetLevel('retention')">追加</a>
                      <a class="btn btn-info btn-xs" v-if="!showObject.json.extra_info.enable_crowd_elevator && showObject.json.task.parameter.crowd.retention.enable && editable" @click="deleteSetLevel('retention')">削除</a>&nbsp;
                    </div>
                  </div>

                  <div class="form-group" v-if="showObject.json.task.parameter.crowd.retention.enable">
                    <label class="col-sm-3 control-label">
                      {{ $t("task.retention_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="row marginLeft">
                        <div class="input-group">
                          <span class="input-group-addon">{{ $t("task.retention_duration") }}</span>
                          <input type="number" min="0" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.task.parameter.crowd.retention.duration" placeholder="Duration seconds" :disabled="!editable">
                          <span class="input-group-addon">{{ $t("common.second") }}</span>
                        </div>
                      </div>
                      <div class="row marginLeft" v-for="(item, index) in retentionList" :key="index">
                        <div class="col-xs-7 paddingStyle">
                          <div class="input-group" style="margin-top: 5px;">
                            <span class="input-group-addon">{{ $t("task.retention_count") }}</span>
                            <input type="number" min="0" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.extra_info_temp['retention_count'+index]" placeholder="Retention count" :disabled="!editable">
                            <span class="input-group-addon">{{ $t("common.person") }}</span>
                          </div>
                        </div>

                        <div class="col-xs-5 paddingStyle">
                          <div class="input-group" style="margin-top: 5px;">
                            <span class="input-group-addon"> DO </span>
                            <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.json.extra_info_temp['retention_adam_do'+index]" placeholder="ADAM番号" :disabled="!editable || showObject.json.extra_info.enable_crowd_elevator">
                          </div>
                        </div>

                      </div>
                    </div>
                  </div>

                  <!-- adam density setting-->
                  <div class="form-group">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.task.parameter.crowd.density.enable" :disabled="!editable || densityCheckDisable"  @change="resetSetLevel('density')">
                      <label class="control-label">{{ $t("task.density") }}</label>

                      &nbsp;&nbsp;&nbsp;&nbsp;
                      <a class="btn btn-info btn-xs" v-if="!showObject.json.extra_info.enable_crowd_elevator && showObject.json.task.parameter.crowd.density.enable && editable" @click="addSetLevel('density')" :disabled="!editable">追加</a>
                      <a class="btn btn-info btn-xs" v-if="!showObject.json.extra_info.enable_crowd_elevator && showObject.json.task.parameter.crowd.density.enable && editable" @click="deleteSetLevel('density')" :disabled="!editable">削除</a>&nbsp;
                    </div>
                  </div>
                  <div class="form-group" v-if="showObject.json.task.parameter.crowd.density.enable">
                    <label class="col-sm-3 control-label">
                      {{ $t("task.density_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="row marginLeft">
                        <div class="input-group" style="margin-top: 5px;">
                          <span class="input-group-addon">{{ $t("task.density_interval") }}</span>
                          <input type="number" min="1" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.task.parameter.crowd.density.interval" placeholder="Alarm interval seconds" :disabled="!editable">
                          <span class="input-group-addon">{{ $t("common.second") }}</span>
                        </div>
                      </div>
                      <div class="row marginLeft" v-for="(item,index) in densityList" :key="index">
                        <div class="col-xs-7 paddingStyle">
                          <div class="input-group" style="margin-top: 5px;">
                            <span class="input-group-addon">{{ $t("task.density_count") }}</span>
                            <input type="number" min="1" oninput="validity.valid||(value='');" step="1" class="form-control" v-model="showObject.json.extra_info_temp['density_threshold'+index]" placeholder="Density count" :disabled="!editable">
                            <span class="input-group-addon">{{ $t("common.person") }}</span>
                          </div>
                        </div>
                        <div class="col-xs-5 paddingStyle">
                          <div class="input-group" style="margin-top: 5px;">
                            <span class="input-group-addon"> DO </span>
                            <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.json.extra_info_temp['density_adam_do'+index]" placeholder="ADAM番号" :disabled="!editable || showObject.json.extra_info.enable_crowd_elevator">
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <!-- adam malfunction-->
                  <div class="form-group" v-if="!showObject.json.extra_info.enable_crowd_elevator">
                    <div class="col-sm-3"></div>
                    <div class="col-sm-9">
                      <input type="checkbox" v-model="showObject.json.extra_info_temp.area_trouble_enable" :disabled="!editable" @change="updateCheckBox(showObject.json.extra_info_temp.area_trouble_enable)">
                      <label class="control-label">{{ $t("task.malfunction") }}</label>
                    </div>
                  </div>

                  <div class="form-group" v-if="showObject.json.extra_info_temp.area_trouble_enable">
                    <label class="col-xs-3 control-label">
                      {{ $t("task.malfunction_config") }}
                    </label>
                    <div class="col-xs-9">
                      <div class="input-group">
                        <span class="input-group-addon"> {{ $t("task.adam_do") }} </span>
                        <input type="number" min="1" max="5" oninput="validity.valid||(value='');if(value.length > 1)value = value.slice(0, 1)" step="1" class="form-control" v-model="showObject.json.extra_info_temp.area_adam_do" :disabled="!editable">
                      </div>
                    </div>
                  </div>


                  <div class="form-group" v-if="!showObject.json.extra_info.enable_crowd_elevator && (showObject.json.task.parameter.crowd.retention.enable || showObject.json.task.parameter.crowd.density.enable || showObject.json.extra_info_temp.area_trouble_enable)">
                    <div class="col-xs-3"></div>
                    <div class="col-xs-9">
                      <label class="control-label">{{ $t("task.do_relay") }}</label>
                    </div>
                  </div>

                  <div class="form-group" v-if="editable">
                    <hr>
                    <label class="col-xs-12 control-label" style="margin-bottom: 5px;">
                      <p class="text-center bold">{{ $t("task.area_config") }}</p>
                    </label>
                    <div class="col-xs-12 btn-group text-center" style="margin-bottom: 5px;">
                      <a @click="clearAreaPoints" class="btn btn-info btn-xs pull-left">{{ $t("task.clear_area_points") }}</a>
                      <a @click="updateAreaStage" class="btn btn-info btn-xs pull-right">{{ $t("task.capture_from_rtsp") }}</a>
                    </div>
                    <div class="col-xs-12">
                      <v-stage ref="stage" :config="areaStageConfig" @click="addAreaPoint">
                        <v-layer ref="layer">
                          <v-image :config="areaImageConfig"/>
                          <v-line ref="line" :config="areaConfig"/>
                          <v-circle v-for="(itemConfig, index) in areaPointsConfig" :key="index" :config="itemConfig"/>
                        </v-layer>
                      </v-stage>
                      <div class="desc">
                        <p class="text-muted">
                          {{ $t("task.area_config_desc") }}
                        </p>
                      </div>
                    </div>
                  </div>
                </template>

                <!-- status-->
                <div class="form-group" v-if="showObject.json.task_id && !editable">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.status") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" :value="showObject.status" disabled>
                  </div>
                </div>

                <!-- created time -->
                <div class="form-group" v-if="showObject.json.task_id && !editable">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.created") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" :value="showObject.create_time" disabled>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <!--footer-->
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showModal=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="updateTask">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>


        <!-- pageModal for importing and exporting-->
        <pageModal :show.sync="showTableModal" :footer="true" :modalclass="'modal-lg'">
          <div slot="header">
            {{ $t("common.import") }}
          </div>
          <div slot="body">
            <table class="table table-bordered table-striped">
                    <tr>
                      <th>{{ $t("task.name") }}</th>
                      <th>{{ $t("task.stype") }}</th>
                      <th>{{ $t("task.camera") }}</th>
                      <th>{{ $t("task.created") }}</th>
                    </tr>
                    <tr v-for="(item, index) in tableList.tasks" :key="index">
                      <td>{{item.extra_info.task_name}}</td>
                      <td>{{item.task.parameter.crowd.parameter.line ? 'LINE' : 'AREA'}}</td>
                      <td>{{item.source.parameter.rtsp.url | formatUrl}}</td>
                      <td>{{item.create_time | formatDate}}</td>
                    </tr>
                  </table>
          </div>
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showTableModal=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="importTasks">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>


      </section>
    </div>
  </div>
</template>
<script>
import * as moment from 'moment';
import * as util from '../assets/js/util';
import api from '../api/api';

import header from '../components/header';
import aside from '../components/aside';
import footer from '../components/footer';
import modal from '../components/modal';

export default {
  components: {
    pageHeader: header,
    pageAside: aside,
    pageFooter: footer,
    pageModal: modal
  },
  filters: {
    formatDate(val) {
      return moment(val).format('YYYY-MM-DD HH:mm:ss')
    },
    formatUrl(val) {
      let s = val.indexOf('@') !== -1 ? (val.indexOf('@') + 1) : 7;
      let e = val.indexOf(':', s) !== -1 ? val.indexOf(':', s) : val.indexOf('/', s);
      const camera = val.substring(s, e !== -1 ? e : val.length);
      return camera;
    },
  },
  data() {
    return {
      user: this.$root.userData,
      device: this.$root.deviceData,
      showModal: false,
      showTableModal: false,
      showObject: {},
      lineStageConfig: {width: 560, height: 315},
      lineImageConfig: {x: 0, y: 0, image: null},
      lineConfig: {stroke: 'red', strokeWidth: 8, points: [], draggable: false},
      lineStartConfig: {x: 0, y: 0, radius: 10, fill: 'green', draggable: true},
      lineEndConfig: {x: 560, y: 315, radius: 10, fill: 'green', draggable: true},
      lineArrowConfig: {fill: 'yellow', stroke: 'yellow', strokeWidth: 15, points: [], draggable: false},
      lineScaleRatio: 1,
      areaStageConfig: {width: 560, height: 315},
      areaImageConfig: {x: 0, y: 0, image: null},
      areaConfig: {stroke: 'red', strokeWidth: 5, fill: 'green', opacity: 0.4, points: [], draggable: false, closed: true},
      areaPointsConfig: [],
      areaScaleRatio: 1,
      editable: false,
      dataTableMps: null,
      taskList: [],
      tableList: [],
      timer: null,
      file: null,
      retentionList: [],
      densityList: [],
      retentionCheckDisable: false,
      densityCheckDisable: false,
      checkboxDis:false
    }
  },
  created() {
    if (!this.user) {
      this.$router.push({ path: '/login' });
    }
    this.initTimer();
  },
  beforeDestroy() {
    if (this.timer) {
      clearInterval(this.timer);
    }
  },
  mounted() {
    let vm = this;

    // MPS DEVICES
    vm.dataTableMps = $('#mps-tasks').DataTable({
      paging: true,
      pageLength: 10,
      lengthChange: false,
      searching: false,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [],
      dom: 'Bfrtip',
      buttons: [
        {
          text: vm.$i18n.t('common.create'),
          className: 'btn btn-primary',
          init(api, node) {
            $(node).removeClass('dt-button');
          },
          action() {
            if((vm.dataTableMps.data().length+1)*2 > 8){
              vm.$toastr.e(vm.$i18n.t('message.task_morethan_failure'));
              return;
            }
            vm.retentionList = [''];
            vm.densityList = [''];
            vm.showObject = {
              task_type: 'LINE',
              json: {
                source: {
                  type: 'VN_RTSP',
                  parameter: {rtsp: {url: ''}}
                },
                task: {
                  type: 'TASK_TYPE_CROWD',
                  parameter: {
                    crowd: {
                      parameter: {
                        polygon: {
                          vertices: []
                        },
                        line: {
                          vertices: []
                        },
                        area: 1
                      },
                      segmentation: {
                        enable: true,
                        interval: 1
                      },
                      intrusion: {
                        enable: false,
                        interests: [{
                          direction: 'FORWARD',
                          count: 0
                        }, {
                          direction: 'REVERSE',
                          count: 0
                        }]
                      },
                      headcount: {
                        enable: false,
                        interval: 1
                      },
                      retention: {
                        enable: false,
                        duration: 60,
                        count: 1
                      },
                      density: {
                        enable: false,
                        threshold: 1,
                        interval: 60
                      }
                    }
                  }
                },
                extra_info: {
                  task_name: '',
                  high_to_low_delay: '',
                  adam_always_on:'0',
                  task_version:'0',
                  retention_duration:'0',
                  density_interval:'0',

                  enable_crowd_elevator: false,
                  floor: '',
                  camera_no: ''
                },
                extra_info_temp: {
                  interests_adam_do_in:'',
                  interests_adam_do_out:'',
                  line_adam_do:'',
                  line_trouble_enable: false,
                  area_adam_do:'',
                  area_trouble_enable: false,
                  retention_count0:'',
                  retention_count1:'',
                  retention_count2:'',
                  retention_count3:'',
                  retention_adam_do0:'',
                  retention_adam_do1:'',
                  retention_adam_do2:'',
                  retention_adam_do3:'',
                  density_threshold0:'',
                  density_threshold1:'',
                  density_threshold2:'',
                  density_threshold3:'',
                  density_adam_do0:'',
                  density_adam_do1:'',
                  density_adam_do2:'',
                  density_adam_do3:''

                }
              }
            };
            vm.clearLineStage();
            vm.clearAreaStage();
            vm.editable = true;
            vm.showModal = true;
          }
        },
        {
          text: vm.$i18n.t('common.export'),
          className: 'btn btn-primary',
          init(api, node) {
            $(node).removeClass('dt-button');
          },
          action() {
            let obj  = JSON.stringify({'tasks': vm.taskList, 'libraries': []})
            vm.download(obj);
          }
        },
        {
          text: vm.$i18n.t('common.import'),
          className: 'btn btn-primary',
          init(api, node) {
            $(node).removeClass('dt-button');
          },
          action() {
            vm.$refs.file.dispatchEvent(new MouseEvent('click'))
          }
        }
      ],
      columnDefs: [
        {
          "width": "200px",
          "targets": -1
        },
        {
          targets: [0, 6],
          visible: false
        },
        {
          targets: 1,
          render(url, type, row) {
            return row[1] ? row[1] : 'UNKNOWN';
          }
        },
        {
          targets: 2,
          render(url, type, row) {
            return row[2] === 'LINE' ? vm.$i18n.t('task.type_line') : vm.$i18n.t('task.type_area');
          }
        },
        {
          targets: -1,
          data: null,
          render() {
            return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;'
                    + vm.$i18n.t('common.detail') + '</a>'
                    + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;'
                    + vm.$i18n.t('common.edit') + '</a>'
                    + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                    + vm.$i18n.t('common.delete') + '</a>';
          },
        }
      ],
      ajax(data, callback) {
        api.taskListMps({'page_request.offset': data.start, 'page_request.limit': data.length})
          .then(res => {
            let result = res.data;
            let records = {draw: new Date().getTime(), data: []};
            if (result.page_response.total >= 0) {
              records.recordsTotal = result.page_response.total;
              records.recordsFiltered = result.page_response.total;
              result.tasks.forEach(element => {
                let rtsp = element.source.parameter.rtsp.url;
                // Get camera ip
                let s = rtsp.indexOf('@') !== -1 ? (rtsp.indexOf('@') + 1) : 7;
                let e = rtsp.indexOf(':', s) !== -1 ? rtsp.indexOf(':', s) : rtsp.indexOf('/', s);
                let camera = rtsp.substring(s, e !==-1 ? e : rtsp.length);
                let task_type = element.task.parameter.crowd.parameter.line ? 'LINE' : 'AREA';
                if (task_type === 'LINE') {
                  if (!element.task.parameter.crowd.segmentation) {
                    element.task.parameter.crowd.segmentation = {
                      enable: false,
                      interval: 1
                    };
                  }
                  if (!element.task.parameter.crowd.intrusion) {
                    element.task.parameter.crowd.intrusion = {
                      enable: false,
                      interests: [{
                        direction: 'FORWARD',
                        count: 0
                      }, {
                        direction: 'REVERSE',
                        count: 0
                      }]
                    };
                  }
                } else {
                  if (!element.task.parameter.crowd.headcount) {
                    element.task.parameter.crowd.headcount = {
                      enable: false,
                      interval: 1
                    };
                  }
                  if (!element.task.parameter.crowd.retention) {
                    element.task.parameter.crowd.retention = {
                      enable: false,
                      duration: 60,
                      count: 1
                    };
                  }
                  if (!element.task.parameter.crowd.density) {
                    element.task.parameter.crowd.density = {
                      enable: false,
                      threshold: 1,
                      interval: 60
                    };
                  } else {
                    //let area_square = element.task.parameter.crowd.parameter.area;
                    let area_threshold = element.task.parameter.crowd.density.threshold;
                    element.task.parameter.crowd.density.threshold = Number(area_threshold) + 0.1;
                  }
                }
                records.data.push([
                  element.task_id,
                  element.extra_info.task_name,
                  task_type,
                  camera,
                  moment(element.create_time).format('YYYY-MM-DD HH:mm:ss'),
                  element.status.status,
                  element,
                  element.extra_info.enable_crowd_elevator
                  ]);
              });
              vm.taskList =  result.tasks
            }
            callback(records);
          }).catch(() => {
            callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
          });
      }
    });
    vm.dataTableMps.on('click', '.detail', async function() {
      let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      let res = await api.taskStatusMps(rowData[0]);
      if (res.data && res.data.status.status) {
        rowData[5] = res.data.status.status;
        vm.dataTableMps.draw();
      }
      vm.showObject = {
        task_id: rowData[0],
        task_type: rowData[2],
        json: rowData[6],
        create_time: rowData[4],
        status: rowData[5]
      };

      if(rowData[7] === 'false') {
        vm.showObject.json.extra_info.enable_crowd_elevator = false;
      }
      if(rowData[7] === 'true') {
        vm.showObject.json.extra_info.enable_crowd_elevator = true;
      }

      vm.showObject.json.extra_info_temp = {};
      if(rowData[2] === 'LINE'){
        if(rowData[6].task.parameter.crowd.intrusion){
          if(rowData[6].extra_info.adam_forward && rowData[6].extra_info.adam_reverse){
            let arr_forward = rowData[6].extra_info.adam_forward.split(',');
            let arr_reverse = rowData[6].extra_info.adam_reverse.split(',');
            vm.showObject.json.extra_info_temp.interests_adam_do_in = arr_forward[1];
            vm.showObject.json.extra_info_temp.interests_adam_do_out = arr_reverse[1];
          }
        }
        if(rowData[6].extra_info.malfunction_enable){
          vm.showObject.json.extra_info_temp.line_trouble_enable = Boolean(rowData[6].extra_info.malfunction_enable)
          if(rowData[6].extra_info.malfunction){
            let arr_malfunction = rowData[6].extra_info.malfunction.split(',');
            vm.showObject.json.extra_info_temp.line_adam_do = arr_malfunction[0];
          }
        }
      }else {
        vm.retentionList = [];
        vm.densityList = [];
        if(rowData[6].task.parameter.crowd.retention.enable){
          for(let i = 0; i < 5; i++){
            if(rowData[6].extra_info['retention_'+i] !== undefined) {
              vm.retentionList.push('');
              let arr_retention = rowData[6].extra_info['retention_'+i].split(',');
              vm.showObject.json.extra_info_temp['retention_count'+i] = arr_retention[0];
              vm.showObject.json.extra_info_temp['retention_adam_do'+i] = arr_retention[1];
            }
          }
        }
        if(rowData[6].task.parameter.crowd.density.enable){
          for(let i = 0; i < 5; i++){
            if(rowData[6].extra_info['density_'+i] !== undefined) {
              vm.densityList.push('');
              let arr_retention = rowData[6].extra_info['density_'+i].split(',');
              vm.showObject.json.extra_info_temp['density_threshold'+i] = arr_retention[0];
              vm.showObject.json.extra_info_temp['density_adam_do'+i] = arr_retention[1];
            }
          }
        }
        if(rowData[6].extra_info.malfunction_enable){
          vm.showObject.json.extra_info_temp.area_trouble_enable = Boolean(rowData[6].extra_info.malfunction_enable);
          if(rowData[6].extra_info.malfunction){
            let arr_malfunction = rowData[6].extra_info.malfunction.split(',');
            vm.showObject.json.extra_info_temp.area_adam_do = arr_malfunction[0];
          }
          vm.$forceUpdate();
        }
        vm.showObject.json.extra_info.adam_always_on = (rowData[6].extra_info.adam_always_on? rowData[6].extra_info.adam_always_on:'0');
      }

      vm.editable = false;
      vm.showModal = true;
    });
    vm.dataTableMps.on('click', '.edit', function() {
      let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      vm.showObject = {
        task_id: rowData[0],
        task_type: rowData[2],
        json: util.deepcopy(rowData[6])
      };

      if(rowData[7] === 'false') {
        vm.showObject.json.extra_info.enable_crowd_elevator = false;
      }
      if(rowData[7] === 'true') {
        vm.showObject.json.extra_info.enable_crowd_elevator = true;
      }

      vm.showObject.json.extra_info_temp = {};
      if(rowData[2] === 'LINE'){
        if(rowData[6].task.parameter.crowd.intrusion){
          if(rowData[6].extra_info.adam_forward && rowData[6].extra_info.adam_reverse){
            let arr_forward = rowData[6].extra_info.adam_forward.split(',');
            let arr_reverse = rowData[6].extra_info.adam_reverse.split(',');
            vm.showObject.json.extra_info_temp.interests_adam_do_in = arr_forward[1];
            vm.showObject.json.extra_info_temp.interests_adam_do_out = arr_reverse[1];
          }else{
            vm.showObject.json.extra_info_temp.interests_adam_do_in = '';
            vm.showObject.json.extra_info_temp.interests_adam_do_out = '';
          }
        }
        if(rowData[6].extra_info.malfunction_enable){
          vm.showObject.json.extra_info_temp.line_trouble_enable = Boolean(rowData[6].extra_info.malfunction_enable)
          if(rowData[6].extra_info.malfunction){
            let arr_malfunction = rowData[6].extra_info.malfunction.split(',');
            vm.showObject.json.extra_info_temp.line_adam_do = arr_malfunction[0];
          }else{
            vm.showObject.json.extra_info_temp.line_adam_do = '';
          }
        }else{
          vm.showObject.json.extra_info_temp['line_trouble_enable'] = false;
        }
      }else {
        vm.retentionList = [];
        vm.densityList = [];
        if(rowData[6].task.parameter.crowd.retention.enable){
          for(let i = 0; i < 5; i++){
            if(rowData[6].extra_info['retention_'+i] !== undefined) {
              vm.retentionList.push('');
              let arr_retention = rowData[6].extra_info['retention_'+i].split(',');
              vm.showObject.json.extra_info_temp['retention_count'+i] = arr_retention[0];
              vm.showObject.json.extra_info_temp['retention_adam_do'+i] = arr_retention[1];
            }else{
              vm.showObject.json.extra_info_temp['retention_count'+i] = '';
              vm.showObject.json.extra_info_temp['retention_adam_do'+i] = '';
            }
          }
          if(vm.retentionList.length === 5){
            vm.densityCheckDisable = true;
          }
        }else{
          vm.retentionList.push('');
        }
        if(rowData[6].task.parameter.crowd.density.enable){
          for(let i = 0; i < 5; i++){
            if(rowData[6].extra_info['density_'+i] !== undefined) {
              vm.densityList.push('');
              let arr_retention = rowData[6].extra_info['density_'+i].split(',');
              vm.showObject.json.extra_info_temp['density_threshold'+i] = arr_retention[0];
              vm.showObject.json.extra_info_temp['density_adam_do'+i] = arr_retention[1];
            }else{
              vm.showObject.json.extra_info_temp['density_threshold'+i] = '';
              vm.showObject.json.extra_info_temp['density_adam_do'+i] = '';
            }
          }
          if(vm.densityList.length === 5){
            vm.retentionCheckDisable = true;
          }
        }else{
          vm.densityList.push('');
        }
        if(rowData[6].extra_info.malfunction_enable){
          vm.showObject.json.extra_info_temp.area_trouble_enable = Boolean(rowData[6].extra_info.malfunction_enable)
          if(rowData[6].extra_info.malfunction){
            let arr_malfunction = rowData[6].extra_info.malfunction.split(',');
            vm.showObject.json.extra_info_temp.area_adam_do = arr_malfunction[0];
          }else{
            vm.showObject.json.extra_info_temp.area_adam_do = '';
          }
        }else{
          vm.showObject.json.extra_info_temp['area_trouble_enable'] = false;
        }
        vm.showObject.json.extra_info.adam_always_on = (rowData[6].extra_info.adam_always_on? rowData[6].extra_info.adam_always_on:'0');
      }

      vm.editable = true;
      vm.showModal = true;
      if (rowData[2] === 'LINE') {
        vm.clearLineStage();
        vm.updateLineStage();
      } else {
        vm.clearAreaStage();
        vm.updateAreaStage();
      }
    });
    vm.dataTableMps.on('click', '.delete', function() {
      let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      if (util.showConfirmDialog(vm.$i18n.t('message.item_delete_confirm')) === 0) {
        api.taskDeleteMps(rowData[0]).then(() => {
          vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
          vm.dataTableMps.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err.response.data.message);
        });
      }
    });
  },
  methods: {
    updateCheckBox(value){
      if(value === 'radio'){
        this.showObject.json.extra_info.high_to_low_delay = '';
      }
      if(value === 'line_trouble'){
        this.showObject.json.extra_info_temp.line_adam_do = '';
      }
      if(value === 'area_trouble'){
        this.showObject.json.extra_info_temp.area_adam_do = '';
      }
      // if enable_crowd_elevator, set the current task type to 'AREA'
      if(value === 'enable_crowd_elevator') {
        if (this.showObject.json.extra_info.enable_crowd_elevator) {
          this.showObject.task_type = 'AREA';

          this.showObject.json.task.parameter.crowd.headcount.enable = true
          this.checkboxDis  = true
        }else{
          this.showObject.json.task.parameter.crowd.headcount.enable = false
          this.checkboxDis  = false
        }
      }
      this.$forceUpdate();
    },
    resetSetLevel(value){
      if(value === 'retention'){
        for(let i =0;i<this.retentionList.length; i++){
          this.showObject.json.extra_info_temp['retention_count'+i] = '';
          this.showObject.json.extra_info_temp['retention_adam_do'+i] = '';
        }
        this.retentionList = [''];
        this.densityCheckDisable = false;
      }else{
        for(let i =0;i<this.densityList.length; i++){
          this.showObject.json.extra_info_temp['density_threshold'+i] = '';
          this.showObject.json.extra_info_temp['density_adam_do'+i] = '';
        }
        this.densityList = [''];
        this.retentionCheckDisable = false;
      }
    },
    addSetLevel(value){
      if(value === 'retention'){
        if(this.showObject.json.task.parameter.crowd.density.enable) {
          if(this.retentionList.length + this.densityList.length <4){
            this.retentionList.push('');
          }
        }else{
          if(this.retentionList.length < 4){
            this.retentionList.push('');
          }
          if(this.retentionList.length === 4){
            this.showObject.json.task.parameter.crowd.density.enable = false;
            this.densityCheckDisable = true;
          }
        }
      }else{
        if(this.showObject.json.task.parameter.crowd.retention.enable) {
          if(this.retentionList.length + this.densityList.length <4){
            this.densityList.push('');
          }
        }else{
          if(this.densityList.length < 4){
            this.densityList.push('');
          }
          if(this.densityList.length === 4){
            this.showObject.json.task.parameter.crowd.retention.enable = false;
            this.retentionCheckDisable = true;
          }
        }
      }
    },
    deleteSetLevel(value){
      if(value === 'retention'){
        if(this.retentionList.length === 4){
          this.densityCheckDisable = false;
        }
        if(this.retentionList.length > 1){
          this.retentionList.pop();
          let retentionLength = this.retentionList.length;
          this.showObject.json.extra_info_temp['retention_count'+retentionLength] = '';
          this.showObject.json.extra_info_temp['retention_adam_do'+retentionLength] = '';
        }
      }else{
        if(this.densityList.length === 4){
          this.retentionCheckDisable = false;
        }
        if(this.densityList.length > 1){
          this.densityList.pop();
          let densityLength = this.densityList.length;
          this.showObject.json.extra_info_temp['density_threshold'+densityLength] = '';
          this.showObject.json.extra_info_temp['density_adam_do'+densityLength] = '';
        }
      }
    },
    initTimer() {
      this.timer = setInterval(() => {
        let tasksMps = this.dataTableMps ? this.dataTableMps.data() : [];
        if (tasksMps.length > 0) {
          let refresh = false;
          for (let i = 0; i < tasksMps.length; i++) {
            if (tasksMps[i][5] === 'PENDING') {
              refresh = true;
              break;
            }
          }
          if (refresh) {
            this.dataTableMps.ajax.reload();
          }
        }
      }, 3000);
    },
    updateTask() {
      const vm = this;

      // check if task_name or rtsp url is empty
      if (!vm.showObject.json || !vm.showObject.json.extra_info.task_name
          || !vm.showObject.json.source.parameter.rtsp.url) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      const params = util.deepcopy(vm.showObject.json);
      params.extra_info = {};
      params.extra_info.task_name = vm.showObject.json.extra_info.task_name;
      params.extra_info.adam_config = vm.showObject.json.extra_info.adam_config;

      // crowd_elevator settings
      params.extra_info.floor = vm.showObject.json.extra_info.floor;
      params.extra_info.camera_no = vm.showObject.json.extra_info.camera_no;
      params.extra_info.enable_crowd_elevator = String(vm.showObject.json.extra_info.enable_crowd_elevator);

      // floor and camera_no check
      if (vm.showObject.json.extra_info.enable_crowd_elevator) {
        if (!String(vm.showObject.json.extra_info.floor) || !String(vm.showObject.json.extra_info.camera_no)) {
          vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
          return;
        }
      }

      if (vm.showObject.task_type === 'LINE' && !vm.showObject.json.extra_info.enable_crowd_elevator) {
        params.task.parameter.crowd = {
          parameter: {
            line: vm.showObject.json.task.parameter.crowd.parameter.line
          }
        };
        if (vm.showObject.json.task.parameter.crowd.segmentation.enable) {
          params.task.parameter.crowd.segmentation = vm.showObject.json.task.parameter.crowd.segmentation;
        }

        // validate if intrusion input elements are empty
        const intrusionInputsEmpty = (vm.showObject.json.task.parameter.crowd.intrusion.enable &&
            (  !String(vm.showObject.json.task.parameter.crowd.intrusion.interests[0].count)
                || !String(vm.showObject.json.task.parameter.crowd.intrusion.interests[1].count)
                || !String(vm.showObject.json.extra_info_temp.interests_adam_do_in)
                || !String(vm.showObject.json.extra_info_temp.interests_adam_do_out)
                || !vm.showObject.json.extra_info.adam_config)) ||

            (vm.showObject.json.extra_info_temp.line_trouble_enable &&
                (!String(vm.showObject.json.extra_info_temp.line_adam_do)
                    ||!vm.showObject.json.extra_info.adam_config));
        if(!vm.showObject.json.extra_info.enable_crowd_elevator && intrusionInputsEmpty){
          vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
          return;
        }

        // high_to_low_delay is not empty when intrusion checkbox is checked
        const highToLowDelayEmpty = (vm.showObject.json.task.parameter.crowd.intrusion.enable ||
            vm.showObject.json.extra_info_temp.line_trouble_enable) && !vm.showObject.json.extra_info.high_to_low_delay;
        if(!vm.showObject.json.extra_info.enable_crowd_elevator && highToLowDelayEmpty) {
          vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
          return;
        }

        //combine intrusion parameters when intrusion checkbox is checked
        if (vm.showObject.json.task.parameter.crowd.intrusion.enable) {
          params.task.parameter.crowd.intrusion = vm.showObject.json.task.parameter.crowd.intrusion;
          params.extra_info.adam_forward = vm.showObject.json.task.parameter.crowd.intrusion.interests[0].count + ',' + vm.showObject.json.extra_info_temp.interests_adam_do_in;
          params.extra_info.adam_reverse = vm.showObject.json.task.parameter.crowd.intrusion.interests[1].count + ',' + vm.showObject.json.extra_info_temp.interests_adam_do_out;
        }

        //combine broken parameters when intrusion checkbox is checked
        if (vm.showObject.json.extra_info_temp.line_trouble_enable) {
          params.extra_info.malfunction_enable = String(vm.showObject.json.extra_info_temp.line_trouble_enable);
          params.extra_info.malfunction = String(vm.showObject.json.extra_info_temp.line_adam_do);
        }
      } else {

        // When enable_crowd_elevator task_type should only be AREA
        vm.showObject.task_type = 'AREA';

        // check polygon
        if (vm.showObject.json.task.parameter.crowd.parameter.polygon.vertices.length < 3) {
          vm.$toastr.i(vm.$i18n.t('message.task_area_failure'));
          return;
        }
        params.task.parameter.crowd = {
          parameter: {
            polygon: vm.showObject.json.task.parameter.crowd.parameter.polygon
          }
        };

        // headcount inputs are not empty when density checkbox is checked
        if (vm.showObject.json.task.parameter.crowd.headcount.enable) {
          params.task.parameter.crowd.headcount = vm.showObject.json.task.parameter.crowd.headcount;
        }

        // adam: retention inputs are not empty when retention checkbox is checked
        if(vm.showObject.json.task.parameter.crowd.retention.enable){
          let isInputEmpty = false;
          let isLevelDescending = false;
          for(let i = 0; i < vm.retentionList.length; i++){
            // check if empty
            const retentionThresholdEmpty = !String(vm.showObject.json.extra_info_temp['retention_count'+i]);
            const doEmpty = !String(vm.showObject.json.extra_info_temp['retention_adam_do'+i]);
            if(!vm.showObject.json.extra_info.enable_crowd_elevator && (retentionThresholdEmpty || doEmpty)){
              isInputEmpty = true;
              break;
            }
            if(vm.showObject.json.extra_info.enable_crowd_elevator && retentionThresholdEmpty) {
              isInputEmpty = true;
              break;
            }
            // set a fake do when enable_crowd_elevator
            // vm.showObject.json.extra_info_temp['retention_adam_do'+i] = 0;

            // prev level retention threshold < curr level retention threshold
            if(i < vm.retentionList.length - 1){
              if (Number(vm.showObject.json.extra_info_temp['retention_count'+i]) > Number(vm.showObject.json.extra_info_temp['retention_count'+(i+1)])){
                isLevelDescending = true;
                break;
              }
            }
            // combine retention parameters when retention checkbox is checked
            params.extra_info['retention_'+i] = vm.showObject.json.extra_info_temp['retention_count'+i] + ',' + vm.showObject.json.extra_info_temp['retention_adam_do'+i];
          }
          if(isInputEmpty){
            vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
            return;
          }
          if(isLevelDescending){
            vm.$toastr.i(vm.$i18n.t('message.common_level_input'));
            return;
          }
          params.task.parameter.crowd.retention = {
            enable: vm.showObject.json.task.parameter.crowd.retention.enable,
            duration: vm.showObject.json.task.parameter.crowd.retention.duration,
            count: vm.showObject.json.extra_info_temp['retention_count0']
          };
        }

        // adam density inputs are not empty when density checkbox is checked
        if(vm.showObject.json.task.parameter.crowd.density.enable){
          let isInputEmpty = false;
          let isLevelDescending = false;
          for(let i = 0; i < vm.densityList.length; i++){
            const densityThresholdEmpty = !String(vm.showObject.json.extra_info_temp['density_threshold'+i]);
            const doEmpty = !String(vm.showObject.json.extra_info_temp['density_adam_do'+i]);
            if(!vm.showObject.json.extra_info.enable_crowd_elevator && (densityThresholdEmpty || doEmpty)){
              isInputEmpty = true;
              break;
            }
            if (vm.showObject.json.extra_info.enable_crowd_elevator && densityThresholdEmpty) {
              isInputEmpty = true;
              break;
            }

            // set a fake do when enable_crowd_elevator
            // vm.showObject.json.extra_info_temp['density_adam_do'+i] = 0;

            //first level density input group < second level density input group and so on
            if(i < vm.densityList.length - 1){
              if (Number(vm.showObject.json.extra_info_temp['density_threshold'+i]) > Number(vm.showObject.json.extra_info_temp['density_threshold'+(i+1)])){
                isLevelDescending = true;
                break;
              }
            }
            //combine density parameters when retention checkbox is checked
            params.extra_info['density_'+i] = vm.showObject.json.extra_info_temp['density_threshold'+i] + ',' + vm.showObject.json.extra_info_temp['density_adam_do'+i];
          }
          if(isInputEmpty){
            vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
            return;
          }
          if(isLevelDescending){
            vm.$toastr.i(vm.$i18n.t('message.common_level_input'));
            return;
          }
          params.task.parameter.crowd.parameter.area = 1;
          params.task.parameter.crowd.density = {
            enable: vm.showObject.json.task.parameter.crowd.density.enable,
            threshold: Number(vm.showObject.json.extra_info_temp['density_threshold0']) -0.1,
            interval: vm.showObject.json.task.parameter.crowd.density.interval
          };
        }

        // adam: malfunction enable
        if (vm.showObject.json.extra_info_temp.area_trouble_enable){
          if(!String(vm.showObject.json.extra_info_temp.area_adam_do)){
            vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
            return;
          }
          params.extra_info.malfunction_enable = String(vm.showObject.json.extra_info_temp.area_trouble_enable);
          params.extra_info.malfunction = vm.showObject.json.extra_info_temp.area_adam_do;
        }
        params.extra_info.adam_always_on = vm.showObject.json.extra_info.adam_always_on;

        const highToLowDelayEmpty = ((vm.showObject.json.task.parameter.crowd.retention.enable ||
            vm.showObject.json.task.parameter.crowd.density.enable ||
            vm.showObject.json.extra_info_temp.area_trouble_enable) &&
            vm.showObject.json.extra_info.adam_always_on === '0' &&
            !vm.showObject.json.extra_info.high_to_low_delay);

        const adamConfigEmpty =  ((vm.showObject.json.task.parameter.crowd.retention.enable ||
            vm.showObject.json.task.parameter.crowd.density.enable ||
            vm.showObject.json.extra_info_temp.area_trouble_enable) &&
            !vm.showObject.json.extra_info.adam_config);

        if((highToLowDelayEmpty || adamConfigEmpty) && !vm.showObject.json.extra_info.enable_crowd_elevator) {
          vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
          return;
        }
      }
      params.extra_info.high_to_low_delay = String(vm.showObject.json.extra_info.high_to_low_delay);
      vm.showObject.json.extra_info.task_version = parseInt(vm.showObject.json.extra_info.task_version) + 1;
      params.extra_info.task_version = String(vm.showObject.json.extra_info.task_version)
      if (vm.showObject.json.task.parameter.crowd.retention && vm.showObject.json.task.parameter.crowd.retention.enable){
        params.extra_info.retention_duration = String(vm.showObject.json.task.parameter.crowd.retention.duration)
      } else {
        params.extra_info.retention_duration = '0'
      }
      if (vm.showObject.json.task.parameter.crowd.density && vm.showObject.json.task.parameter.crowd.density.enable){
        params.extra_info.density_interval = String(vm.showObject.json.task.parameter.crowd.density.interval)
      } else {
        params.extra_info.density_interval = '0'
      }
      delete params.extra_info_temp;
      // console.log(params);
      if (params.task_id) {
        api.taskUpdateMps(params).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
          vm.dataTableMps.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
        });
      } else {
        api.taskNewMps(params).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
          vm.dataTableMps.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
        });
      }
    },
    async importTasks() {
      const vm = this;
      vm.$emit('loading', true);
      if (vm.tableList.tasks.length >0) {
        const dataList = vm.dataTableMps.data();
        for(let n = 0; n< vm.tableList.tasks.length; n++){
          let flag = true;
          let task = vm.tableList.tasks[n];
          if (!task || !task.extra_info.task_name || !task.source.parameter.rtsp.url) {
              vm.$toastr.i('temp.extra_info.task_name'+vm.$i18n.t('message.common_empty_input'));
              continue;
          }
          for(let i = 0; i<dataList.length; i++){
            if(dataList[i][0] === task.task_id){
              await api.taskUpdateMps(task).then(() => {
              }).catch(err => {
                vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
              });
              flag = false;
              break;
            }
          }
          if(flag){
            await api.taskNewMps(task).then(() => {
            }).catch(err => {
              vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
            });
          }
        }
        vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
        vm.dataTableMps.ajax.reload();
      }
      vm.showTableModal = false;
      vm.$refs.file.value = null;
      vm.$emit('loading', false);
    },
    changeTaskType() {
      let vm = this;
      if (vm.showObject.task_type === 'LINE') {
        vm.showObject.json.task.parameter.crowd.parameter.polygon.vertices = [];
        vm.showObject.json.task.parameter.crowd.headcount.enable = false;
        vm.showObject.json.task.parameter.crowd.retention.enable = false;
        vm.showObject.json.task.parameter.crowd.density.enable = false;
        vm.clearAreaStage();
      } else {
        vm.showObject.json.task.parameter.crowd.parameter.line.vertices = [];
        vm.showObject.json.task.parameter.crowd.segmentation.enable = false;
        vm.showObject.json.task.parameter.crowd.intrusion.enable = false;
        vm.clearLineStage();
      }
    },
    updateLine(isDragmove) {
      let vm = this;
      let startNode = vm.$refs.lineStart.getStage();
      let endNode = vm.$refs.lineEnd.getStage();

      if (isDragmove) {
        if (startNode.x() < 0) {
          startNode.x(0);
        }
        if (startNode.x() > vm.lineStageConfig.width) {
          startNode.x(vm.lineStageConfig.width);
        }
        if (startNode.y() < 0) {
          startNode.y(0);
        }
        if (startNode.y() > vm.lineStageConfig.height) {
          startNode.y(vm.lineStageConfig.height);
        }
        if (endNode.x() < 0) {
          endNode.x(0);
        }
        if (endNode.x() > vm.lineStageConfig.width) {
          endNode.x(vm.lineStageConfig.width);
        }
        if (endNode.y() < 0) {
          endNode.y(0);
        }
        if (endNode.y() > vm.lineStageConfig.height) {
          endNode.y(vm.lineStageConfig.height);
        }
        vm.lineConfig.points = [
          startNode.x(),
          startNode.y(),
          endNode.x(),
          endNode.y()
        ];
      } else {
        startNode.x(vm.lineStartConfig.x);
        startNode.y(vm.lineStartConfig.y);
        endNode.x(vm.lineEndConfig.x);
        endNode.y(vm.lineEndConfig.y);
        vm.lineConfig.points = [
          vm.lineStartConfig.x,
          vm.lineStartConfig.y,
          vm.lineEndConfig.x,
          vm.lineEndConfig.y,
        ];
      }
      let arrowLength = 50;
      let arrowStartX = (vm.lineConfig.points[2] + vm.lineConfig.points[0]) / 2;
      let arrowStartY = (vm.lineConfig.points[3] + vm.lineConfig.points[1]) / 2;
      let arrowEndX;
      let arrowEndY;
      if (vm.lineConfig.points[2] === vm.lineConfig.points[0]) {
        arrowEndY = arrowStartY;
        if(vm.lineConfig.points[0] === 0){
          arrowEndX = arrowStartX + vm.lineConfig.points[3] >= vm.lineConfig.points[1] ? -arrowLength : arrowLength;
        }else{
          arrowEndX = vm.lineConfig.points[0] - arrowLength;
        }
      } else {
        let k = (vm.lineConfig.points[3] - vm.lineConfig.points[1]) / (vm.lineConfig.points[2] - vm.lineConfig.points[0]);
        let arrowDiffY = Math.sqrt(Math.pow(arrowLength, 2)/(Math.pow(k, 2)+1));
        let arrowDiffX = Math.abs(k * arrowDiffY);
        arrowEndX = arrowStartX + arrowDiffX * (vm.lineConfig.points[3] >= vm.lineConfig.points[1] ? -1 : 1);
        arrowEndY = arrowStartY + arrowDiffY * (vm.lineConfig.points[2] >= vm.lineConfig.points[0] ? 1 : -1);
      }
      vm.lineArrowConfig.points = [
        arrowStartX,
        arrowStartY,
        arrowEndX,
        arrowEndY
      ];

      // Update parameters

      let realStartX = Math.round(startNode.x()/vm.lineScaleRatio);
      let realStartY = Math.round(startNode.y()/vm.lineScaleRatio);
      let realEndX = Math.round(endNode.x()/vm.lineScaleRatio);
      let realEndY = Math.round(endNode.y()/vm.lineScaleRatio);
      vm.showObject.json.task.parameter.crowd.parameter.line.vertices = [{x: realStartX, y: realStartY}, {x: realEndX, y: realEndY}];
    },
    clearLineStage() {
      let vm = this;
      vm.lineStageConfig = {width: 560, height: 315};
      vm.lineImageConfig = {x: 0, y: 0, image: null};
      vm.lineConfig = {stroke: 'red', strokeWidth: 8, points: [], draggable: false};
      vm.lineStartConfig = {x: 0, y: 0, radius: 10, fill: 'green', draggable: true};
      vm.lineEndConfig = {x: 560, y: 315, radius: 10, fill: 'green', draggable: true};
      vm.lineArrowConfig = {fill: 'yellow', stroke: 'yellow', strokeWidth: 15, points: [], draggable: false};
      vm.lineScaleRatio = 1;
    },
    async updateLineStage() {
      let vm = this;
      vm.$emit('loading', true);
      let task_id = vm.showObject.json.task_id;
      let line_data = vm.showObject.json.task.parameter.crowd.parameter.line;
      let rtsp = vm.showObject.json.source.parameter.rtsp.url;
      let res = await vm.$electron.ipcRenderer.invoke('readCapture', rtsp).catch(() => {
        return {data: ''};
      });
      let capture = res.data;

      if (!capture) {
        vm.$toastr.e(vm.$i18n.t('message.capture_no_result'));
        vm.$emit('loading', false);
        return;
      }

      const image = new window.Image();
      const fixWidth = 560;

      image.src = capture;
      image.onload = () => {
        vm.lineScaleRatio = fixWidth / image.width;
        vm.lineImageConfig.image = image;
        vm.lineImageConfig.width = fixWidth;
        vm.lineImageConfig.height = image.height * vm.lineScaleRatio;
        vm.lineStageConfig.width = fixWidth;
        vm.lineStageConfig.height = image.height * vm.lineScaleRatio;

        if (line_data && line_data.vertices && line_data.vertices.length >= 2) {
          let vertices = line_data.vertices;
          vm.lineStartConfig.x = vertices[0].x * vm.lineScaleRatio;
          vm.lineStartConfig.y = vertices[0].y * vm.lineScaleRatio;
          vm.lineEndConfig.x = vertices[1].x * vm.lineScaleRatio;
          vm.lineEndConfig.y = vertices[1].y * vm.lineScaleRatio;
        } else {
          vm.lineStartConfig.x = 0;
          vm.lineStartConfig.y = 0;
          vm.lineEndConfig.x = fixWidth;
          vm.lineEndConfig.y = image.height * vm.lineScaleRatio;
        }

        vm.updateLine(false);
      };
      vm.$emit('loading', false);
    },
    clearAreaStage() {
      let vm = this;
      vm.areaStageConfig = {width: 560, height: 315};
      vm.areaImageConfig = {x: 0, y: 0, image: null};
      vm.areaConfig = {stroke: 'red', strokeWidth: 5, fill: 'green', opacity: 0.4, points: [], draggable: false, closed: true};
      vm.areaPointsConfig = [];
      vm.areaScaleRatio = 1;
    },
    addAreaPoint(event) {
      let vm = this;
      if (vm.areaPointsConfig.length >= 10) {
        vm.$toastr.w(vm.$i18n.t('message.task_area_pointslimit'));
        return;
      }
      let pointX = event.evt.offsetX;
      let pointY = event.evt.offsetY;
      vm.areaPointsConfig.push({x: pointX, y: pointY, radius: 10, fill: 'green', draggable: false});
      vm.areaConfig.points.push(pointX);
      vm.areaConfig.points.push(pointY);

      let realX = Math.round(pointX/vm.areaScaleRatio);
      let realY = Math.round(pointY/vm.areaScaleRatio);
      vm.showObject.json.task.parameter.crowd.parameter.polygon.vertices.push({x: realX, y: realY});
    },
    clearAreaPoints() {
      let vm = this;
      vm.areaPointsConfig = [];
      vm.areaConfig.points = [];
      vm.showObject.json.task.parameter.crowd.parameter.polygon.vertices = [];
    },
    async updateAreaStage() {
      let vm = this;
      vm.$emit('loading', true);
      let task_id = vm.showObject.json.task_id;
      let area_data = vm.showObject.json.task.parameter.crowd.parameter.polygon;
      let rtsp = vm.showObject.json.source.parameter.rtsp.url;
      let res = await vm.$electron.ipcRenderer.invoke('readCapture', rtsp).catch(() => {
        return {data: ''};
      });
      let capture = res.data;

      if (!capture) {
        vm.$toastr.e(vm.$i18n.t('message.capture_no_result'));
        vm.$emit('loading', false);
        return;
      }

      const image = new window.Image();
      const fixWidth = 560;

      image.src = capture;
      image.onload = () => {
        vm.areaScaleRatio = fixWidth / image.width;
        vm.areaImageConfig.image = image;
        vm.areaImageConfig.width = fixWidth;
        vm.areaImageConfig.height = image.height * vm.areaScaleRatio;
        vm.areaStageConfig.width = fixWidth;
        vm.areaStageConfig.height = image.height * vm.areaScaleRatio;
        vm.areaConfig.points = [];
        vm.areaPointsConfig = [];

        if (area_data && area_data.vertices && area_data.vertices.length >= 3) {
          let vertices = area_data.vertices;
          vertices.forEach(item => {
            let pointX = item.x * vm.areaScaleRatio;
            let pointY = item.y * vm.areaScaleRatio;
            vm.areaPointsConfig.push({x: pointX, y: pointY, radius: 10, fill: 'green', draggable: false});
            vm.areaConfig.points.push(pointX);
            vm.areaConfig.points.push(pointY);
          });
        }
      };
      vm.$emit('loading', false);
    },
    download (data) {
      if (!data) {
          return
      }
      let url = window.URL.createObjectURL(new Blob([data]))
      let link = document.createElement('a')
      link.style.display = 'none'
      link.href = url
      link.setAttribute('download', `tasks_${this.device.name}_${this.device.type}_${this.device.address}.json`)

      document.body.appendChild(link)
      link.click()
    },
    loadTextFromFile(e){
      let vm = this;
      try{
        if(e.target.files[0] !== null){
          let reader = new FileReader()
          reader.readAsText(e.target.files[0], 'UTF-8')
          reader.onload = function (e) {
            let fileContent = e.target.result
            vm.tableList = JSON.parse(fileContent);
            vm.showTableModal = true;
          }
        }else{
          vm.$toastr.e(vm.$i18n.t('message.task_select_file'));
        }
      }catch(e){
        vm.$toastr.e(vm.$i18n.t('message.task_data_format'));
      }
    }
  }
};
</script>
