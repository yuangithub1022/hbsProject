<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.panorama {
  width: 100%;
  max-height: 180px;
}
.icon {
  top: -15px!important;
}
.head-image {
  height: 100px;
  width: 100px;
}
.result-span {
  font-size: 12px;
  min-height: 90px;
}
.head-image-sm {
  height: 50px;
  width: 50px;
}
.info-box-text {
  font-size: 20px;
}
.info-box-number {
  font-size: 36px;
}
</style>

<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.live") }}</h4>
            </div>
            <div class="box-body">
              <div class="row">
                <div class="col-md-12">
                  <div class="form-group">
                    <select v-model="targetLiveTasks" @change="changeLiveTasks" v-select2="tastLiveSelectOption" multiple="multiple" class="form-control select2" data-placeholder="Select Tasks" style="width: 100%;">
                      <option v-for="item of tasks" :key="item.task_id" :value="item">{{ item.extra_info.task_name }}</option>
                    </select>
                  </div>
                </div>
              </div>
              <div class="row mt-10">
                <div class="col-md-12">
                  <ul class="timeline">
                    <li v-for="item of results" :key="item.capture_time">
                      <i v-if="item.task_type==='TASK_TYPE_FACE'" class="fa fa-user bg-blue"></i>
                      <i v-if="item.task_type==='TASK_TYPE_CROWD'" class="fa fa-users bg-green"></i>

                      <div class="timeline-item">
                        <span class="time"><i class="fa fa-clock-o"></i> {{ item.capture_time.substring(11, 23) }}</span>

                        <h3 class="timeline-header">
                          <a href="javascript:void(0)">{{ item.extra_info.task_name }}</a>
                          <span v-if="item.task_type==='TASK_TYPE_FACE'"> 顔認証結果 </span>
                          <template v-if="item.task_type==='TASK_TYPE_CROWD'">
                            <span v-if="item.capture_result.crowd.type==='CROWD_TYPE_HEADCOUNT'"> エリア人数カウント結果 </span>
                            <span v-if="item.capture_result.crowd.type==='CROWD_TYPE_DENSITY'"> エリア混雑検知アラーム </span>
                            <span v-if="item.capture_result.crowd.type==='CROWD_TYPE_RETENTION'"> エリア滞留検知アラーム </span>
                            <span v-if="item.capture_result.crowd.type==='CROWD_TYPE_SEGMENTATION'"> ラインクロス検知結果 </span>
                            <span v-if="item.capture_result.crowd.type==='CROWD_TYPE_INTRUSION'"> ラインクロス侵入検知アラーム </span>
                          </template>
                        </h3>

                        <div class="timeline-body">
                          <div class="row">
                            <div class="col-md-4">
                              <img :src="'data:image/jpg;base64,'+item.panorama.data" v-if="item.panorama.data" class="panorama">
                              <img v-auth-image="item.panorama.url" v-if="item.panorama.url" class="panorama">
                            </div>
                            <div class="col-md-4" v-if="item.task_type==='TASK_TYPE_FACE'">
                              <div class="small-box bg-green">
                                <div class="inner">
                                  <h5><strong> {{ $t("capture.image") }} </strong></h5>
                                  <p class="result-span">
                                    {{ $t("capture.v_gender") }}: {{ item.capture_result.face.attributes.gender }} <br>
                                    {{ $t("capture.v_age") }}: {{ item.capture_result.face.attributes.age }} <br>
                                    {{ $t("alarm.score") }}: {{ item.capture_result.face.score }}
                                  </p>
                                </div>
                                <div class="icon">
                                  <img :src="'data:image/jpg;base64,'+item.capture_result.face.portrait.data" v-if="item.capture_result.face.portrait.data" class="head-image">
                                  <img v-auth-image="item.capture_result.face.portrait.url" v-if="item.capture_result.face.portrait.url" class="head-image">
                                </div>
                                <a href="javascript:void(0)" class="small-box-footer">
                                  <span v-if="item.capture_result.face.score && item.capture_result.face.score >= item.extra_info.min_score">
                                    <i class="fa fa-check-circle"></i> 認証OK
                                  </span>
                                  <span v-else> <i class="fa fa-times"></i> 認証NG </span>
                                </a>
                              </div>
                            </div>
                            <div class="col-md-4" v-if="item.task_type==='TASK_TYPE_FACE'">
                              <div class="small-box bg-yellow" v-if="item.capture_result.face.most_similar_user">
                                <div class="inner">
                                  <h5> <strong>{{ item.capture_result.face.most_similar_user.name }}</strong> </h5>
                                  <p class="result-span">
                                    {{ $t("user.cardId") }}: {{ item.capture_result.face.most_similar_user.card_id }} <br>
                                    {{ $t("user.gender") }}: {{ item.capture_result.face.most_similar_user.gender }} <br>
                                    {{ $t("user.age") }}: {{ item.capture_result.face.most_similar_user.age }}
                                  </p>
                                </div>
                                <div class="icon">
                                  <img :src="'data:image/jpg;base64,'+item.capture_result.face.most_similar_user.image.data" v-if="item.capture_result.face.most_similar_user.image.data" class="head-image">
                                  <img v-auth-image="item.capture_result.face.most_similar_user.image.url" v-if="item.capture_result.face.most_similar_user.image.url" class="head-image">
                                </div>
                                <a href="javascript:void(0)" class="small-box-footer">
                                  {{ $t("user.create_time") }}: {{ item.capture_result.face.most_similar_user.create_time.substring(0, 20) }}
                                </a>
                              </div>
                            </div>
                            <template v-if="item.task_type==='TASK_TYPE_CROWD'">
                              <template v-if="item.capture_result.crowd.type==='CROWD_TYPE_HEADCOUNT'">
                                <div class="col-md-4">
                                  <div class="info-box">
                                    <span class="info-box-icon bg-yellow">
                                      <i class="fa fa-users"></i>
                                    </span>

                                    <div class="info-box-content">
                                      <span class="info-box-text">エリア内人数</span>
                                      <span class="info-box-number">{{ item.capture_result.crowd.subclass.headcount.count }}</span>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-4">
                                  <span v-for="(person,index) in item.capture_result.crowd.subclass.headcount.persons" :key="index">
                                    <img :src="'data:image/jpg;base64,'+person.portrait.data" v-if="person.portrait.data" class="head-image-sm">
                                    <img v-auth-image="person.portrait.url" v-if="person.portrait.url" class="head-image-sm">
                                  </span>
                                </div>
                              </template>
                              <template v-if="item.capture_result.crowd.type==='CROWD_TYPE_DENSITY'">
                                <div class="col-md-4">
                                  <div class="info-box">
                                    <span class="info-box-icon bg-yellow">
                                      <i class="fa fa-users"></i>
                                    </span>

                                    <div class="info-box-content">
                                      <span class="info-box-text">エリア混雑度</span>
                                      <span class="info-box-number">{{ item.capture_result.crowd.subclass.density.percent }}</span>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-4">
                                  <span v-for="(person,index) in item.capture_result.crowd.subclass.density.persons" :key="index">
                                    <img :src="'data:image/jpg;base64,'+person.portrait.data" v-if="person.portrait.data" class="head-image-sm">
                                    <img v-auth-image="person.portrait.url" v-if="person.portrait.url" class="head-image-sm">
                                  </span>
                                </div>
                              </template>
                              <template v-if="item.capture_result.crowd.type==='CROWD_TYPE_RETENTION'">
                                <div class="col-md-4">
                                  <div class="info-box">
                                    <span class="info-box-icon bg-yellow">
                                      <i class="fa fa-users"></i>
                                    </span>

                                    <div class="info-box-content">
                                      <span class="info-box-text">エリア滞留人数</span>
                                      <span class="info-box-number"> {{ item.capture_result.crowd.subclass.retention.count }} </span>
                                    </div>
                                  </div>
                                </div>
                                <div class="col-md-4">
                                  <span v-for="(person,index) in item.capture_result.crowd.subclass.retention.persons" :key="index">
                                    <img :src="'data:image/jpg;base64,'+person.portrait.data" v-if="person.portrait.data" class="head-image-sm">
                                    <img v-auth-image="person.portrait.url" v-if="person.portrait.url" class="head-image-sm">
                                  </span>
                                </div>
                              </template>
                              <template v-if="item.capture_result.crowd.type==='CROWD_TYPE_SEGMENTATION'">
                                <div class="col-md-4">
                                  <div class="info-box">
                                    <span class="info-box-icon bg-yellow">
                                      <i class="fa fa-users"></i>
                                    </span>

                                    <div class="info-box-content">
                                      <span class="info-box-text">進入人数</span>
                                      <span class="info-box-number"> {{ item.capture_result.crowd.subclass.segmentation.forward }} </span>
                                    </div>
                                  </div>
                                  <div>
                                    <span v-for="(person,index) in item.capture_result.crowd.subclass.segmentation.forward_persons" :key="index">
                                      <img :src="'data:image/jpg;base64,'+person.portrait.data" v-if="person.portrait.data" class="head-image-sm">
                                      <img v-auth-image="person.portrait.url" v-if="person.portrait.url" class="head-image-sm">
                                    </span>
                                  </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="info-box">
                                    <span class="info-box-icon bg-yellow">
                                      <i class="fa fa-users"></i>
                                    </span>

                                    <div class="info-box-content">
                                      <span class="info-box-text">退出人数</span>
                                      <span class="info-box-number"> {{ item.capture_result.crowd.subclass.segmentation.reverse }} </span>
                                    </div>
                                  </div>
                                  <div>
                                    <span v-for="(person,index) in item.capture_result.crowd.subclass.segmentation.reverse_persons" :key="index">
                                      <img :src="'data:image/jpg;base64,'+person.portrait.data" v-if="person.portrait.data" class="head-image-sm">
                                      <img v-auth-image="person.portrait.url" v-if="person.portrait.url" class="head-image-sm">
                                    </span>
                                  </div>
                                </div>
                              </template>
                              <template v-if="item.capture_result.crowd.type==='CROWD_TYPE_INTRUSION'">
                                <div class="col-md-4" v-for="(interest,index) in item.capture_result.crowd.subclass.intrusion.interests" :key="index">
                                  <div class="info-box">
                                    <span class="info-box-icon bg-yellow">
                                      <i class="fa fa-user-secret"></i>
                                    </span>

                                    <div class="info-box-content">
                                      <span class="info-box-text">{{ interest.direction }}侵入人数</span>
                                      <span class="info-box-number">{{ interest.count }}</span>
                                    </div>
                                  </div>
                                  <div>
                                    <span v-for="(person,i) in interest.persons" :key="i">
                                      <img :src="'data:image/jpg;base64,'+person.portrait.data" v-if="person.portrait.data" class="head-image-sm">
                                      <img v-auth-image="person.portrait.url" v-if="person.portrait.url" class="head-image-sm">
                                    </span>
                                  </div>
                                </div>
                              </template>
                            </template>
                          </div>
                        </div>
                      </div>
                    </li>
                    <li v-if="results.length===0">
                      <i class="fa fa-comments bg-yellow"></i>
                      <div class="timeline-item">
                        <h3 class="timeline-header no-border"> 検知結果はまだありません </h3>
                      </div>
                    </li>
                    <li>
                      <i class="fa fa-clock-o bg-gray"></i>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>
<script>
import * as moment from 'moment';
import api from '../api/api'; 

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      device: this.$root.deviceData,
      tasks: [],
      results: [],
      targetLiveTasks: [],
      tastLiveSelectOption: {
        allowClear: true,
        maximumSelectionLength: 4,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
    };
  },
  methods: {
    receiveMessage(data) {
      let vm = this;
      let task_id = data.task_id;
      if (!vm.targetLiveTasks || vm.targetLiveTasks.length === 0) {
        return;
      }

      for (let index = 0; index < vm.targetLiveTasks.length; index++) {
        const element = vm.targetLiveTasks[index];
        if (element.task_id === task_id) {
          console.log(JSON.stringify(data))
          if (vm.results.length >= 10) {
            vm.results.splice(9);
          }
          vm.results.unshift(data);
          break;
        }
      }
    },
    changeLiveTasks() {
      let vm = this;
      if (!vm.targetLiveTasks || vm.targetLiveTasks.length === 0) {
        vm.results = [];
        return;
      }
      vm.results = vm.results.filter(element => {
        for (let task of vm.targetLiveTasks) {
          if (task.task_id === element.task_id) {
            return true;
          }
        }
        return false;
      });
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
  },
  destroyed: function() {
    this.$electron.ipcRenderer.removeAllListeners();
  },
  mounted: async function() {
    let vm = this;
    // Get All tasks (status===OK)
    await api.taskListMps({'page_request.offset': 0, 'page_request.limit': 100}).then(res =>{
      if (res.data.tasks) {
        let running = res.data.tasks.filter(element => {
          if (element.status.status === 'OK') return true;
        });
        if (running.length > 0) {
          vm.tasks = vm.tasks.concat(running);
        }
       }
    });

    if (vm.device.type === 'face') {
      await api.taskListAcs({'page_request.offset': 0, 'page_request.limit': 100}).then(res =>{
        if (res.data.tasks) {
          let running = res.data.tasks.filter(element => {
            if (element.status.status === 'OK') return true;
          });
          if (running.length > 0) {
            vm.tasks = vm.tasks.concat(running);
          }
        }
      });
    }

    vm.$electron.ipcRenderer.on('upload', (event, data) => {
      if (data) {
        vm.receiveMessage(data);
      }
    });
  }
};
</script>
