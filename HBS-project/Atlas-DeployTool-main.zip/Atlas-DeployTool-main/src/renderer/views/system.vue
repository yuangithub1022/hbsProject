<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.setting {
  vertical-align: middle;
  margin-bottom: 15px;
}
.http-title {
  margin-top: 5px;
}
.info-text {
  color: gray;
  font-size: smaller;
}
#library {
  margin-bottom: 15px;
}
</style>
<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.system") }}</h4>
            </div>
            <div class="box-body">
              <table id="library" class="table table-bordered" width="100%">
                <thead>
                  <tr>
                    <th width="100px">{{ $t("common.no") }}</th>
                    <th width="300px">{{ $t("system.serviceName") }}</th>
                    <th>{{ $t("system.serviceVersion") }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>FeatureProcessService</td>
                    <td><span class="info-text">{{ fpsVersion }}</span></td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>OperationMaintenanceService</td>
                    <td><span class="info-text">{{ omsVersion }}</span></td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>MediaProcessService</td>
                    <td><span class="info-text">{{ mpsVersion }}</span></td>
                  </tr>
                  <tr v-if="device.type==='face'">
                    <td>4</td>
                    <td>AccessControlService</td>
                    <td><span class="info-text">{{ acsVersion }}</span></td>
                  </tr>
                  <tr v-if="device.type==='face'">
                    <td>5</td>
                    <td>StaticFeatureDatabaseService</td>
                    <td><span class="info-text">{{ afdVersion }}</span></td>
                  </tr>
                </tbody>
              </table>

              <div class="row">
                <div class="setting col-xs-12">
                  <div class="row">
                    <div class="col-xs-6" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.http") }} <span class="info-text">(Captures and Alarms will be posted to Http Server.)</span></label>
                      <button class="btn btn-primary pull-right" v-if="!editable" @click="editable=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="editable" @click="updateHttpServer">{{ $t("common.update") }}</button>
                    </div>
                    <div class="col-xs-6" style="margin-bottom: 5px;">
                      <div class="col-xs-6" style="padding:0;">
                        <label class="http-title">{{ $t("system.ntp") }} </label>
                        <button class="btn btn-primary pull-right" @click="updateNTPServer">{{ $t("common.update") }}</button>
                      </div>
                      <div class="col-xs-6">
                        <label class="http-title">{{ $t("system.storagePolicy") }} </label>
                        <button class="btn btn-primary pull-right" @click="updateStoragePolicy">{{ $t("common.update") }}</button>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-xs-6">
                      <textarea class="form-control" rows="1" placeholder="" :disabled="!editable" v-model="httpServer"></textarea>
                    </div>
                    <div class="col-xs-6">
                      <div class="col-xs-6" style="padding:0;">
                        <ipAddressInput :ip="ntpIp" :on-change="onIpChange" :on-blur="onIpBlur"></ipAddressInput>
                      </div>
                      <div class="col-xs-6">
                        <select class="form-control" v-model="storagePolicy">
                          <option value="LOCAL">LOCAL</option>
                          <option value="REMOTE">REMOTE</option>
                        </select>
                      </div>
                    </div>
                  </div>
                  <div class="form-group row">
                    <div class="col-xs-6" >
                      <span class="info-text">通知先をツールアプリに設定する場合、http://パソコンIP:5000/deploy/upload</span> <br>
                      <template v-if="device.type === 'face'">
                        <span class="info-text">通知先をRS485伝送アプリに設定する場合、http://{{ device.address }}:5010/access/upload</span> <br>
                        <span class="info-text">通知先を顔認証接点連動アプリに設定する場合、http://{{ device.address }}:5012/upload</span> <br>
                        <span class="info-text">通知先を顔毎に接点連動アプリに設定する場合、http://{{ device.address }}:5015/upload</span>
                      </template>
                      <template v-if="device.type === 'crowd'">
                        <span class="info-text">通知先をCSV伝送アプリに設定する場合、http://{{ device.address }}:5005/transfer/upload</span> <br>
                        <span class="info-text">通知先を人流接点連動アプリに設定する場合、http://{{ device.address }}:5011/upload</span> <br>
                        <span class="info-text">通知先を人流エレベーター連動アプリに設定する場合、http://{{ device.address }}:5014/upload</span>
                      </template>

                    </div>

                    <div class="col-xs-6">
                      <div class="col-xs-6" style="padding:0;">
                        <span class="info-text">利用できるNTPサーバのIPアドレスをAtlas500に設定します。</span> <br>
                      </div>
                      <div class="col-xs-6">
                        <span class="info-text">Atlas500に画像データ又は統計データを保存するかどうかを設定します。</span> <br>
                        <span class="info-text">LOCAL: Atlas500に保存する</span> <br>
                        <span class="info-text">REMOTE: Atlas500に保存しない</span>
                      </div>
                    </div>
                  </div>
                  <button class="btn btn-danger pull-left" @click="clear">{{ $t("common.clear") }}</button>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>
<script>
import axios from 'axios';
import * as util from '../assets/js/util';
import api from '../api/api';
import esp from '../api/esp';

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    ipAddressInput: () => import("../components/ipAddressInput.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      device: this.$root.deviceData,
      fpsVersion: '',
      omsVersion: '',
      mpsVersion: '',
      acsVersion: '',
      afdVersion: '',
      httpServer: '',
      editable: false,
      ntpIp: '',
      authParams: {
        UserName: 'admin',
        Password: 'Huawei12#$'
      },
      storagePolicy: ''
    };
  },
  methods: {
    onIpChange(ip) {
      this.ntpIp = ip;
    },
    onIpBlur(ip) {
      //console.log('ip input blur:', ip);
    },
    updateStoragePolicy(){
      let vm = this;
      let params = {
        policy: this.storagePolicy
      }

      api.setStoragePolicy(params).then(() => {
        vm.$toastr.s(vm.$i18n.t('message.update_storagePolicy_success'));
      }).catch((err) => {
        vm.$toastr.e(vm.$i18n.t('message.update_storagePolicy_failure') + err);
      })
    },
    updateNTPServer() {
      let vm = this;
      let serverEnabled;
      let ntpIp;
      if(vm.ntpIp){
        serverEnabled = true;
        let reg =  /^(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])\.(\d{1,2}|1\d\d|2[0-4]\d|25[0-5])$/
        if(!reg.test(vm.ntpIp)){
          vm.$toastr.i(vm.$i18n.t('message.ntp_format_invalid'));
          return;
        }
        ntpIp = vm.ntpIp;
      }else{
        serverEnabled = false;
        ntpIp =  '127.127.1.0';
      }

      let params = {
        "ClientEnabled": true,
        "ServerEnabled": serverEnabled,
        "NTPRemoteServers": ntpIp,
        "NTPLocalServers": ""
      };
      vm.$emit('loading', true);

      esp.login(vm.device.address, vm.authParams).then(() => {
        esp.updateNTPServer(params).then(res => {
          vm.$toastr.s(vm.$i18n.t('message.ntp_update_success'));
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.ntp_update_failure') + '<br>' + err.response.data.message);
        }).finally(()=> {
          vm.$emit('loading', false);
        });
      }).catch((err) => {
          vm.$toastr.e(vm.$i18n.t('message.ntp_update_failure') + err);
          vm.$emit('loading', false);
      });
    },
    updateHttpServer() {
      let vm = this;
      let newServer = vm.httpServer.trim();
      if (!newServer) {
        vm.$toastr.e(vm.$i18n.t('message.http_update_empty'));
        return;
      }
      api.setHttpServer({url: newServer}).then(() => {
        vm.editable = false;
        vm.httpServer = newServer;
        vm.$toastr.s(vm.$i18n.t('message.http_update_success'));
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.http_update_failure') + '<br>' + err.response.data.message);
      });
    },
    clear() {
      let vm = this;
      if (util.showConfirmDialog(vm.$i18n.t('message.item_delete_confirm')) === 0) {
        vm.$emit('loading', true);
        api.deleteAllRecords().then(() => {
          vm.$toastr.s(vm.$i18n.t('message.delete_all_success'));
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.delete_all_failure') + '<br>' + err.response.data.message);
          vm.$emit('loading', false);
        });
      }
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    // Get version info and http server url
    let vm = this;
    api.fpsGetVersion().then(res => {
      if (res.data) {
        vm.fpsVersion = res.data.version;
      }
    }).catch(err => {
      vm.fpsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.omsGetVersion().then(res => {
      if (res.data) {
        vm.omsVersion = res.data.version;
      }
    }).catch(err => {
      vm.omsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.mpsGetVersion().then(res => {
      if (res.data) {
        vm.mpsVersion = res.data.version;
      }
    }).catch(err => {
      vm.mpsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    if (vm.device.type === 'face') {
      api.acsGetVersion().then(res => {
        if (res.data) {
          vm.acsVersion = res.data.version;
        }
      }).catch(err => {
        vm.acsVersion = 'UNKNOWN';
        vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
      });
      api.afdGetVersion().then(res => {
        if (res.data) {
          vm.afdVersion = res.data.version;
        }
      }).catch(err => {
        vm.afdVersion = 'UNKNOWN';
        vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
      });
    }

    api.getHttpServer().then(res => {
      if (res.data) {
        vm.httpServer = res.data.url;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });

    vm.$emit('loading', true);
    esp.login(vm.device.address, vm.authParams).then(() => {
      esp.getNTPServer().then(res => {
        if(res.data != null) {
          if(res.data.ServerEnabled){
            vm.ntpIp = res.data.NTPRemoteServers;
          }else{
            vm.ntpIp = '';
          }
        }
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.ntp_info_failure') + '<br>' + err.response.data.message);
      });
    }).catch((err) => {
      vm.$toastr.e(vm.$i18n.t('message.ntp_info_failure') + err);
    }).finally(()=> {
      vm.$emit('loading', false);
    });

    api.getStoragePolicy().then(res => {
      if (res.data) {
        vm.storagePolicy = res.data.policy;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.get_storagePolicy_failure') + '<br>' + err.response.data.message);
    });
  }
};
</script>
