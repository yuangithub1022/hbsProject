<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.modal-form {
  margin-top: 15px;
}
</style>
<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.ipconfig") }}</h4>
            </div>
            <div class="box-body">
              <table id="ips" class="table table-bordered table-striped" width="100%">
                <thead>
                  <tr>
                    <th>{{ $t("ipconfig.id") }}</th>
                    <th>{{ $t("ipconfig.name") }}</th>
                    <th>{{ $t("ipconfig.address") }}</th>
                    <th>{{ $t("ipconfig.subnet") }}</th>
                    <th>{{ $t("ipconfig.gateway") }}</th>
                    <th></th>
                    <th>{{ $t("common.action") }}</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          <pageModal :show.sync="showModal" :footer="true">
            <div slot="header">
              <span v-if="showObject.id">{{ $t("common.edit") }} (ID: {{ showObject.name }})</span>
            </div>
            <div slot="body">
              <form class="form-horizontal">
                <div class="modal-form">
                  <div class="form-group">
                    <label class="col-xs-3 control-label">
                      {{ $t("ipconfig.name") }}
                    </label>
                    <div class="col-xs-9">
                      <input type="text" class="form-control" v-model="showObject.name" readonly>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label">
                      {{ $t("ipconfig.address") }}
                    </label>
                    <div class="col-xs-9">
                      <input type="text" class="form-control" v-model="showObject.address"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label">
                      {{ $t("ipconfig.subnet") }}
                    </label>
                    <div class="col-xs-9">
                      <input type="text" class="form-control" v-model="showObject.subnet"/>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-3 control-label">
                      {{ $t("ipconfig.gateway") }}
                    </label>
                    <div class="col-xs-9">
                      <input type="text" class="form-control" v-model="showObject.gateway"/>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div slot="footer">
              <button class="btn btn-default pull-left" @click="showModal=false;">{{ $t("common.cancel") }}</button>
              <button class="btn btn-primary pull-right" @click="updateIp">{{ $t("common.ok") }}</button>
            </div>
          </pageModal>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>
<script>
import axios from 'axios';
import api from '../api/esp'; 

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      device: this.$root.deviceData,
      showModal: false,
      showObject: {},
      dataTable: null,
      timer: null,
      authParams: {
        UserName: 'admin',
        Password: 'Huawei12#$' 
      }
    };
  },
  methods: {
    updateIp() {
      const vm = this;
      if (!vm.showObject.address || !vm.showObject.subnet) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      const id = vm.showObject.id;
      const params = {
        IPv4Addresses: [
          {
            Address: vm.showObject.address,
            SubnetMask: vm.showObject.subnet,
            Gateway: vm.showObject.gateway,
            AddressOrigin: vm.showObject.obj.AddressOrigin,
            Tag: vm.showObject.obj.Tag
          }
        ]
      };

      vm.$emit('loading', true);
      api.login(vm.device.address, vm.authParams).then(() => {
        api.updateIp(id, params).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.ip_update_success'));
          vm.dataTable.ajax.reload();
        }).catch(() => {
          vm.$toastr.e(vm.$i18n.t('message.ip_update_success'));
        }).finally(() => {
          vm.$emit('loading', false);
        });
      }).catch(() => {
        vm.$emit('loading', false);
        vm.$toastr.e(vm.$i18n.t('message.ip_update_failure'));
      });
    }
  },
  mounted() {
    const vm = this;
    vm.dataTable = $('#ips').DataTable({
      paging: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: false,
      order: [[ 1, "asc" ]],
      dom: 'rti',
      columnDefs: [
        {
          targets: [0, 5],
          visible: false
        },
        {
          targets: -1,
          data: null,
          orderable: false,
          render() {
            return '<a class="btn btn-info btn-xs edit"><i class="fa fa-pencil"></i>&nbsp;' 
                    + vm.$i18n.t('common.edit') + '</a>';
          },
        }
      ],
      ajax(data, callback) {
        vm.$emit('loading', true);
        const records = {draw: 1, data: []};
        api.login(vm.device.address, vm.authParams).then(() => {
          const ids = ['GMAC0', 'GMAC1'];
          Promise.all(ids.map(element => {
            return new Promise((resolve) => {
              api.getIp(element).then(res => {
                const ip = res.data;
                const eth = ip.IPv4Addresses[0];
                records.data.push([element, ip.Name, eth.Address, eth.SubnetMask, eth.Gateway, eth]);
                return resolve(true);
              }).catch((err) => {
                vm.$toastr.e(vm.$i18n.t('message.ip_get_failure') + err);
                return resolve(false);
              });
            });
          })).then(() => {
            callback(records);
            vm.$emit('loading', false);
          });
        }).catch((err) => {
          callback(records);
          vm.$toastr.e(vm.$i18n.t('message.ip_get_failure') + err);
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTable.on('click', '.edit', function() {
      const rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.showObject = {
        id: rowData[0],
        name: rowData[1],
        address: rowData[2],
        subnet: rowData[3],
        gateway: rowData[4],
        obj: rowData[5]
      };
      vm.showModal = true;
    });
  }
};
</script>
