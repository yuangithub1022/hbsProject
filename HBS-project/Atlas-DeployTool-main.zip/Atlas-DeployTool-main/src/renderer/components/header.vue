<style scoped>
.atlas-menu {
  width: 150px !important;
}
.atlas-item {
  width: 150px !important;
}
.user-header {
  height: 150px !important;
}
.main-header {
  z-index: 2000 !important;
}
</style>

<template>
  <header class="main-header">
    <!-- Logo -->
    <router-link to="/" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini">A500</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Atlas 500</b></span>
    </router-link>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-chevron-circle-down"></i>&nbsp; {{ device.name }}({{ $t(`device.${device.type}`) }})
            </a>
            <ul class="dropdown-menu atlas-menu">
              <li>
                <ul class="menu">
                  <li v-for="item in devices" :key="item.address" class="atlas-item">
                    <a href="javascript:void(0);" @click="changeDevice(item)">
                      <span class="align-middle"> {{ item.name }}({{ $t(`device.${item.type}`) }}) </span>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../assets/images/face.png" class="user-image" alt="User Image">
              <span class="hidden-xs">{{ user.name }}</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../assets/images/face.png" class="img-circle" alt="User Image">
                <p>
                  {{ user.name }} - {{ user.role }}
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <router-link :to="{path: '/'}" class="btn btn-default btn-flat">System</router-link>
                </div>
                <div class="pull-right">
                  <a href="javascript:void(0);" @click="logout" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
</template>

<script>
import * as util from '../assets/js/util';

export default {
  data() {
    return {
      user: this.$root.userData,
      devices: this.$root.devices,
      device: this.$root.deviceData
    };
  },
  methods: {
    changeDevice(item) {
      // Clear token
      util.session('device', item);
      util.session('token', '');
      // Reload app
      location.reload();
    },
    logout: function() {
      if (util.showConfirmDialog(this.$i18n.t('message.user_logout_confirm')) === 0) {
        // Clear local information
        util.session('user', '');
        util.session('device', '');
        util.session('token', '');
        // Reload app
        location.reload();
      }
    }
  }
};
</script>
