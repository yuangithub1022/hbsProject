<style scoped>

</style>

<template>
  <footer class="main-footer">
    <div class="pull-right hidden-xs">
      <b>Version</b> 0.0.1
    </div>
    <strong>Copyright &copy; 2019 <a href="https://adminlte.io">Huawei.com</a>.</strong> All rights reserved.
  </footer>
</template>

<script>
export default {
  data() {
    return {

    };
  },
  methods: {

  },
  mounted: () => {
  }
};
</script>
