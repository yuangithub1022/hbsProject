const en = {
  language: {
    name: 'English',
    icon: '../assets/images/en.jpg'
  },
  navbar: {
    home: 'home',
    introduction: 'introduction',
    contact: 'contact'
  }
}
export default en;