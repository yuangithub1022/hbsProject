import instance from './index';

export default {
  login(params) {
    const users = {'admin': 'admin', 'test': 'test'};
    return new Promise((resolve) => {
      let result = false;
      if (params.user && users[params.user] === params.password) {
        resolve({data: {code: 0}});
      } else {
        resolve({data: {code: -1}});
      }
    });
  },
  signIn(params) {
    return instance.post('/components/operation-maintenance/v1/users/sign_in', params);
  },
  signOut(params) {
    params.token = instance.defaults.headers.common['Authorization'];
    return instance.post('/components/operation-maintenance/v1/users/sign_out', params);
  },
  listCaptureResults(params) {
    return instance.get('/engine/feature-process/v1/capture_results', {params: params});
  },
  async getLatestCaptureResult(task_id) {
    let result = null;
    let offset = 0;
    let res = await this.listCaptureResults({
      'page_request.offset': offset,
      'page_request.limit': 100
    });
    if (!res.data || !res.data.results) {
      return result;
    }
    
    if (res.data.results.length < 100) {
      for (let i = res.data.results.length-1; i >= 0; i--) {
        if (res.data.results[i].task_id === task_id) {
          result = res.data.results[i];
          return result;
        }
      }
      return result;
    }

    offset = res.data.page_request.total - 100;

    for (;;) {
      res = await this.listCaptureResults({
        'page_request.offset': offset,
        'page_request.limit': 100
      });

      for (let i = res.data.results.length-1; i >= 0; i--) {
        if (res.data.results[i].task_id === task_id) {
          result = res.data.results[i];
          return result;
        }
      }
      offset -= 100;
      if (offset <= 0) {
        break;
      }
    }
    return result;
  },
  async listAllCaptureResults() {
    let result = [];
    let offset = 0;
    for (;;) {
      let res = await this.listCaptureResults({
        'page_request.offset': offset,
        'page_request.limit': 100
      });
      if (!res.data || !res.data.results) {
        break;
      }
      for (let i = 0; i < res.data.results.length; i++) {
        let panoramaData;
        try {
          panoramaData = await this.downloadObject(res.data.results[i].panorama.url);
        } catch (err) {
          panoramaData = '';
        }
        let imageData;
        try {
          imageData = await this.downloadObject(res.data.results[i].capture_result.face.portrait.url);
        } catch (err) {
          imageData = '';
        }
        res.data.results[i].panorama.data = panoramaData;
        res.data.results[i].capture_result.face.portrait.data = imageData;
        result.push(res.data.results[i]);
      }
      if (res.data.results.length < 100) {
        break;
      }
      offset += 100;
    }
    return result;
  },
  taskNewAcs(params) {
    return instance.post('/engine/access-control/v1/tasks', params);
  },
  taskStatusAcs(id)  {
    return instance.get(`/engine/access-control/v1/tasks/${id}`);
  },
  taskListAcs(params) {
    return instance.get('/engine/access-control/v1/tasks', {params: params});
  },
  taskUpdateAcs(params)  {
    return instance.put(`/engine/access-control/v1/tasks/${params.task_id}`, params);
  },
  taskDeleteAcs(id)  {
    return instance.delete(`/engine/access-control/v1/tasks/${id}`);
  },
  taskNewMps(params) {
    return instance.post('/engine/media-process/v1/tasks', params);
  },
  taskStatusMps(id)  {
    return instance.get(`/engine/media-process/v1/tasks/${id}`);
  },
  taskListMps(params) {
    return instance.get('/engine/media-process/v1/tasks', {params: params});
  },
  taskUpdateMps(params)  {
    return instance.put(`/engine/media-process/v1/tasks/${params.task_id}`, params);
  },
  taskDeleteMps(id)  {
    return instance.delete(`/engine/media-process/v1/tasks/${id}`);
  },
  dBNew(params)  {
    return instance.post('/engine/alert-feature/v1/databases', params);
  },
  dBGet(id)  {
    return instance.get(`/engine/alert-feature/v1/databases/${id}`);
  },
  dBList(params)  {
    return instance.get('/engine/alert-feature/v1/databases', params);
  },
  dBUpdate(params)  {
    return instance.put(`/engine/alert-feature/v1/databases/${params.id}`, params);
  },
  dBDelete(id)  {
    return instance.delete(`/engine/alert-feature/v1/databases/${id}`);
  },
  userBatchAdd(params)  {
    return instance.post(`/engine/alert-feature/v1/databases/${params.db_id}/users`, params);
  },
  userGet(db_id, user_id)  {
    return instance.get(`/engine/alert-feature/v1/databases/${db_id}/users/${user_id}`);
  },
  userList(db_id, params)  {
    return instance.get(`/engine/alert-feature/v1/databases/${db_id}/users`, {params: params});
  },
  async userListAll(db_id) {
    let result = [];
    let offset = 0;
    for (;;) {
      let res = await this.userList(db_id, {'page_request.offset': offset, 'page_request.limit': 100});
      if (!res.data || !res.data.users) {
        break;
      }
      for (let i = 0; i < res.data.users.length; i++) {
        let imageData;
        try {
          imageData = await this.downloadObject( res.data.users[i].image.url);
        } catch (err) {
          imageData = '';
        }
        res.data.users[i].image.data = imageData;
        result.push(res.data.users[i]);
      }
      if (res.data.users.length < 100) {
        break;
      }
      offset += 100;
    }
    return result;
  },
  userUpdate(params)  {
    return instance.put(`/engine/alert-feature/v1/databases/${params.db_id}/users/${params.user_id}`, params);
  },
  userDelete(db_id, user_id) {
    return instance.delete(`/engine/alert-feature/v1/databases/${db_id}/users/${user_id}`);
  },
  downloadObject(fid) {
    return instance.get(`/components/osg-default/v1/objects/${fid}`, {responseType: 'arraybuffer'})
      .then(res => {
        let mimeType = res.headers['content-type'].toLowerCase();
        let imgBase64 = new Buffer(res.data, 'binary').toString('base64');
        return 'data:' + mimeType + ';base64,' + imgBase64;
      });
  },
  getFileUrl(fid) {
    let token = instance.defaults.headers.common['Authorization'];
    return `${instance.defaults.baseURL}/components/osg-default/v1/objects/${fid}?token=${token}`;
  },
  getHttpServer() {
    return instance.get('/engine/feature-process/v1/http_server');
  },
  setHttpServer(params) {
    return instance.post('/engine/feature-process/v1/http_server', params);
  },
  deleteAllRecords() {
    return instance.delete('/engine/feature-process/v1/records');
  },
  acsGetVersion() {
    return instance.get('/engine/access-control/v1/version');
  },
  fpsGetVersion() {
    return instance.get('/engine/feature-process/v1/version');
  },
  mpsGetVersion() {
    return instance.get('/engine/media-process/v1/version');
  },
  omsGetVersion() {
    return instance.get('/components/operation-maintenance/v1/version');
  },
  afdGetVersion() {
    return instance.get('/engine/alert-feature/v1/version');
  },
  setStoragePolicy(params) {
    return instance.post('/engine/feature-process/v1/storage_policy',params);
  },
  getStoragePolicy(params) {
    return instance.get('/engine/feature-process/v1/storage_policy');
  }
}
