import axios from 'axios';

const instance = axios.create({
  baseURL: '',
  withCredentials: true,
  headers: {'Cache-Control': 'no-cache'},
  timeout: 15000
});

instance.defaults.headers.post['Content-Type'] = 'application/json';

export default {
  login(ip, params) {
    instance.defaults.baseURL = `https://${ip}/redfish/v1`;
    return instance.post('/SessionService/Sessions', params).then(res => {
      if (res.headers && res.headers['x-auth-token']) {
        instance.defaults.headers.common['X-Auth-Token'] = res.headers['x-auth-token'];
      }
    });
  },
  listIps() {
    return instance.get('/EdgeSystem/EthernetInterfaces');
  },
  getIp(id) {
    return instance.get(`/EdgeSystem/EthernetInterfaces/${id}`);
  },
  updateIp(id, params) {
    return instance.patch(`/EdgeSystem/EthernetInterfaces/${id}`, params);
  },
  getNTPServer(){
    return instance.get(`/EdgeSystem/NTPService`);
  },
  updateNTPServer(ip){
    return instance.patch(`/EdgeSystem/NTPService`, ip);
  }
}