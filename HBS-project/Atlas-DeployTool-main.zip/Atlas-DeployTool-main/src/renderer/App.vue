<style>
</style>

<template>
  <div id="app">
    <router-view @login="loginDirect" @loading="switchLoading"></router-view>
    <vue-element-loading :active="loading" spinner="bar-fade-scale" color="#FF6700" size="64" is-full-screen/>
  </div>
</template>

<script>
import axios from 'axios';
import VueElementLoading from 'vue-element-loading';
import * as util from './assets/js/util';
import faceRoutesData from './router/pathface';
import crowdRoutesData from './router/pathcrowd';
import instance from './api/index';
import api from './api/api'; 

export default {
  data() {
    return {
      menuData: null,
      userData: null,
      deviceData: null,
      devices: [],
      loading: true,
      timer: null,
      refresher: null
    }
  },
  components: {
    VueElementLoading
  },
  methods: {
    switchLoading: function(loading) {
      this.loading = loading;
    },
    extendRoutes: function(type) {
      let originPath = util.deepcopy(type==='face' ? faceRoutesData : crowdRoutesData);
      
      this.$router.addRoutes(originPath.concat([{
        path: '*',
        redirect: '/404'
      }]));

      return originPath;
    },
    generateMenus: function(routes) {
      let vm = this;
      let menus = routes.filter(function(item) {
        if (item.meta.menu) {
          return true;
        }
        return false;
      });
      vm.$root.menuData = menus;
    },
    loginDirect: async function(newPath) {
      // Step 1 Check login status and atlas
      let localUser = util.session('user');
      let localDevice = util.session('device');
      if (!localUser || !localUser.name || !localDevice || !localDevice.address) {
        return this.$router.push({path: '/login'});
      }
      this.$root.userData = localUser;
      this.$root.deviceData = localDevice;
      if (localDevice.address.startsWith('http')) {
        instance.defaults.baseURL = `${localDevice.address}/`;
      } else {
        instance.defaults.baseURL = `https://${localDevice.address}:38443/`;
      }
      

      // Step 2 Check token status
      let localToken = util.session('token');
      let authParams = {
        user: 'admin',
        password: 'Atlas@2019'
      };
      try {
        let res = await api.signIn(authParams);
        if (res && res.data && res.data.token) {
          localToken = {token: res.data.token};
          util.session('token', localToken);
        }
      } catch (err) {
        // pass
      }

      // Step 3 Set Authorization
      if (localToken) {
        instance.defaults.headers.common['Authorization'] = localToken.token;
      }

      // Step 4 Adding routing privileges to users
      let routes = this.extendRoutes(localDevice.type);

      // Step 5 Build Menu data
      this.generateMenus(routes);
      
      // Step 6 move to next page
      this.$router.replace({path: newPath || '/'});

      // Step 7 init token refresher
      this.initRefresher();
    },
    initRefresher: function() {
      this.refresher = setInterval(() => {
        api.omsGetVersion();
      }, 3 * 60 * 1000);
    },
  },
  created: function() {
    this.$root.devices = this.$electron.ipcRenderer.sendSync('readDevices', []);
    this.loginDirect(this.$route.path);
  },
  mounted: function() {
    this.loading = false;
  }
}
</script>
