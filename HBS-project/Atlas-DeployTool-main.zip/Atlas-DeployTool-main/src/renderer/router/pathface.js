// Menu Route
export default [{
  path: '/',
  alias: '/system',
  name: 'System',
  meta: {
    name: 'menu.system',
    icon: 'fa fa-cog',
    menu: true
  },
  component: (resolve) => require(['../views/system.vue'], resolve)
}, {
  path: '/task',
  name: 'TaskManagement',
  meta: {
    name: 'menu.task',
    icon: 'fa fa-tasks',
    menu: true
  },
  component: (resolve) => require(['../views/taskface.vue'], resolve)
}, {
  path: '/live',
  name: 'LiveMonitor',
  meta: {
    name: 'menu.live',
    icon: 'fa fa-bell',
    menu: true
  },
  component: (resolve) => require(['../views/live.vue'], resolve)
}, {
  path: '/library',
  name: 'LibraryManagement',
  meta: {
    name: 'menu.library',
    icon: 'fa fa-database',
    menu: true
  },
  component: (resolve) => require(['../views/library.vue'], resolve)
}, {
  path: '/library/:id/user',
  name: 'UserManagement',
  meta: {
    
  },
  component: (resolve) => require(['../views/user.vue'], resolve)
}, {
  path: '/ipconfig',
  name: 'IpConfig',
  meta: {
    name: 'menu.ipconfig',
    icon: 'fa fa-sitemap',
    menu: true
  },
  component: (resolve) => require(['../views/ipconfig.vue'], resolve)
}];