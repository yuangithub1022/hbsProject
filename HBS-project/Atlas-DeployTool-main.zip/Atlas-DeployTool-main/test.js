var fs = require('fs');
var spawn = require('child_process').spawn;

var ops = [
  '-i', 'rtsp://admin:HuaWei123@124.219.161.88:554/LiveMedia/ch1/Media1',
  '-vframes', '1',
  '-f', 'image2pipe',
  '-'
]
var chunks = Buffer.from([]);
var wstream = fs.createWriteStream('a.jpg');

var ffmpeg_process = spawn('ffmpeg', ops);

ffmpeg_process.stdout.on('data', function(chunk) {
  console.log(Buffer.isBuffer(chunks))
  console.log(Buffer.isBuffer(chunk))
  chunks = Buffer.concat([chunks, chunk])
  wstream.write(chunk);
})

ffmpeg_process.stdout.on('end', () => {
  console.log(JSON.stringify(chunks))
  wstream.end();
});
