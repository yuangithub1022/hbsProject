import json
import logging
import os
import platform
import threading

from flask import Flask, request
from waitress import serve

from adam import Adam6000
from monitor import Monitor

app = Flask(__name__)
app.config['LOW_TO_HIGH_DELAY'] = 3000
app.config['HIGH_TO_LOW_DELAY'] = 3000
app.config['MONITOR_INTERVAL'] = 2000
app.config['DO_ERROR_COUNT'] = 5
app.config['ATLAS_API'] = 'https://172.31.254.100:38443'
app.config['ATLAS_USERNAME'] = 'admin'
app.config['ATLAS_PASSWORD'] = 'Atlas@2019'
app.config['ADAM_CONFIG_IP'] = '192.168.0.51:502'
app.config['ADAM_COUNT'] = 6

fmt = "%(asctime)s - %(levelname)s - %(name)s : %(message)s"
logging.basicConfig(format=fmt)
logger = logging.getLogger('Atlas-FaceElevator')
logger.setLevel(logging.DEBUG)

# Update config if config file exists
is_win = platform.system() == "Windows"
config_file = ('./config.json' if is_win else '/var/face/config.json')
if os.path.isfile(config_file):
    with open(config_file) as f:
        try:
            config = json.load(f)
            if config:
                app.config.update(config)
        except Exception as err:
            logger.warning('Read config file error', err)

adam6000_dict = {}  # adam_ip_port -> adam object
timer_dict = {}  # adam_ip_port_ch -> timer

try:
    low_to_high_delay = app.config['LOW_TO_HIGH_DELAY'] * 0.001
except Exception as err:
    low_to_high_delay = 3.0
    logger.warning('Invalid value LOW_TO_HIGH_DELAY use default value 3.0', err)

try:
    monitor_interval = app.config['MONITOR_INTERVAL'] * 0.001
except Exception as err:
    monitor_interval = 2.0
    logger.warning('Invalid value MONITOR_INTERVAL use default value 2.0', err)

if not app.config['ADAM_CONFIG_IP']:
    logger.warning('Invalid adam config ip: ', app.config['ADAM_CONFIG_IP'])
else:
    adam_config_list = app.config['ADAM_CONFIG_IP'].split(':')
    if not adam_config_list[0]:
        logger.warning('Invalid adam ip')

monitor = Monitor(atlas_api=app.config['ATLAS_API'], atlas_user=app.config['ATLAS_USERNAME'],
                  atlas_password=app.config['ATLAS_PASSWORD'], logger=logger, adam_dict=adam6000_dict,
                  low_to_high_delay=low_to_high_delay, monitor_interval=monitor_interval,
                  do_error_count=app.config['DO_ERROR_COUNT'], adam_config_ip=app.config['ADAM_CONFIG_IP'],
                  adam_count=app.config['ADAM_COUNT'])


@app.route('/upload', methods=['POST'])
def upload():
    # read json data
    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
    except Exception as e:
        logger.warning('Received invalid json data', e)
        return '{"code": -1}'

    # check post data
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_FACE':
        logger.warning('task type is not TASK_TYPE_FACE')
        return '{"code": -1}'

    if 'capture_result' not in post_data or 'face' not in post_data['capture_result']:
        logger.warning('Invalid capture result')
        return '{"code": -1}'

    if 'extra_info' not in post_data:
        logger.warning('No found extra info from post data')
        return '{"code": -1}'

    extra_info = post_data['extra_info']
    min_score = extra_info['min_score'] if 'min_score' in extra_info else 0
    face_result = post_data['capture_result']['face']
    most_similar_user = face_result['most_similar_user'] if 'most_similar_user' in face_result else None
    most_similar_score = face_result['score'] if 'score' in face_result else 0
    user_card_id = most_similar_user['card_id'] if most_similar_user and 'card_id' in most_similar_user else ''
    adam_elevator_use = extra_info['adam_elevator_use'] if 'adam_elevator_use' in extra_info else 'no'
    do_time = extra_info['adam_do_time'] if 'adam_do_time' in extra_info else app.config['HIGH_TO_LOW_DELAY'] * 0.001

    try:
        min_score = float(min_score)
        most_similar_score = float(most_similar_score)
    except Exception as e:
        logger.warning('Invalid post data value', e)
        return '{"code": -1}'

    adam_config_list = app.config['ADAM_CONFIG_IP'].split(':')
    if not adam_config_list[0]:
        logger.warning('Invalid adam ip')
        return '{"code": -1}'
    else:
        adam_ip = adam_config_list[0]
        adam_ip_arr = adam_ip.split('.')
        if len(adam_ip_arr) != 4:
            logger.warning('Invalid adam ip')
            return '{"code": -1}'
        adam_base_ip = adam_ip_arr[0] + '.' + adam_ip_arr[1] + '.' + adam_ip_arr[2] + '.'
        if adam_ip_arr[3].isnumeric():
            adam_base_end_ip = int(adam_ip_arr[3])
        else:
            logger.warning('Invalid adam ip')
        adam_port = adam_config_list[1] if len(adam_config_list) > 1 and adam_config_list[1] != '' else 502

    try:
        adam_port = int(adam_port)
    except Exception as e:
        logger.warning('Invalid post data value', e)
        adam_port = 502

    if not 1 <= adam_port <= 65535:
        logger.warning('Port out of range [1 - 65535]')
        adam_port = 502

    # init all adams
    for num in range(int(app.config['ADAM_COUNT'])):
        adam_ip = adam_base_ip + str(adam_base_end_ip + num)
        adam_ip_port = f'{adam_ip}:{adam_port}'
        if adam_ip_port not in adam6000_dict or adam6000_dict[adam_ip_port] is None:
            try:
                adam6000_dict[adam_ip_port] = Adam6000(logger=logger, adam_ip=adam_ip, adam_port=adam_port,
                                                       monitor_interval=monitor_interval,
                                                       do_error_count=app.config['DO_ERROR_COUNT'])
            except Exception as e:
                logger.warning('Init adam6000 error', e)
                return '{"code": -1}'

    # Check if recognize success
    if most_similar_score > 0 and most_similar_score >= min_score and most_similar_user:
        try:
            floor_num = int(most_similar_user['attributes']['floor_num']) if 'floor_num' in most_similar_user[
                'attributes'] else 0
            logger.info(f'Floor Num:{floor_num}')
            if floor_num < 1 or floor_num > 24:
                logger.info(f'Floor Num invalid.')
                return '{"code": -1}'
        except Exception as e:
            logger.warning('Floor data empty.', e)
            return '{"code": -1}'

        try:
            adam_num = int(floor_num - 1) // 4
            adam_do_num = int((floor_num // 6) * 6 + floor_num % 6 + 1 - ((floor_num - 1) // 4) * 4)
            logger.info(f'Adam Num:{adam_num} channel:DO{adam_do_num}')
            if adam_do_num < 2:
                logger.warning('Adam do number invalid.')
                return '{"code": -1}'
        except Exception as e:
            logger.warning('Calculate adam number and adam do number failure.', e)
            return '{"code": -1}'

        # get DO channel num and write 1 to DO channel
        adam_ip = adam_base_ip + str(adam_base_end_ip + adam_num)
        adam_ip_port = f'{adam_ip}:{adam_port}'
        adam = adam6000_dict[adam_ip_port]
        channel_do = adam_do_num
        

        if adam_elevator_use != 'no': 
            try:
                do_time = int(do_time)
            except Exception as e: 
                logger.warning(f'adam do time is not number. use default time')
                do_time = app.config['HIGH_TO_LOW_DELAY'] * 0.001
                
            if 2 <= channel_do <= 5:
                if 1 <= do_time <= 180:
                    adam.write_channel_on(channel_do)
                    logger.info(f'write_channel_on - IP:{adam._ip} channel:DO{channel_do}')
                    set_timer_to_off(channel_do, adam, adam_ip_port, do_time)
                else:
                    logger.warning(f'Cannot write channel 1 if channel 1 delay time out of range [1 - 180]')
            else:
                logger.warning(f'Cannot write DO{channel_do} out of range [1 - 5]')
        else:
            logger.info(f'do not use adam elevator.')

        logger.info(f'Face data identified OK:{user_card_id} channel:DO{channel_do}')
    else:
        logger.info(f'Face data identified NG.')

    return '{"code": 0}'


def set_timer_to_off(ch, adam, adam_ip_port, high_to_low_delay):
    adam_ip_port_ch = f'{adam_ip_port}:{ch}'

    if adam_ip_port_ch in timer_dict and timer_dict[adam_ip_port_ch] is not None \
            and not timer_dict[adam_ip_port_ch].is_alive():
        timer_dict[adam_ip_port_ch] = None

    if adam_ip_port_ch not in timer_dict or timer_dict[adam_ip_port_ch] is None:
        timer_dict[adam_ip_port_ch] = threading.Timer(high_to_low_delay, adam.write_channel_off, (ch,))
        timer_dict[adam_ip_port_ch].start()
    else:
        timer_dict[adam_ip_port_ch].cancel()
        timer_dict[adam_ip_port_ch] = threading.Timer(high_to_low_delay, adam.write_channel_off, (ch,))
        timer_dict[adam_ip_port_ch].start()


if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=5015)
