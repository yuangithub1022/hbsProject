# importing the requests library
import requests
import json
import os

# defining the api-endpoint
API_ENDPOINT = 'http://localhost:5011/facetransmit/upload'


#print(os.getcwd())


# data to be sent to api
json_file = '../jsons/face_result_ch3.json'
with open(json_file) as json_file:
    data = json.load(json_file)

# sending post request and saving response as response object
r = requests.post(url=API_ENDPOINT, json=data)
# extracting response text
print(f'The response is: {r.text}')

