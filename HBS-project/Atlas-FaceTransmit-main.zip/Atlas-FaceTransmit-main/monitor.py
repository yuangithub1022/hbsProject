import platform
import re
import subprocess
import threading
import time
import warnings

import requests

from adam import Adam6000


class Monitor:
    warnings.filterwarnings('ignore', message='Unverified HTTPS request')

    def __init__(self, logger=None, atlas_api=None, atlas_user='admin', atlas_password='Atlas@2019', adam_dict={},
                 low_to_high_delay=3.0, monitor_interval=2.0, do_error_count=5):
        self._logger = logger
        self._atlas_api = atlas_api
        self._username = atlas_user
        self._password = atlas_password
        self._adam_dict = adam_dict  # adam_ip_port -> adam object
        self._thread = None  # monitor thread
        self._thread_dict = {}  # ch -> adam_ip_port_ch -> thread
        self._thread_status_dict = {}  # adam_ip_port_ch -> bool
        self._ping_dict = {}  # adam_ip_port_ch -> ping
        self._token = self.get_token()
        self._low_to_high_delay = low_to_high_delay
        self._monitor_interval = monitor_interval
        self._do_error_count = do_error_count
        self._adam_config_list_new = []  # adam_ip_port_ch
        self._adam_config_list_old = []  # adam_ip_port_ch
        self._task_id_dict = {}  # task_id -> task_version

        self.monitor_start()

    def monitor_start(self):
        self._thread = threading.Thread(target=self.monitor_loop)
        self._thread.setDaemon(True)
        self._thread.start()

    def monitor_loop(self):
        while True:
            if not self._token:
                self._token = self.get_token()

            if self._token:
                self._adam_config_list_new = []
                mps_task_list = self.get_mps_task_list()
                for task in mps_task_list:
                    thread = threading.Thread(target=self.check_task, args=(task, 'mps'))
                    thread.setDaemon(True)
                    thread.start()
                    time.sleep(0.1)

                acs_task_list = self.get_acs_task_list()
                for task in acs_task_list:
                    thread = threading.Thread(target=self.check_task, args=(task, 'acs'))
                    thread.setDaemon(True)
                    thread.start()
                    time.sleep(0.1)

            time.sleep(self._monitor_interval)

            if not self._adam_config_list_old:
                self._adam_config_list_old = self._adam_config_list_new

            if self._adam_config_list_old != self._adam_config_list_new:
                for value in self._adam_config_list_old:
                    if value not in self._adam_config_list_new:
                        thread = threading.Thread(target=self.clear_ch_no_use, args=(value,))
                        thread.setDaemon(True)
                        thread.start()

                adam_info_list = []
                for value in self._adam_config_list_new:
                    adam_info_list.append(value[:-2])  # adam_info_list -> adam_ip_port

                for key in self._adam_dict:
                    if key not in adam_info_list and self._adam_dict[key]:
                        thread = threading.Thread(target=self.clear_adam_no_use, args=(key,))
                        thread.setDaemon(True)
                        thread.start()

                self._adam_config_list_old = self._adam_config_list_new

    def clear_ch_no_use(self, adam_info):
        adam_ip_port = adam_info[:-2]
        adam_ch = int(adam_info[-1])
        time.sleep(self._monitor_interval)
        self._adam_dict[adam_ip_port].write_channel_off(ch=adam_ch)

    def clear_adam_no_use(self, adam_ip_port):
        wait_all_ch_off = self._low_to_high_delay + 4
        time.sleep(wait_all_ch_off)
        self._adam_dict[adam_ip_port].loop_stop()
        self._adam_dict[adam_ip_port] = None

    def get_token(self):
        # make login call
        try:
            res = self.face_dev_log_in_call()
        except Exception as e:
            self._logger.warning(f'Cannot make the login call, {e}.')
            return ''

        try:
            res_data = res.json()
        except Exception as e:
            self._logger.warning(f'Received invalid json data, {e}.')
            return ''

        if 'token' not in res_data or res_data['token'] == '':
            self._logger.warning('No valid token')
            return ''
        else:
            self._logger.info('Get token success')
            return res_data['token']

    def get_mps_task_list(self):
        # get mps task list
        try:
            res = self.face_dev_get_mps_task_list()
        except Exception as e:
            self._logger.warning(f'Cannot get the task list, {e}.')
            return []

        try:
            res_data = res.json()
        except Exception as e:
            self._logger.warning(f'Cannot get task list from response, {e}')
            return []

        if 'tasks' not in res_data or not res_data['tasks']:
            return []
        else:
            return res_data['tasks']

    def get_acs_task_list(self):
        # get acs task list
        try:
            res = self.face_dev_get_acs_task_list()
        except Exception as e:
            self._logger.warning(f'Cannot get the task list, {e}.')
            return []

        try:
            res_data = res.json()
        except Exception as e:
            self._logger.warning(f'Cannot get task list from response, {e}')
            return []

        if 'tasks' not in res_data or not res_data['tasks']:
            return []
        else:
            return res_data['tasks']

    def check_task(self, task_data, task_service):
        # check task service type
        if task_service != 'mps' and task_service != 'acs':
            return

        # check task type
        if 'type' not in task_data['task'] or task_data['task']['type'] != 'TASK_TYPE_FACE':
            return

        # check task source type
        if task_service == 'mps':
            if 'type' not in task_data['source'] or task_data['source']['type'] != 'VN_RTSP':
                return
        elif task_service == 'acs':
            if 'type' not in task_data['source'] or task_data['source']['type'] != 'FC_SENSEPASS':
                return

        # get adam ip port from extra info
        if 'extra_info' not in task_data or 'adam_config' not in task_data['extra_info']:
            return

        extra_info = task_data['extra_info']
        task_id = task_data['task_id'] if 'task_id' in task_data else ''
        task_version = extra_info['task_version'] if 'task_version' in extra_info else '0'
        adam_config = extra_info['adam_config']
        adam_config_list = adam_config.split(':')
        if adam_config_list[0] == '':
            self._logger.warning('Invalid adam ip')
            return
        else:
            adam_ip = adam_config_list[0]
            adam_port = adam_config_list[1] if len(adam_config_list) > 1 and adam_config_list[1] != '' else 502

        try:
            adam_port = int(adam_port)
        except Exception as e:
            self._logger.warning('Invalid adam config value from post data', e)
            adam_port = 502

        if not 1 <= adam_port <= 65535:
            self._logger.warning('Adam port out of range [1 - 65535]')
            adam_port = 502

        adam_ip_port = f'{adam_ip}:{adam_port}'
        if adam_ip_port not in self._adam_dict or self._adam_dict[adam_ip_port] is None:
            try:
                self._adam_dict[adam_ip_port] = Adam6000(logger=self._logger, adam_ip=adam_ip, adam_port=adam_port,
                                                         monitor_interval=self._monitor_interval)
            except Exception as e:
                self._logger.warning('Init adam6000 error', e)
                return

        adam = self._adam_dict[adam_ip_port]

        try:
            task_version = int(task_version)
        except Exception as e:
            self._logger.warning('Invalid task_version', e)
            task_version = 0

        if task_id not in self._task_id_dict:
            # write relay channel on
            adam.write_channel_on(0)
            self._task_id_dict[task_id] = task_version
        else:
            if self._task_id_dict[task_id] < task_version:
                adam.write_channel_on(0)
                self._task_id_dict[task_id] = task_version

        if task_service == 'mps':
            # get rtsp ip from url if task service is mps
            if 'url' not in task_data['source']['parameter']['rtsp'] \
                    or task_data['source']['parameter']['rtsp']['url'] == '':
                self._logger.warning('Task rtsp url is not found.')
                return

            url = task_data['source']['parameter']['rtsp']['url']
            pattern = re.compile(
                r"rtsp:\/\/(?:([^\s@\/]+?)[@])?([^\s\/:]+)(?:[:]([0-9]+))?(?:(\/[^\s?#]+)([?][^\s#]+)?)?([#]\S*)?",
                re.S)
            rtsp_ip = re.findall(pattern, url)
            rtsp_ip = rtsp_ip[0][1] if rtsp_ip and len(rtsp_ip[0]) > 1 and rtsp_ip[0][1] != '' else ''
        elif task_service == 'acs':
            # get camera ip from extra info if task service is acs
            camera_ip = extra_info['camera_config'] if 'camera_config' in extra_info else ''

        # get adam do4 info from extra info
        if 'adam_do4' not in extra_info or extra_info['adam_do4'] == '':
            self._logger.warning('Failed to find adam do4 from extra info')
            return
        else:
            channel_do4 = extra_info['adam_do4']
            try:
                channel_do4 = int(channel_do4)
            except Exception as e:
                self._logger.warning('Invalid adam DO4', e)
                return

            if not 1 <= channel_do4 <= 5:
                self._logger.warning('Cannot write DO4 channel out of range [1 - 5]')
                return

        adam_ip_port_ch = f'{adam_ip_port}:{channel_do4}'

        if adam_ip_port_ch not in self._adam_config_list_new:
            self._adam_config_list_new.append(adam_ip_port_ch)

        if adam_ip_port_ch not in self._ping_dict or self._ping_dict[adam_ip_port_ch] is None:
            self._ping_dict[adam_ip_port_ch] = 0

        if not adam.adam_status:
            # adam is error
            return

        is_win = platform.system() == "Windows"
        if task_service == 'mps':
            ping_str = 'ping ' + ("-w 100 -n 1 " if is_win else "-c 1 -w 1 ") + rtsp_ip
        elif task_service == 'acs':
            ping_str = 'ping ' + ("-w 100 -n 1 " if is_win else "-c 1 -w 1 ") + camera_ip

        try:
            subprocess.check_output(ping_str, shell=True)
        except:
            # ping error and ping error count plus 1
            if self._ping_dict[adam_ip_port_ch] < self._do_error_count:
                self._ping_dict[adam_ip_port_ch] += 1
                self._logger.warning(f'DO{channel_do4} ping error. count: {self._ping_dict[adam_ip_port_ch]}.')
                adam.write_channel_off(ch=channel_do4)
                adam.write_channel_on(ch=channel_do4)
        else:
            # ping ok
            self._ping_dict[adam_ip_port_ch] = 0
            adam.write_channel_off(ch=channel_do4)
            adam.write_channel_on(ch=channel_do4)

        if self._ping_dict[adam_ip_port_ch] > self._do_error_count - 1:
            # ping error count greater than 5
            if adam_ip_port_ch in self._thread_dict and self._thread_dict[adam_ip_port_ch].is_alive():
                # do4 is flashing
                return
            else:
                # start thread to make do4 flashing if thread is not alive
                self._thread_dict[adam_ip_port_ch] = threading.Thread(target=self.write_channel4_on_off,
                                                                      args=(adam, channel_do4, adam_ip_port))
                self._thread_dict[adam_ip_port_ch].setDaemon(True)
                self._thread_dict[adam_ip_port_ch].start()
                return
        else:
            if adam_ip_port_ch in self._thread_dict and self._thread_dict[adam_ip_port_ch].is_alive():
                if adam_ip_port_ch in self._thread_status_dict and self._thread_status_dict[adam_ip_port_ch]:
                    self._logger.info(f'DO{channel_do4} Get back to normal.')
                    self._thread_status_dict[adam_ip_port_ch] = False
            return

    def write_channel4_on_off(self, adam, channel_do4, adam_ip_port):
        # make do4 flashing when the camera ping error
        adam_ip_port_ch = f'{adam_ip_port}:{channel_do4}'

        if adam_ip_port_ch not in self._thread_status_dict or not self._thread_status_dict[adam_ip_port_ch]:
            self._thread_status_dict[adam_ip_port_ch] = True

        while True:
            if adam_ip_port_ch in self._adam_config_list_old and adam_ip_port_ch in self._thread_status_dict \
                    and self._thread_status_dict[adam_ip_port_ch]:
                adam.write_channel_on(ch=channel_do4)
                time.sleep(self._low_to_high_delay + 3.0)
                adam.write_channel_off(ch=channel_do4)
            else:
                # stop thread if task is deleted or camera error is recover
                self._ping_dict[adam_ip_port_ch] = 0
                break

    def face_dev_log_in_call(self):
        url = f'{self._atlas_api}/components/operation-maintenance/v1/users/sign_in'
        data = {
            'user': self._username,
            'password': self._password
        }
        res = requests.post(url, verify=False, json=data, timeout=5)
        return res

    def face_dev_get_mps_task_list(self):
        url = f'{self._atlas_api}/engine/media-process/v1/tasks?page_request.limit=100'
        headers = {
            'Authorization': self._token
        }
        res = requests.get(url, verify=False, timeout=5, headers=headers)
        return res

    def face_dev_get_acs_task_list(self):
        url = f'{self._atlas_api}/engine/access-control/v1/tasks?page_request.limit=100'
        headers = {
            'Authorization': self._token
        }
        res = requests.get(url, verify=False, timeout=5, headers=headers)
        return res
