import socket
import threading
import time


class Adam6000:

    def __init__(self, logger=None, adam_ip='10.0.0.1', adam_port=502, monitor_interval=2.0, do_error_count=5):
        self._logger = logger
        self._ip = adam_ip
        self._port = adam_port
        self._timeout_socket = 1.0
        self._unit = 1
        self._thread = None
        self._monitor_interval = monitor_interval
        self._do_error_count = do_error_count
        self._sock_alive = False
        self._loop_status = True
        self.adam_status = True

        self.loop_start()

    def write_channel_off(self, ch):
        """ Write data to force coil Off
            ch - coil number to set
        """
        val = 0x0000
        address = ch + 16
        reply = self._force_single_coil(address, val)

        self._logger.info(f'Write 0 to DO{ch}: (success: {reply[0]}, msg: {reply[1]}, reply: {reply[2]})')
        return reply[0]

    def write_channel_on(self, ch):
        """ Write data to force coil On
            ch    - coil number to set

            reply - bool: success or not
        """
        val = 0xff00
        address = ch + 16
        reply = self._force_single_coil(address, val)

        self._logger.info(f'Write 1 to DO{ch}: (success: {reply[0]}, msg: {reply[1]}, reply: {reply[2]})')
        return reply[0]

    def loop_stop(self):
        self._loop_status = False

    def loop_start(self):
        self._thread = threading.Thread(target=self.loop_forever)
        self._thread.setDaemon(True)
        self._thread.start()

    def loop_forever(self):
        time.sleep(5)
        keep_alive_count = 0
        while True:
            if not self._loop_status:
                time.sleep(10.0)
                if self._sock_alive:
                    self._sock.close()
                    self._sock_alive = False
                break

            if self._sock_alive:
                time.sleep(self._monitor_interval)
                try:
                    reply = self._adam_diagnosis()
                except Exception as e:
                    self._sock_alive = False
                    reply = False
                    self._logger.warning('Exception sending Modbus message by socket.', e)

                if reply:
                    if not self.adam_status and keep_alive_count > self._do_error_count:
                        self._logger.info('ADAM got back to normal.')
                    keep_alive_count = 0
                    self.adam_status = True
                else:
                    keep_alive_count += 1
                    if keep_alive_count > self._do_error_count:
                        self._logger.warning('ADAM error.')
                        self.adam_status = False
            else:
                self._connect_sock()
                time.sleep(1)

    def _connect_sock(self):
        try:
            self._sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self._sock.settimeout(self._timeout_socket)
            self._sock.connect((self._ip, self._port))
            self._sock_alive = True
            self._logger.info(f'TCP connected: {self._ip} ({self._port})')
        except:
            self._sock.close()
            self._sock_alive = False
            self._logger.info(f'TCP connect failed: {self._ip} ({self._port})')

    def _send_and_verify(self, command):
        """ send command to adam and verify reply
        """
        # convert to bytes
        msg = bytes(command)

        if not self._sock_alive:
            self._connect_sock()

        if self._sock_alive:
            try:
                self._sock.send(msg)
                reply = self._sock.recv(255)
            except Exception as e:
                self._sock_alive = False
                return 0, f'Exception sending Modbus message by socket. {e}', None
        else:
            return 0, 'Socket is not alive', None

        reply_data = [int(elem) for elem in reply]

        # verify that we have enough data
        if len(reply_data) < 6:
            return 0, f'Wrong response length ({len(reply_data)})', reply_data

        # verify transaction and protocol
        if reply_data[:4] != command[:4]:
            return 0, f'Wrong transaction or protocol {bytes(reply_data[:4]).hex()} != {command[:4].hex()}', reply_data

        data_size = reply_data[4] << 8
        data_size = data_size | reply_data[5]
        if len(reply_data[6:]) < data_size:
            return 0, 'Not enough data', reply_data

        return 1, 'ok', reply_data

    def _adam_diagnosis(self):
        command = self._get_command_head()
        dag_val = 0xfafa
        command.extend(self._get_command_body(0x08, 0, dag_val, self._unit))

        # send and verify response
        resp = self._send_and_verify(command)
        if resp[0] != 1:
            self._logger.warning(f'{resp[1]}')
            return False
        reply_data = resp[2]

        # verify unit number and command number and byte count
        if reply_data != command:
            self._logger.warning(f'Command and response should match {command} != {reply_data}')
            return False

        # success
        return True

    def _force_single_coil(self, start_address, force_data):
        """ Write data to force coil On or Off
            start_address - coil start address
            force_data    - value to force coil On(0xff00) or Off (0x0000)

            returns tuple of (int, str, array) where:
                item 1 = 1 for success, 0 for error
                item 2 = Error message or "ok" if success
                item 3 = raw response
        """
        command = self._get_command_head()
        command.extend(self._get_command_body(0x05, start_address, force_data, self._unit))

        # send and verify response
        resp = self._send_and_verify(command)
        if resp[0] != 1:
            return resp
        reply_data = resp[2]

        # verify unit number and command number and byte count
        if reply_data != command:
            return 0, f'Command and response should match {command} != {reply_data}', reply_data

        # success
        return 1, 'ok', reply_data

    @staticmethod
    def _get_command_head(transaction_id=0, protocol_id=0, length_field=6):
        t_id = transaction_id & 0x0000ffff
        p_id = protocol_id & 0x0000ffff
        length = length_field & 0x0000ffff
        return [t_id >> 8, t_id & 0xff, p_id >> 8, p_id & 0xff, length >> 8, length & 0xff]

    @staticmethod
    def _get_command_body(function_code, start_address, request_number, unit_id=1):
        fc = function_code & 0xff
        sa = start_address & 0x0000ffff
        rn = request_number & 0x0000ffff
        return [unit_id & 0xff, fc, sa >> 8, sa & 0xff, rn >> 8, rn & 0xff]
