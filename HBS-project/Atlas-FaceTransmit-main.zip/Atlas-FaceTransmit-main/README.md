# Installation

```
pip3 install -r requirements.txt
```

# Run

```
python3 app.py
```

# Test Sending Requests

```
pip3 install requests
```

POST request

modify ./jsons/fake_crowd_result.json

```
cd ./test_send_reqs
python3 post_req.py
```



Check if success by Adam's software:

- Adam/Apax. Net Utility for ADAM/APAX series

```
https://support.advantech.com/support/DownloadSRDetail_New.aspx?SR_ID=1-2AKUDB&Doc_Source=Download
```


