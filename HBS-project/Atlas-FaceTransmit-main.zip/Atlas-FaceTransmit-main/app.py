import json
import logging
import os
import platform
import threading

from flask import Flask, request
from waitress import serve

from adam import Adam6000
from monitor import Monitor

app = Flask(__name__)
app.config['LOW_TO_HIGH_DELAY'] = 3000
app.config['MONITOR_INTERVAL'] = 2000
app.config['DO_ERROR_COUNT'] = 5
app.config['ATLAS_API'] = 'https://172.31.254.100:38443'
app.config['ATLAS_USERNAME'] = 'admin'
app.config['ATLAS_PASSWORD'] = 'Atlas@2019'

fmt = "%(asctime)s - %(levelname)s - %(name)s : %(message)s"
logging.basicConfig(format=fmt)
logger = logging.getLogger('Atlas-FaceTransmit')
logger.setLevel(logging.DEBUG)

# Update config if config file exists
is_win = platform.system() == "Windows"
config_file = ('./config.json' if is_win else '/var/face/config.json')
if os.path.isfile(config_file):
    with open(config_file) as f:
        try:
            config = json.load(f)
            if config:
                app.config.update(config)
        except Exception as err:
            logger.warning('Read config file error', err)

adam6000_dict = {}  # adam_ip_port -> adam object
timer_dict = {}  # adam_ip_port_ch -> timer

try:
    low_to_high_delay = app.config['LOW_TO_HIGH_DELAY'] * 0.001
except Exception as err:
    low_to_high_delay = 3.0
    logger.warning('Invalid value LOW_TO_HIGH_DELAY use default value 3.0', err)

try:
    monitor_interval = app.config['MONITOR_INTERVAL'] * 0.001
except Exception as err:
    monitor_interval = 2.0
    logger.warning('Invalid value MONITOR_INTERVAL use default value 2.0', err)

monitor = Monitor(atlas_api=app.config['ATLAS_API'], atlas_user=app.config['ATLAS_USERNAME'],
                  atlas_password=app.config['ATLAS_PASSWORD'], logger=logger, adam_dict=adam6000_dict,
                  low_to_high_delay=low_to_high_delay, monitor_interval=monitor_interval,
                  do_error_count=app.config['DO_ERROR_COUNT'])


@app.route('/upload', methods=['POST'])
def upload():
    # read json data
    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
    except Exception as e:
        logger.warning('Received invalid json data', e)
        return '{"code": -1}'

    # check post data
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_FACE':
        logger.warning('task type is not TASK_TYPE_FACE')
        return '{"code": -1}'

    if 'capture_result' not in post_data or 'face' not in post_data['capture_result']:
        logger.warning('Invalid capture result')
        return '{"code": -1}'

    if 'extra_info' not in post_data:
        logger.warning('No found extra info from post data')
        return '{"code": -1}'

    if 'adam_config' not in post_data['extra_info'] or 'min_score' not in post_data['extra_info']:
        logger.warning('Invalid extra info')
        return '{"code": -1}'

    extra_info = post_data['extra_info']
    min_score = extra_info['min_score'] if 'min_score' in extra_info else 0
    adam_config = extra_info['adam_config'] if 'adam_config' in extra_info else ''
    do1_time = extra_info['adam_do1_time'] if 'adam_do1_time' in extra_info and extra_info[
        'adam_do1_time'] and extra_info['adam_do1_time'].isnumeric() else 0
    do2_time = extra_info['adam_do2_time'] if 'adam_do2_time' in extra_info and extra_info[
        'adam_do2_time'] and extra_info['adam_do2_time'].isnumeric() else 0
    do3_time = extra_info['adam_do3_time'] if 'adam_do3_time' in extra_info and extra_info[
        'adam_do3_time'] and extra_info['adam_do3_time'].isnumeric() else 0
    face_result = post_data['capture_result']['face']
    most_similar_user = face_result['most_similar_user'] if 'most_similar_user' in face_result else None
    most_similar_score = face_result['score'] if 'score' in face_result else 0
    user_card_id = most_similar_user['card_id'] if most_similar_user and 'card_id' in most_similar_user else ''

    try:
        min_score = float(min_score)
        most_similar_score = float(most_similar_score)
        do1_time = float(do1_time)
        do2_time = float(do2_time)
        do3_time = float(do3_time)
    except Exception as e:
        logger.warning('Invalid post data value', e)
        return '{"code": -1}'

    adam_config_list = adam_config.split(':')
    if adam_config_list[0] == '':
        logger.warning('Invalid adam ip')
        return '{"code": -1}'
    else:
        adam_ip = adam_config_list[0]
        adam_port = adam_config_list[1] if len(adam_config_list) > 1 and adam_config_list[1] != '' else 502

    try:
        adam_port = int(adam_port)
    except Exception as e:
        logger.warning('Invalid post data value', e)
        adam_port = 502

    if not 1 <= adam_port <= 65535:
        logger.warning('Port out of range [1 - 65535]')
        adam_port = 502

    adam_ip_port = f'{adam_ip}:{adam_port}'
    if adam_ip_port not in adam6000_dict or adam6000_dict[adam_ip_port] is None:
        try:
            adam6000_dict[adam_ip_port] = Adam6000(logger=logger, adam_ip=adam_ip, adam_port=adam_port,
                                                   monitor_interval=monitor_interval,
                                                   do_error_count=app.config['DO_ERROR_COUNT'])
        except Exception as e:
            logger.warning('Init adam6000 error', e)
            return '{"code": -1}'

    adam = adam6000_dict[adam_ip_port]

    try:
        # Check if recognize success
        if most_similar_score > 0 and most_similar_score >= min_score and most_similar_user:
            # get DO1 channel num and write 1 to DO1 channel
            if 'adam_do1' not in extra_info or extra_info['adam_do1'] == '':
                logger.warning('No found adam do1 from extra info')
                channel_do1 = ''
            else:
                channel_do1 = extra_info['adam_do1']
                try:
                    channel_do1 = int(channel_do1)
                except Exception as e:
                    logger.warning(f'Invalid adam DO1', e)
                else:
                    if 1 <= channel_do1 <= 5:
                        if 1 <= do1_time <= 180:
                            adam.write_channel_on(channel_do1)
                            set_timer_to_off(channel_do1, adam, adam_ip_port, do1_time)
                        else:
                            logger.warning(f'Cannot write channel 1 if channel 1 delay time out of range [1 - 180]')
                    else:
                        logger.warning(f'Cannot write DO{channel_do1} out of range [1 - 5]')

            # get DO2 channel num and write 1 to DO2 channel
            if 'adam_do2' not in extra_info or extra_info['adam_do2'] == '':
                logger.warning('No found adam do2 from extra info')
                channel_do2 = ''
            else:
                channel_do2 = extra_info['adam_do2']
                try:
                    channel_do2 = int(channel_do2)
                except Exception as e:
                    logger.warning(f'Invalid adam DO2', e)
                else:
                    if 1 <= channel_do2 <= 5:
                        if 1 <= do2_time <= 180:
                            adam.write_channel_on(channel_do2)
                            set_timer_to_off(channel_do2, adam, adam_ip_port, do2_time)
                        else:
                            logger.warning('Cannot write channel 2 if channel 2 delay time out of range [1 - 180]')
                    else:
                        logger.warning(f'Cannot write DO{channel_do2} out of range [1 - 5]')

            logger.info(f'Face data identified OK:{user_card_id} channel 1:DO{channel_do1} channel 2:DO{channel_do2}')
        else:
            # get DO3 channel and write 1 to DO3 channel
            if 'adam_do3' not in extra_info or extra_info['adam_do3'] == '':
                logger.warning('No found adam do3 from extra info')
                channel_do3 = ''
            else:
                channel_do3 = extra_info['adam_do3']
                try:
                    channel_do3 = int(channel_do3)
                except Exception as e:
                    logger.warning(f'Invalid adam DO3', e)
                else:
                    if 1 <= channel_do3 <= 5:
                        if 1 <= do3_time <= 180:
                            adam.write_channel_on(channel_do3)
                            set_timer_to_off(channel_do3, adam, adam_ip_port, do3_time)
                        else:
                            logger.warning('Cannot write channel 3 if channel 3 delay time out of range [1 - 180]')
                    else:
                        logger.warning(f'Cannot write DO{channel_do3} out of range [1 - 5]')

            logger.info(f'Face data identified NG: channel 3:DO{channel_do3}')

    except Exception as e:
        logger.warning(f'On error.', e)
        return '{"code": -1}'

    return '{"code": 0}'


def set_timer_to_off(ch, adam, adam_ip_port, high_to_low_delay):
    adam_ip_port_ch = f'{adam_ip_port}:{ch}'

    if adam_ip_port_ch in timer_dict and timer_dict[adam_ip_port_ch] is not None \
            and not timer_dict[adam_ip_port_ch].is_alive():
        timer_dict[adam_ip_port_ch] = None

    if adam_ip_port_ch not in timer_dict or timer_dict[adam_ip_port_ch] is None:
        timer_dict[adam_ip_port_ch] = threading.Timer(high_to_low_delay, adam.write_channel_off, (ch,))
        timer_dict[adam_ip_port_ch].start()
    else:
        timer_dict[adam_ip_port_ch].cancel()
        timer_dict[adam_ip_port_ch] = threading.Timer(high_to_low_delay, adam.write_channel_off, (ch,))
        timer_dict[adam_ip_port_ch].start()


if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=5012)
