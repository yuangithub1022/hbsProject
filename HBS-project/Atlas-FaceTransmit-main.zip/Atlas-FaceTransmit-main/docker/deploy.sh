#!/bin/bash
scp -r huawei@192.168.40.216:"/home/huawei/temp/frontend /home/huawei/temp/backend" /home/software/neu/temp/transfer
rm -rf /home/software/neu/temp/frontend/*
rm -rf /home/software/neu/temp/backend/*
mv /home/software/neu/temp/transfer/frontend/* /home/software/neu/temp/frontend
mv /home/software/neu/temp/transfer/backend/* /home/software/neu/temp/backend
/home/software/neu/temp/util.sh -c stop -t WEB_APP
/home/software/neu/temp/util.sh -c uninstall -t WEB_APP
docker build -t atlas_temp:1.0.0 /home/software/neu/temp



rm -rf /var/lib/docker/face/*
scp -P 10092 -r root@172.30.150.101:/home/hbs/face/source/* /var/lib/docker/face/source/
scp -P 10092 -r /var/lib/docker/face/atlas_face.1.0.0.tar.gz root@172.30.150.101:/home/hbs/face/
NEVS0FT_12#$

cd /var/lib/docker/face

cp config.json /var/lib/docker/config/face/

cp monitor.py /var/lib/docker/face/source
cp adam.py /var/lib/docker/face/source
cp app.py /var/lib/docker/face/source


/var/lib/docker/face/util.sh -c stop
/var/lib/docker/face/util.sh -c uninstall
  docker build -t atlas_face:1.0.0 /var/lib/docker/face
/var/lib/docker/face/util.sh -c start
  docker logs -f atlas_face

docker save atlas_face:1.0.0 | gzip > atlas_face.1.0.0.tar.gz
