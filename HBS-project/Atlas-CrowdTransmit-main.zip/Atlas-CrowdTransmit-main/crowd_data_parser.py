import re
import threading
import time

from flask import current_app as app

from adam import Adam6000
from adam_dict import adam6000_dict
from logger import logger

timer_dict = {}  # adam_ip_port_ch -> timer


class CrowdDataParser:
    def _get_adam_ip_port(self, extra_info):
        # check adam_config (ip and port)
        if 'adam_config' not in extra_info:
            logger.warning('adam_config not found in post data')
            return None

        adam_config = extra_info['adam_config'] if 'adam_config' in extra_info else ''
        adam_config_list = adam_config.split(':')

        if adam_config_list[0] == '':
            logger.warning('Invalid adam ip')
            return None
        else:
            adam_ip = adam_config_list[0]

        adam_port = int(adam_config_list[1]) if len(adam_config_list) > 1 and adam_config_list[1].isnumeric() else 502

        if not 1 <= adam_port <= 65535:
            logger.warning('Port out of range [1 - 65535]. Set to 502')
            adam_port = 502

        return adam_ip, adam_port

    def _write_do(self, adam_no, extra_info):
        res = self._get_adam_ip_port(extra_info)
        if not res:
            return False

        adam_ip, adam_port = res
        adam_ip_port = f'{adam_ip}:{adam_port}'
        if adam_ip_port not in adam6000_dict or adam6000_dict[adam_ip_port] is None:
            try:
                adam6000_dict[adam_ip_port] = Adam6000(adam_ip=adam_ip, adam_port=adam_port,
                                                       monitor_interval=app.config['MONITOR_INTERVAL'],
                                                       do_error_count=app.config['DO_ERROR_COUNT'])
            except Exception as e:
                logger.warning('Init adam6000 error', e)
                return False

        adam = adam6000_dict[adam_ip_port]

        if 1 <= adam_no <= 5:
            adam.write_channel_on(adam_no)
            if 'adam_always_on' in extra_info and extra_info['adam_always_on'] == '1':
                if self.crowd_type == 'CROWD_TYPE_RETENTION':
                    # get retention duration from extra_info
                    try:
                        adam_always_on_delay = float(extra_info['retention_duration'])
                    except:
                        logger.info('No duration can be found.')
                        return False
                elif self.crowd_type == 'CROWD_TYPE_DENSITY':
                    # get density interval from extra_info
                    try:
                        adam_always_on_delay = float(extra_info['density_interval'])
                    except:
                        logger.info('No interval can be found.')
                        return False

                if adam_always_on_delay > 0:
                    set_timer_to_off(adam_no, adam, adam_ip_port, adam_always_on_delay + 1.0)
                    return True
                else:
                    logger.info('Duration or interval is 0.')
                    return False

            # write 0 to DO
            if 'high_to_low_delay' in extra_info and extra_info['high_to_low_delay'].isnumeric():
                high_to_low_delay = int(extra_info['high_to_low_delay'])
            else:
                logger.info('high_to_low_delay not exist or not valid')
                high_to_low_delay = 5
            set_timer_to_off(adam_no, adam, adam_ip_port, high_to_low_delay)
        else:
            logger.warning('Cannot write DO channel out of range [1 - 5]')
            return False

        return True

    def parse(self, extra_info, crowd_data):
        pass


class IntrusionCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_INTRUSION'

    def parse(self, extra_info, crowd_data):
        try:
            interests = crowd_data['subclass']['intrusion']['interests']
        except:
            logger.info('No interests can be found.')
            return False

        for interest in interests:
            if 'direction' not in interest:
                return False

            direction = interest['direction']

            if direction not in ('FORWARD', 'REVERSE'):
                logger.info(f'Direction {direction} not supported')
                return False

            try:
                count = int(interest['count'])
            except Exception as e:
                logger.info(f'Cannot get count from crowd_data, {e}')
                return False

            if direction == 'FORWARD':
                if 'adam_forward' not in extra_info:
                    logger.info('adam_forward not found')
                    return False
                adam_forward = extra_info['adam_forward']
                try:
                    threshold, adam_no = map(int, adam_forward.split(','))
                except:
                    logger.info(f'adam_forward invalid: {adam_forward}')
                    return False
            else:
                if 'adam_reverse' not in extra_info:
                    logger.info('adam_reverse not found')
                    return False
                adam_reverse = extra_info['adam_reverse']
                try:
                    threshold, adam_no = map(int, adam_reverse.split(','))
                except:
                    logger.info(f'adam_reverse invalid: {adam_reverse}')
                    return False

            if count >= threshold:
                if not self._write_do(adam_no, extra_info):
                    logger.info(f'Received {direction} {self.crowd_type} data. '
                                f'Current {count} >= Threshold {threshold}. '
                                f'Failed to write to DO{adam_no}')
                    return False
                logger.info(f'Received {direction} {self.crowd_type} data. '
                            f'Current {count} >= Threshold {threshold}. '
                            f'Wrote to DO{adam_no}')

        return True


class RetentionCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_RETENTION'

    def parse(self, extra_info, crowd_data):
        # get count from crowd_data
        try:
            count = int(crowd_data['subclass']['retention']['count'])
        except:
            logger.info('No count can be found.')
            return False

        logger.info(f'Received {self.crowd_type} data. Current {count}.')

        # compare each retention key in extra_info
        for key, value in extra_info.items():
            if not re.match(r'retention_[0-3]', key):
                continue

            try:
                threshold, adam_no = map(int, value.split(','))
            except:
                logger.info(f'Invalid value of {key}: {value}')
                return False

            if count >= threshold:
                if not self._write_do(adam_no, extra_info):
                    logger.info(f'Retention level {int(key[-1]) + 1}. '
                                f'Current {count} >= Threshold {threshold}. '
                                f'Failed to write to DO{adam_no}.')
                    return False
                logger.info(f'Retention level {int(key[-1]) + 1}. '
                            f'Current {count} >= Threshold {threshold}. '
                            f'Wrote to DO{adam_no}')
            time.sleep(0.1)

        return True


class DensityCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_DENSITY'

    def parse(self, extra_info, crowd_data):
        # get count from crowd_data
        try:
            percent = int(crowd_data['subclass']['density']['percent'])
        except:
            logger.info('No percent can be found.')
            return False

        logger.info(f'Received {self.crowd_type} data. Current {percent}')

        # compare each retention key in extra_info
        for key, value in extra_info.items():
            if not re.match(r'density_[0-3]', key):
                continue

            try:
                threshold, adam_no = map(int, value.split(','))
            except:
                logger.info(f'Invalid value of {key}: {value}')
                return False

            if percent >= threshold:
                if not self._write_do(adam_no, extra_info):
                    logger.info(f'Density level {int(key[-1]) + 1}. '
                                f'Current {percent} >= Threshold {threshold}. '
                                f'Failed to write to DO{adam_no}.')
                    return False
                logger.info(f'Density level {int(key[-1]) + 1}. '
                            f'Current {percent} >= Threshold {threshold}. '
                            f'Wrote to DO{adam_no}')
            time.sleep(0.1)

        return True


class CrowdDataParserFactory:
    @staticmethod
    def create_parser(crowd_type):
        crowd_type = crowd_type.split('_')[2]
        crowd_type = crowd_type[0] + crowd_type[1:].lower()
        class_name = f'{crowd_type}CrowdDataParser'
        try:
            parser = globals()[class_name]()
            return parser
        except Exception as e:
            logger.info(f'Failed to create instance of class {class_name}. {e}')
            return None


def set_timer_to_off(ch, adam, adam_ip_port, high_to_low_delay):
    adam_ip_port_ch = f'{adam_ip_port}:{ch}'

    if adam_ip_port_ch in timer_dict and timer_dict[adam_ip_port_ch] is not None \
            and not timer_dict[adam_ip_port_ch].is_alive():
        timer_dict[adam_ip_port_ch] = None

    if adam_ip_port_ch not in timer_dict or timer_dict[adam_ip_port_ch] is None:
        timer_dict[adam_ip_port_ch] = threading.Timer(high_to_low_delay, adam.write_channel_off, (ch,))
        timer_dict[adam_ip_port_ch].start()
    else:
        timer_dict[adam_ip_port_ch].cancel()
        timer_dict[adam_ip_port_ch] = threading.Timer(high_to_low_delay, adam.write_channel_off, (ch,))
        timer_dict[adam_ip_port_ch].start()






