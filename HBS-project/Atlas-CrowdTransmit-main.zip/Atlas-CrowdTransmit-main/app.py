import json
import os
import platform

from flask import Flask, request
from waitress import serve

from crowd_data_parser import CrowdDataParserFactory
from logger import logger
from monitor import Monitor

# Init app and default config
app = Flask(__name__)
app.config['LOW_TO_HIGH_DELAY'] = 3000
app.config['MONITOR_INTERVAL'] = 2000
app.config['DO_ERROR_COUNT'] = 5
app.config['ATLAS_API'] = 'https://172.31.254.100:38443'
app.config['ATLAS_USERNAME'] = 'admin'
app.config['ATLAS_PASSWORD'] = 'Atlas@2019'


# Update config if config file exists
base_dir = '.' if platform.system() == 'Windows' else '/var/crowd'
config_file = f'{base_dir}/config.json'

if os.path.isfile(config_file):
    with open(config_file) as f:
        try:
            config = json.load(f)
            if config:
                app.config.update(config)
        except Exception as err:
            logger.warning('Read config file error', err)

try:
    app.config['LOW_TO_HIGH_DELAY'] *= 0.001
except Exception as err:
    app.config['LOW_TO_HIGH_DELAY'] = 5.0
    logger.warning('Invalid value of LOW_TO_HIGH_DELAY, Using default value 5.0', err)

try:
    app.config['MONITOR_INTERVAL'] *= 0.001
except Exception as err:
    app.config['MONITOR_INTERVAL'] = 2.0
    logger.warning('Invalid value MONITOR_INTERVAL use default value 2.0', err)

monitor = Monitor(atlas_api=app.config['ATLAS_API'], atlas_user=app.config['ATLAS_USERNAME'],
                  atlas_password=app.config['ATLAS_PASSWORD'], low_to_high_delay=app.config['LOW_TO_HIGH_DELAY'],
                  monitor_interval=app.config['MONITOR_INTERVAL'], do_error_count=app.config['DO_ERROR_COUNT'])


# @app.route('/crowd/read', methods=['GET'])
# def read_do():
#     """ request - GET {'channel': channel number}
#
#         returns str:
#             '{"code": 0}' for success, '{"code": -1}' for error
#     """
#
#     # read json data
#     try:
#         get_data = request.data.decode('utf-8')
#         get_data = json.loads(get_data)
#     except:
#         logger.warning('Received Invalid json data')
#         return '{"code": -1}'
#
#     # get channel num
#     try:
#         channel = int(get_data['channel'])
#     except:
#         return '{"code": -1}'
#
#     # read and return result
#     reply = (0, '', '')
#     if 0 <= channel <= 5:
#         reply = adam6000.read_digital_output(channel)
#     logger.info(f'Read DO{channel}: (success: {reply[0]}, msg: {reply[1]}, reply: {reply[2]})')
#     return '{"code": -1}' if reply[0] == 0 else '{"code": 0}'


@app.route('/upload', methods=['POST'])
def upload():
    # read json data
    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
    except Exception as e:
        logger.warning(f'Received invalid json data, {e}')
        return '{"code": -1}'

    # # for test
    # global i
    # with open(f'data{i}.json', 'w', encoding='utf-8') as f:
    #     json.dump(post_data, f, ensure_ascii=False, indent=4)
    #     i += 1

    # check if post data is crowd data
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_CROWD':
        logger.warning('task_type is not TASK_TYPE_CROWD')
        return '{"code": -1}'

    # get crowd data
    try:
        crowd_data = post_data['capture_result']['crowd']
    except Exception as e:
        logger.warning(f'Invalid capture result, {e}')
        return '{"code": -1}'

    # check crowd type
    if 'type' not in crowd_data:
        logger.warning('No crowd type in post data')
        return '{"code": -1}'

    crowd_type = crowd_data['type']

    if crowd_type == 'CROWD_TYPE_UNKNOWN':
        return '{"code": -1}'

    supported_crowd_types = ['CROWD_TYPE_DENSITY', 'CROWD_TYPE_RETENTION', 'CROWD_TYPE_INTRUSION']

    if crowd_type not in supported_crowd_types:
        # logger.info(f'Received {crowd_type} data')
        # logger.warning(f'Only the following crowd types are supported: {supported_crowd_types}')
        return '{"code": -1}'

    # get extra_info
    if 'extra_info' not in post_data:
        logger.warning('extra_info not found in post data')
        return '{"code": -1}'

    # parse crowd data
    extra_info = post_data['extra_info']
    crowd_data_parser = CrowdDataParserFactory.create_parser(crowd_type)
    is_success = crowd_data_parser.parse(extra_info, crowd_data)
    if not is_success:
        return '{"code": -1}'

    return '{"code": 0}'


if __name__ == "__main__":
    serve(app, host='0.0.0.0', port=5011)
