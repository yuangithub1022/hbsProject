class AdamDict:
    instance = None

    def __init__(self):
        if AdamDict.instance is None:
            AdamDict.instance = {}

# adam_ip_port -> adam object
AdamDict()
adam6000_dict = AdamDict.instance