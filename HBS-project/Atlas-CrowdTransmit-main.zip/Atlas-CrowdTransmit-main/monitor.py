import platform
import re
import subprocess
import threading
import time
import warnings

import requests

from adam import Adam6000
from adam_dict import adam6000_dict
from logger import logger


class Monitor:
    warnings.filterwarnings('ignore', message='Unverified HTTPS request')

    def __init__(self, atlas_api=None, atlas_user='admin', atlas_password='Atlas@2019',
                 low_to_high_delay=5.0, monitor_interval=2.0, do_error_count=5):
        self._atlas_api = atlas_api
        self._username = atlas_user
        self._password = atlas_password
        self._thread = None  # monitor thread
        self._thread_dict = {}  # ch -> adam_ip_port_ch -> thread
        self._thread_status_dict = {}  # adam_ip_port_ch -> bool
        self._ping_dict = {}  # adam_ip_port_ch -> ping
        self._token = self.get_token()
        self._low_to_high_delay = low_to_high_delay
        self._monitor_interval = monitor_interval
        self._do_error_count = do_error_count
        self._adam_config_list_new = []
        self._adam_config_list_old = []
        self._task_id_dict = {}  # task_id -> task_version

        self.monitor_start()

    def monitor_start(self):
        self._thread = threading.Thread(target=self.monitor_loop)
        self._thread.setDaemon(True)
        self._thread.start()

    def monitor_loop(self):
        while True:
            if not self._token:
                self._token = self.get_token()

            if self._token:
                task_list = self.get_task_list()
                self._adam_config_list_new = []
                for task in task_list:
                    thread = threading.Thread(target=self.check_task, args=(task,))
                    thread.setDaemon(True)
                    thread.start()
                    time.sleep(0.1)

            time.sleep(self._monitor_interval)

            if not self._adam_config_list_old:
                self._adam_config_list_old = self._adam_config_list_new

            if self._adam_config_list_old != self._adam_config_list_new:
                for value in self._adam_config_list_old:
                    if value not in self._adam_config_list_new:
                        thread = threading.Thread(target=self.clear_ch_no_use, args=(value,))
                        thread.setDaemon(True)
                        thread.start()

                adam_info_list = []
                for value in self._adam_config_list_new:
                    adam_info_list.append(value[:-2])  # adam_info_list -> adam_ip_port

                for key in adam6000_dict:
                    if key not in adam_info_list and adam6000_dict[key]:
                        thread = threading.Thread(target=self.clear_adam_no_use, args=(key,))
                        thread.setDaemon(True)
                        thread.start()

                self._adam_config_list_old = self._adam_config_list_new

    def clear_ch_no_use(self, adam_info):
        adam_ip_port = adam_info[:-2]
        adam_ch = int(adam_info[-1])
        time.sleep(self._monitor_interval)
        adam6000_dict[adam_ip_port].write_channel_off(ch=adam_ch)

    def clear_adam_no_use(self, adam_ip_port):
        wait_all_ch_off = self._monitor_interval + 4
        time.sleep(wait_all_ch_off)
        adam6000_dict[adam_ip_port].loop_stop()
        adam6000_dict[adam_ip_port] = None

    def get_token(self):
        # make login call
        try:
            res = self.face_dev_log_in_call()
        except Exception as e:
            logger.warning(f'Cannot make the login call, {e}.')
            return ''

        try:
            res_data = res.json()
        except Exception as e:
            logger.warning(f'Received invalid json data, {e}.')
            return ''

        if 'token' not in res_data or not res_data['token']:
            logger.warning('No valid token')
            return ''
        else:
            logger.info('Get token success')
            return res_data['token']

    def get_task_list(self):
        # get task list
        try:
            res = self.face_dev_get_task_list()
        except Exception as e:
            logger.warning(f'Cannot get the task list, {e}.')
            return []

        try:
            res_data = res.json()
        except Exception as e:
            logger.warning(f'Cannot get task list from response, {e}')
            return []

        if 'tasks' not in res_data or not res_data['tasks']:
            logger.warning('No valid task_list')
            return []
        else:
            return res_data['tasks']

    def check_task(self, task_data):
        # check task type
        if 'type' not in task_data['task'] or task_data['task']['type'] != 'TASK_TYPE_CROWD':
            return

        if 'type' not in task_data['source'] or task_data['source']['type'] != 'VN_RTSP':
            return

        # check extra info
        if 'extra_info' not in task_data:
            return

        extra_info = task_data['extra_info']

        # get task id and version
        task_id = task_data['task_id'] if 'task_id' in task_data else ''
        task_version = extra_info['task_version'] if 'task_version' in extra_info else '0'

        # get adam ip and port
        adam_config = extra_info['adam_config'] if 'adam_config' in extra_info else ''
        adam_config_list = adam_config.split(':')
        if adam_config_list[0] == '':
            logger.warning('Invalid adam ip')
            return
        else:
            adam_ip = adam_config_list[0]

        adam_port = int(adam_config_list[1]) if len(adam_config_list) > 1 and adam_config_list[1].isnumeric() else 502

        if not 1 <= adam_port <= 65535:
            logger.warning('Port out of range [1 - 65535]')
            adam_port = 502

        # get adam object
        adam_ip_port = f'{adam_ip}:{adam_port}'
        if adam_ip_port not in adam6000_dict or adam6000_dict[adam_ip_port] is None:
            try:
                adam6000_dict[adam_ip_port] = Adam6000(adam_ip=adam_ip, adam_port=adam_port,
                                                       monitor_interval=self._monitor_interval,
                                                       do_error_count=self._do_error_count)
            except Exception as e:
                logger.warning('Init adam6000 error', e)
                return

        adam = adam6000_dict[adam_ip_port]

        try:
            task_version = int(task_version)
        except Exception as e:
            logger.warning('Invalid task_version', e)
            task_version = 0

        if task_id not in self._task_id_dict:
            # write relay channel on
            adam.write_channel_on(0)
            self._task_id_dict[task_id] = task_version
        else:
            if self._task_id_dict[task_id] < task_version:
                adam.write_channel_on(0)
                self._task_id_dict[task_id] = task_version

        # get RTSP ip from url
        if 'url' not in task_data['source']['parameter']['rtsp'] or not task_data['source']['parameter']['rtsp']['url']:
            logger.warning('Task rtsp url is not found.')
            return

        url = task_data['source']['parameter']['rtsp']['url']
        pattern = re.compile(
            r'rtsp:\/\/(?:([^\s@\/]+?)[@])?([^\s\/:]+)(?:[:]([0-9]+))?(?:(\/[^\s?#]+)([?][^\s#]+)?)?([#]\S*)?', re.S)
        rtsp_ip = re.findall(pattern, url)
        if rtsp_ip and len(rtsp_ip[0]) > 1 and rtsp_ip[0][1]:
            rtsp_ip = rtsp_ip[0][1]
        else:
            logger.warning(f'RTSP IP not found.')
            return

        # get malfunction info
        if 'malfunction_enable' not in extra_info or extra_info['malfunction_enable'] != 'true':
            return

        if 'malfunction' not in extra_info:
            logger.warning('"malfunction not in extra_info')
            return

        try:
            do_channel = int(extra_info['malfunction'])
        except Exception as e:
            logger.warning(f'extra_info["malfunction"]: {extra_info["malfunction"]} not valid, {e}')
            return

        # check if out of range
        if not 1 <= do_channel <= 5:
            logger.warning(f'Cannot write to DO{do_channel}: out of range [1 - 5]')
            return

        adam_ip_port_ch = f'{adam_ip_port}:{do_channel}'

        if adam_ip_port_ch not in self._adam_config_list_new:
            self._adam_config_list_new.append(adam_ip_port_ch)

        if adam_ip_port_ch not in self._ping_dict or self._ping_dict[adam_ip_port_ch] is None:
            self._ping_dict[adam_ip_port_ch] = 0

        if not adam.adam_status:
            return

        is_win = platform.system() == "Windows"
        ping_str = f'ping {"-w 100 -n 1" if is_win else "-c 1 -w 1"} {rtsp_ip}'
        try:
            subprocess.check_output(ping_str, shell=True)
        except:
            # ping error and ping error count plus 1
            if self._ping_dict[adam_ip_port_ch] < self._do_error_count:
                self._ping_dict[adam_ip_port_ch] += 1
                logger.warning(f'DO{do_channel} ping {rtsp_ip} error. count: {self._ping_dict[adam_ip_port_ch]}.')
                adam.write_channel_off(ch=do_channel)
                adam.write_channel_on(ch=do_channel)

        else:
            self._ping_dict[adam_ip_port_ch] = 0
            adam.write_channel_off(ch=do_channel)
            adam.write_channel_on(ch=do_channel)

        if self._ping_dict[adam_ip_port_ch] >= self._do_error_count:
            if adam_ip_port_ch in self._thread_dict and self._thread_dict[adam_ip_port_ch].is_alive():
                # do4 is flashing
                return

            else:
                # if 'high_to_low_delay' in extra_info and extra_info['high_to_low_delay'].isnumeric():
                #     high_to_low_delay = int(extra_info['high_to_low_delay'])
                # else:
                #     high_to_low_delay = 5
                high_to_low_delay = 3
                self._thread_dict[adam_ip_port_ch] = threading.Thread(target=self.write_channel_on_off,
                                                                      args=(adam, do_channel, adam_ip_port,
                                                                            high_to_low_delay))
                self._thread_dict[adam_ip_port_ch].setDaemon(True)
                self._thread_dict[adam_ip_port_ch].start()

                return
        else:
            if adam_ip_port_ch in self._thread_dict and self._thread_dict[adam_ip_port_ch].is_alive():
                if adam_ip_port_ch in self._thread_status_dict and self._thread_status_dict[adam_ip_port_ch]:
                    logger.info(f'Malfunction channel:DO{do_channel} Get back to normal.')
                    self._thread_status_dict[adam_ip_port_ch] = False
            return

    def write_channel_on_off(self, adam, channel_do, adam_ip_port, high_to_low_delay):
        # make do4 flashing when the camera ping error
        adam_ip_port_ch = f'{adam_ip_port}:{channel_do}'

        if adam_ip_port_ch not in self._thread_status_dict or not self._thread_status_dict[adam_ip_port_ch]:
            self._thread_status_dict[adam_ip_port_ch] = True

        while True:
            if adam_ip_port_ch in self._adam_config_list_old and adam_ip_port_ch in self._thread_status_dict \
                    and self._thread_status_dict[adam_ip_port_ch]:
                adam.write_channel_on(ch=channel_do)
                time.sleep(self._low_to_high_delay + high_to_low_delay)
                adam.write_channel_off(ch=channel_do)
            else:
                # stop thread if task is deleted or camera error is recover
                self._ping_dict[adam_ip_port_ch] = 0
                break

    def face_dev_log_in_call(self):
        url = f'{self._atlas_api}/components/operation-maintenance/v1/users/sign_in'
        data = {
            'user': self._username,
            'password': self._password
        }
        res = requests.post(url, verify=False, json=data, timeout=5)
        return res

    def face_dev_get_task_list(self):
        url = f'{self._atlas_api}/engine/media-process/v1/tasks?page_request.limit=100'
        headers = {
            'Authorization': self._token
        }
        res = requests.get(url, verify=False, timeout=5, headers=headers)
        return res
