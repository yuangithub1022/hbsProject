#!/bin/bash
scp -P 10092 -r root@172.30.150.101:"/home/hbs/crowd/source" /var/lib/docker/crowd/transfer
rm -rf /var/lib/docker/crowd/source/*
mv /var/lib/docker/crowd/transfer/source/*  /var/lib/docker/crowd/source
/var/lib/docker/crowd/util.sh -c stop
/var/lib/docker/crowd/util.sh -c uninstall
docker build -t atlas_crowd:1.0.0 /var/lib/docker/crowd/
/var/lib/docker/crowd/util.sh -c start