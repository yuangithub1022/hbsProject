#!/bin/bash

AUTO_START_FILE=/var/lib/docker/APPPreInstall/app_autostart.sh

usage() {
    echo
    echo -e "usage: $(basename "$0") -c command"
    echo -e "[M]\t-c  : command = install | uninstall | start | stop"
    echo -e "M=mandatory, O=optional"
    echo
    exit 1
}

parse_args() {
	# global variable
	while getopts "c:h" arg; do
		case $arg in
			c) readonly cmd="$OPTARG";;
			h) usage;;
			?) usage;;
		esac
	done

	[[ $cmd != "install" && $cmd != "uninstall" && $cmd != "start" && $cmd != "stop" ]] && usage
}

install() {
    docker load -i atlas_crowd.1.0.0.tar.gz
    write_to_auto_start
}

write_to_auto_start()
{

    if [ ! -f "$AUTO_START_FILE" ] ; then
        return
    fi

    DIR="$( cd "$( dirname "$0" )" && pwd )"

    if grep -q "${DIR}/util.sh -c start" "$AUTO_START_FILE"; then
        return
    fi

    sed -i "/user_custom_func(){/a\ \ \ \ ${DIR}/util.sh -c start" $AUTO_START_FILE

 }

uninstall() {
    docker rmi atlas_crowd:1.0.0
    del_auto_start_commands
}

del_auto_start_commands()
{
    if [ ! -f "$AUTO_START_FILE" ] ; then
        return
    fi

    DIR="$( cd "$( dirname "$0" )" && pwd )"

    local command="${DIR}/util.sh -c start"

    sed -i "\:${command}:d" $AUTO_START_FILE
}

start() {
    docker run -p 5011:5011 \
               -v /var/lib/docker/crowd/config:/var/crowd \
               --name=atlas_crowd \
               --log-opt max-size=1m \
               --log-opt max-file=3 \
               -d atlas_crowd:1.0.0
    docker logs atlas_crowd
}

stop() {
    docker stop atlas_crowd
    docker rm atlas_crowd
}

main() {
    parse_args "$@"
    [[ $cmd == "install" ]] && install
    [[ $cmd == "uninstall" ]] && uninstall
    [[ $cmd == "start" ]] && start
    [[ $cmd == "stop" ]] && stop
}

main "$@"
