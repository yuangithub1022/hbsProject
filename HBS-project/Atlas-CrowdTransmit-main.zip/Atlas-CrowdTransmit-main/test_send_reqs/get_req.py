# usage: python get_req.py 1

# importing the requests library
import requests
import sys

# defining the api-endpoint
API_ENDPOINT = 'http://59.166.163.11:5011/crowd/read'
  

# data to be sent to api 
data = {
    'channel': 1
}
  
# sending post request and saving response as response object
r = requests.get(url=API_ENDPOINT, json=data)
# extracting response text

print(f'The response is: {r.text}')
