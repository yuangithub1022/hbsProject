# importing the requests library
import requests
import json
from tkinter import Tk
from tkinter.filedialog import askopenfilename

Tk().withdraw()  # we don't want a full GUI, so keep the root window from appearing
file_location = askopenfilename()  # open the dialog GUI

# defining the api-endpoint
API_ENDPOINT = "http://localhost:5011/upload"

# data to be sent to api
with open(file_location) as json_file:
    data = json.load(json_file)


# sending post request and saving response as response object
r = requests.post(url=API_ENDPOINT, json=data)
# extracting response text
print(f'The response is: {r.text}')

