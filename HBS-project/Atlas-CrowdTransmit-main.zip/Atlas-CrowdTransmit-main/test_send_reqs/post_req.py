# importing the requests library
import requests
import json

# defining the api-endpoint
API_ENDPOINT = "http://localhost:5011/crowd/upload"

# data to be sent to api
with open('../jsons/area_density1.json') as json_file:
    data = json.load(json_file)


# sending post request and saving response as response object
r = requests.post(url=API_ENDPOINT, json=data)
# extracting response text
print(f'The response is: {r.text}')

