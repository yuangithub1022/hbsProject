import subprocess


def get_bcc(arr):
    bcc = 0
    for elem in arr:
        bcc ^= elem
    return bcc


def set_rs485_send():
    try:
        subprocess.run('./my_memctrl_app 1 0x1F0000f4 4 0x00001d00'.split())
        subprocess.run('./my_memctrl_app 1 0x12140400 4 0x00000010'.split())
        subprocess.run('./my_memctrl_app 1 0x12140040 4 0x00000010'.split())
    except:
        pass


def set_rs485_receive():
    try:
        subprocess.run('./my_memctrl_app 1 0x1F0000f4 4 0x00001d02'.split())
        subprocess.run('./my_memctrl_app 1 0x12140400 4 0x00000000'.split())
        subprocess.run('./my_memctrl_app 1 0x12140040 4 0x00000000'.split())
    except:
        pass
