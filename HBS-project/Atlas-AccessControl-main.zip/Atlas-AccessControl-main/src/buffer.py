import queue
from src.env import CAPTURE_TIME


class Buffer:
    def __init__(self, maxsize=50):
        self.maxsize = maxsize
        self.timeout = 0.02
        self.buffer = queue.Queue()

    def add(self, item):
        if self.buffer.qsize() > self.maxsize:
            try:
                self.buffer.get(block=True, timeout=self.timeout)
            except queue.Empty:
                pass

        self.buffer.put(item, block=False)

    def get(self, time_limit=0):
        if self.buffer.empty():
            return None

        while True:
            try:
                item = self.buffer.get(block=True, timeout=self.timeout)
                if item[CAPTURE_TIME] >= time_limit:
                    return item
            except queue.Empty:
                return None
