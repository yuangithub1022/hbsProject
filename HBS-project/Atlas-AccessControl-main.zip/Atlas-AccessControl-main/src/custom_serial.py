import serial
import time
import threading
from src.utils import set_rs485_send, set_rs485_receive

SERIAL_LOG_INFO = 0x01
SERIAL_LOG_ERR = 0x02


class Ser:
    """serial class,use library: pyserial"""
    def __init__(self):
        # default serial
        self.serial = serial.Serial()

        # serial receive threading
        self._thread = None
        self.serial_alive = False

        self._on_message = None
        self._on_log = None

        self._callback_mutex = threading.RLock()
        self._open_mutex = threading.Lock()

    def loop_start(self):
        self._thread = threading.Thread(target=self.loop_forever)
        self._thread.setDaemon(True)
        self._thread.start()

    def loop_forever(self):
        while True:
            if not self.serial_alive:
                with self._open_mutex:
                    try:
                        self._open_serial()
                    except:
                        time.sleep(1)

            if self.serial_alive:
                while True:
                    try:
                        b = self.serial.read(self.serial.in_waiting)
                        if not b:
                            break
                        self._easy_log(SERIAL_LOG_INFO, 'Serial receive message: %s', b.hex())
                        self._handle_on_message(b)
                        time.sleep(0.01)
                    except serial.SerialException:
                        self.serial_alive = False
                        break

    def _open_serial(self):
        """try to open the serial"""
        if self.serial.port and self.serial.baudrate:
            try:
                if self.serial.isOpen():
                    self._close_serial()
                self.serial.open()
            except serial.SerialException as e:
                self._easy_log(SERIAL_LOG_ERR, "Open serial error!!! %s", e)
                raise
            else:
                self.serial_alive = True
                self._easy_log(SERIAL_LOG_INFO, "Open serial success: %s / %s", self.serial.port, self.serial.baudrate)
        else:
            self._easy_log(SERIAL_LOG_ERR, "Port is not setting!!!")

    def _close_serial(self):
        try:
            self.serial.close()
            self.serial_alive = False
        except serial.SerialException as e:
            self._easy_log(SERIAL_LOG_ERR, "Close serial error!!! %s", e)

    @property
    def on_message(self):
        """ If implemented, called when the serial has receive message.
        Defined to allow receive.

        """
        return self._on_message

    @on_message.setter
    def on_message(self, func):
        with self._callback_mutex:
            self._on_message = func

    def _handle_on_message(self, message):
        """serial receive message handle"""
        self.on_message(message)

    def on_send(self, msg):
        """send msg,
        msg: type of bytes or str"""
        with self._callback_mutex:
            if msg:
                if isinstance(msg, bytes):
                    self.serial.write(msg)
                if isinstance(msg, str):
                    self.serial.write(msg.encode('utf-8'))
                self._easy_log(SERIAL_LOG_INFO, "Serial send message: %s", msg.hex())

    @property
    def on_log(self):
        """If implemented, called when the serial has log information.
        Defined to allow debugging."""
        return self._on_log

    @on_log.setter
    def on_log(self, func):
        """ Define the logging callback implementation.

        Expected signature is:
            log_callback(level, buf)

        level:      gives the severity of the message and will be one of
                    SERIAL_LOG_INFO, SERIAL_LOG_NOTICE, SERIAL_LOG_WARNING,
                    SERIAL_LOG_ERR, and SERIAL_LOG_DEBUG.
        buf:        the message itself
        """
        self._on_log = func

    def _easy_log(self, level, fmt, *args):
        if self.on_log:
            buf = fmt % args
            try:
                self.on_log(level, buf)
            except Exception:
                pass


class Serial:
    def __init__(self, app):
        self.ser = Ser()
        self.delay = 0
        if app:
            self.init_app(app)

    def init_app(self, app):
        self.ser.serial.timeout = app.config.get("SERIAL_TIMEOUT")
        self.ser.serial.port = app.config.get("SERIAL_PORT")
        self.ser.serial.baudrate = app.config.get("SERIAL_BAUDRATE")
        self.ser.serial.bytesize = app.config.get("SERIAL_BYTESIZE")
        self.ser.serial.parity = app.config.get("SERIAL_PARITY")
        self.ser.serial.stopbits = app.config.get("SERIAL_STOPBITS")
        self.delay = app.config.get("SERIAL_DELAY")
        set_rs485_receive()

        # try open serial
        self.ser.loop_start()

    def on_message(self):
        """serial receive message use decorator
        use：
            @serial.on_message()
            def handle_message(msg):
                print("serial receive message：", msg)
        """
        def decorator(handler):
            self.ser.on_message = handler
            return handler
        return decorator

    def on_send(self, msg):
        """serial send message
        use：
            serial.on_send("send a message to serial")
        """
        set_rs485_send()
        self.ser.on_send(msg)
        time.sleep(self.delay)
        set_rs485_receive()

    def on_log(self):
        """logging
        use：
            serial.on_log()
            def handle_logging(level, info)
                print(info)
        """
        def decorator(handler):
            self.ser.on_log = handler
            return handler
        return decorator
