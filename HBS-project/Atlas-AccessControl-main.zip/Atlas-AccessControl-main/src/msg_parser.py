from src import utils
from src.env import CAMERA_NO, CARD_ID


class MessageParser:
    def __init__(self, num_per_req=5, id_info_size=65):
        # message info
        self.STX = 0x02
        self.CMD = 0x31
        self.ETX = 0x03

        # settings
        self.num_per_trans = num_per_req
        self.id_info_size = id_info_size

    def respond(self, message, buffer, time_limit):
        """ response base on message and buffer
        """
        if message['cmd'] != self.CMD:
            return None

        response = []
        count = 0

        # add all available id info
        for i in range(self.num_per_trans):
            item = buffer.get(time_limit)
            if item is None:
                break
            response += self._data_obj_to_arr(item)
            count += 1

        # add count to the front
        response = [count] + response

        # add prefix [STX(1Byte), LEN(2Byte),CMD(1Byte)]
        if 1 + len(response) <= 255:
            prefix = [self.STX, 0, 1 + len(response), self.CMD]
        else:
            prefix = [self.STX, (1 + len(response)) // 256, (1 + len(response)) % 256, self.CMD]

        # add suffix
        bcc = utils.get_bcc(prefix[1:] + response)
        suffix = [bcc, self.ETX]

        return bytes(prefix + response + suffix)

    def parse(self, message):
        if message == b'\x02\x00\x01\x31\x30\x03':
            return {'cmd': self.CMD, 'data': ''}

        return {'cmd': None, 'data': message}

    def _data_obj_to_arr(self, data_obj):
        identified = False if data_obj[CARD_ID] is None else True

        # parse id info into binary format
        arr = [0x20] * self.id_info_size
        arr[0] = data_obj[CAMERA_NO]

        if identified:
            for i in range(len(data_obj[CARD_ID])):
                arr[1 + i] = ord(data_obj[CARD_ID][i])
        else:
            arr[1:5] = [0xFF, 0xFF, 0xFF, 0xFF]

        # todo: test
        # return [0xFF, arr[0], 0xFF] + arr
        return arr


if __name__ == '__main__':
    # test parse function
    message_parser = MessageParser()
    msg = b'\x02\x00\x0110\x03'
    data = message_parser.parse(msg)
    print(data)
    data = message_parser.parse(b'\x02\x00\x021\x003\x03')
    print(data)
