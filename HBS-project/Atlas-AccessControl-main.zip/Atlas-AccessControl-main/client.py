from flask import Flask
from src.custom_serial import Serial
import logging

app = Flask(__name__)

app.config['SERIAL_PORT'] = 'COM5'
app.config['SERIAL_BAUDRATE'] = 57600
app.config['SERIAL_BYTESIZE'] = 8
app.config['SERIAL_PARITY'] = 'E'
app.config['SERIAL_STOPBITS'] = 1
app.config['SERIAL_DELAY'] = 0.05

app.logger.setLevel(logging.DEBUG)

ser = Serial(app)


@app.route("/")
def send_message():
    ser.on_send(b'\x02\x00\x01\x31\x30\x03')
    return 'sent'


@ser.on_message()
def handle_message(msg):
    pass


@ser.on_log()
def handle_logging(level, info):
    app.logger.info(f'Info: {info}')


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    app.run(debug=False, host='127.0.0.1', port=5009)



