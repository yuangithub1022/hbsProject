#!/usr/bin/env python
import json
import logging
import os
import platform
import sys
from datetime import datetime

from flask import Flask, request
from waitress import serve

from src.buffer import Buffer
from src.custom_serial import Serial
from src.env import CARD_ID, CAMERA_NO, CAPTURE_TIME
from src.msg_parser import MessageParser

# Init app and default config
app = Flask(__name__)
app.config['SERIAL_PORT'] = '/dev/ttyAMA3'
app.config['SERIAL_BAUDRATE'] = 57600
app.config['SERIAL_BYTESIZE'] = 8
app.config['SERIAL_PARITY'] = 'E'
app.config['SERIAL_STOPBITS'] = 1
app.config['SERIAL_DELAY'] = 0.01
app.config['ENABLE_UNIDENTIFIED_USERS'] = 1
app.config['MAX_USERS_COUNT'] = 50
app.config['MAX_HOLDING_TIME'] = 5

fmt = "%(asctime)s %(levelname)s %(name)s : %(message)s"
logging.basicConfig(format=fmt)
logger = logging.getLogger('waitress')
logger.setLevel(logging.DEBUG)
cmd = b''

# Update config if config file exists
base_dir = '.' if platform.system() == 'Windows' else '/var/access'
config_file = f'{base_dir}/config.json'
# config_file = './config.json'
if os.path.isfile(config_file):
    with open(config_file) as f:
        try:
            config = json.load(f)
            if config:
                app.config.update(config)
        except Exception as err:
            logger.warning('Read config file error', err)

# Check current config
if type(app.config["MAX_USERS_COUNT"]) != int or app.config["MAX_USERS_COUNT"] < 5:
    logger.error(f'MAX_USERS_COUNT is not valid integer. It should be greater than 5.')
    sys.exit(1)

if type(app.config["MAX_HOLDING_TIME"]) != int or app.config["MAX_HOLDING_TIME"] < 1:
    logger.error(f'MAX_HOLDING_TIME is not valid integer. It should be greater than 1.')
    sys.exit(1)

if type(app.config["SERIAL_DELAY"]) != float or app.config["SERIAL_DELAY"] < 0:
    logger.error(f'SERIAL_DELAY is not valid float. It should be greater than 0.')
    sys.exit(1)

# Init serial module for rs485 communication
ser = Serial(app)
# Init message parser
message_parser = MessageParser()
# Init buffer for users retention
buffer = Buffer(maxsize=app.config["MAX_USERS_COUNT"])


@app.route('/access/upload', methods=['POST'])
def upload():
    """
    Receive face recognition result and save to buffer
    """
    try:
        # Read json data
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
    except Exception as e:
        logger.warning('Received invalid json data', e)
        return '{"code": -1}'

    # Check json data
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_FACE':
        logger.warning('Received data without face recognition result')
        return '{"code": -1}'

    if 'extra_info' not in post_data or 'task_name' not in post_data['extra_info']:
        logger.warning('Received data without task name')
        return '{"code": -1}'

    if 'capture_result' not in post_data or 'face' not in post_data['capture_result']:
        logger.warning('Received data without capture result')
        return '{"code": -1}'

    extra_info = post_data['extra_info']
    camera_no = extra_info['task_name']
    min_score = extra_info['min_score'] if 'min_score' in extra_info else 0
    face_result = post_data['capture_result']['face']
    most_similar_user = face_result['most_similar_user'] if 'most_similar_user' in face_result else None
    most_similar_score = face_result['score'] if 'score' in face_result else 0
    capture_time = datetime.now().timestamp()

    try:
        camera_no = int(camera_no)
        min_score = float(min_score)
        most_similar_score = float(most_similar_score)
    except Exception as e:
        logger.warning('Received data with invalid task name or score', e)
        return '{"code": -1}'

    if camera_no < 0 or camera_no > 255:
        # Camera number is saved by 1 Byte
        logger.warning('Received data with task name that not in range 0 ~ 255')
        return '{"code": -1}'

    # Check if recognize success
    if most_similar_score > 0 and most_similar_user and most_similar_score >= min_score:
        card_id = most_similar_user['card_id'] if 'card_id' in most_similar_user else ''
        card_id = card_id[:64]
        item = {
            CARD_ID: card_id,
            CAMERA_NO: camera_no,
            CAPTURE_TIME: capture_time
        }
        buffer.add(item)
        logger.info(f'Received face recognition success result: {item}')
        return '{"code": 0}'

    item = {
        CARD_ID: None,
        CAMERA_NO: camera_no,
        CAPTURE_TIME: capture_time
    }
    if app.config['ENABLE_UNIDENTIFIED_USERS']:
        buffer.add(item)

    logger.info(f'Received face recognition failure result: {item}')
    return '{"code": 0}'


@ser.on_log()
def handle_logging(level, info):
    # todo: test
    logger.info(f'Level: {level}, Info: {info}')
    pass


@ser.on_message()
def handle_request(msg):
    # Check request data
    global cmd
    msg_obj = message_parser.parse(msg)
    if msg_obj['cmd'] is None:
        logger.debug('Serial: Receive invalid request data and skip')
        cmd = cmd + msg_obj['data']
        msg_obj = message_parser.parse(cmd)
        if msg_obj['cmd'] is None:
            logger.debug('Serial: Receive invalid request data and skip')
            if len(cmd) > 6:
                cmd = b''
            return None

    cmd = b''

    # Get items and make response data
    time_limit = datetime.now().timestamp() - app.config["MAX_HOLDING_TIME"]
    response_data = message_parser.respond(msg_obj, buffer, time_limit)

    # Send serial response data
    if response_data:
        ser.on_send(response_data)


if __name__ == '__main__':
    serve(app, host='0.0.0.0', port=5010)
