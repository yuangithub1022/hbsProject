while :
do
	curl -H "Content-Type:application/text" -X POST "http://192.168.0.203:5010/access/upload" -d '{"task_id":"10002019090605114167101","task_type":"TASK_TYPE_FACE","extra_info":{"task_name":"1","output_type":"RS-485","output_value":"AABBCCDDEEFF","min_score":0.85},"capture_time":"2019-09-09T07:57:46.865202939Z","panorama":{"format":"IMAGE_JPEG","url":"3,02ffa0bf6fc5"},"capture_result":{"face":{"rectangle":{"vertices":[{"x":598,"y":210},{"x":736,"y":346}]},"portrait":{"format":"IMAGE_JPEG","url":"4,030017db52bf"},"quality":0.6593673,"attributes":{"age":"34","gender":"MALE"},"db_id":"80c2ed16-9966-4cd2-81fc-d5dd020bad3a","score":0.9441671,"most_similar_user":{"user_id":"82f44ada-8fcf-4729-aaec-81d0f2334ee0","card_id":"100000001","name":"LUO WEITAO","gender":"MALE","age":35,"image":{"url":"2,02e83808bb9d"},"create_time":"2019-09-09T07:42:39.292086115Z"}}}}'
	sleep 3
done
