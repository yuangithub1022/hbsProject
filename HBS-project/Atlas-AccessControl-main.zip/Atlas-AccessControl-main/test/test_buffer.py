import unittest
from src.buffer import Buffer
from src.env import CAPTURE_TIME
from datetime import datetime


class TestRemoveOldData(unittest.TestCase):
    def test_remove_old_data(self):
        buffer = Buffer()
        buffer.add({CAPTURE_TIME: 0})
        curr_time = datetime.now().timestamp()
        buffer.add({CAPTURE_TIME: curr_time})
        oldest = buffer.get()
        self.assertEqual(oldest[CAPTURE_TIME], 0)
        self.assertEqual(len(buffer), 1)
        self.assertEqual(buffer.get()[CAPTURE_TIME], curr_time)


if __name__ == '__main__':
    unittest.main()
