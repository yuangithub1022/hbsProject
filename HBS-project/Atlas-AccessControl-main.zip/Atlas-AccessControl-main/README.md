# Installation

```
pip3 install -r requirements.txt
```

# Start

## Debug

```
sudo chmod 666 /dev/ttyUSB0
python3 app.py
```

Message should be
```
 * Serving Flask app "app" (lazy loading)
 * Environment: production
   WARNING: Do not use the development server in a production environment.
   Use a production WSGI server instead.
 * Debug mode: off
```
## Production
```
./start.sh
```

# uWSGI setup
```
https://www.digitalocean.com/community/tutorials/how-to-serve-flask-applications-with-uswgi-and-nginx-on-ubuntu-18-04
```

# Test Sending Data to Atlas 
POST http://localhost:5000/atlas/access/upload
```json
{
  "task_id": "10002019090605114167101",
  "task_type": "TASK_TYPE_FACE",
  "extra_info": {
    "task_name": "1",
    "output_type": "RS-485",
    "output_value": "AABBCCDDEEFF",
    "min_score": 0.85
  },
  "capture_time": "2019-09-09T07:57:46.865202939Z",
  "panorama": {
    "format": "IMAGE_JPEG",
    "url": "3,02ffa0bf6fc5"
  },
  "capture_result": {
    "face": {
      "rectangle": {
        "vertices": [
          {
            "x": 598,
            "y": 210
          },
          {
            "x": 736,
            "y": 346
          }
        ]
      },
      "portrait": {
        "format": "IMAGE_JPEG",
        "url": "4,030017db52bf"
      },
      "quality": 0.6593673,
      "attributes": {
        "age": "34",
        "gender": "MALE"
      },
      "db_id": "80c2ed16-9966-4cd2-81fc-d5dd020bad3a",
      "score": 0.9441671,
      "most_similar_user": {
        "user_id": "82f44ada-8fcf-4729-aaec-81d0f2334ee0",
        "card_id": "1234567890",
        "name": "LUO WEITAO",
        "gender": "MALE",
        "age": 35,
        "image": {
          "url": "2,02e83808bb9d"
        },
        "create_time": "2019-09-09T07:42:39.292086115Z"
      }
    }
  }
}
```