#!/bin/bash
PROJECT_PATH=/var/lib/docker/websocketDisplay
scp -P 10092 -r huawei@172.30.150.101:"/home/huawei/websocketDisplay/source" "${PROJECT_PATH}/transfer"
rm -rf ${PROJECT_PATH}/source/*
mv ${PROJECT_PATH}/transfer/source/* ${PROJECT_PATH}/source
${PROJECT_PATH}/util.sh -c stop
${PROJECT_PATH}/util.sh -c uninstall
docker build -t atlas_websocket_display:1.0.0 ${PROJECT_PATH}
${PROJECT_PATH}/util.sh -c start
