<template>
  <div>
    <img v-if="image" :src="image" alt="image" />
  </div>
</template>


<script>
import io from 'socket.io-client';
export default {
  name: 'ImageDisplay',
  data() {
    return {
      socket: null,
      image: ''
    }
  },
  created() {
    this.connectWebsocket();
  },
  beforeDestroy() {
    this.disconnectWebsocket();
  },
  methods: {
    connectWebsocket() {
      this.socket = io('/message', {
        path: '/backend/socket.io'
      });
      this.socket.on('image_stream', (message) => {
        if (message.data) {
          this.receiveMessage(message.data);
        }
      });
    },
    disconnectWebsocket() {
      if (this.socket) {
        this.socket.emit('disconnect');
        this.socket.disconnect();
      }
    },
    receiveMessage(data) {
      this.image = "data:image/jpg;base64," + data;
    }
  }
}

</script>

<style scoped>
</style>
