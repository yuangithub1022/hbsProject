<template>
  <div id="app">
    <ImageDisplay />
  </div>
</template>

<script>
import ImageDisplay from './components/ImageDisplay.vue'

export default {
  name: 'App',
  components: {
    ImageDisplay
  }
}
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
