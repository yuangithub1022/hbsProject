﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Windows.Media.Imaging;
using Codeplex.Data;
using System.IO;
using System.Drawing;

namespace RegisterFaceAuthTool
{
    public class AtlasApi
    {
        private int request_count = 0;
        private static readonly HttpClient client = new HttpClient();

        public AtlasApi()
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                    new System.Net.Security.RemoteCertificateValidationCallback(
                        (http_sender, certification, chain, errors) => true);
        }

        public async Task<string> GetToken(string atlas_ip)
        {
            try
            {
                string token = "";

                InfoSettingIniFile infoSettingIniFile = new InfoSettingIniFile();
                string TempUsername = infoSettingIniFile.IniReadValue("Atlas_info", "Username");
                string TempPassword = infoSettingIniFile.IniReadValue("Atlas_info", "Password");

                var user_pwd = new Dictionary<string, string>()
                {
                    {"user", TempUsername },
                    {"password", TempPassword },
                };
                var content = new StringContent(JsonConvert.SerializeObject(user_pwd), Encoding.UTF8, @"application/json");
                
                string url = $"https://{atlas_ip}/components/operation-maintenance/v1/users/sign_in";
                

                // No.72 ログ強化
                DateTime t = System.DateTime.Now;
                int ms = t.Millisecond;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。GetToken_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

                var result = await client.PostAsync(url, content);

                // No.72 ログ強化
                DateTime tStop = System.DateTime.Now;
                int msStop = tStop.Millisecond;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。GetToken_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");

                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    request_count = 0;
                    var token_str = await result.Content.ReadAsStringAsync();
                    Dictionary<string, string> token_dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(token_str);
                    token_dict.TryGetValue("token", out token);
                }

                if (token == "")
                {
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})への認証は失敗しました。");
                }

                return token;
            }
            catch (Exception ex)
            {
                // No.72 ログ強化
                DateTime tStop = System.DateTime.Now;
                int msStop = tStop.Millisecond;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。GetToken_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                request_count++;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のトークン取得({request_count}回目)に失敗しました。{ex.Message}");
                if (request_count >= 3)
                {
                    request_count = 0;
                    return "";
                }
                return await GetToken(atlas_ip);
            }
        }

        public async Task<string> GetDBIdByName(string atlas_ip, string token, string db_name)
        {
            string db_id = "";
            if ("".Equals(token))
            {
                return db_id;
            }

            // No.130 通信断状態で呼び出すとメソッドが落ちないように対応
            try
            {
                string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。GetDBIdByName_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。GetDBIdByName_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var response_str = await result.Content.ReadAsStringAsync();
                    var json = DynamicJson.Parse(response_str);
                    foreach (var database in json.databases)
                    {
                        if (database.name == db_name)
                        {
                            db_id = database.id;
                        }
                    }
                }
            }
            catch
            {
                db_id = "";
            }
            

            if (db_id == "")
            {
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})には顔認証ライブラリ({db_name})が見つかりませんでした。");
            }

            return db_id;
        }

        public async Task<string> NewDBByName(string atlas_ip, string token, string db_name, string db_desc)
        {
            string db_id = "";
            if ("".Equals(token))
            {
                return db_id;
            }

            // No.130 通信断状態で呼び出すとメソッドが落ちないように対応
            try
            {
                var db_info = new Dictionary<string, string>()
                {
                    {"name", db_name },
                    {"description", db_desc },
                };
                var content = new StringContent(JsonConvert.SerializeObject(db_info), Encoding.UTF8, @"application/json");

                string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases";
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Authorization", token);
                request.Content = content;
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。NewDBByName_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。NewDBByName_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var response_str = await result.Content.ReadAsStringAsync();
                    db_id = DynamicJson.Parse(response_str).id;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})へのライブラリー作成が成功しました。");
                }
                else
                {
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})へのライブラリー作成が失敗しました。 " + result.ReasonPhrase);
                }
            }
            catch
            {
                db_id = "";
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})へのライブラリー作成が失敗しました。 ");
            }

            return db_id;
        }

        public async Task<Boolean> GetUserList(string atlas_ip, string token, string db_id, int Index, int Count, List<FaceAuthDataBean> user_list)
        {
            // No.73 疎通確認後のベリファイチェック中に通信断になった場合、登録チェックの結果画面に遷移せず、既存の疎通状態確認画面に遷移
            try
            {
                if ("".Equals(token) || "".Equals(db_id))
                {
                    return false;
                }

                int offset = 0;
                int limit = 100;

                do
                {
                    var query_obj = new Dictionary<string, string>()
                {
                    {"page_request.offset", Convert.ToString(offset) },
                    {"page_request.limit", Convert.ToString(limit) },
                };
                    string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();

                    string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users?{query_str}";
                    var request = new HttpRequestMessage(HttpMethod.Get, url);
                    request.Headers.Add("Authorization", token);

                    // No.72 ログ強化
                    DateTime t = System.DateTime.Now;
                    int ms = t.Millisecond;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。GetUserList_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

                    var result = await client.SendAsync(request);

                    // No.72 ログ強化
                    DateTime tStop = System.DateTime.Now;
                    int msStop = tStop.Millisecond;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。GetUserList_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");

                    if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    {
                        WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データ取得が失敗しました。" + result.ReasonPhrase);

                        WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データを{user_list.Count}件取得しました。");
                        return false;
                    }

                    var response_str = await result.Content.ReadAsStringAsync();
                    var json = DynamicJson.Parse(response_str);

                    int index = 0;
                    foreach (var user in json.users)
                    {
                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            UserIds = new string[64],
                            Idx = ++index + offset,
                            TicketId = user.attributes.ticket_id,
                            FaceId = user.card_id,
                            ManageId = user.attributes.manage_id,
                            StaffName = user.name,
                            StaffNameKN = user.attributes.name_kn,
                            FigureId = user.attributes.figure_id,
                            FigureStatus = user.attributes.figure_status,
                            Thresholds = user.attributes.thresholds,
                            StartDate = user.attributes.start_date,
                            ValidDate = user.attributes.valid_date,
                            // 2.2.xx対応対策一覧 No.9
                            HasFilePath = "1",
                            StaffImgPath = "",
                            StaffImgName = user.image.url,
                            LoginStatus = Count == 1 ? "有" : "無",
                            LoginStatusCode = Count == 1 ? "1" : "0",
                            IsChecked = false,
                            IsSelected = false,
                            IsDeleted = false,
                            IsUpdatedSuccess = new bool[64],
                            OnlyExistType = "",
                            OnlyExistAtlas = "",
                            // No.68
                            IsImageDataUpdateSuccess = true,
                            // No.97
                            CreateTime = Convert.ToDateTime(user.create_time),
                        };
                        // # 273
                        for (int i = 0; i < item.IsUpdatedSuccess.Length; i++)
                        {
                            item.IsUpdatedSuccess[i] = false;
                        }

                        if (JsonConvert.SerializeObject(user.attributes).IndexOf("\"floor_num\":") > -1)
                        {
                            item.FloorNum = user.attributes.floor_num;
                        }
                        if (Index >= 1 && Index <= 64)
                        {
                            item.UserIds[Index - 1] = user.user_id;
                        }
                        else
                        {
                            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
                        }
                        user_list.Add(item);
                    }

                    if (index < limit)
                    {
                        break;
                    }
                    offset += limit;
                } while (true);

                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データを{user_list.Count}件取得しました。");
                return true;
            }
            catch
            {
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データ取得が失敗しました。");

                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データを{user_list.Count}件取得しました。");
                return false;
            }
        }

        public async Task<Boolean> GetUserListByCardId(string atlas_ip, string token, string db_id, int Index, int Count, string Card_id, List<FaceAuthDataBean> user_list)
        {
            bool GetResult = false;
            // No.73 疎通確認後のベリファイチェック中に通信断になった場合、登録チェックの結果画面に遷移せず、既存の疎通状態確認画面に遷移
            try
            {
                if ("".Equals(token) || "".Equals(db_id))
                {
                    return GetResult;
                }

                int offset = 0;
                int limit = 100;

                string card_id = Card_id;

                do
                {
                    var query_obj = new Dictionary<string, string>()
                {
                    {"page_request.offset", Convert.ToString(offset) },
                    {"page_request.limit", Convert.ToString(limit) },
                    {"search",  card_id},
                };
                    string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();

                    string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users?{query_str}";
                    var request = new HttpRequestMessage(HttpMethod.Get, url);
                    request.Headers.Add("Authorization", token);

                    // No.72 ログ強化
                    DateTime t = System.DateTime.Now;
                    int ms = t.Millisecond;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。GetUserListByCardId_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

                    var result = await client.SendAsync(request);

                    // No.72 ログ強化
                    DateTime tStop = System.DateTime.Now;
                    int msStop = tStop.Millisecond;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。Atlas装置({atlas_ip})の応答が返ってきました。GetUserListByCardId_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");

                    if (result.StatusCode != System.Net.HttpStatusCode.OK)
                    {
                        WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データ取得が失敗しました。" + result.ReasonPhrase);
                        return GetResult;
                    }

                    var response_str = await result.Content.ReadAsStringAsync();
                    var json = DynamicJson.Parse(response_str);

                    int index = 0;
                    foreach (var user in json.users)
                    {
                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            UserIds = new string[64],
                            Idx = ++index + offset,
                            TicketId = user.attributes.ticket_id,
                            FaceId = user.card_id,
                            ManageId = user.attributes.manage_id,
                            StaffName = user.name,
                            StaffNameKN = user.attributes.name_kn,
                            FigureId = user.attributes.figure_id,
                            FigureStatus = user.attributes.figure_status,
                            Thresholds = user.attributes.thresholds,
                            StartDate = user.attributes.start_date,
                            ValidDate = user.attributes.valid_date,
                            StaffImgPath = "",
                            StaffImgName = user.image.url,
                            LoginStatus = Count == 1 ? "有" : "無",
                            LoginStatusCode = Count == 1 ? "1" : "0",
                            IsChecked = false,
                            IsSelected = false,
                            IsDeleted = false,
                            IsUpdatedSuccess = new bool[64],
                            OnlyExistType = "",
                            OnlyExistAtlas = "",
                            // No.68
                            IsImageDataUpdateSuccess = true,
                        };
                        // # 273
                        for (int i = 0; i < item.IsUpdatedSuccess.Length; i++)
                        {
                            item.IsUpdatedSuccess[i] = false;
                        }

                        if (JsonConvert.SerializeObject(user.attributes).IndexOf("\"floor_num\":") > -1)
                        {
                            item.FloorNum = user.attributes.floor_num;
                        }
                        if (Index >= 1 && Index <= 64)
                        {
                            item.UserIds[Index - 1] = user.user_id;
                        }
                        else
                        {
                            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
                        }
                        user_list.Add(item);
                    }

                    if (index < limit)
                    {
                        break;
                    }
                    offset += limit;
                } while (true);

                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データを{user_list.Count}件取得しました。顔ID：{card_id}");
                GetResult = true;

                return GetResult;
            }
            catch
            {
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データ取得が失敗しました。");
                return GetResult;
            }
        }

        public async Task<BitmapImage> DownloadImage(string atlas_ip, string token, string image_id, string user_id)
        {
            if ("".Equals(token) || "".Equals(image_id))
            {
                return null;
            }

            BitmapImage bitmapImage = new BitmapImage();

            try
            {
                string url = $"https://{atlas_ip}/components/osg-default/v1/objects/{image_id}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。DownloadImage_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。DownloadImage_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    using (var stream = await result.Content.ReadAsStreamAsync())
                    {
                        bitmapImage.BeginInit();
                        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapImage.StreamSource = stream;
                        bitmapImage.EndInit();
                    }
                }
                else
                {
                    bitmapImage = null;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの画像データ取得(画像ID:{image_id})が失敗しました。 " + result.ReasonPhrase);
                }
            }
            catch
            {
                bitmapImage = null;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの画像データ取得(画像ID:{image_id})が失敗しました。 ");
            }

            return bitmapImage;
        }

        public async Task<BitmapImage> DownloadImageSizeChange(string atlas_ip, string token, string image_id, string user_id)
        {
            if ("".Equals(token) || "".Equals(image_id))
            {
                return null;
            }

            BitmapImage bitmapImage = new BitmapImage();

            try
            {
                string url = $"https://{atlas_ip}/components/osg-default/v1/objects/{image_id}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
                var result = await client.SendAsync(request);
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    using (var stream = await result.Content.ReadAsStreamAsync())
                    {
                        int oldPixelWidth = System.Drawing.Image.FromStream(stream).Width; //横幅
                        int oldPixelHeighth = System.Drawing.Image.FromStream(stream).Height; //高さ
                        int oldPixelMax = oldPixelWidth * oldPixelHeighth;

                        stream.Position = 0;

                        if (oldPixelMax > Configure.MaxPixel)
                        {
                            double PixelMaxRate = (double)Configure.MaxPixel / (double)oldPixelMax;
                            double rate = Math.Sqrt(PixelMaxRate);

                            double newPixelWidth = oldPixelWidth * rate;
                            double newPixelHeighth = oldPixelHeighth * rate;

                            bitmapImage.BeginInit();
                            bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                            bitmapImage.StreamSource = stream;
                            bitmapImage.DecodePixelWidth = (int)newPixelWidth;
                            bitmapImage.DecodePixelHeight = (int)newPixelHeighth;
                            bitmapImage.EndInit();
                        }
                        else
                        {
                            bitmapImage.BeginInit();
                            bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                            bitmapImage.StreamSource = stream;
                            bitmapImage.EndInit();
                        }
                    }
                }
                else
                {
                    bitmapImage = null;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの画像データ取得(画像ID:{image_id})が失敗しました。 " + result.ReasonPhrase);
                }
            }
            catch
            {
                bitmapImage = null;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})からの画像データ取得(画像ID:{image_id})が失敗しました。 ");
            }

            return bitmapImage;
        }

        public async Task<string> AddUserBatch(string atlas_ip, string token, string db_id, IEnumerable<FaceAuthDataBean> recordings)
        {
            string response = "";
            if ("".Equals(token) || "".Equals(db_id))
            {
                return response;
            }

            var user_list = new HashSet<Dictionary<string, Object>>();

            try
            {
                foreach (FaceAuthDataBean record in recordings)
                {
                    // No.67 メモリ対策
                    string TempBase64 = "";
                    if (record.IsEditSuccess == true)
                    {
                        TempBase64 = ImageHelper.BitmapToBase64((BitmapImage)record.Staff_Image);
                    }
                    else
                    {
                        TempBase64 = ImageHelper.DecryptFileToBase64(record.StaffImgPath);
                    }

                    var obj = new Dictionary<string, Object>()
                    {
                        { "card_id", record.FaceId},
                        { "name", record.StaffName},
                        { "image",
                            new Dictionary<string, string>()
                            {
                                // No.67 メモリ対策
                                { "data", TempBase64 },
                            }
                        },
                        { "attributes",
                            new Dictionary<string, string>()
                            {
                                { "ticket_id", record.TicketId },
                                { "manage_id", record.ManageId },
                                { "name_kn", record.StaffNameKN },
                                { "figure_id", record.FigureId },
                                { "figure_status", record.FigureStatus },
                                { "thresholds", record.Thresholds },
                                { "start_date", record.StartDate },
                                { "valid_date", record.ValidDate },
                                { "floor_num", record.FloorNum },
                            }
                        },
                    };
                        user_list.Add(obj);
                    }
                    var body_list = new Dictionary<string, Object>()
                {
                    { "db_id", db_id },
                    { "users", user_list },
                };

                var content = new StringContent(JsonConvert.SerializeObject(body_list), Encoding.UTF8, @"application/json");

                string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users";
                var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("Authorization", token);
                request.Content = content;
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。AddUserBatch_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。AddUserBatch_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    response = await result.Content.ReadAsStringAsync();
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})への顔データ登録({user_list.Count}件)が成功しました。");
                }
                else
                {
                    request_count++;
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})への顔データ登録({user_list.Count}件)が失敗しました。" + result.ReasonPhrase);
                    if (request_count <= 3)
                    {
                        System.Threading.Thread.Sleep(3000);
                        return await AddUserBatch(atlas_ip, token, db_id, recordings);
                    }
                }
            }
            catch
            {
                request_count++;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})への顔データ登録({user_list.Count}件)が失敗しました。");
                if (request_count <= 3)
                {
                    System.Threading.Thread.Sleep(3000);
                    return await AddUserBatch(atlas_ip, token, db_id, recordings);
                }
            }

            request_count = 0;
            return response;
        }

        public async Task<Boolean> DelUserByUserID(string atlas_ip, string token, string db_id, string user_id)
        {
            Boolean rtn = false;
            if ("".Equals(token) || "".Equals(db_id) || "".Equals(user_id))
            {
                return rtn;
            }

            try
            {
                string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users/{user_id}";
                var request = new HttpRequestMessage(HttpMethod.Delete, url);
                request.Headers.Add("Authorization", token);
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。DelUserByUserID_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。DelUserByUserID_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    rtn = true;
                }
                else
                {
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の顔データ削除(USERID:{user_id})が失敗しました。" + result.ReasonPhrase);
                }
            }
            catch
            {
                rtn = false;
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の顔データ削除(USERID:{user_id})が失敗しました。");
            }

            return rtn;
        }

        public async Task<string> ListCaptureResults(string atlas_ip, string token, int offset, int limit)
        {
            string user_list = "";
            if ("".Equals(token))
            {
                return user_list;
            }

            try
            {
                var query_obj = new Dictionary<string, string>()
                {
                    {"page_request.offset", Convert.ToString(offset) },
                    {"page_request.limit", Convert.ToString(limit) },
                    {"order", "ASC" },
                };
                string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();

                string url = $"https://{atlas_ip}/engine/feature-process/v1/capture_results?{query_str}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。ListCaptureResults_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。ListCaptureResults_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var response_str = await result.Content.ReadAsStringAsync();
                    var json = DynamicJson.Parse(response_str);
                    user_list = json.ToString();
                }
                else
                {
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。" + result.ReasonPhrase);
                }
            }
            catch
            {
                user_list = "";
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。");
            }
            

            return user_list;
        }

        public async Task<string> ListCaptureResultsByTime(string atlas_ip, string token, int offset, int limit, DateTime dt_start, DateTime dt_stop)
        {
            string user_list = "";
            if ("".Equals(token))
            {
                return user_list;
            }

            try
            {
                var query_obj = new Dictionary<string, string>()
                {
                    {"page_request.offset", Convert.ToString(offset) },
                    {"page_request.limit", Convert.ToString(limit) },
                    {"order", "ASC" },
                };
                string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();

                string start_str = "&time_range.start=" + dt_start.AddHours(-9).GetDateTimeFormats('s')[0].ToString() + "Z";
                string end_str = "&time_range.end=" + dt_stop.AddHours(-9).GetDateTimeFormats('s')[0].ToString() + "Z";

                query_str = query_str + start_str + end_str;

                string url = $"https://{atlas_ip}/engine/feature-process/v1/capture_results?{query_str}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。ListCaptureResultsByTime_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。ListCaptureResultsByTime_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var response_str = await result.Content.ReadAsStringAsync();
                    var json = DynamicJson.Parse(response_str);
                    user_list = json.ToString();
                }
                else
                {
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。" + result.ReasonPhrase);
                }
            }
            catch
            {
                user_list = "";
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。");
            }

            return user_list;
        }

        public async Task<string> ListExportCaptureResults(string atlas_ip, string token, int offset, int limit)
        {
            limit = 500;

            string user_list = "";
            if ("".Equals(token))
            {
                return user_list;
            }

            try
            {
                var query_obj = new Dictionary<string, string>()
                {
                    {"page_request.offset", Convert.ToString(offset) },
                    {"page_request.limit", Convert.ToString(limit) },
                    {"order", "ASC" },
                };
                string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();

                string url = $"https://{atlas_ip}/engine/feature-process/v1/capture_results?{query_str}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
            // No.72 ログ強化
            DateTime t = System.DateTime.Now;
            int ms = t.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})にコマンドを送信します。ListExportCaptureResults_開始時間：{t.ToString() + "." + ms.ToString().PadLeft(3, '0')}");

            var result = await client.SendAsync(request);

            // No.72 ログ強化
            DateTime tStop = System.DateTime.Now;
            int msStop = tStop.Millisecond;
            WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})の応答が返ってきました。ListExportCaptureResults_終了時間：{tStop.ToString() + "." + msStop.ToString().PadLeft(3, '0')}");
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    var response_str = await result.Content.ReadAsStringAsync();
                    var json = DynamicJson.Parse(response_str);
                    user_list = json.ToString();
                }
                else
                {
                    WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。" + result.ReasonPhrase);
                }
            }
            catch
            {
                user_list = "";
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。");
            }

            return user_list;
        }
    }
}
