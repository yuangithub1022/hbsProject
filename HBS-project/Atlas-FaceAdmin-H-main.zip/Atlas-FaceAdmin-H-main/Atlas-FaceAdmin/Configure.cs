﻿using System.IO;
using System.Windows;

namespace RegisterFaceAuthTool
{
    class Configure
    {
        public static readonly string BasePath = @"C:\Users\Atlas_tool";
        public static readonly string ConfigFile = BasePath + @"\config.ini";
        public static readonly string LibraryName = @"vivabivale";
        public static string ConfigFileForBakup = BasePath + @"\config.ini";

        public static string ConfigFileNew = ConfigFile;

        public static readonly int MaxFaceCount = 8000;

        public static string ToolCsvPath;
        public static string FaceDataPath;
        public static string ToolLogPath;
        public static string[] AtlasList;
        public static bool FlagAtlas = false;
        public static bool FlagImage = false;
        public static bool FlagMemory = false;

        // for バックアップ　コンフィグファイル
        public static string ToolCsvPath_BackUp;
        public static string FaceDataPath_BackUp;
        public static string ToolLogPath_BackUp;
        public static string[] AtlasList_BackUp;
        public static bool FlagAtlas_BackUp = false;

        // for メモリーオーバー防止 顔情報クリア
        public static long ImageSizeMb = 5120;

        // for メモリ対策
        public static long MaxPixel = 10000;

        // for ベリファイ設定
        public static int CheckFlag = 0;

        static Configure()
        {
            if (!Directory.Exists(BasePath) || !File.Exists(ConfigFile))
            {
                return;
            }
            ConfigureIni(ConfigFile);
        }
        // コンフィグファイル共通化処理
        public static void ConfigureIni(string ConfigFileRead)
            {
                IniFile ini = new IniFile(ConfigFileRead);
                ToolCsvPath = ini["path", "tool_csv"];
                FaceDataPath = ini["path", "face_data_jpg"];
                ToolLogPath = ini["path", "tool_log"];
				FlagImage = false;
                FlagMemory = false;
                FlagAtlas = false;
                MaxPixel = 10000;
                ImageSizeMb = 5120;

                // for メモリーオーバー防止 顔情報クリア
                try
                {
                    ImageSizeMb = long.Parse(ini["setting", "memoryClearSize"]);

                    // No.61 memoryClearSizeの下限値、上限値の制約
                    if (ImageSizeMb < 0)
                    {
                        ImageSizeMb = 0;
                        WriteLogSafe.LogSafe("メモリサイズの設定値が最小値(0)を下回りました。最小値(0)を使います。");
                    }
                    if (ImageSizeMb > 8192)
                    {
                        ImageSizeMb = 8192;
                        WriteLogSafe.LogSafe("メモリサイズの設定値が最大値(8192)を上回りました。最大値(8192)を使います。");
                    }
                    FlagMemory = true;
                }
                catch
                {
                    ImageSizeMb = 5120;
                }

                // for メモリ対策
                try
                {
                    MaxPixel = long.Parse(ini["setting", "pixelMaxSize"]);

                    // No.60 pixelMaxSizeの下限値、上限値の制約
                    if (MaxPixel < 100)
                    {
                        MaxPixel = 100;
                        WriteLogSafe.LogSafe("ピクセルの設定値が最小値(100)を下回りました。最小値(100)を使います。");
                    }
                    if (MaxPixel > 50000000)
                    {
                        MaxPixel = 50000000;
                        WriteLogSafe.LogSafe("ピクセルの設定値が最大値(50000000)を上回りました。最大値(50000000)を使います。");
                    }
                    FlagImage = true;
                }
                catch
                {
                    MaxPixel = 10000;
                }

                // for ベリファイ設定
                try
                {
                    CheckFlag = int.Parse(ini["setting", "ifCheck"]);
                    if (CheckFlag != 1)
                    {
                        CheckFlag = 0;
                    }
                }
                catch
                {
                    CheckFlag = 0;
                }

                string[] List = new string[64];
                for (int i = 0; i < List.Length; i++)
                {
                    string item = ini["atlas", $"ipaddr{i + 1}"];

                    // No.57 config.iniにエッジ端末のIPアドレスがコメントアウトなどで、1台も有効になっていない場合、アプリを終了
                    if (item != null && item != "")
                    {
                        FlagAtlas = true;

                        // No.77 コンフィグファイルにポート番号「:38443」が記載されていない場合、アプリ側で初期値を「:38443」に固定する
                        string[] AtlasIpInfo = item.Split(':');
                        if (AtlasIpInfo.Length == 1)
                        {
                            item += ":38443";
                        }
                    }

                    List[i] = item;
                }

                Configure.AtlasList = List;
            }

        public static void ConfigureIni_BackUp(string ConfigFileRead)
        {
            IniFile ini = new IniFile(ConfigFileRead);
            ToolCsvPath_BackUp = ini["path", "tool_csv"];
            FaceDataPath_BackUp = ini["path", "face_data_jpg"];
            ToolLogPath_BackUp = ini["path", "tool_log"];
            FlagAtlas_BackUp = false;

            // for ベリファイ設定
            try
            {
                CheckFlag = int.Parse(ini["setting", "ifCheck"]);
                if (CheckFlag != 1)
                {
                    CheckFlag = 0;
                }
            }
            catch
            {
                CheckFlag = 0;
            }

            string[] List = new string[64];
            for (int i = 0; i < List.Length; i++)
            {
                string item = ini["atlas", $"ipaddr{i + 1}"];

                // No.57 config.iniにエッジ端末のIPアドレスがコメントアウトなどで、1台も有効になっていない場合、アプリを終了
                if (item != null && item != "")
                {
                    FlagAtlas_BackUp = true;

                    // No.77 コンフィグファイルにポート番号「:38443」が記載されていない場合、アプリ側で初期値を「:38443」に固定する
                    string[] AtlasIpInfo = item.Split(':');
                    if (AtlasIpInfo.Length == 1)
                    {
                        item += ":38443";
                    }
                }

                List[i] = item;
            }

            Configure.AtlasList_BackUp = List;
        }
    }
}
