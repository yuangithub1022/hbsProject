﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using Codeplex.Data;
using MahApps.Metro.Controls;
using System.Drawing;
using System.Windows.Controls.Primitives;
using System.Windows.Threading;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// FaceCheckLIstPage.xaml の相互作用ロジック
    /// </summary>
    public partial class FaceCheckLIstPage : Window
    {
        // Disabled close button
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, UInt32 bRevert);
        [DllImport("USER32.DLL ", CharSet = CharSet.Unicode)]
        private static extern UInt32 RemoveMenu(IntPtr hMenu, UInt32 nPosition, UInt32 wFlags);
        private const UInt32 SC_CLOSE = 0x0000F060;
        private const UInt32 MF_BYCOMMAND = 0x00000000;

        private ObservableCollection<FaceAuthDataBean> Recordings = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<FaceAuthDataBean> Recordings_Update = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Csv = new ObservableCollection<FaceAuthDataBean>();

        // for 疎通処理
        private ObservableCollection<FaceAuthDataBean> Recordings_Ping = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<AtlasServerDataBean> AtlasListNoError = new ObservableCollection<AtlasServerDataBean>();
        private ObservableCollection<AtlasServerDataBean> AtlasListNoErrorForMakeDataSame = new ObservableCollection<AtlasServerDataBean>();

        public FaceAuthViewModel ViewModel { get; set; }
        public AtlasServerViewModel AtlasViewModel { get; set; }
        public bool HasChanged { get; set; }

        private readonly int IsFaceTransmitMode = 0;
        private readonly string LibraryDesp = @"01.00.00";

        public int HasBeanIdx = 1;

        // for 疎通処理
        private bool pingJudegError = false;


        public FaceCheckLIstPage(ObservableCollection<FaceAuthDataBean> Recordings_Check_Sum, ObservableCollection<AtlasServerDataBean> atlasListNoError = null)
        {
            InitializeComponent();

            // No.75 PCの画面の中央に表示するようにします
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            WriteLogSafe.LogSafe($"[登録チェック結果] 登録チェック結果を開きました。");
            this.ViewModel = new FaceAuthViewModel();
            this.AtlasViewModel = new AtlasServerViewModel();

            this.HasChanged = false;

            this.Recordings_Check_Sum = Recordings_Check_Sum;

            this.IconImage.Source = ToImageSource(SystemIcons.Warning);

            int Idx_ = 0;
            foreach (FaceAuthDataBean Bean in Recordings_Check_Sum)
            {
                Bean.Idx = ++Idx_;
                Recordings.Add(Bean);
            }

            //No.63 再登録対象の件数、削除対象の件数の計算
            int deleteCount = 0;
            foreach (FaceAuthDataBean Bean in Recordings_Check_Sum)
            {
                if (Bean.IsDeleted == true)
                {
                    deleteCount++;
                }
            }
            int updateCount = Recordings_Check_Sum.Count - deleteCount;

            lab_count.Content = $"登録チェックをした結果、\r\n不整合が{Recordings_Check_Sum.Count}件見つかりました。\r\n再登録してください。\r\n\r\n再登録対象\r\n削除対象";

            // No.66 
            lab_count_login.Content = $"{updateCount}件";
            lab_count_delete.Content = $"{deleteCount}件";

            if (atlasListNoError != null)
            {
                AtlasListNoError = atlasListNoError;
            }
        }

        private ImageSource ToImageSource(Icon icon)
        {
            ImageSource imageSource = Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());

            return imageSource;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            IntPtr hMenu = GetSystemMenu(hwnd, 0);
            RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
        }

        public void Content_Rendered(object sender, EventArgs e)
        {
            loading.IsActive = true;
            loadingPart.Visibility = Visibility.Visible;

            this.ViewModel.ReadViewDelay(this.IsFaceTransmitMode);
            Recordings_Check_Csv = this.ViewModel.Recordings;

            loading.IsActive = false;
            loadingPart.Visibility = Visibility.Hidden;
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            string msg = "本当に登録を行わなくてもよろしいですか？";
            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                MessageBoxButton.OKCancel, MessageBoxImage.Information);
            if (messageBoxResult.Equals(MessageBoxResult.Cancel))
            {
                return;
            }

            // No.51 OK釦を押下したログを残す
            WriteLogSafe.LogSafe($"[登録チェック結果] 本当に登録を行わなくてもよろしいですか？「OK」押下。");
            WriteLogSafe.LogSafe($"[登録チェック結果] 登録チェック結果を閉じました。");
            this.Close();
        }

        private void Btn_Login_Click(object sender, RoutedEventArgs e)
        {
            int count = 0;
            var faceIdFirst = "";
            string msg = "再登録しますか？";
            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (messageBoxResult.Equals(MessageBoxResult.No))
            {
                return;
            }

            // No.51 はい釦を押下したログを残す
            WriteLogSafe.LogSafe($"[登録チェック結果] 再登録しますか？「はい」押下。");
            // No.47 不整合解消開始のログを出力する
            WriteLogSafe.LogSafe($"[登録チェック結果] 不整合解消処理を開始しました。");


            // 画像ファイル、またはパスが存在しない顔情報があるかをチェックする
            foreach (FaceAuthDataBean Bean in this.Recordings)
            {
                if (Bean.StaffName == "未登録" && Bean.StaffImgName == "画像なし" && Bean.IsDeleted)
                {
                    continue;
                }

                if (Bean.StaffImgPath == null || "".Equals(Bean.StaffImgPath) || !File.Exists(Bean.StaffImgPath))
                {
                    if (count == 0)
                    {
                        faceIdFirst = Bean.FaceId;
                    }
                    count++;
                }
            }

            if (count > 0)
            {
                MessageBox.Show($"{faceIdFirst}の画像ファイル、またはパスが存在しません。" + "\r\n" + "\r\n" + "エラー件数" + count + "件", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);

                WriteLogSafe.LogSafe($"[登録チェック結果] 不整合解消処理を終了しました。{faceIdFirst}の画像ファイル、またはパスが存在しません。");
                return;
            }

           //　再登録処理を開始
            Make_Date_Same();

            HasChanged = true;
        }

        private void Make_Date_Same()
        {
            try
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                if (this.AtlasViewModel.Recordings.Count() <= 1)
                {
                    System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                Recordings_Update.Clear();

                List<FaceAuthDataBean> FaceDatasToDelete = this.Recordings_Check_Sum.Where(item =>
                {
                    return item.IsDeleted && "未登録".Equals(item.StaffName);
                }).ToList();

                List<FaceAuthDataBean> FaceDatasToUpdate = this.Recordings_Check_Sum.Where(item =>
                {
                    return !"未登録".Equals(item.StaffName);
                }).ToList();

                List<Task<bool>> tasks = new List<Task<bool>>();

                // # 273 対応
                foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                {
                    // # 273 対応
                    for (int i = 0; i < bean.IsUpdatedSuccess.Length; i++)
                    {
                        bean.IsUpdatedSuccess[i] = false;
                    }
                }

                var AtlasList = this.AtlasViewModel.Recordings;

                // for 疎通処理
                pingJudegError = false;
                bool runContinue = true;

                Recordings_Ping.Clear();

                // No.126 再登録実行時に疎通失敗したときのエラー画面が「疎通結果画面」を表示する
                List<Task<bool>> task_ping = new List<Task<bool>>();
                task_ping.Add(Ping_Retry());

                Task.Run(() => { Task.WaitAll(task_ping.ToArray()); }).ContinueWith(t1 =>
                {
                    this.Invoke(new Action(() =>
                    {
                        if (pingJudegError)
                        {
                            // No.126 再登録実行時に疎通失敗したときのエラー画面が「疎通結果画面」を表示する
                            int errorType = 7;
                            PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasListNoError.Count + 1, errorType, AtlasListNoError, AtlasListNoErrorForMakeDataSame);
                            pingJudge.Owner = this;
                            pingJudge.ShowDialog();

                            runContinue = pingJudge.HasRunContinue;

                            if (!runContinue)
                            {
                                loading.IsActive = false;
                                loadingPart.Visibility = Visibility.Hidden;
                                return;
                            }
                        }

                        pingJudegError = false;
                        Recordings_Ping.Clear();

                        foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                        {
                            bean.IsImageDataUpdateSuccess = false;
                            if (bean.IsEditSuccess)
                            {
                                continue;
                            }
                            else
                            {
                                // 2.2.xx対応対策一覧 No.3 登録する顔画像が500kBを超えている場合、顔登録アプリで500kBに縮小して登録する。
                                if ((long)((double)ImageHelper.DecryptFileToBase64(bean.StaffImgPath).Length * 0.75) > 512000)
                                {
                                    ImageHelper.JpgFileToBase64(bean.StaffImgPath, bean.FaceId);
                                }
                            }
                        }

                        // No.84 確認のとれた装置のみ登録チェックを行います
                        for (int i = 0; i < AtlasListNoErrorForMakeDataSame.Count; i++)
                        {
                            tasks.Add(CheckDateSame(AtlasListNoErrorForMakeDataSame[i].Server_Name, AtlasListNoErrorForMakeDataSame[i].Server_Ip, FaceDatasToDelete, FaceDatasToUpdate, int.Parse(AtlasListNoErrorForMakeDataSame[i].Server_Name)));
                        }
                        Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
                        {
                            // No.47 不整合解消終了時のログを出力する
                            WriteLogSafe.LogSafe($"[登録チェック結果] 不整合解消処理を終了しました。");
                    
                            // Check all results
                            int deletedCount = 0;
                            foreach (FaceAuthDataBean Bean in FaceDatasToDelete)
                            {
                                bool detetedResult = true;
                                // No.84 確認のとれた装置のみ登録チェックを行います
                                for (int i = 0; i < AtlasListNoErrorForMakeDataSame.Count; i++)
                                {
                                    string userId = ReturnUserId(Bean, int.Parse(AtlasListNoErrorForMakeDataSame[i].Server_Name));
                                    if (!"".Equals(userId))
                                    {
                                        detetedResult = false;
                                        break;
                                    }
                                }

                                if (detetedResult)
                                {
                                    deletedCount++;

                                    foreach (FaceAuthDataBean beanTable in this.Recordings_Check_Csv)
                                    {
                                        if (beanTable.FaceId.Equals(Bean.FaceId))
                                        {
                                            this.Recordings_Check_Csv.Remove(beanTable);
                                            break;
                                        }
                                    }
                                }
                            }

                            int updatedCount = 0;
                            foreach (FaceAuthDataBean Bean in FaceDatasToUpdate)
                            {
                                bool updatedResult = true;
                                // No.84 確認のとれた装置のみ登録チェックを行います
                                for (int i = 0; i < AtlasListNoErrorForMakeDataSame.Count; i++)
                                {
                                    string userId = ReturnUserId(Bean, int.Parse(AtlasListNoErrorForMakeDataSame[i].Server_Name));
                                    if ("".Equals(userId))
                                    {
                                        updatedResult = false;
                                        break;
                                    }

                                    // # 273
                                    if (!Bean.IsUpdatedSuccess[int.Parse(AtlasListNoErrorForMakeDataSame[i].Server_Name) - 1])
                                    {
                                        updatedResult = false;
                                        break;
                                    }
                                }

                                if (updatedResult)
                                {
                                    // No.42
                                    if (!Bean.IsImageDataUpdateSuccess)
                                    {
                                        continue;
                                    }
                                    updatedCount++;
                                    Bean.LoginStatus = "有";
                                    Bean.LoginStatusCode = "1";
                                    Bean.IsDeleted = false;
                                    Bean.IsUpdated = false;
                                    Bean.IsInserted = false;
                                    Bean.IsSelected = false;
                                    // 2.2.xx対応対策一覧 No.9 登録時、1へ設定
                                    Bean.HasFilePath = "1";

                                    foreach (FaceAuthDataBean beanTable in this.Recordings_Check_Csv)
                                    {
                                        if (beanTable.FaceId.Equals(Bean.FaceId))
                                        {
                                            this.Recordings_Check_Csv.Remove(beanTable);
                                            break;
                                        }
                                    }
                                    this.Recordings_Check_Csv.Add(Bean);
                                }
                                else
                                {
                                    foreach (FaceAuthDataBean beanTable in this.Recordings_Check_Csv)
                                    {
                                        if (beanTable.FaceId.Equals(Bean.FaceId))
                                        {
                                            // No.43 登録失敗しているので、登録有無を「有」から「無」に変更する
                                            beanTable.LoginStatus = "無";
                                            beanTable.LoginStatusCode = "0";
                                            break;
                                        }
                                    }
                                }
                            }

                            if (deletedCount < FaceDatasToDelete.Count())
                            {
                                WriteLogSafe.LogSafe($"[登録チェック結果] 装置へ顔データの削除が失敗しました。{FaceDatasToDelete.Count()}件の削除が必要ですが、{deletedCount}件だけが削除成功しました。");
                            }
                            if (updatedCount < FaceDatasToUpdate.Count())
                            {
                                WriteLogSafe.LogSafe($"[登録チェック結果] 装置へ顔データの更新が失敗しました。{FaceDatasToUpdate.Count()}件の更新が必要ですが、{updatedCount}件だけが更新成功しました。");
                            }

                            // Save csv file
                            bool csvResult = ToToolCSV();

                            int FaceDataCount = FaceDatasToDelete.Count() + FaceDatasToUpdate.Count();
                            int FaceDataSuccess = deletedCount + updatedCount;
                            int FaceDataError = FaceDataCount - FaceDataSuccess;

                            // #255対応
                            if (!pingJudegError && Recordings_Ping.Count == 0)
                            {
                                // No.68 Face not found(もしくは通信系以外のエラーの場合)を検出したら、全ベリファイチェック促さずに、以下のメッセージを表示します。
                                IEnumerable<FaceAuthDataBean> ImageUnsuccessFaceDatas = FaceDatasToUpdate.Where(item => { return (!item.IsImageDataUpdateSuccess); });
                                if (ImageUnsuccessFaceDatas.Count() > 0)
                                {
                                    System.Windows.MessageBox.Show($"成功{FaceDataSuccess}件、失敗{FaceDataError}件\n\r\n\r顔画像の登録に失敗しています。\n\r顔画像を見直して、再登録してください。", "エラー",
                                                     MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                                else
                                {
                                    System.Windows.MessageBox.Show($"　登録完了しました。　　　\n\r\n\r　　成功　{FaceDataSuccess}件 \n\r　　失敗　{FaceDataError}件", "情報",
                                            MessageBoxButton.OK, MessageBoxImage.Information);
                                } 
                            }

                            this.Invoke(new Action(() =>
                            {
                                int Idx_ = 0;
                                foreach (FaceAuthDataBean Bean in this.Recordings)
                                {
                                    Bean.Idx = ++Idx_;
                                }

                                loading.IsActive = false;
                                loadingPart.Visibility = Visibility.Hidden;
                                //CollectionViewSource.GetDefaultView(this.DG2.ItemsSource).Refresh();

                                if (pingJudegError && Recordings_Ping.Count > 0)
                                {
                                    int errorType = 4;
                                    // No.84 確認のとれた装置のみ登録チェックを行います
                                    PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasListNoErrorForMakeDataSame.Count + 1, errorType);
                                    pingJudge.Owner = this;
                                    pingJudge.ShowDialog();
                                }
                                else
                                {
                                    WriteLogSafe.LogSafe($"[登録チェック結果] 登録チェック結果を閉じました。");
                                    this.Close();
                                }
                            }));
                        });
                    }));
                });
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録チェック結果] 顔データの取得に失敗しました。{ex.Message}");
                MessageBox.Show($"顔データの取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                //loading.IsActive = false;
                //loadingPart.Visibility = Visibility.Hidden;
            }
        }

        private async Task<bool> CheckDateSame(string AtlasName, string AtlasIp, List<FaceAuthDataBean> FaceDatasToDelete, List<FaceAuthDataBean> FaceDatasToUpdate, int No)
        {
            // for 疎通処理
            string[] AtlasIpInfo = AtlasIp.Split(':');
            string AtlasIpNoPort = AtlasIpInfo[0];

            int AtlasCount = this.AtlasViewModel.Recordings.Count();
            int AtlasKey = No;

            AtlasApi Api = new AtlasApi();
            string Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);

                return false;
            }

            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
            if ("".Equals(DBId))
            {
                DBId = await Api.NewDBByName(AtlasIp, Token, Configure.LibraryName, LibraryDesp);
                if ("".Equals(DBId))
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);

                    foreach (FaceAuthDataBean bean in FaceDatasToDelete.Concat(FaceDatasToUpdate))
                    {
                        this.UpdateUserId(bean, No, "");
                    }

                    return false;
                }
            }

            //No.43 再登録成功後のみ、古い顔データを削除する
            bool Flag = true;
            foreach (FaceAuthDataBean bean_atlas in FaceDatasToDelete.Concat(FaceDatasToUpdate))
            {
                List<FaceAuthDataBean> UserListToCheck = new List<FaceAuthDataBean>();

                bool FlagCheck = await Api.GetUserListByCardId(AtlasIp, Token, DBId, AtlasKey, AtlasCount, bean_atlas.FaceId, UserListToCheck);

                if (FlagCheck)
                {
                    if (UserListToCheck.Count == 0)
                    {
                        this.UpdateUserId(bean_atlas, No, "");
                    }
                    else
                    {
                        foreach (var user in UserListToCheck)
                        {
                            string UserId_Atlas = ReturnUserId(user, No);
                            Flag = await Api.DelUserByUserID(AtlasIp, Token, DBId, UserId_Atlas);
                            if (!Flag)
                            {
                                WriteLogSafe.LogSafe($"[登録チェック結果] 顔データ(顔ID:{bean_atlas.FaceId})の削除が失敗しました。");
                                this.UpdateUserId(bean_atlas, No, "");

                                // for 疎通処理
                                pingJudegError = true;
                                FaceAuthDataBean item = new FaceAuthDataBean()
                                {
                                    StaffName = "ベリファイエラー",
                                    OnlyExistAtlas = AtlasIpNoPort,
                                    FigureId = AtlasName,
                                };
                                Recordings_Ping.Add(item);

                                return false;
                            }
                            else
                            {
                                // # 287 対応
                                WriteLogSafe.LogSafe($"[登録チェック結果] 顔データの削除が成功しました。(Atlas Ip:{AtlasIp},KeyID:{UserId_Atlas},顔ID:{bean_atlas.FaceId})");
                                this.UpdateUserId(bean_atlas, No, "");
                            }
                        }
                    }
                }
                else
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "ベリファイエラー",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);

                    return false;
                }
            }

            if (FaceDatasToUpdate.Count() == 0)
            {
                return true;
            }

            // 顔なしの画像データ登録時、対応
            //bool UpdateDatasErrorExist = false;

            int loginAddCount = 50;
            int totalCount = FaceDatasToUpdate.Count();

            for (int i = 0; i <= totalCount / loginAddCount; i++)
            {
                IEnumerable<FaceAuthDataBean> FaceDatasTemp;
                if (i == totalCount / loginAddCount)
                {
                    if (totalCount > loginAddCount)
                    {
                        if (i * loginAddCount < totalCount)
                        {
                            FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, totalCount % loginAddCount);
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, totalCount);
                    }
                }
                else
                {
                    FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, loginAddCount);
                }

                // # 253
                long totalImageSize = 0;

                var Template = FaceDatasTemp.ToArray();

                for (int j = 0; j < Template.Length; j++)
                {
                    // No.68 base 64から直接ファイルサイズの理論値を計算する方法
                    // No.67 メモリ対策
                    if (Template[j].IsEditSuccess)
                    {
                        if (Template[j].Staff_Image != null)
                        {
                            totalImageSize += (long)((double)ImageHelper.BitmapToBase64((BitmapImage)Template[j].Staff_Image).Length * 0.75);
                        }
                    }
                    else
                    {
                        totalImageSize += (long)((double)ImageHelper.DecryptFileToBase64(Template[j].StaffImgPath).Length * 0.75);
                    }
                }

                if (totalImageSize <= 15 * 1024 * 1024)
                {
                    string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTemp);
                    if ("".Equals(response))
                    {
                        WriteLogSafe.LogSafe($"[登録チェック結果] Atlas装置({AtlasIp})への顔データ登録は中断されました。(顔ID Max50件、Size15MB以下登録)");

                        // for 疎通処理
                        pingJudegError = true;
                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "登録時にエラー応答",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasName,
                        };
                        Recordings_Ping.Add(item);

                        return false;
                    }

                    var jsonArr = DynamicJson.Parse(response).results;
                    foreach (FaceAuthDataBean bean in FaceDatasTemp)
                    {
                        foreach (var json in jsonArr)
                        {
                            if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                            {
                                this.UpdateUserId(bean, No, json.user.user_id);

                                // # 273
                                bean.IsUpdatedSuccess[No - 1] = true;

                                // No.133 
                                bean.IsImageDataUpdateSuccess = true;

                                break;
                            }
                        }
                    }
                }
                else
                {
                    long lSendInfoSizeToCheck = 0;
                    ObservableCollection<FaceAuthDataBean> FaceDatasTempCheck = new ObservableCollection<FaceAuthDataBean>();
                    List<FaceAuthDataBean> FaceDatasTempCheckList = FaceDatasTempCheck.ToList();
                    for (int k = 0; k < Template.Length; k++)
                    {
                        // No.68 base 64から直接ファイルサイズの理論値を計算する方法
                        // No.67 メモリ対策
                        if (Template[k].IsEditSuccess)
                        {
                            if (Template[k].Staff_Image != null)
                            {
                                lSendInfoSizeToCheck += (long)((double)ImageHelper.BitmapToBase64((BitmapImage)Template[k].Staff_Image).Length * 0.75);
                            }
                        }
                        else
                        {
                            // 2.2.xx対応対策一覧 No.3 登録する顔画像が500kBを超えている場合、顔登録アプリで500kBに縮小して登録する。
                            //lSendInfoSizeToCheck += (long)((double)ImageHelper.BitmapToBase64(ImageHelper.DecryptFile(Template[k].StaffImgPath)).Length * 0.75);
                            lSendInfoSizeToCheck += (long)((double)ImageHelper.DecryptFileToBase64(Template[k].StaffImgPath).Length * 0.75);
                        }

                        if (lSendInfoSizeToCheck < 15 * 1024 * 1024)
                        {
                            FaceDatasTempCheckList.Add(Template[k]);

                            // 15MB未満の最後の総データ
                            if (k == Template.Length - 1)
                            {
                                string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTempCheckList);
                                if ("".Equals(response))
                                {
                                    WriteLogSafe.LogSafe($"[登録チェック結果] Atlas装置({AtlasIp})への顔データ登録は中断されました。(Size15MB超えたため、顔ID 件数を50件以下にして(最終回)登録)");

                                    // for 疎通処理
                                    pingJudegError = true;
                                    FaceAuthDataBean item = new FaceAuthDataBean()
                                    {
                                        StaffName = "登録時にエラー応答",
                                        OnlyExistAtlas = AtlasIpNoPort,
                                        FigureId = AtlasName,
                                    };
                                    Recordings_Ping.Add(item);

                                    return false;
                                }
                                var jsonArr = DynamicJson.Parse(response).results;
                                foreach (FaceAuthDataBean bean in FaceDatasTempCheckList)
                                {
                                    foreach (var json in jsonArr)
                                    {
                                        if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                                        {
                                            this.UpdateUserId(bean, No, json.user.user_id);

                                            // # 273
                                            bean.IsUpdatedSuccess[No - 1] = true;
                                            // No.133 
                                            bean.IsImageDataUpdateSuccess = true;
                                            break;
                                        }                                        
                                    }
                                }
                            }
                            continue;
                        }
                        else
                        {
                            // Size15MB超えたため、顔ID 件数を50件以下にして登録
                            string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTempCheckList);
                            if ("".Equals(response))
                            {
                                WriteLogSafe.LogSafe($"[登録チェック結果] Atlas装置({AtlasIp})への顔データ登録は中断されました。(Size15MB超えたため、顔ID 件数を50件以下にして登録)");

                                // for 疎通処理
                                pingJudegError = true;
                                FaceAuthDataBean item = new FaceAuthDataBean()
                                {
                                    StaffName = "登録時にエラー応答",
                                    OnlyExistAtlas = AtlasIpNoPort,
                                    FigureId = AtlasName,
                                };
                                Recordings_Ping.Add(item);

                                return false;
                            }
                            var jsonArr = DynamicJson.Parse(response).results;
                            foreach (FaceAuthDataBean bean in FaceDatasTempCheckList)
                            {
                                foreach (var json in jsonArr)
                                {
                                    if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                                    {
                                        this.UpdateUserId(bean, No, json.user.user_id);

                                        // # 273
                                        bean.IsUpdatedSuccess[No - 1] = true;
                                        // No.133 
                                        bean.IsImageDataUpdateSuccess = true;

                                        break;
                                    }
                                }
                            }
                            FaceDatasTempCheckList.Clear();
                            lSendInfoSizeToCheck = 0;
                            k--;
                        }
                    }
                }
            }
            // 登録処理 終了

            return true;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (this.loading.IsActive == true)
            {
                e.Handled = true;
            }
        }

        private string ReturnUserId(FaceAuthDataBean Bean, int Index)
        {
            string UserId;
            if (Index >= 1 && Index <= 64)
            {
                UserId = Bean.UserIds[Index - 1];
            }
            else
            {
                UserId = "";
                WriteLogSafe.LogSafe($"[登録チェック結果] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
            return UserId;
        }

        private void UpdateUserId(FaceAuthDataBean Bean, int Index, string UserId)
        {
            if (Index >= 1 && Index <= 64)
            {
                Bean.UserIds[Index - 1] = UserId;
            }
            else
            {
                WriteLogSafe.LogSafe($"[登録チェック結果] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
        }

        public bool ToToolCSV()
        {
            string FilePathToolCSV = Configure.ToolCsvPath + @"\tool_csv.csv";

            try
            {
                using (FileStream _stream = WriteToolCsv.fs)
                {
                    _stream.SetLength(0);
                    StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);
                    foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                    {
                        string sline;
                        if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                        {
                            ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                        }
                        if (this.IsFaceTransmitMode == 2)
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + beanTable.FloorNum + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        else
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        _writer.WriteLine(sline);
                    }
                    _writer.Close();
                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                    return true;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録チェック結果] CSVファイルへの出力が失敗しました。{ex.Message}");
                return false;
            }
        }

        private void Btn_Match_Click(object sender, RoutedEventArgs e)
        {
            // No.84 確認のとれた装置のみ登録チェックを行います
            FaceDateSelectListPage faceDataSelect = new FaceDateSelectListPage(HasBeanIdx, Recordings_Check_Sum, AtlasListNoError);
            faceDataSelect.Owner = this;
            faceDataSelect.ShowDialog();

            HasBeanIdx = faceDataSelect.FaceDataId;

            faceDataSelect.Recordings_Show.Clear();
            faceDataSelect.Recordings_Show_Old.Clear();
            faceDataSelect.DG2.DataContext = "";
            GC.Collect();
        }

        // No.126 再登録実行時に疎通失敗したときのエラー画面が「疎通結果画面」を表示する
        private async Task<bool> Ping_Retry()
        {
            var ping = new System.Net.NetworkInformation.Ping();

            await Task.Delay(1000);

            AtlasListNoErrorForMakeDataSame.Clear();

            for (int i = 0; i < AtlasListNoError.Count; i++)
            {
                string[] AtlasIpInfo = AtlasListNoError[i].Server_Ip.Split(':');
                string AtlasNumber = AtlasListNoError[i].Server_Name;
                string AtlasIpNoPort = AtlasIpInfo[0];

                await Task.Delay(100);

                try
                {
                    // No.99 画面を移動させてマウスが効かなくなることを修正
                    var result = await ping.SendPingAsync(AtlasIpNoPort);

                    if (result.Status != System.Net.NetworkInformation.IPStatus.Success)
                    {
                        pingJudegError = true;

                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "疎通失敗",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasNumber,
                        };

                        Recordings_Ping.Add(item);
                    }
                    // No.84 確認のとれた装置のみ登録チェックを行います
                    else
                    {
                        AtlasListNoErrorForMakeDataSame.Add(AtlasListNoError[i]);
                    }
                }
                catch (Exception)
                {
                    pingJudegError = true;

                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasNumber,
                    };

                    Recordings_Ping.Add(item);
                }
            }

            return true;
        }

        public void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(ExitFrames), frame);
            Dispatcher.PushFrame(frame);
        }

        public object ExitFrames(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }
    }
}
