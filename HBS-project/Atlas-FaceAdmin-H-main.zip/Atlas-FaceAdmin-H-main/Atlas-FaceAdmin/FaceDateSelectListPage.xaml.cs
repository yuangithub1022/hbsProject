﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.IO;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// FaceDateSelectListPage.xaml の相互作用ロジック
    /// </summary>
    public partial class FaceDateSelectListPage : Window
    {
        // for Disabled close button
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, UInt32 bRevert);
        [DllImport("USER32.DLL ", CharSet = CharSet.Unicode)]
        private static extern UInt32 RemoveMenu(IntPtr hMenu, UInt32 nPosition, UInt32 wFlags);
        private const UInt32 SC_CLOSE = 0x0000F060;
        private const UInt32 MF_BYCOMMAND = 0x00000000;

        [System.Runtime.InteropServices.DllImport("gdi32.dll")]
        public static extern bool DeleteObject(IntPtr hObject);


        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>();

        public ObservableCollection<FaceAuthDataBean> Recordings_Show = new ObservableCollection<FaceAuthDataBean>();

        public ObservableCollection<FaceAuthDataBean> Recordings_Show_Old = new ObservableCollection<FaceAuthDataBean>();
        // for 疎通処理
        private ObservableCollection<FaceAuthDataBean> Recordings_Ping = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<AtlasServerDataBean> AtlasListNoError = new ObservableCollection<AtlasServerDataBean>();

        private FaceAuthDataBean Face_Data_Select = new FaceAuthDataBean();

        private FaceAuthDataBean Face_Data_Csv = new FaceAuthDataBean();

        public int FaceDataId = 1;
        public int DataCount = 0;

        // for 疎通処理
        private bool pingJudegError = false;

        private bool IsNextButtonClick = false;
        private bool IsPreButtonClick = false;

        public FaceDateSelectListPage(int SelectFaceDataId, ObservableCollection<FaceAuthDataBean> Recordings_Check_Sum, ObservableCollection<AtlasServerDataBean> atlasListNoError = null)
        {
            InitializeComponent();

            // No.84 確認のとれた装置のみ登録チェックを行います
            if (atlasListNoError != null)
            {
                AtlasListNoError = atlasListNoError;
            }

            // No.75 PCの画面の中央に表示するようにします
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            WriteLogSafe.LogSafe($"[結果詳細表示] 結果詳細表示を開きました。");

            this.Recordings_Check_Sum = Recordings_Check_Sum;

            DataCount = Recordings_Check_Sum.Count;

            FaceDataId = SelectFaceDataId;

            SetFaceInfoToPage("fiststart");
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            // for Disabled close button
            var hwnd = new WindowInteropHelper(this).Handle;
            IntPtr hMenu = GetSystemMenu(hwnd, 0);
            RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);
        }

        private void Content_Rendered(object sender, EventArgs e)
        {
            loading.IsActive = true;
            loadingPart.Visibility = Visibility.Visible;

            //　一行目のTool_csvの顔情報を読込
            Get_First_Data();

            //　二行目以降のAtlasの顔情報を読込
            Get_Show_Data();
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            // ぐるぐる表示中、画面でKey操作を無効にする
            if (this.loading.IsActive)
            {
                e.Handled = true;
            }
        }

        private void Get_First_Data()
        {
            FaceAuthDataBean Face_Data_Csv_Show = new FaceAuthDataBean();

            Face_Data_Csv_Show.AtlasNo = "PC";
            Face_Data_Csv_Show.OnlyExistAtlas = "-";
            Face_Data_Csv_Show.CheckResult = "-";

            if (this.Recordings_Check_Sum[FaceDataId - 1].StaffName == "未登録")
            {
                Face_Data_Csv_Show.StaffName = "未登録";
                Face_Data_Csv_Show.StaffImgName = "画像なし";
                Face_Data_Csv_Show.Staff_Image = null;
            }
            else
            {
                Face_Data_Csv_Show.StaffName = Recordings_Check_Sum[FaceDataId - 1].StaffName;

                string StaffImgPath = System.IO.Path.Combine(Configure.FaceDataPath, Recordings_Check_Sum[FaceDataId - 1].FaceId + @".jpg");
                BitmapImage image = ImageHelper.DecryptFile(StaffImgPath);
                if (image != null)
                {
                    Face_Data_Csv_Show.StaffImgName = Recordings_Check_Sum[FaceDataId - 1].FaceId + @".jpg";
                    Face_Data_Csv_Show.Staff_Image = image;
                }
                else
                {
                    Face_Data_Csv_Show.StaffImgName = @"画像なし";
                    Face_Data_Csv_Show.Staff_Image = null;
                }
            }

            Face_Data_Csv = Face_Data_Csv_Show;
        }

        private void Get_Show_Data()
        {
            try
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                this.Recordings_Show.Clear();

                // for 疎通処理　エラー状態を復旧
                pingJudegError = false;
                Recordings_Ping.Clear();

                List<Task<bool>> tasks = new List<Task<bool>>();

                // No.84 確認のとれた装置のみ登録チェックを行います
                for (int i = 0; i < AtlasListNoError.Count; i++)
                {
                    tasks.Add(GetShowDate(AtlasListNoError[i].Server_Ip, int.Parse(AtlasListNoError[i].Server_Name)));
                }
                Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
                {
                    this.Invoke(new Action(() =>
                    {
                        GC.Collect();
                        // Atlas情報を読込中にエラー発生した場合、新しい顔情報を表示せず、もとの顔情報に戻り、疎通確認画面に進む。
                        if (pingJudegError && Recordings_Ping.Count > 0)
                        {
                            // 前/次Button押下後、エラーになるので、もと画面情報を戻る
                            if (IsPreButtonClick)
                            {
                                SetFaceInfoToPage("next");
                            }
                            else if (IsNextButtonClick)
                            {
                                SetFaceInfoToPage("pre");
                            }

                            // 疎通確認画面を表示させる
                            int errorType = 6;
                            // No.84 確認のとれた装置のみ登録チェックを行います
                            // No.134 疎通結果画面でリトライすると不具合対応
                            PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasListNoError.Count + 1, errorType, AtlasListNoError);
                            pingJudge.Owner = this;
                            pingJudge.ShowDialog();

                            // 疎通確認画面でリファイを押下した場合、再度Atlas情報を読込

                            if (pingJudge.HasRunContinue)
                            {
                                pingJudegError = false;
                                Recordings_Ping.Clear();

                                //　押したButtonにより、処理を再起
                                if (IsPreButtonClick)
                                {
                                    Btn_Previous_Click(null, null);
                                }
                                else if (IsNextButtonClick)
                                {
                                    Btn_Next_Click(null, null);
                                }
                                else
                                {
                                    // この場合は、初回起動なので、Atlasの情報のみ再度読込
                                    Get_Show_Data();
                                }
                            }
                            else
                            {
                                // この場合は、初回起動なので、閉じるButton押下後、もとの顔情報がないので、この画面を閉じる
                                if (!IsPreButtonClick && !IsNextButtonClick)
                                {
                                    Btn_Close_Click(null, null);
                                }
                            }

                            // 疎通確認画面で閉じるButtonを押下した場合、もとの画面情報に戻るので、次の処理を行いません。
                            loading.IsActive = false;
                            loadingPart.Visibility = Visibility.Hidden;
                            return;
                        }

                        // Atlas情報を読込中にエラーが発生しない場合、新しい顔情報を表示します。

                        //　Atlasの顔情報をAtlas号機の順にソートします。
                        this.Recordings_Show = new ObservableCollection<FaceAuthDataBean>(this.Recordings_Show.OrderBy(item => item.AtlasNo));

                        //　画面の一行目にTool_csvの顔情報を追加し、Tool_csvの顔情報を一行目に固定
                        this.Recordings_Show.Insert(0, Face_Data_Csv);

                        int Idx_ = 0;
                        foreach (FaceAuthDataBean Bean in this.Recordings_Show)
                        {
                            Bean.Idx = ++Idx_;
                        }

                        //　新しい顔情報を画面に表示させます。
                        this.Recordings_Show_Old = this.Recordings_Show;
                        this.DG2.DataContext = this.Recordings_Show_Old;
                        this.Recordings_Show = new ObservableCollection<FaceAuthDataBean>();

                        CollectionViewSource.GetDefaultView(this.DG2.ItemsSource).Refresh();
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                    }));
                });
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[結果詳細表示] 顔データの取得に失敗しました。{ex.Message}");
                MessageBox.Show($"顔データの取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }

        private async Task<bool> GetShowDate(string AtlasIp, int No)
        {
            int AtlasCount = this.AtlasListNoError.Count();
            int AtlasKey = No;
            string AtlasNo = Convert.ToString(AtlasKey);

            string AtlasIpNoPort = "";
            string[] AtlasIpInfo = AtlasIp.Split(':');
            AtlasIpNoPort = AtlasIpInfo[0];

            AtlasApi Api = new AtlasApi();
            string Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean itemPing = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasNo,
                };
                Recordings_Ping.Add(itemPing);
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    UserIds = new string[64],
                    Idx = 0,
                    TicketId = "",
                    FaceId = Face_Data_Select.FaceId,
                    ManageId = "",
                    StaffName = "取得失敗",
                    StaffNameKN = "",
                    FigureId = "",
                    FigureStatus = "",
                    Thresholds = "",
                    StartDate = "",
                    ValidDate = "",
                    StaffImgPath = "",
                    StaffImgName = "取得失敗",
                    LoginStatus = "無",
                    LoginStatusCode = "0",
                    IsChecked = false,
                    IsSelected = false,
                    IsDeleted = false,
                    IsUpdatedSuccess = new bool[64],
                    OnlyExistType = "",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FloorNum = "",
                    // No.68
                    IsImageDataUpdateSuccess = true,
                };
                for (int i = 0; i < item.IsUpdatedSuccess.Length; i++)
                {
                    item.IsUpdatedSuccess[i] = false;
                }
                Recordings_Show.Add(item);
                return false;
            }
            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);

            List<FaceAuthDataBean> UserListToCheck = new List<FaceAuthDataBean>();

            bool FlagCheck = await Api.GetUserListByCardId(AtlasIp, Token, DBId, AtlasKey, AtlasCount, Face_Data_Select.FaceId, UserListToCheck);

            if (FlagCheck)
            {
                if (UserListToCheck.Count == 0)
                {
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        UserIds = new string[64],
                        Idx = 0,
                        TicketId = "",
                        FaceId = Face_Data_Select.FaceId,
                        ManageId = "",
                        StaffName = "未登録",
                        StaffNameKN = "",
                        FigureId = "",
                        FigureStatus = "",
                        Thresholds = "",
                        StartDate = "",
                        ValidDate = "",
                        StaffImgPath = "",
                        StaffImgName = "画像なし",
                        LoginStatus = "無",
                        LoginStatusCode = "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsDeleted = true,
                        IsUpdatedSuccess = new bool[64],
                        OnlyExistType = "",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FloorNum = "",
                        // No.68
                        IsImageDataUpdateSuccess = true,
                        // No.66 AtlasNo ⇒ 対象装置, CheckResult ⇒ チェック結果
                        AtlasNo = "号機:" + No.ToString().PadLeft(2, '0'),
                        CheckResult = "異常",
                    };
                    for (int i = 0; i < item.IsUpdatedSuccess.Length; i++)
                    {
                        item.IsUpdatedSuccess[i] = false;
                    }
                    Recordings_Show.Add(item);
                }
                else
                {
                    string ToolCsvUserId = Recordings_Check_Sum[FaceDataId - 1].UserIds[No - 1];

                    foreach (var user in UserListToCheck)
                    {
                        if (user.UserIds[No - 1] == ToolCsvUserId && Recordings_Check_Sum[FaceDataId - 1].StaffName != "未登録")
                        {
                            user.CheckResult = "正常";
                        }
                        else
                        {
                            user.CheckResult = "異常";
                            user.IsDeleted = true;
                        }

                        user.AtlasNo = "号機:" + No.ToString().PadLeft(2, '0');
                        user.OnlyExistAtlas = AtlasIpNoPort;

                        var ImageId = user.StaffImgName;
                        // No.124　メモリ対策
                        BitmapImage TempImage = await Api.DownloadImageSizeChange(AtlasIp, Token, ImageId, Convert.ToString(user.FaceId));

                        if (TempImage == null)
                        {
                            user.StaffImgName = $"取得失敗";
                            user.CheckResult = "異常";
                            user.IsDeleted = true;
                        }
                        else
                        {
                            user.StaffImgName = $"{user.FaceId}" + @".jpg";
                            user.StaffImgPath = System.IO.Path.Combine(Configure.FaceDataPath, user.StaffImgName);
                            user.Staff_Image = TempImage;
                        }

                        Recordings_Show.Add(user);
                    }
                }
            }
            else
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean itemPing = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasNo,
                };
                Recordings_Ping.Add(itemPing);
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    UserIds = new string[64],
                    Idx = 0,
                    TicketId = "",
                    FaceId = Face_Data_Select.FaceId,
                    ManageId = "",
                    StaffName = "取得失敗",
                    StaffNameKN = "",
                    FigureId = "",
                    FigureStatus = "",
                    Thresholds = "",
                    StartDate = "",
                    ValidDate = "",
                    StaffImgPath = "",
                    StaffImgName = "取得失敗",
                    LoginStatus = "無",
                    LoginStatusCode = "0",
                    IsChecked = false,
                    IsSelected = false,
                    IsDeleted = false,
                    IsUpdatedSuccess = new bool[64],
                    OnlyExistType = "",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FloorNum = "",
                    // No.68
                    IsImageDataUpdateSuccess = true,
                };
                for (int i = 0; i < item.IsUpdatedSuccess.Length; i++)
                {
                    item.IsUpdatedSuccess[i] = false;
                }
                Recordings_Show.Add(item);
                return false;
            }

            return true;
        }

        private void Btn_Previous_Click(object sender, RoutedEventArgs e)
        {
            IsNextButtonClick = false;
            IsPreButtonClick = true;

            //　前の顔情報を画面に表示させる
            SetFaceInfoToPage("pre");

            //　一行目のTool_csvの顔情報を読込
            Get_First_Data();

            //　二行目以降のAtlasの顔情報を読込
            Get_Show_Data();
        }

        private void Btn_Next_Click(object sender, RoutedEventArgs e)
        {
            IsNextButtonClick = true;
            IsPreButtonClick = false;

            //　次の顔情報を画面に表示させる
            SetFaceInfoToPage("next");

            //　一行目のTool_csvの顔情報を読込
            Get_First_Data();

            //　二行目以降のAtlasの顔情報を読込
            Get_Show_Data();
        }

        private void SetFaceInfoToPage(string whichFaceData)
        {
            if (whichFaceData == "pre")
            {
                //　前の顔情報を画面に表示させる
                FaceDataId -= 1;
            }
            else if (whichFaceData == "next")
            {
                //　次の顔情報を画面に表示させる
                FaceDataId += 1;
            }
            
            SetButtonPage();

            foreach (FaceAuthDataBean Bean in Recordings_Check_Sum)
            {
                if (FaceDataId == Bean.Idx)
                {
                    Face_Data_Select = Bean;
                    break;
                }
            }
            this.lab_cardid.Content = Face_Data_Select.FaceId;

            SetPageCount();
        }

        private void SetButtonPage()
        {
            if (FaceDataId == 1)
            {
                btn_previou.IsEnabled = false;
                btn_previou.Content = new TextBlock { Text = "◁前顔ID" };
            }
            else
            {
                btn_previou.IsEnabled = true;
                btn_previou.Content = new TextBlock { Text = "◀前顔ID" };
            }

            if (FaceDataId < DataCount)
            {
                btn_next.IsEnabled = true;
                btn_next.Content = new TextBlock { Text = "次顔ID▶" };
            }
            else
            {
                btn_next.IsEnabled = false;
                btn_next.Content = new TextBlock { Text = "次顔ID▷" };
            }
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            WriteLogSafe.LogSafe($"[結果詳細表示] 結果詳細表示を閉じました。");
            this.Close();
        }

        private void SetPageCount()
        {
            string RecordsCnt = $"{FaceDataId} / {Recordings_Check_Sum.Count}件";
            this.Invoke(new Action(() =>
            {
                this.page_cnt.Text = RecordsCnt;
            }));
            WriteLogSafe.LogSafe($"[結果詳細表示] 件数No: {FaceDataId}, 不整合総件数: {Recordings_Check_Sum.Count}");
        }
    }
}
