﻿using Microsoft.Win32;
using System;
using System.Windows;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// Interaction logic for LoginFaceAuthSelect.xaml
    /// </summary>
    public partial class LoginFaceAuthSelect : Window
    {
        private readonly int IsFaceTransmitMode = 0;
        private bool IsLoginByHitachiadmin = false;
        public LoginFaceAuthSelect(bool IsLoginByHitachiadmin = false)
        {
            InitializeComponent();

            this.IsLoginByHitachiadmin = IsLoginByHitachiadmin;

            this.IsFaceTransmitMode = CheckIsFaceTransmitMode();

            if (this.IsFaceTransmitMode != 0)
            {
                this.btn_login.Content = "顔情報登録";
                this.btn_update.Content = "顔情報復旧";
            }
        }

        private void Btn_Login_Click(object sender, RoutedEventArgs e)
        {
            WriteLogSafe.LogSafe("[登録種別選択画面] 新規登録で登録者一覧画面を表示します。");
            FaceAuthListPage ListPage = new FaceAuthListPage(this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
            ListPage.Show();
            this.Close();
        }

        private void Btn_Update_Click(object sender, RoutedEventArgs e)
        {
            //WriteLogSafe.LogSafe("[登録種別選択画面] 追加変更でバックアップファイルの選択画面を表示します。");
            //FaceAuthSelectData SelectData = new FaceAuthSelectData(this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
            //SelectData.Show();
            //this.Close();

            String Path = Configure.ToolCsvPath + "\\tool_csv.csv";

            WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({Path})で登録者一覧画面を表示します。");
            FaceAuthListPage FaceListPage = new FaceAuthListPage(Path, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
            FaceListPage.Show();
            this.Close();
        }

        private void Btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            WriteLogSafe.LogSafe("[登録種別選択画面] アプリを終了しました。");
            this.Close();
        }

        public int CheckIsFaceTransmitMode()
        {
            string path = "SOFTWARE\\Atlas_face\\Setting";
            string key = "FaceTransmit";
            try
            {
                RegistryKey root = Registry.LocalMachine;
                RegistryKey rk = root.OpenSubKey(path);
                if (rk != null)
                {
                    string value = (string)rk.GetValue(key, null);
                    if (value != null && value.Trim() == "1")
                    {
                        return 1;
                    }
                    else if (value != null && value.Trim() == "2")
                    {
                        return 2;
                    }
                    else
                        return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] レジストリキーの読取に失敗しました。{ex.Message}");
                return 0;
            }

            return 0;
        }
    }
}
