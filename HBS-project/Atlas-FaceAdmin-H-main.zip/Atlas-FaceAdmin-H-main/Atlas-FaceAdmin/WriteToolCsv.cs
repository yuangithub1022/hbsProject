using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace RegisterFaceAuthTool
{
    // # 285 対応
    public class WriteToolCsv
    {
        private static readonly string FilePathToolCSV = Configure.ToolCsvPath + @"\tool_csv.csv";
        public static FileStream fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
        
        public WriteToolCsv()
        {
        }
        public static List<List<string>> ReadToolCSV(int Count, string Codeset)
        {
            List<List<string>> Lists = new List<List<string>>();
            var encoding = Encoding.GetEncoding(Codeset);
            // 読み込みたいCSVファイルのパスを指定して開く
            StreamReader Sr = new StreamReader(fs, encoding);
            {
                int CountTemp = 0;
                // 末尾まで繰り返す
                while (!Sr.EndOfStream)
                {
                    // CSVファイルの一行を読み込む
                    string line = Sr.ReadLine();
                    // 読み込んだ一行をカンマ毎に分けて配列に格納する
                    string[] Values = line.Split(',');
                    CountTemp++;
                    if (CountTemp >= Count)
                    {
                        // 配列からリストに格納する
                        List<string> List = new List<string>();
                        List.AddRange(Values);

                        Lists.Add(List);
                    }
                }
                fs.Position = 0;
            }
            WriteToolCsv.fs.Close();
            try
            {
                WriteToolCsv.fs = new FileStream(Configure.ToolCsvPath + @"\tool_csv.csv", FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"Tool_csvの排他処理に失敗しました。{ex.Message}");
            }
            return Lists;
        }
    }
}