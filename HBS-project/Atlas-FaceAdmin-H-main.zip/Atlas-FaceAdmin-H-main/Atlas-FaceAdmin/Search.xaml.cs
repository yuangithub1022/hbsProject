﻿using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// Search.xaml の相互作用ロジック
    /// </summary>
    public partial class Search : Window
    {
        //private static string m_searchTarget = "";
        private static string m_searchText = "";
        private static int m_searchCount = 0;
        private FaceAuthListPage pParentWin = null;
        List<FaceAuthDataBean> m_lsFaceDatasToFindName = null;
        List<FaceAuthDataBean> m_lsFaceDatasToFindCardID = null;

        public Search(FaceAuthListPage WinMain)
        {
            InitializeComponent();
            pParentWin = WinMain;
            this.Topmost = true;

            // modify by yuan 2021/01/28 　　#224により、仕様変更
            this.SearchTarget.SelectedIndex = 1;
        }

        private void Button_Click_Close(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            pParentWin.btn_search.IsEnabled = true;
            base.OnClosing(e);
        }

        private void Button_Click_SearchNext(object sender, RoutedEventArgs e)
        {
            // Np.149 検索をしても、対象の顔IDにスクロールしないことを修正
            try
            {
                pParentWin.SearchFlag = true;
                if (m_searchText == "")
                {
                    System.Windows.MessageBox.Show("検索する文字列を入力してください。", "情報",
                        System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                    this.SearchText.Focus();
                    pParentWin.SearchFlag = false;
                    return;
                }

                if (this.SearchTarget.SelectedIndex == 0)
                {
                    List<FaceAuthDataBean> lsTempCardID = pParentWin.ViewModel.Recordings.Where(item =>
                    {
                        return item.FaceId.Contains(m_searchText);
                    }).ToList();
                    if (lsTempCardID.Count() == 0)
                    {
                        m_lsFaceDatasToFindCardID = null;
                        m_searchCount = -1;
                    }
                    else if (!m_lsFaceDatasToFindCardID.SequenceEqual(lsTempCardID))
                    {
                        m_lsFaceDatasToFindCardID = lsTempCardID;
                        m_searchCount = -1;
                    }

                    if (m_lsFaceDatasToFindCardID == null)
                    {
                        System.Windows.MessageBox.Show("検索条件に一致するデータが見つかりません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        pParentWin.SearchFlag = false;
                        return;
                    }
                    pParentWin.DG1.Focus();
                    if (m_lsFaceDatasToFindCardID.Count() == 1)
                    {
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindCardID[0]);
                    }
                    else
                    {
                        m_searchCount++;
                        if (m_searchCount >= m_lsFaceDatasToFindCardID.Count())
                        {
                            m_searchCount = 0;
                        }
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindCardID[m_searchCount]);
                    }
                    pParentWin.DG1.UpdateLayout();
                    pParentWin.DG1.ScrollIntoView(pParentWin.DG1.SelectedItem);
                    pParentWin.SearchFlag = false;
                }
                else if (this.SearchTarget.SelectedIndex == 1)
                {
                    List<FaceAuthDataBean> lsTempName = pParentWin.ViewModel.Recordings.Where(item =>
                    {
                        return item.StaffName.Contains(m_searchText);
                    }).ToList();
                    if (lsTempName.Count() == 0)
                    {
                        m_lsFaceDatasToFindName = null;
                        m_searchCount = -1;
                    }
                    else if (!m_lsFaceDatasToFindName.SequenceEqual(lsTempName))
                    {
                        m_lsFaceDatasToFindName = lsTempName;
                        m_searchCount = -1;
                    }

                    if (m_lsFaceDatasToFindName == null)
                    {
                        System.Windows.MessageBox.Show("検索条件に一致するデータが見つかりません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        pParentWin.SearchFlag = false;
                        return;
                    }

                    pParentWin.DG1.Focus();
                    if (m_lsFaceDatasToFindName.Count() == 1)
                    {
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindName[0]);
                    }
                    else
                    {
                        m_searchCount++;
                        if (m_searchCount >= m_lsFaceDatasToFindName.Count())
                        {
                            m_searchCount = 0;
                        }
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindName[m_searchCount]);
                    }
                    pParentWin.DG1.UpdateLayout();
                    pParentWin.DG1.ScrollIntoView(pParentWin.DG1.SelectedItem);
                    pParentWin.SearchFlag = false;
                }
            }
            catch
            {
                pParentWin.SearchFlag = false;
            }
        }

        private void Button_Click_SearchBefore(object sender, RoutedEventArgs e)
        {
            // Np.149 検索をしても、対象の顔IDにスクロールしないことを修正
            try
            {
                pParentWin.SearchFlag = true;
                if (m_searchText == "")
                {
                    System.Windows.MessageBox.Show("検索する文字列を入力してください。", "情報",
                        System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                    this.SearchText.Focus();
                    pParentWin.SearchFlag = false;
                    return;
                }

                if (this.SearchTarget.SelectedIndex == 0)
                {
                    List<FaceAuthDataBean> lsTempCardID = pParentWin.ViewModel.Recordings.Where(item =>
                    {
                        return item.FaceId.Contains(m_searchText);
                    }).ToList();
                    if (lsTempCardID.Count() == 0)
                    {
                        m_lsFaceDatasToFindCardID = null;
                        m_searchCount = -1;
                    }
                    else if (!m_lsFaceDatasToFindCardID.SequenceEqual(lsTempCardID))
                    {
                        m_lsFaceDatasToFindCardID = lsTempCardID;
                        m_searchCount = -1;
                    }

                    if (m_lsFaceDatasToFindCardID == null)
                    {
                        System.Windows.MessageBox.Show("検索条件に一致するデータが見つかりません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        pParentWin.SearchFlag = false;
                        return;
                    }
                    pParentWin.DG1.Focus();
                    if (m_lsFaceDatasToFindCardID.Count() == 1)
                    {
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindCardID[0]);
                    }
                    else
                    {
                        m_searchCount--;
                        if (m_searchCount < 0)
                        {
                            m_searchCount = m_lsFaceDatasToFindCardID.Count() - 1;
                        }
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindCardID[m_searchCount]);
                    }
                    pParentWin.DG1.UpdateLayout();
                    pParentWin.DG1.ScrollIntoView(pParentWin.DG1.SelectedItem);
                    pParentWin.SearchFlag = false;
                }
                else if (this.SearchTarget.SelectedIndex == 1)
                {
                    List<FaceAuthDataBean> lsTempName = pParentWin.ViewModel.Recordings.Where(item =>
                    {
                        return item.StaffName.Contains(m_searchText);
                    }).ToList();
                    if (lsTempName.Count() == 0)
                    {
                        m_lsFaceDatasToFindName = null;
                        m_searchCount = -1;
                    }
                    else if (!m_lsFaceDatasToFindName.SequenceEqual(lsTempName))
                    {
                        m_lsFaceDatasToFindName = lsTempName;
                        m_searchCount = -1;
                    }

                    if (m_lsFaceDatasToFindName == null)
                    {
                        System.Windows.MessageBox.Show("検索条件に一致するデータが見つかりません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        pParentWin.SearchFlag = false;
                        return;
                    }

                    pParentWin.DG1.Focus();
                    if (m_lsFaceDatasToFindName.Count() == 1)
                    {
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindName[0]);
                    }
                    else
                    {
                        m_searchCount--;
                        if (m_searchCount < 0)
                        {
                            m_searchCount = m_lsFaceDatasToFindName.Count() - 1;
                        }
                        CollectionViewSource.GetDefaultView(pParentWin.DG1.ItemsSource).MoveCurrentTo(m_lsFaceDatasToFindName[m_searchCount]);
                    }
                    pParentWin.DG1.UpdateLayout();
                    pParentWin.DG1.ScrollIntoView(pParentWin.DG1.SelectedItem);
                    pParentWin.SearchFlag = false;
                }
            }
            catch
            {
                pParentWin.SearchFlag = false;
            }
        }

        private void SearchText_TextChanged(object sender, TextChangedEventArgs e)
        {
            m_searchText = this.SearchText.Text;
            if (m_searchText != "")
            {
                if (this.SearchTarget.SelectedIndex == 0)
                {
                    m_lsFaceDatasToFindCardID = pParentWin.ViewModel.Recordings.Where(item =>
                    {
                        return item.FaceId.Contains(m_searchText);
                    }).ToList();
                    if (m_lsFaceDatasToFindCardID.Count() == 0)
                    {
                        m_lsFaceDatasToFindCardID = null;
                    }
                    m_searchCount = -1;
                }
                else if (this.SearchTarget.SelectedIndex == 1)
                {
                    m_lsFaceDatasToFindName = pParentWin.ViewModel.Recordings.Where(item =>
                    {
                        return item.StaffName.Contains(m_searchText);
                    }).ToList();
                    if (m_lsFaceDatasToFindName.Count() == 0)
                    {
                        m_lsFaceDatasToFindName = null;
                    }
                    m_searchCount = -1;
                }
            }
            else
            {
                m_lsFaceDatasToFindCardID = null;
                m_lsFaceDatasToFindName = null;
                m_searchCount = -1;
            }
        }

        private void SearchTarget_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            this.SearchText.Text = "";
            m_lsFaceDatasToFindCardID = null;
            m_lsFaceDatasToFindName = null;
            m_searchCount = -1;
        }
    }
}
