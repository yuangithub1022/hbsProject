﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Drawing;
using System.Windows.Interop;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// BackupSelect.xaml 的交互逻辑
    /// </summary>
    public partial class BackupSelect : Window
    {
        public static int BackupFlag = 0;
        public BackupSelect()
        {
            InitializeComponent();

            // PCの画面の中央に表示するようにします
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            this.IconImage.Source = ToImageSource(SystemIcons.Information);
            BackupFlag = 0;

            radio_ok.IsChecked = true;
        }

        public void Btn_OK(object sender, RoutedEventArgs e)
        {
            if (radio_ok.IsChecked == true)
            {
                BackupFlag = 1;
                this.Close();
            }
            else if (radio_cancel.IsChecked == true)
            {
                BackupFlag = 2;
                this.Close();
            }
            else
            {
                System.Windows.MessageBox.Show($"復旧方法を選んでください。", "",
                                       MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

        public void Btn_Cancel(object sender, RoutedEventArgs e)
        {
            BackupFlag = 0;
            this.Close();
        }

        private ImageSource ToImageSource(Icon icon)
        {
            ImageSource imageSource = Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());

            return imageSource;
        }
    }
}
