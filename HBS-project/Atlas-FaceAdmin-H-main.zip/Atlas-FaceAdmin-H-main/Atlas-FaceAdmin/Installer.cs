﻿using Microsoft.Win32;
using System;
using System.Collections;
using System.ComponentModel;
using System.IO;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Windows;

namespace RegisterFaceAuthTool
{
    [RunInstaller(true)]
    public partial class Installer : System.Configuration.Install.Installer
    {
        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        public Installer()
        {
            InitializeComponent();
        }

        protected override void OnAfterInstall(IDictionary savedState)
        {
            string UseChangeName = this.Context.Parameters["usefacetransmit"];
            if (UseChangeName == "1")
            {
                // UseChangeName == 1 --> FaceTransmit == 0    BIVALE連携
                RegistryKey root = Registry.LocalMachine;
                RegistryKey CreateKey = root.CreateSubKey("SOFTWARE\\Atlas_Face\\Setting");
                CreateKey.SetValue("FaceTransmit", "0");
            }
            else if(UseChangeName == "2")
            {
                // UseChangeName == 2 --> FaceTransmit == 1    接点連動
                RegistryKey root = Registry.LocalMachine;
                RegistryKey CreateKey = root.CreateSubKey("SOFTWARE\\Atlas_Face\\Setting");
                CreateKey.SetValue("FaceTransmit", "1");
            }
            else
            {
                RegistryKey root = Registry.LocalMachine;
                RegistryKey CreateKey = root.CreateSubKey("SOFTWARE\\Atlas_Face\\Setting");
                CreateKey.SetValue("FaceTransmit", "2");
            }

            // modify by yuan for #225
            try
            {
                // modify by yuan #225 /2021/01/29

                // BasePath存在しない場合、新規作成し権限を与えます。
                string BasePath = @"C:\Users\Atlas_tool";
                if (!Directory.Exists(BasePath))
                {
                    Directory.CreateDirectory(BasePath);

                    // フォルダのインフォメーションを取得
                    DirectoryInfo dir = new DirectoryInfo(BasePath);
                    // フォルダの訪問権限を取得
                    System.Security.AccessControl.DirectorySecurity dirSecurity = dir.GetAccessControl(AccessControlSections.All);
                    // ファイルのACLの継承を設定
                    InheritanceFlags inherits = InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit;
                    // everyone組の訪問権限規則を添加　完全コントロール権限
                    FileSystemAccessRule everyoneFileSystemAccessRule = new FileSystemAccessRule("Everyone", FileSystemRights.FullControl, inherits, PropagationFlags.None, AccessControlType.Allow);
                    // user組の訪問権限規則を添加　完全コントロール権限
                    FileSystemAccessRule usersFileSystemAccessRule = new FileSystemAccessRule("Users", FileSystemRights.FullControl, inherits, PropagationFlags.None, AccessControlType.Allow);
                    bool isModified = false;
                    dirSecurity.ModifyAccessRule(AccessControlModification.Add, everyoneFileSystemAccessRule, out isModified);
                    dirSecurity.ModifyAccessRule(AccessControlModification.Add, usersFileSystemAccessRule, out isModified);
                    // 訪問権限の設定
                    dir.SetAccessControl(dirSecurity);
                }

                // config.iniを初期化する
                string ConfigFile = BasePath + @"\config.ini";
                if (!File.Exists(ConfigFile))
                {
                    WritePrivateProfileString("atlas", ";Atlas 1 IP アドレス\nipaddr1", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 8 IP アドレス\n;ipaddr8", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 7 IP アドレス\n;ipaddr7", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 6 IP アドレス\n;ipaddr6", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 5 IP アドレス\n;ipaddr5", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 4 IP アドレス\n;ipaddr4", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 3 IP アドレス\n;ipaddr3", @"", ConfigFile);
                    WritePrivateProfileString("atlas", "\n;Atlas 2 IP アドレス\n;ipaddr2", @"", ConfigFile);

                    if (UseChangeName == "4")
                    {
                        // BIVALE連携－通行パータン対応
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 8 通行パターン\n;ipaddr8", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 7 通行パターン\n;ipaddr7", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 6 通行パターン\n;ipaddr6", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 5 通行パターン\n;ipaddr5", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 4 通行パターン\n;ipaddr4", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 3 通行パターン\n;ipaddr3", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", "\n;Atlas 2 通行パターン\n;ipaddr2", @"", ConfigFile);
                        WritePrivateProfileString("traffic_pattern", ";Atlas 1 通行パターン\n;ipaddr1", @"", ConfigFile);
                    }

                    WritePrivateProfileString("path", ";アプリCSVファイル格納先\ntool_csv", @"C:\Users\Atlas_tool\tool_csv\", ConfigFile);
                    WritePrivateProfileString("path", ";顔データ格納先\nface_data_jpg", @"C:\Users\Atlas_tool\face_data_jpg\", ConfigFile);
                    WritePrivateProfileString("path", ";ログファイル格納先\ntool_log", @"C:\Users\Atlas_tool\tool_log\", ConfigFile);
                }

                // 必要なフォルダを初期化する
                string FaceDataJpgPath = BasePath + @"\face_data_jpg";
                string ToolCSVPath = BasePath + @"\tool_csv";
                string ToolLogPath = BasePath + @"\tool_log";

                if (!Directory.Exists(FaceDataJpgPath))
                {
                    Directory.CreateDirectory(FaceDataJpgPath);
                }

                if (!Directory.Exists(ToolCSVPath))
                {
                    Directory.CreateDirectory(ToolCSVPath);
                }

                if (!Directory.Exists(ToolLogPath))
                {
                    Directory.CreateDirectory(ToolLogPath);
                }

                // 客様要望対応　config_inisフォルダなくす
                string ToolConfiginisPath = BasePath + @"\config_inis";
                DirectoryInfo DirConfigInis = new DirectoryInfo(ToolConfiginisPath);
                if (DirConfigInis.Exists)
                {
                    DirectoryInfo[] childs = DirConfigInis.GetDirectories();
                    foreach (DirectoryInfo child in childs)
                    {
                        child.Delete(true);
                    }
                    DirConfigInis.Delete(true);
                }

                string ToolConfiginisPath_2 = BasePath + @"\config.inis";
                DirectoryInfo DirConfigInis_2 = new DirectoryInfo(ToolConfiginisPath_2);
                if (DirConfigInis_2.Exists)
                {
                    DirectoryInfo[] childs = DirConfigInis_2.GetDirectories();
                    foreach (DirectoryInfo child in childs)
                    {
                        child.Delete(true);
                    }
                    DirConfigInis_2.Delete(true);
                }

                // 8000初期データ　接点連動と顔ごとに接点連動対応
                string csvPath = ToolCSVPath + "\\tool_csv.csv";

                if (!File.Exists(csvPath) && (UseChangeName == "2" || (UseChangeName != "1" && UseChangeName != "2" && UseChangeName != "4")))
                {
                    using (FileStream _stream = new FileStream(csvPath, FileMode.Create, FileAccess.ReadWrite))
                    {
                        StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);

                        if (UseChangeName == "2")
                        {
                            //　接点連動対応
                            string sline;
                            for (int id = 1; id < 8001; id++)
                            {
                                string card_id = "CARDID" + id.ToString().PadLeft(10, '0');

                                sline = "," + card_id + "," + "," + "," + "," + "," + "0" + "," + "," + "," + "," + "," + "無" + "," + "," + ",";
                                for (int user_id = 0; user_id < 64; user_id++)
                                {
                                    sline = sline + ",";
                                }
                                _writer.WriteLine(sline);
                            }
                        }

                        if (UseChangeName != "1" && UseChangeName != "2" && UseChangeName != "4")
                        {
                            //　顔ごとに接点連動対応　UseChangeName==3保留
                            string sline;
                            for (int id = 1; id < 8001; id++)
                            {
                                string card_id = "CARDID" + id.ToString().PadLeft(10, '0');

                                sline = "," + card_id + "," + "," + "," + "," + "," + "0" + "," + "," + "," + "," + "," + "無" + "," + "1" + "," + ",";
                                for (int user_id = 0; user_id < 64; user_id++)
                                {
                                    sline = sline + ",";
                                }
                                _writer.WriteLine(sline);
                            }
                        }
                        _writer.Close();
                    }
                }                
            }
            catch (Exception)
            {
                MessageBox.Show($"コンフィグ関連ファイルの初期化に失敗しました。\n管理者として実行する必要があります。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
            }

            base.OnAfterInstall(savedState);
        }
    }
}
