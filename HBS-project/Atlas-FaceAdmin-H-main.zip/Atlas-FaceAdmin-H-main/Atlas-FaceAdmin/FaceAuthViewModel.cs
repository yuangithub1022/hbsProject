﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace RegisterFaceAuthTool
{
    public class FaceAuthDataBean
    {
        public int Idx { get; set; }
        public string[] UserIds { get; set; }
        public string TicketId { get; set; }
        public string FaceId { get; set; }
        public string ManageId { get; set; }
        public string StaffName { get; set; }
        public string StaffNameKN { get; set; }
        public string FigureId { get; set; }
        public string FigureStatus { get; set; }
        public string Thresholds { get; set; }
        public string StartDate { get; set; }
        public string ValidDate { get; set; }
        public string StaffImgPath { get; set; }
        public string StaffImgName { get; set; }
        public string FloorNum { get; set; }
        public string LoginStatus { get; set; }
        public string LoginStatusCode { get; set; }
        public bool IsChecked { get; set; }
        public bool IsSelected { get; set; }
        public bool IsInserted { get; set; }
        public bool IsUpdated { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsLossed { get; set; }

        // No.68
        public bool IsImageDataUpdateSuccess { get; set; }

        // No.67　メモリ対策
        public bool IsEditSuccess { get; set; } = false;

        // # 273
        public bool[] IsUpdatedSuccess { get; set; }
        public ImageSource Staff_Image { get; set; }
        public string OnlyExistType { get; set; }
        public string OnlyExistAtlas { get; set; }
        // No.66
        public string AtlasNo { get; set; }
        public string CheckResult { get; set; } = "異常";
        // No.97 重複顔ID対策
        public DateTime CreateTime { get; set; }
        // 2.2.xx対応対策一覧 No.9 画像取得方法を統一する対策
        public string HasFilePath { get; set; }
        public bool CheckResultForFlag { get; set; } = false;
    }

    public class FaceAuthViewModel
    {
        private List<List<string>> Lines;
        private static readonly string FilePath = Configure.ToolCsvPath + @"\tool_csv.csv";
        private readonly string Path_ = "";

        public ObservableCollection<FaceAuthDataBean> Recordings { get; set; } = new ObservableCollection<FaceAuthDataBean>();
        public ObservableCollection<FaceAuthDataBean> Recordings_WithoutImage { get; set; } = new ObservableCollection<FaceAuthDataBean>();

        public FaceAuthViewModel()
        {
            this.Path_ = FilePath;
        }

        public FaceAuthViewModel(string Path_)
        {
            this.Path_ = Path_;
        }

        public void ReadViewDelay(int IsFaceTransmitMode)
        {
            ReadCsvFormal(IsFaceTransmitMode);
        }

        public void ReadViewDelayWithoutImage(int IsFaceTransmitMode)
        {
            ReadCsvFormalWithoutImage(IsFaceTransmitMode);
        }

        public void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(ExitFrames), frame);
            Dispatcher.PushFrame(frame);
        }

        public object ExitFrames(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }

        public void ReadCsvFormalWithoutImage(int IsFaceTransmitMode)
        {
            try
            {
                if (!File.Exists(this.Path_))
                {
                    return;
                }

                this.Recordings_WithoutImage.Clear();

                CsvFile Csv = new CsvFile(this.Path_);
                // # 285 対応
                this.Lines = WriteToolCsv.ReadToolCSV(0, "UTF-8");
                //this.Lines = Csv.Read(0, "UTF-8");
                int Count = 0;
                int maxColumn = 0;

                if (IsFaceTransmitMode == 2)
                {
                    maxColumn = 21;
                }
                else
                {
                    maxColumn = 20;
                }
                foreach (List<string> line in Lines)
                {
                    string[] Values = line.ToArray();

                    if (Values.Length < maxColumn)
                    {
                        continue;
                    }
                    if (CheckBytes(Values[0], 32) || CheckBytes(Values[1], 32) || CheckBytes(Values[2], 16)
                        || CheckBytes(Values[3], 50) || CheckBytes(Values[4], 50) || CheckBytes(Values[5], 4)
                        || CheckBytes(Values[6], 1) || CheckBytes(Values[7], 4) || CheckBytes(Values[8], 10)
                        || CheckBytes(Values[9], 10))
                    {
                        continue;
                    }
                    FaceAuthDataBean FaceItem = new FaceAuthDataBean
                    {
                        TicketId = Values[0],
                        FaceId = Values[1],
                        ManageId = Values[2],
                        StaffName = Values[3],
                        StaffNameKN = Values[4],
                        FigureId = Values[5],
                        FigureStatus = Values[6],
                        Thresholds = Values[7],
                        StartDate = Values[8],
                        ValidDate = Values[9],
                        // 2.2.xx対応対策一覧 No.9 画像データのファイル名取得方法を統一する
                        StaffImgPath = Path.Combine(Configure.FaceDataPath, Values[1] + @".jpg"),
                        HasFilePath = Values[10],
                        StaffImgName = "",
                        Staff_Image = null,
                        UserIds = new string[64],
                        LoginStatus = "有".Equals(Values[11]) ? "有" : "無",
                        LoginStatusCode = "有".Equals(Values[11]) ? "1" : "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsInserted = false,
                        IsUpdated = false,
                        IsDeleted = false,
                        IsUpdatedSuccess = new bool[64],
                        OnlyExistType = "",
                        OnlyExistAtlas = "",
                        // No.68
                        IsImageDataUpdateSuccess = true
                    };
                    for (int i = 0; i < FaceItem.UserIds.Length; i++)
                    {
                        // userid_1 is start from Valuse[15]
                        int valNum = i + 15;
                        FaceItem.UserIds[i] = Values[valNum];
                    }

                    for (int i = 0; i < FaceItem.IsUpdatedSuccess.Length; i++)
                    {
                        FaceItem.IsUpdatedSuccess[i] = false;
                    }

                    if (IsFaceTransmitMode == 2)
                    {
                        if (Values[12] != null && !"".Equals(Values[12]))
                        {
                            FaceItem.FloorNum = Values[12];
                        }
                        else
                        {
                            FaceItem.FloorNum = "";
                        }
                    }

                    Count++;
                    if (Count > Configure.MaxFaceCount)
                    {
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                        MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    }
                    this.Recordings_WithoutImage.Add(FaceItem);
                    DoEvents();
                }

                this.Recordings_WithoutImage = new ObservableCollection<FaceAuthDataBean>(this.Recordings_WithoutImage.OrderBy(item => item.FaceId));
                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.Recordings_WithoutImage)
                {
                    Bean.Idx = ++Idx_;
                }

                GC.Collect();
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] ファイルから顔データの読込は失敗しました。{ex.Message}");
                MessageBox.Show($"ファイルから顔データの読込は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void ReadCsvFormal(int IsFaceTransmitMode)
        {
            try
            {
                if (!File.Exists(this.Path_))
                {
                    return;
                }

                this.Recordings.Clear();

                CsvFile Csv = new CsvFile(this.Path_);
                // # 285 対応
                this.Lines = WriteToolCsv.ReadToolCSV(0, "UTF-8");
                //this.Lines = Csv.Read(0, "UTF-8");
                int Count = 0;
                int maxColumn = 0;

                if (IsFaceTransmitMode == 2)
                {
                    maxColumn = 21;
                }
                else
                {
                    maxColumn = 20;
                }
                foreach (List<string> line in Lines)
                {
                    string[] Values = line.ToArray();

                    if (Values.Length < maxColumn)
                    {
                        continue;
                    }
                    if (CheckBytes(Values[0], 32) || CheckBytes(Values[1], 32) || CheckBytes(Values[2], 16)
                        || CheckBytes(Values[3], 50) || CheckBytes(Values[4], 50) || CheckBytes(Values[5], 4)
                        || CheckBytes(Values[6], 1) || CheckBytes(Values[7], 4) || CheckBytes(Values[8], 10)
                        || CheckBytes(Values[9], 10))
                    {
                        continue;
                    }
                    FaceAuthDataBean FaceItem = new FaceAuthDataBean
                    {
                        TicketId = Values[0],
                        FaceId = Values[1],
                        ManageId = Values[2],
                        StaffName = Values[3],
                        StaffNameKN = Values[4],
                        FigureId = Values[5],
                        FigureStatus = Values[6],
                        Thresholds = Values[7],
                        StartDate = Values[8],
                        ValidDate = Values[9],
                        // 2.2.xx対応対策一覧 No.9 画像データのファイル名取得方法を統一する
                        StaffImgPath = Path.Combine(Configure.FaceDataPath, Values[1] + @".jpg"),
                        HasFilePath = Values[10],
                        StaffImgName = "",
                        Staff_Image = null,
                        UserIds = new string[64],
                        LoginStatus = "有".Equals(Values[11]) ? "有" : "無",
                        LoginStatusCode = "有".Equals(Values[11]) ? "1" : "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsInserted = false,
                        IsUpdated = false,
                        IsDeleted = false,
                        IsUpdatedSuccess = new bool[64],
                        OnlyExistType = "",
                        OnlyExistAtlas = "",
                        // No.68
                        IsImageDataUpdateSuccess = true
                    };
                    for (int i = 0; i < FaceItem.UserIds.Length; i++)
                    {
                        // userid_1 is start from Valuse[15]
                        int valNum = i + 15;
                        FaceItem.UserIds[i] = Values[valNum];
                    }

                    // # 273 対応
                    for (int i = 0; i < FaceItem.IsUpdatedSuccess.Length; i++)
                    {
                        FaceItem.IsUpdatedSuccess[i] = false;
                    }

                    // 2.2.xx対応対策一覧 No.9 画像データのファイル名取得方法を統一する
                    if (File.Exists(FaceItem.StaffImgPath))
                    {
                        FaceItem.StaffImgName = Values[1] + @".jpg";
                    }

                    if (IsFaceTransmitMode == 2)
                    {
                        if (Values[12] != null && !"".Equals(Values[12]))
                        {
                            FaceItem.FloorNum = Values[12];
                        }
                        else
                        {
                            FaceItem.FloorNum = "";
                        }
                    }

                    Count++;
                    if (Count > Configure.MaxFaceCount)
                    {
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                        MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    }
                    this.Recordings.Add(FaceItem);
                    DoEvents();
                }

                this.Recordings = new ObservableCollection<FaceAuthDataBean>(this.Recordings.OrderBy(item => item.FaceId));
                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.Recordings)
                {
                    Bean.Idx = ++Idx_;
                }

                GC.Collect();
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] ファイルから顔データの読込は失敗しました。{ex.Message}");
                MessageBox.Show($"ファイルから顔データの読込は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public async Task<bool> ReadFromAtlas(string AtlasIp, int AtlasKey, int AtlasCount)
        {
            try
            {
                this.Recordings.Clear();
                GC.Collect();
                GC.WaitForPendingFinalizers();

                AtlasApi Api = new AtlasApi();
                string Token = await Api.GetToken(AtlasIp);
                if ("".Equals(Token))
                {
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 装置への認証は失敗しました。");
                    return false;
                }
                string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);

                List<FaceAuthDataBean> UserList = new List<FaceAuthDataBean>();

                bool FlagCheck = await Api.GetUserList(AtlasIp, Token, DBId, AtlasKey, AtlasCount, UserList);

                int Count = 0;
                foreach (var user in UserList)
                {
                    Count++;
                    if (Count > Configure.MaxFaceCount)
                    {
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                        MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    }

                    this.Recordings.Add(user);
                }

                this.Recordings = new ObservableCollection<FaceAuthDataBean>(this.Recordings.OrderBy(item => item.FaceId));

                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.Recordings)
                {
                    Bean.Idx = ++Idx_;
                }

                GC.Collect();
                return true;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置から顔データの読込が失敗しました。{ex.Message}");
                MessageBox.Show($"装置から顔データの読込が失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return false;
        }

        public Boolean CheckBytes(string text, int max)
        {
            int ByteLength = System.Text.Encoding.Default.GetByteCount(text.Trim());
            if (ByteLength > max)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public class AtlasServerDataBean
    {
        public string Server_Name { get; set; }
        public string Server_Ip { get; set; }
    }

    public class AtlasServerViewModel
    {
        public ObservableCollection<AtlasServerDataBean> Recordings { get; } = new ObservableCollection<AtlasServerDataBean>();
        public AtlasServerDataBean InitSelectedItem { get; }
        public AtlasServerViewModel(bool byWriteBitmap = false)
        {
            if (byWriteBitmap)
            {
                this.Recordings.Add(new AtlasServerDataBean()
                {
                    Server_Name = "",
                    Server_Ip = ""
                });
            }
            else
            {
                this.Recordings.Add(new AtlasServerDataBean()
                {
                    Server_Name = "All",
                    Server_Ip = ""
                });
            }
            for (int i = 0; i < Configure.AtlasList.Length; i++)
            {
                string Item = Configure.AtlasList[i];
                if (Item != "")
                {
                    Recordings.Add(new AtlasServerDataBean()
                    {
                        Server_Name = $"{i + 1}",
                        Server_Ip = Item
                    });
                }
            }

            this.InitSelectedItem = this.Recordings.First();
        }
    }

    public class ReadSrcDataBean
    {
        public int Key { get; set; }
        public string Value { get; set; }
    }

    public class ReadSrcViewModel
    {
        public ObservableCollection<ReadSrcDataBean> Recordings { get; } = new ObservableCollection<ReadSrcDataBean>();

        public ReadSrcDataBean InitSelectedItem { get; }

        public ReadSrcViewModel(int IsFaceTransmitMode = 0, bool IsLoginByHitachiadmin = false)
        {
            if (IsFaceTransmitMode == 0)
            {
                this.Recordings.Add(new ReadSrcDataBean()
                {
                    Key = 1,
                    Value = "ファイル"
                });
            }
            // ログイン　ユーザーがhitachiadmin以外の場合、読出し設定先から「設置Atlas」を隠す
            if (IsLoginByHitachiadmin)
            {
                this.Recordings.Add(new ReadSrcDataBean()
                {
                    Key = 2,
                    Value = "装置(Atlas)"
                });
            }

            if (IsFaceTransmitMode == 0 || IsLoginByHitachiadmin)
            {
                this.InitSelectedItem = this.Recordings.First();
            }
        }
    }
}
