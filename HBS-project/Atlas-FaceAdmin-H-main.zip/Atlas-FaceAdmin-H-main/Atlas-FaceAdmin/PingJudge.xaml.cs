﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using MahApps.Metro.Controls;
using System.Drawing;
using System.Windows.Threading;
using System.Collections;
using System.Windows.Controls.Primitives;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// PingJudge.xaml の相互作用ロジック
    /// </summary>
    public partial class PingJudge : Window
    {
        // Disabled close button
        [DllImport("USER32.DLL", CharSet = CharSet.Unicode)]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, UInt32 bRevert);
        [DllImport("USER32.DLL ", CharSet = CharSet.Unicode)]
        private static extern UInt32 RemoveMenu(IntPtr hMenu, UInt32 nPosition, UInt32 wFlags);
        private const UInt32 SC_CLOSE = 0x0000F060;
        private const UInt32 MF_BYCOMMAND = 0x00000000;

        public int SumCount = 0;
        public int SuccessCount = 0;
        public int ErrorCount = 0;
        public int errorType = 1;

        // No.1 全選択できるようにします
        public bool CopyEnable = false;

        // No.40 Retryボタン押下後、正しい遷移流れを訂正する
        private bool FlagRetryOnError = false;

        public bool HasRunContinue { get; set; }

        // No.46 疎通成功した装置が0台の場合、すぐに一覧画面に遷移します。
        public bool HasRunCoutinueForAllError { get; set; }

        public bool HasBtnClosedYes { get; set; }

        private ObservableCollection<FaceAuthDataBean> Recordings = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<AtlasServerDataBean> AtlasListNoError = new ObservableCollection<AtlasServerDataBean>();
        private ObservableCollection<AtlasServerDataBean> AtlasListNoErrorForMakeDataSame = new ObservableCollection<AtlasServerDataBean>();
        public AtlasServerViewModel AtlasViewModel { get; set; }

        public PingJudge(ObservableCollection<FaceAuthDataBean> Recordings_Ping, int AtlasCount, int errorType = 1, ObservableCollection<AtlasServerDataBean> atlasListNoError = null, ObservableCollection<AtlasServerDataBean> atlasListNoErrorForMakeDataSame = null)
        {
            InitializeComponent();

            // No.75 PCの画面の中央に表示するようにします
            this.WindowStartupLocation = WindowStartupLocation.CenterScreen;

            this.AtlasViewModel = new AtlasServerViewModel();

            this.HasRunContinue = false;

            // No.46 疎通成功した装置が0台の場合、すぐに一覧画面に遷移します。
            this.HasRunCoutinueForAllError = false;

            foreach (FaceAuthDataBean bean in Recordings_Ping)
            {
                bean.FigureId = bean.FigureId.PadLeft(2, '0');
            }

            Recordings_Ping = new ObservableCollection<FaceAuthDataBean>(Recordings_Ping.OrderBy(item => item.FigureId));

            Recordings = Recordings_Ping;

            // No.1 2021/04/28
            this.DG2.DataContext = Recordings;

            this.IconImage.Source = ToImageSource(SystemIcons.Error);

            string str = "";

            var gridHeight = DG2.Height;

            foreach (FaceAuthDataBean bean in Recordings_Ping)
            {
                str += bean.FigureId + "\t" + bean.OnlyExistAtlas + "\r\n";
                // No.45 疎通結果ログ出力
                WriteLogSafe.LogSafe($"[疎通結果] {bean.StaffName}：号機：{bean.FigureId}、装置IPアドレス：{bean.OnlyExistAtlas}。");
            }
            this.txb_message.Text = str;

            SumCount = AtlasCount - 1;
            ErrorCount = Recordings_Ping.Count;
            SuccessCount = SumCount - ErrorCount;

            lab_count.Content = $"成功{SuccessCount}台\r\n失敗{ErrorCount}台";

            this.errorType = errorType;

            // ログイン時、疎通失敗 / 登録者一覧画面で、登録チェック時、疎通失敗
            if (errorType == 1)
            {
                // No.102 登録チェック時に、1台も疎通に成功してない場合は疎通エラー画面に文言とボタン修正
                UIChanged();
            }

            //  登録時、登録エラー
            if (errorType == 2)
            {
                lab_message.Content = $"以下の装置でエラーが発生しました。\r\n登録チェックを行いますか";
                this.Title = "登録エラー";

                btn_match.Visibility = Visibility.Hidden;

                btn_login.SetValue(Grid.ColumnSpanProperty, 2);
                Thickness marginLogin = new Thickness(82, 10, 0, 35);
                this.btn_login.Margin = marginLogin;

                btn_close.SetValue(Grid.ColumnProperty, 3);
                btn_close.SetValue(Grid.ColumnSpanProperty, 2);
                Thickness marginClose = new Thickness(63, 10, 90, 35);                
                this.btn_close.Margin = marginClose;                
            }

            // べリファイ時、疎通失敗
            if (errorType == 3)
            {
                lab_message.Content = $"以下の装置でエラーが発生しました。\r\n再度登録チェックを行うには登録一覧画面の\r\n「登録チェック」釦を押下してください。";

                btn_match.Visibility = Visibility.Hidden;
                btn_login.Visibility = Visibility.Hidden;
                btn_close.Content = "OK";
            }

            //　再登録時、登録エラー
            if (errorType == 4)
            {
                lab_message.Content = $"以下の装置でエラーが発生しました。";
                this.Title = "登録エラー";

                btn_match.Visibility = Visibility.Hidden;
                btn_login.Visibility = Visibility.Hidden;
                btn_close.Content = "OK";
            }

            // 登録時の疎通確認に関しての文言を変更
            if (errorType == 5)
            {
                // No.109 登録操作時に1台もAtlasと疎通が取れていないときに出るエラー画面について、表示内容を見直し
                UIChanged();
            }

            // No.63,76 結果詳細表示画面で、次/前顔ID釦押下で、通信断になった場合
            if (errorType == 6)
            {
                lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n各装置のLANの接続をご確認の上、\r\nリトライしてください。";
                btn_login.Visibility = Visibility.Hidden;

                btn_match.SetValue(Grid.ColumnProperty, 2);
                Thickness marginMatch = new Thickness(0, 10, 0, 35);
                this.btn_match.Margin = marginMatch;

                btn_close.SetValue(Grid.ColumnProperty, 3);
                Thickness marginClose = new Thickness(0, 10, 0, 35);
                this.btn_close.Margin = marginClose;
                btn_close.Content = "閉じる";
            }

            // No. 再登録する前の疎通確認画面です。その場合は「はい」ボタンを消します。
            if (errorType == 7)
            {
                UIChanged();
            }

            // No.97 エッジ端末の台数分処理を繰り返す時、通信エラー画面
            if (errorType == 8)
            {
                lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n各装置のLANの接続をご確認の上、\r\nリトライしてください。";
                btn_login.Visibility = Visibility.Hidden;

                btn_match.SetValue(Grid.ColumnProperty, 2);
                Thickness marginMatch = new Thickness(0, 10, 0, 35);
                this.btn_match.Margin = marginMatch;

                btn_close.SetValue(Grid.ColumnProperty, 3);
                Thickness marginClose = new Thickness(0, 10, 0, 35);
                this.btn_close.Margin = marginClose;
                btn_close.Content = "中止";
            }

            // Atlasから復旧時の疎通確認に関しての文言を変更
            if (errorType == 9)
            {
                UIChanged();
            }

            if (atlasListNoError != null)
            {
                AtlasListNoError = atlasListNoError;
            }
            if (atlasListNoErrorForMakeDataSame != null)
            {
                AtlasListNoErrorForMakeDataSame = atlasListNoErrorForMakeDataSame;
            }
            //No.85
            if ((Recordings.Count * DG2.RowHeight + DG2.ColumnHeaderHeight) < DG2.Height)
            {
                DG2.Height = Recordings.Count * DG2.RowHeight + DG2.ColumnHeaderHeight;
                this.Height = this.Height - (gridHeight - DG2.Height);
            }

            WriteLogSafe.LogSafe($"[疎通結果画面] 疎通結果画面を開きました。成功{SuccessCount}台、失敗{ErrorCount}台。");
        }

        // No.102 登録チェック時に、1台も疎通に成功してない場合は疎通エラー画面に文言とボタン修正
        private void UIChanged()
        {
            // No.109 登録操作時に1台もAtlasと疎通が取れていないときに出るエラー画面について、表示内容を見直し
            if (errorType == 5)
            {
                // No.102 登録チェック時に、1台も疎通に成功してない場合は疎通エラー画面にて、「はい」を非表示にする
                if (SuccessCount == 0)
                {
                    btn_login.Visibility = Visibility.Hidden;

                    btn_match.SetValue(Grid.ColumnProperty, 2);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_close.SetValue(Grid.ColumnProperty, 3);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n各装置のLANの接続をご確認の上、\r\nリトライしてください。";
                }
                else
                {
                    btn_match.SetValue(Grid.ColumnProperty, 1);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_login.Visibility = Visibility.Visible;
                    btn_login.SetValue(Grid.ColumnProperty, 2);
                    btn_login.SetValue(Grid.ColumnSpanProperty, 2);
                    Thickness marginLogin = new Thickness(74, 10, 77, 35);
                    this.btn_login.Margin = marginLogin;

                    btn_close.SetValue(Grid.ColumnProperty, 4);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n確認のとれた装置のみ登録を行いますか？";
                }
            }
            if (errorType == 1)
            {
                // No.102 登録チェック時に、1台も疎通に成功してない場合は疎通エラー画面にて、「はい」を非表示にする
                if (SuccessCount == 0)
                {
                    btn_login.Visibility = Visibility.Hidden;

                    btn_match.SetValue(Grid.ColumnProperty, 2);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_close.SetValue(Grid.ColumnProperty, 3);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n\r\n装置全台の登録チェックを行う場合は、\r\n疎通失敗した装置のLANの接続をご確認の上、リトライしてください。";
                }
                else
                {
                    btn_match.SetValue(Grid.ColumnProperty, 1);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_login.Visibility = Visibility.Visible;
                    btn_login.SetValue(Grid.ColumnProperty, 2);
                    btn_login.SetValue(Grid.ColumnSpanProperty, 2);
                    Thickness marginLogin = new Thickness(74, 10, 77, 35);
                    this.btn_login.Margin = marginLogin;

                    btn_close.SetValue(Grid.ColumnProperty, 4);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n\r\n装置全台の登録チェックを行う場合は、\r\n疎通失敗した装置のLANの接続をご確認の上、リトライしてください。\r\n\r\nそれとも確認の取れた装置のみ登録チェックを行いますか？";
                }
            }
            if (errorType == 7)
            {
                if (SuccessCount == 0)
                {
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n各装置のLANの接続をご確認の上、\r\nリトライしてください。";
                    btn_login.Visibility = Visibility.Hidden;

                    btn_match.SetValue(Grid.ColumnProperty, 2);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_close.SetValue(Grid.ColumnProperty, 3);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    btn_close.Content = "閉じる";
                }
                else
                {
                    //lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n各装置のLANの接続をご確認の上、\r\nリトライしてください。";
                    // 2.2.xx対応対策一覧 No.10 疎通確認画面文言と「はい」ボタン対応
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n疎通失敗した装置のLANの接続をご確認の上、リトライしてください。\r\n\r\nそれとも確認のとれた装置のみ登録を行いますか？";
                    btn_match.SetValue(Grid.ColumnProperty, 1);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_login.Visibility = Visibility.Visible;
                    btn_login.SetValue(Grid.ColumnProperty, 2);
                    btn_login.SetValue(Grid.ColumnSpanProperty, 2);
                    Thickness marginLogin = new Thickness(74, 10, 77, 35);
                    this.btn_login.Margin = marginLogin;

                    btn_close.SetValue(Grid.ColumnProperty, 4);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                }
            }
            if (errorType == 9)
            {
                if (SuccessCount == 0)
                {
                    btn_login.Visibility = Visibility.Hidden;

                    btn_match.SetValue(Grid.ColumnProperty, 2);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_close.SetValue(Grid.ColumnProperty, 3);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。\r\n各装置のLANの接続をご確認の上、\r\nリトライしてください。";
                }
                else
                {
                    btn_match.SetValue(Grid.ColumnProperty, 1);
                    Thickness marginMatch = new Thickness(0, 10, 0, 35);
                    this.btn_match.Margin = marginMatch;

                    btn_login.Visibility = Visibility.Visible;
                    btn_login.SetValue(Grid.ColumnProperty, 2);
                    btn_login.SetValue(Grid.ColumnSpanProperty, 2);
                    Thickness marginLogin = new Thickness(74, 10, 77, 35);
                    this.btn_login.Margin = marginLogin;

                    btn_close.SetValue(Grid.ColumnProperty, 4);
                    Thickness marginClose = new Thickness(0, 10, 0, 35);
                    this.btn_close.Margin = marginClose;
                    lab_message.Content = $"以下の装置でLANの疎通確認に失敗しました。" +
                        $"\r\n\r\n装置全台からPC復旧を行う場合は、" +
                        $"\r\n疎通失敗した装置のLANの接続をご確認の上、リトライしてください。" +
                        $"\r\n\r\nそれとも確認の取れた装置からPC復旧を行いますか？";
                }
            }
        }

        private ImageSource ToImageSource(Icon icon)
        {
            ImageSource imageSource = Imaging.CreateBitmapSourceFromHIcon(
                icon.Handle,
                Int32Rect.Empty,
                BitmapSizeOptions.FromEmptyOptions());

            return imageSource;
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            var hwnd = new WindowInteropHelper(this).Handle;
            IntPtr hMenu = GetSystemMenu(hwnd, 0);
            RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);

            loading.IsActive = false;
            loadingPart.Visibility = Visibility.Hidden;
        }

        private void Content_Rendered(object sender, EventArgs e)
        {

        }

        private void Btn_Retry_Click(object sender, RoutedEventArgs e)
        {
            // No.51 はい釦を押下したログを残す
            WriteLogSafe.LogSafe($"[疎通結果] リトライ処理を実行します。");
            this.loading.IsActive = true;
            this.loadingPart.Visibility = Visibility.Visible;

            txb_message.Text = "";
            this.Recordings.Clear();
            // No.40 Retryボタン押下後、正しい遷移流れを訂正する
            FlagRetryOnError = false;

            List<Task<bool>> tasks = new List<Task<bool>>();

            tasks.Add(Ping_Retry());

            Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
            {
                this.Invoke(new Action(() =>
                {
                    foreach (FaceAuthDataBean bean in Recordings)
                    {
                        bean.FigureId = bean.FigureId.PadLeft(2, '0');
                    }

                    Recordings = new ObservableCollection<FaceAuthDataBean>(Recordings.OrderBy(item => item.FigureId));

                    string str = "";

                    foreach (FaceAuthDataBean bean in Recordings)
                    {
                        str += bean.FigureId + "\t" + bean.OnlyExistAtlas + "\r\n";
                        // No.45 疎通結果ログ出力
                        WriteLogSafe.LogSafe($"[疎通結果] {bean.StaffName}：号機：{bean.FigureId}、装置IPアドレス：{bean.OnlyExistAtlas}。");
                    }
                    this.txb_message.Text = str;

                    this.DG2.DataContext = Recordings;

                    ErrorCount = Recordings.Count;
                    SuccessCount = SumCount - ErrorCount;

                    lab_count.Content = $"成功{SuccessCount}台\r\n失敗{ErrorCount}台";

                    // No.102,109 登録チェック時に、1台も疎通に成功してない場合は疎通エラー画面に文言とボタン修正
                    UIChanged();

                    // No.40 Retryボタン押下後、正しい遷移流れを訂正する
                    if (!FlagRetryOnError && ErrorCount == 0)
                    {
                        // Retry後、すべての疎通状態が正常になる場合、エラーメッセージを表示せず、疎通確認画面を閉じる。
                        this.lab_message.Content = "";
                    }

                    //No.146 リトライごとに画面には、疎通エラーなった台数分のサイズで表示します。
                    var gridHeight = DG2.Height;
                    if (Recordings.Count < 6)
                    {
                        DG2.Height = Recordings.Count * DG2.RowHeight + DG2.ColumnHeaderHeight;
                        this.Height = this.Height - (gridHeight - DG2.Height);
                    }
                    else
                    {
                        DG2.Height = 280;
                        this.Height = 648;
                    }

                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;

                    WriteLogSafe.LogSafe($"[疎通結果画面] リトライ処理を実行しました。成功{SuccessCount}台、失敗{ErrorCount}台。");

                    // No.40 Retryボタン押下後、正しい遷移流れを訂正する
                    if (!FlagRetryOnError && ErrorCount == 0)
                    {
                        // Retry後、すべての疎通状態が正常になる場合、エラーメッセージを表示せず、疎通確認画面を閉じる。
                        Btn_Yes_Click(sender, e);
                    }
                }));
            });
        }

        private async Task<bool> Ping_Retry()
        {
            var AtlasList = this.AtlasViewModel.Recordings;
            int AtlasCount = AtlasList.Count;

            // No.134 疎通結果画面でリトライすると不具合対応
            if (errorType == 6　|| errorType == 7 || errorType == 8)
            {
                AtlasList = AtlasListNoError;
                AtlasCount = AtlasListNoError.Count + 1;

                AtlasListNoError = new ObservableCollection<AtlasServerDataBean>();
            }

            var ping = new System.Net.NetworkInformation.Ping();
            ObservableCollection<FaceAuthDataBean> Recordings_Ping_Retry = new ObservableCollection<FaceAuthDataBean>();

            await Task.Delay(1000);

            // No.84 確認のとれた装置のみ登録チェックを行います
            // No.128「リトライ」後に全台のベリファイチェックを行っているかの見直し
            if (errorType == 7)
            {
                AtlasListNoErrorForMakeDataSame.Clear();
            }
            else
            {
                AtlasListNoError.Clear();
            }

            for (int i = 1; i < AtlasCount; i++)
            {
                string[] AtlasIpInfo;
                string AtlasNumber;

                // No.134 疎通結果画面でリトライすると不具合対応
                int AtlasNo;
                if (errorType == 6 || errorType == 7 || errorType == 8)
                {
                    AtlasNo = i - 1;
                }
                else
                {
                    AtlasNo = i;
                }

                AtlasIpInfo = AtlasList[AtlasNo].Server_Ip.Split(':');
                AtlasNumber = AtlasList[AtlasNo].Server_Name;
                string AtlasIpNoPort = AtlasIpInfo[0];

                await Task.Delay(100);

                try
                {
                    // No.99 画面を移動させてマウスが効かなくなることを修正
                    var result = await ping.SendPingAsync(AtlasIpNoPort);

                    if (result.Status != System.Net.NetworkInformation.IPStatus.Success)
                    {
                        FlagRetryOnError = true;
                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "疎通失敗",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasNumber,
                        };

                        Recordings_Ping_Retry.Add(item);
                    }
                    // No.84 確認のとれた装置のみ登録チェックを行います
                    else
                    {
                        if (errorType == 7)
                        {
                            AtlasListNoErrorForMakeDataSame.Add(AtlasList[AtlasNo]);
                        }
                        else
                        {
                            // No.134 疎通結果画面でリトライすると不具合対応
                            AtlasListNoError.Add(AtlasList[AtlasNo]);
                        }
                    }
                }
                catch (Exception)
                {
                    FlagRetryOnError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasNumber,
                    };

                    Recordings_Ping_Retry.Add(item);
                }
            }

            Recordings = Recordings_Ping_Retry;

            // No.134 疎通結果画面でリトライすると不具合対応
            if (errorType == 6 || errorType == 7 || errorType == 8)
            {
                AtlasListNoError = AtlasList;
            }

            return true;
        }

        private async Task<bool> Ping_Retry_NoError()
        {
            var AtlasList = AtlasListNoError;
            int AtlasCount = AtlasListNoError.Count;

            ObservableCollection<AtlasServerDataBean> AtlasListNoErrorForRetry = new ObservableCollection<AtlasServerDataBean>();

            var ping = new System.Net.NetworkInformation.Ping();
            ObservableCollection<FaceAuthDataBean> Recordings_Ping_Retry = new ObservableCollection<FaceAuthDataBean>();

            await Task.Delay(1000);

            for (int i = 0; i < AtlasCount; i++)
            {
                string[] AtlasIpInfo;
                string AtlasNumber;

                AtlasIpInfo = AtlasList[i].Server_Ip.Split(':');
                AtlasNumber = AtlasList[i].Server_Name;
                string AtlasIpNoPort = AtlasIpInfo[0];

                await Task.Delay(100);

                try
                {
                    // No.99 画面を移動させてマウスが効かなくなることを修正
                    var result = await ping.SendPingAsync(AtlasIpNoPort);

                    if (result.Status != System.Net.NetworkInformation.IPStatus.Success)
                    {
                        FlagRetryOnError = true;
                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "疎通失敗",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasNumber,
                        };

                        Recordings_Ping_Retry.Add(item);
                    }
                    // No.84 確認のとれた装置のみ登録チェックを行います
                    else
                    {
                        AtlasListNoErrorForRetry.Add(AtlasList[i]);
                    }
                }
                catch (Exception)
                {
                    FlagRetryOnError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasNumber,
                    };

                    Recordings_Ping_Retry.Add(item);
                }
            }

            Recordings = Recordings_Ping_Retry;

            AtlasListNoError = AtlasListNoErrorForRetry;

            return true;
        }

        private void Btn_Yes_Click(object sender, RoutedEventArgs e)
        {
            // No.51 はい釦を押下したログを残す
            WriteLogSafe.LogSafe($"[疎通結果画面] はいを押下しました。");
            this.HasRunContinue = true;

            // No.46 疎通成功した装置が0台の場合、すぐに一覧画面に遷移します。
            if (SuccessCount == 0)
            {
                this.HasRunCoutinueForAllError = true;
            }

            WriteLogSafe.LogSafe($"[疎通結果画面] 疎通結果画面を閉じました。");
            this.Close();
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            if (errorType == 2)
            {
                string msg = $"本当に登録チェックを行わなくてもよろしいですか？";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                          MessageBoxButton.OKCancel, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.Cancel))
                {
                    return;
                }
                // No.51 OK釦を押下したログを残す
                WriteLogSafe.LogSafe($"[疎通結果] 本当に登録チェックを行わなくてもよろしいですか「OK」押下。");
            }

            if (errorType == 8)
            {
                string msg = $"PC復旧を中断しますが、よろしいですか？";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                          MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.No))
                {
                    return;
                }
                HasBtnClosedYes = true;
                // はい釦を押下したログを残す
                WriteLogSafe.LogSafe($"[疎通結果] PC復旧を中断しますが、よろしいですか「はい」押下。");
            }

            this.HasRunContinue = false;


            // No.51 いいえ釦を押下したログを残す
            WriteLogSafe.LogSafe($"[疎通結果画面] いいえを押下しました。");
            WriteLogSafe.LogSafe($"[疎通結果画面] 疎通結果画面を閉じました。");
            this.Close();
        }

        // No.1 CtrlAで全選択対応。
        public List<T> GetChildObjects<T>(DependencyObject obj, string name) where T : FrameworkElement
        {
            DependencyObject child = null;
            List<T> childList = new List<T>();
            for (int i = 0; i <= VisualTreeHelper.GetChildrenCount(obj) - 1; i++)
            {
                child = VisualTreeHelper.GetChild(obj, i);
                if (child is T && (((T)child).Name == name || string.IsNullOrEmpty(name)))
                {
                    childList.Add((T)child);
                }
                childList.AddRange(GetChildObjects<T>(child, ""));//指定集合的元素添加到List队尾
            }
            return childList;
        }

        private void TextBox_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            bool isCtrl = e.KeyboardDevice.Modifiers == ModifierKeys.Control;
            bool isCtrlC = e.Key == Key.C && e.KeyboardDevice.Modifiers == ModifierKeys.Control;
            bool isCtrlA = e.Key == Key.A && e.KeyboardDevice.Modifiers == ModifierKeys.Control;

            // No.1 CtrlAで全選択対応。
            if (isCtrlA)
            {
                List<TextBox> collection = GetChildObjects<TextBox>(this.DG2, "nameItemTemplate");
                foreach (TextBox item in collection)
                {
                    if (item.Text != "")
                    {
                        item.Background = System.Windows.Media.Brushes.CornflowerBlue;
                    }
                }
                TextBox textbox = (TextBox)sender;
                textbox.SelectionStart = textbox.Text.Length;

                this.CopyEnable = true;

                e.Handled = true;
            }
            else if (isCtrlC)
            {
                if (CopyEnable)
                {
                    // No.1 2021/04/28
                    if (this.txb_message.Text != "")
                    {
                        Clipboard.Clear();
                        Clipboard.SetDataObject(this.txb_message.Text, true);
                    }

                    List<TextBox> collection = GetChildObjects<TextBox>(this.DG2, "nameItemTemplate");
                    foreach (TextBox item in collection)
                    {
                        if (item.Text != "")
                        {
                            item.Background = System.Windows.Media.Brushes.White;
                        }
                    }
                    TextBox textbox = (TextBox)sender;
                    textbox.SelectionStart = textbox.Text.Length;

                    this.CopyEnable = false;

                    e.Handled = false;
                }

                e.Handled = false;
            }
            else if (isCtrl)
            {
                e.Handled = true;
            }
            else
            {
                List<TextBox> collection = GetChildObjects<TextBox>(this.DG2, "nameItemTemplate");
                foreach (TextBox item in collection)
                {
                    if (item.Text != "")
                    {
                        item.Background = System.Windows.Media.Brushes.White;
                    }
                }

                this.CopyEnable = false;

                e.Handled = true;
            }
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            if (this.loading.IsActive == true)
            {
                e.Handled = true;
            }
        }

        public void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(ExitFrames), frame);
            Dispatcher.PushFrame(frame);
        }

        public object ExitFrames(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            List<TextBox> collection = GetChildObjects<TextBox>(this.DG2, "nameItemTemplate");
            foreach (TextBox item in collection)
            {
                if (item.Text != "")
                {
                    item.Background = System.Windows.Media.Brushes.White;
                }
            }

            this.CopyEnable = false;
        }
    }
}
