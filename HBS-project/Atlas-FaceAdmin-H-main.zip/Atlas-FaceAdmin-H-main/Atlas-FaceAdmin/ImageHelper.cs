﻿using System;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.Windows;
using System.Drawing.Imaging;
using System.Drawing.Drawing2D;

namespace RegisterFaceAuthTool
{
    public class ImageHelper
    {
        public static string Key = "QXRsYXM1MDA=";
        public static byte[] sKey = new byte[8];
        public static byte[] sIV = new byte[8];

        static ImageHelper()
        {
            byte[] keyByteArray = Encoding.Default.GetBytes(Key);
            SHA1 ha = new SHA1Managed();
            byte[] hb = ha.ComputeHash(keyByteArray);

            for (int i = 0; i < 8; i++)
                sKey[i] = hb[i];
            for (int i = 8; i < 16; i++)
                sIV[i - 8] = hb[i];
        }

        public static bool EncryptFile(BitmapImage bitmapImage, string savePath)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapImage));
                using (MemoryStream ims = new MemoryStream())
                {
                    encoder.Save(ims);
                    inputByteArray = ims.ToArray();
                }

                des.Key = sKey;
                des.IV = sIV;
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(inputByteArray, 0, inputByteArray.Length);
                        cs.FlushFinalBlock();
                        using (FileStream fs = File.Create(savePath))
                        {
                            foreach (byte b in ms.ToArray())
                            {
                                fs.WriteByte(b);
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 画像ファイル({savePath})の暗号化保存は失敗しました。{ex.Message}");
            }
            return false;
        }

        public static BitmapImage DecryptFile(string filePath, bool hasLog = true)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                using (FileStream fs = File.OpenRead(filePath))
                {
                    inputByteArray = new byte[fs.Length];
                    fs.Read(inputByteArray, 0, (int)fs.Length);
                }

                des.Key = sKey;
                des.IV = sIV;
                using (WrappingStream wrapper = new WrappingStream(new MemoryStream()))
                {
                    using (CryptoStream cs = new CryptoStream(wrapper, des.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(inputByteArray, 0, inputByteArray.Length);
                        cs.FlushFinalBlock();
                        wrapper.Position = 0;
                        BitmapImage bitmapImage = new BitmapImage();
                        bitmapImage.BeginInit();
                        bitmapImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapImage.UriSource = null;
                        bitmapImage.StreamSource = wrapper;
                        bitmapImage.EndInit();
                        bitmapImage.Freeze();

                        int oldPixelWidth = bitmapImage.PixelWidth; //横幅
                        int oldPixelHeighth = bitmapImage.PixelHeight; //高さ

                        // メモリ対策　ピクセル設定
                        int oldPixelMax = oldPixelWidth * oldPixelHeighth;

                        if (oldPixelMax > Configure.MaxPixel)
                        {
                            double PixelMaxRate = (double)Configure.MaxPixel / (double)oldPixelMax;
                            double rate = Math.Sqrt(PixelMaxRate);

                            double newPixelWidth = oldPixelWidth * rate;
                            double newPixelHeighth = oldPixelHeighth * rate;

                            wrapper.Position = 0;
                            BitmapImage bitmapImage_pixel = new BitmapImage();
                            bitmapImage_pixel.BeginInit();
                            bitmapImage_pixel.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                            bitmapImage_pixel.CacheOption = BitmapCacheOption.OnLoad;
                            bitmapImage_pixel.UriSource = null;
                            bitmapImage_pixel.StreamSource = wrapper;
                            bitmapImage_pixel.DecodePixelWidth = (int)newPixelWidth;
                            bitmapImage_pixel.DecodePixelHeight = (int)newPixelHeighth;
                            bitmapImage_pixel.EndInit();
                            bitmapImage_pixel.Freeze();

                            return bitmapImage_pixel;
                        }
                        return bitmapImage;
                    }
                }
            }
            catch (Exception ex)
            {
                // No.100 無駄なログを出力しない対応　デフォルト値はTRUEなので、ログ出力　出力しない時はFALSEで設定してください
                if (hasLog)
                {
                    WriteLogSafe.LogSafe($"[イメージツール]  暗号化した画像ファイル({filePath})の読み込みは失敗しました。{ex.Message}");
                }
            }
            return null;
        }

		// No.67 メモリ対策
        public static BitmapImage DecryptFileOriginalSize(string filePath)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                using (FileStream fs = File.OpenRead(filePath))
                {
                    inputByteArray = new byte[fs.Length];
                    fs.Read(inputByteArray, 0, (int)fs.Length);
                }

                des.Key = sKey;
                des.IV = sIV;
                using (WrappingStream wrapper = new WrappingStream(new MemoryStream()))
                {
                    using (CryptoStream cs = new CryptoStream(wrapper, des.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(inputByteArray, 0, inputByteArray.Length);
                        cs.FlushFinalBlock();
                        wrapper.Position = 0;
                        BitmapImage bitmapImage = new BitmapImage();
                        bitmapImage.BeginInit();
                        bitmapImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapImage.UriSource = null;
                        bitmapImage.StreamSource = wrapper;
                        bitmapImage.EndInit();
                        bitmapImage.Freeze();

                        return bitmapImage;
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 暗号化した画像ファイル( {filePath})の読み込みは失敗しました。{ex.Message}");
            }
            return null;
        }

		// No.67 メモリ対策
        public static string DecryptFileToBase64(string filePath)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                using (FileStream fs = File.OpenRead(filePath))
                {
                    inputByteArray = new byte[fs.Length];
                    fs.Read(inputByteArray, 0, (int)fs.Length);
                }

                des.Key = sKey;
                des.IV = sIV;
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(inputByteArray, 0, inputByteArray.Length);
                        cs.FlushFinalBlock();

                        byte[] inputByteArrayAfterDecrypt = ms.ToArray();
                        return Convert.ToBase64String(inputByteArrayAfterDecrypt);
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 暗号化した画像ファイル({filePath} )の読み込みは失敗しました。{ex.Message}");
            }
            return "";
        }

        public static long GetImageSize(string file)
        {
            try
            {
                FileInfo info = new FileInfo(file);
                return info.Length;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 画像ファイル({file})のサイズ取得は失敗しました。{ex.Message}");
            }
            return 0;
        }

        public static BitmapImage GetBitmapImage(string file)
        {
            try
            {
                // メモリ対策　ピクセル設定
                int oldPixelWidth = 0;
                int oldPixelHeighth = 0;
                using (System.IO.FileStream fs = new FileStream(file, System.IO.FileMode.Open, System.IO.FileAccess.Read))
                {
                    oldPixelWidth = System.Drawing.Image.FromStream(fs).Width; //横幅
                    oldPixelHeighth = System.Drawing.Image.FromStream(fs).Height; //高さ
                }

                BitmapImage bmpImg = new BitmapImage();
                bmpImg.BeginInit();
                bmpImg.CacheOption = BitmapCacheOption.OnLoad;
                bmpImg.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                bmpImg.UriSource = new Uri(file);

                // メモリ対策　ピクセル設定
                int oldPixelMax = oldPixelWidth * oldPixelHeighth;

                if (oldPixelMax > Configure.MaxPixel)
                {
                    double PixelMaxRate = (double)Configure.MaxPixel / (double)oldPixelMax;
                    double rate = Math.Sqrt(PixelMaxRate);

                    double newPixelWidth = oldPixelWidth * rate;
                    double newPixelHeighth = oldPixelHeighth * rate;

                    bmpImg.DecodePixelWidth = (int)newPixelWidth;
                    bmpImg.DecodePixelHeight = (int)newPixelHeighth;
                }

                bmpImg.EndInit();                
                bmpImg.Freeze();
                return bmpImg;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 画像ファイル({file})の読み込みは失敗しました。{ex.Message}");
            }
            return null;
        }

        // No.67 メモリ対策
        public static BitmapImage GetBitmapImageOriginalSize(string file)
        {
            try
            {
                BitmapImage bmpImg = new BitmapImage();
                bmpImg.BeginInit();
                bmpImg.CacheOption = BitmapCacheOption.OnLoad;
                bmpImg.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                bmpImg.UriSource = new Uri(file);
                bmpImg.EndInit();
                bmpImg.Freeze();
                return bmpImg;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 画像ファイル({file})の読み込みは失敗しました。{ex.Message}");
            }
            return null;
        }

        public static string BitmapToBase64(BitmapImage bi)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bi));
                encoder.Save(ms);
                byte[] bitmapdata = ms.ToArray();
                return Convert.ToBase64String(bitmapdata);
            }
        }

        public static BitmapSource GetBitmapImageExifOrientate(string file)
        {
            BitmapImage bmpImage = new BitmapImage();
            FileStream stream = File.OpenRead(file);
            bmpImage.BeginInit();
            bmpImage.CacheOption = BitmapCacheOption.OnLoad;
            bmpImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
            bmpImage.StreamSource = stream;


            var metaData = (BitmapFrame.Create(stream).Metadata) as BitmapMetadata;

            stream.Position = 0;
            bmpImage.UriSource = new Uri(file);
            

            string query = "/app1/ifd/exif:{uint=274}";
            if (!metaData.ContainsQuery(query))
            {
                bmpImage.EndInit();
                bmpImage.Freeze();
                stream.Close();
                return bmpImage;
            }
            switch (Convert.ToUInt32(metaData.GetQuery(query)))
            {
                case 1:
                    break;
                case 3:
                    bmpImage.Rotation = Rotation.Rotate180;
                    break;
                case 6:
                    bmpImage.Rotation = Rotation.Rotate90;
                    break;
                case 8:
                    bmpImage.Rotation = Rotation.Rotate270;
                    break;
                case 2:
                    break;
                case 4:
                    break;
                case 5:
                    bmpImage.Rotation = Rotation.Rotate90;
                    break;
                case 7:
                    bmpImage.Rotation = Rotation.Rotate270;
                    break;
            }
            bmpImage.EndInit();
            bmpImage.Freeze();

            stream.Close();
            return bmpImage;
        }

        public static BitmapSource TransformBitmap(BitmapSource source, Transform transform)
        {
            var result = new TransformedBitmap();
            result.BeginInit();
            result.Source = source;
            result.Transform = transform;
            result.EndInit();
            return result;
        }

        public static bool SaveBitmapImageIntoFile(BitmapImage bitmapImage, string filePath)
        {
            try
            {
                BitmapEncoder encoder = new PngBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapImage));

                using (var fileStream = new System.IO.FileStream(filePath, System.IO.FileMode.Create))
                {
                    encoder.Save(fileStream);
                }

                return true;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 画像ファイル({filePath})の読み込みは失敗しました。{ex.Message}");
                return false;
            }
        }
        //Scale down the image till it fits the given file size.
        public static Image ScaleDownToKb(Image img, long targetKilobytes, long quality)
        {
            //DateTime start = DateTime.Now;
            //DateTime end;

            float h, w;
            float halfFactor = 100; // halves itself each iteration
            float testPerc = 100;
            var direction = -1;
            long lastSize = 0;
            var iteration = 0;
            var origH = img.Height;
            var origW = img.Width;

            // if already below target, just return the image
            var size = GetImageFileSizeBytes(img, 250000, quality);
            if (size < targetKilobytes * 1024)
            {
                //end = DateTime.Now;
                //Console.WriteLine("================ DONE.  ITERATIONS: " + iteration + " " + end.Subtract(start));
                return img;
            }

            while (true)
            {
                iteration++;

                halfFactor /= 2;
                testPerc += halfFactor * direction;

                h = origH * testPerc / 100;
                w = origW * testPerc / 100;

                var test = ScaleImage(img, (int)w, (int)h);
                size = GetImageFileSizeBytes(test, 50000, quality);

                var byteTarg = targetKilobytes * 1024;
                //Console.WriteLine(iteration + ": " + halfFactor + "% (" + testPerc + ") " + size + " " + byteTarg);

                if ((Math.Abs(byteTarg - size) / (double)byteTarg) < .1 || size == lastSize || iteration > 15 /* safety measure */)
                {
                    //end = DateTime.Now;
                    //Console.WriteLine("================ DONE.  ITERATIONS: " + iteration + " " + end.Subtract(start));
                    return test;
                }

                if (size > targetKilobytes * 1024)
                {
                    direction = -1;
                }
                else
                {
                    direction = 1;
                }

                lastSize = size;
            }
        }
        public static long GetImageFileSizeBytes(Image image, int estimatedSize, long quality)
        {
            long jpegByteSize;
            using (var ms = new MemoryStream(estimatedSize))
            {
                SaveJpeg(image, ms, quality);
                jpegByteSize = ms.Length;
            }
            return jpegByteSize;
        }
        public static void SaveJpeg(Image image, MemoryStream ms, long quality)
        {
            ((Bitmap)image).Save(ms, FindEncoder(ImageFormat.Jpeg), GetEncoderParams(quality));
        }
        public static void SaveJpeg(Image image, string filename, long quality)
        {
            ((Bitmap)image).Save(filename, FindEncoder(ImageFormat.Jpeg), GetEncoderParams(quality));
        }
        public static ImageCodecInfo FindEncoder(ImageFormat format)
        {

            if (format == null)
                throw new ArgumentNullException("format");

            foreach (ImageCodecInfo codec in ImageCodecInfo.GetImageEncoders())
            {
                if (codec.FormatID.Equals(format.Guid))
                {
                    return codec;
                }
            }

            return null;
        }
        public static EncoderParameters GetEncoderParams(long quality)
        {
            System.Drawing.Imaging.Encoder encoder = System.Drawing.Imaging.Encoder.Quality;
            //Encoder encoder = new Encoder(ImageFormat.Jpeg.Guid);
            EncoderParameters eparams = new EncoderParameters(1);
            EncoderParameter eparam = new EncoderParameter(encoder, quality);
            eparams.Param[0] = eparam;
            return eparams;
        }
        //Scale an image to a given width and height.
        public static Image ScaleImage(Image img, int outW, int outH)
        {
            Bitmap outImg = new Bitmap(outW, outH, img.PixelFormat);
            outImg.SetResolution(img.HorizontalResolution, img.VerticalResolution);
            Graphics graphics = Graphics.FromImage(outImg);
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            graphics.DrawImage(img, new Rectangle(0, 0, outW, outH), new Rectangle(0, 0, img.Width, img.Height), GraphicsUnit.Pixel);
            graphics.Dispose();

            return outImg;
        }
        // 2.2.xx対応対策一覧　No.3 登録する顔画像が500kBを超えている場合、顔登録アプリで500kBに縮小して登録する
        public static void JpgFileToBase64(string staffImagePath, string cardId)
        {
            try
            {
                // 一時ファイルのパスをタイムスタンプ別から設定する
                DateTime dt = DateTime.Now;
                string savePath500kb = Configure.FaceDataPath + @"\" + cardId + @"_temp_" + string.Format("{0:yyyyMMdd_HHmmss}", dt) + @".jpg";

                // 暗号化した画像をBitmapImageに変更する
                BitmapImage image = DecryptFileOriginalSize(staffImagePath);

                // BitmapImageをBitmapに変更する
                Bitmap image_original = BitmapImageToBitmap(image);

                // 画像を500KBに縮小する
                Image scaled = ScaleDownToKb(image_original, 500, 80);

                // 縮小した画像を一時ファイルとして、ローカルフォルダに保存する
                ImageHelper.SaveJpeg(scaled, savePath500kb, 80);

                // 一時ファイルを隠しファイルに設定する
                File.SetAttributes(savePath500kb, FileAttributes.Hidden);

                // 一時ファイルを暗号化して、元の画像を替わる
                BitmapImage staffImgSource = GetBitmapImageOriginalSize(savePath500kb);
                EncryptFile(staffImgSource, staffImagePath);

                // 一時ファイルを削除する
                if (File.Exists(savePath500kb))
                {
                    File.Delete(savePath500kb);
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[イメージツール] 顔画像{staffImagePath}が500kBを超えている、500kBに縮小に失敗しました。{ex.Message}");
            }
        }
        public static Bitmap BitmapImageToBitmap(BitmapImage bitmapImage)
        {
            // BitmapImage bitmapImage = new BitmapImage(new Uri("../Images/test.png", UriKind.Relative));

            using (MemoryStream outStream = new MemoryStream())
            {
                BitmapEncoder enc = new BmpBitmapEncoder();
                enc.Frames.Add(BitmapFrame.Create(bitmapImage));
                enc.Save(outStream);
                Bitmap bitmap = new Bitmap(outStream);

                return new Bitmap(bitmap);
            }
        }
    }
}