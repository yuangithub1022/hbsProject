﻿using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// App.xaml の相互作用ロジック
    /// </summary>
    public partial class App : Application
    {
        private static System.Threading.Mutex mutex;

        // No.101 「すでに起動しています。」のメッセージ表示の後、後のメッセージを表示させないようにする
        public static bool isStart = false;
        protected override void OnStartup(StartupEventArgs e)
        {
            mutex = new System.Threading.Mutex(true, "OnlyRunOne_AtlasFaceAdmin");
            //ミューテックスの所有権を要求する
            if (mutex.WaitOne(0, false))
            {
                // # 275 対応
                if (!Directory.Exists(Configure.BasePath))
                {
                    MessageBox.Show($"指定ディレクトリ({Configure.BasePath})が存在しません。", "エラー",
                                MessageBoxButton.OK, MessageBoxImage.Error);
                }
                else
                {
                    if (File.Exists(Configure.ConfigFile))
                    {
                        Configure.ConfigFileNew = Configure.ConfigFile;
                        base.OnStartup(e);
                    }
                    else
                    {
                        System.Windows.MessageBox.Show($"コンフィグファイル({Configure.ConfigFile})が存在しません。\n\rコンフィグファイルを指定してください。", "",
                                            MessageBoxButton.OK, MessageBoxImage.Information);

                        System.Windows.Forms.OpenFileDialog openFile = new System.Windows.Forms.OpenFileDialog
                        {
                            Multiselect = false,
                            Filter = "コンフィグファイル|*.ini"
                        };
                        System.Windows.Forms.DialogResult result = openFile.ShowDialog();
                        if (result == System.Windows.Forms.DialogResult.Cancel)
                        {
                            //MessageBox.Show($"コンフィグファイルが指定しません。", "エラー",
                            //    MessageBoxButton.OK, MessageBoxImage.Error);
                            //this.Shutdown();
                            return;
                        }

                        var SelectCconfigFile = openFile.FileName;

                        Configure.ConfigFileNew = SelectCconfigFile;

                        // No.60 コンフィグファイル共通化処理
                        Configure.ConfigureIni(SelectCconfigFile);

                        base.OnStartup(e);
                    }
                }
            }
            else
            {
                MessageBox.Show("既に起動しています。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                // No.101 「すでに起動しています。」のメッセージ表示の後、後のメッセージを表示させないようにする
                isStart = true;
                this.Shutdown();
            }
        }
    }
}
