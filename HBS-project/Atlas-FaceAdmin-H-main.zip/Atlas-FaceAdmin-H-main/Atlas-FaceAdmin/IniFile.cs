﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// INIファイルを読み書きするクラス
    /// </summary>
    public class IniFile
    {
        private const StringComparison Comparison = StringComparison.Ordinal;
        private static readonly StringComparer Comparer = StringComparer.OrdinalIgnoreCase;

        private readonly Dictionary<string, Dictionary<string, string>> _ini = new Dictionary<string, Dictionary<string, string>>(Comparer);

        /// <summary>
        /// ファイル名を指定して初期化します。
        /// ファイルが存在しない場合は初回書き込み時に作成されます。
        /// </summary>
        /// <param name="filePath">ファイルのパス</param>
        public IniFile(string file, Encoding encoding = null)
        {
            var lines = File.ReadLines(file, encoding ?? Encoding.GetEncoding("shift_jis"))
                .Where(x => !string.IsNullOrWhiteSpace(x))
                .Select(x => x.Trim())
                .Where(x => !x.StartsWith(";", Comparison));

            var currentSection = new Dictionary<string, string>(Comparer);
            var key = "";
            var isNextLine = false;

            _ini[""] = currentSection;

            foreach (var line in lines)
            {
                if (isNextLine)
                {
                    isNextLine = IsNextLine(line);
                    currentSection[key] += GetValue(line, 0, isNextLine).TrimEnd();
                    continue;
                }

                if (line[0] == '[' && line[line.Length - 1] == ']')
                {
                    currentSection = new Dictionary<string, string>(Comparer);
                    var section = line.Substring(1, line.Length - 2).Trim();
                    _ini[section] = currentSection;
                    continue;
                }

                var index = line.IndexOf("=", Comparison);
                if (index == -1) continue;

                key = line.Substring(0, index).Trim();
                isNextLine = IsNextLine(line);
                currentSection[key] = GetValue(line, index + 1, isNextLine).Trim();
            }

            const char nextLineChar = '+';
            const char escapeChar = '\\';

            bool IsNextLine(string line) => line[line.Length - 1] == nextLineChar && line.Length >= 2 &&
                                            line[line.Length - 2] != escapeChar;

            string GetValue(string line, int startIndex, bool isNextLineChar)
            {
                var length = line.Length - startIndex - (isNextLineChar ? 1 : 0);

                var sb = new StringBuilder();
                var escape = false;
                var ignoreSpace = false;

                // "\Ima+ ge\+123.png"のようになっていたら、"\Image+123.png"と見なす
                foreach (var c in line.Skip(startIndex).Take(length))
                {
                    if (escape)
                    {
                        if (c != nextLineChar)
                            sb.Append(escapeChar);
                    }
                    else
                    {
                        switch (c)
                        {
                            case escapeChar:
                                escape = true;
                                ignoreSpace = false;
                                continue;
                            case nextLineChar:
                                ignoreSpace = true;
                                continue;
                            case ' ' when ignoreSpace:
                                continue;
                        }
                    }

                    escape = false;
                    ignoreSpace = false;
                    sb.Append(c);
                }

                return sb.ToString();
            }
        }

        public string GetValueRoot(string key, string @default = null) => GetValue("", key, @default);

        public IEnumerable<string> GetKeys(string section)
        {
            return _ini.TryGetValue(section, out var iniSection) ? iniSection.Keys : Enumerable.Empty<string>();
        }

        public IEnumerable<string> GetSections() => _ini.Keys.Where(x => x != "");

        public string this[string section, string key]
        {
            get
            {
                return GetValue(section, key, string.Empty);
            }
        }

        /// <summary>
        /// sectionとkeyからiniファイルの設定値を取得します。
        /// 指定したsectionとkeyの組合せが無い場合はdefaultvalueで指定した値が戻ります。
        /// </summary>
        /// <param name="section"></param>
        /// <param name="key"></param>
        /// <param name="@default"></param>
        /// <returns>
        /// 指定したsectionとkeyの組合せが無い場合はdefaultvalueで指定した値が戻ります。
        /// </returns>
        public string GetValue(string section, string key, string @default)
        {
            return _ini.TryGetValue(section, out var iniSection) &&
                    iniSection.TryGetValue(key, out var value)
                ? value
                : @default;
        }
    }

    public class InfoSettingIniFile
    {
        public string inipath;
        private static string Key_Encrypt = "JUNDAOXT";

        [DllImport("kernel32")]
        private static extern long WritePrivateProfileString(string section, string key, string val, string filePath);
        [DllImport("kernel32")]
        private static extern int GetPrivateProfileString(string section, string key, string def, StringBuilder retVal, int size, string filePath);

        /// <summary> 
        /// 初期化
        /// </summary> 
        public InfoSettingIniFile()
        {
            inipath = Configure.BasePath + @"\settings.ini";
            if (!File.Exists(inipath))
            {
                IniWriteValue("Atlas_info", "Username", "admin");                
                IniWriteValue("Atlas_info", "Password", "Atlas@2019");
                WriteLogSafe.LogSafe($"[INIファイルツール] Atlas通信用ユーザIDとパスワードを初期化、INIファイルInfoSetting作成します。");

                IniWriteValue("FaceAdmin_info_1", "Username", "admin");
                IniWriteValue("FaceAdmin_info_1", "Password", "admin");
                WriteLogSafe.LogSafe($"[INIファイルツール] Atlas通信用ユーザIDとパスワードを初期化、INIファイルInfoSetting作成します。");

                IniWriteValue("FaceAdmin_info_2", "Username", "hitachiadmin");
                IniWriteValue("FaceAdmin_info_2", "Password", "vivabivale");
                WriteLogSafe.LogSafe($"[INIファイルツール] Atlas通信用ユーザIDとパスワードを初期化、INIファイルInfoSetting作成します。");
            }
        }

        /// <summary> 
        /// 暗号化処理
        /// </summary> 
        public string MD5Encrypt(string pToEncrypt, string sKey)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray = Encoding.Default.GetBytes(pToEncrypt);
                des.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
                des.IV = ASCIIEncoding.ASCII.GetBytes(sKey);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();
                StringBuilder ret = new StringBuilder();
                foreach (byte b in ms.ToArray())
                {
                    ret.AppendFormat("{0:X2}", b);
                }
                ret.ToString();
                return ret.ToString();
            }
            catch
            {
                WriteLogSafe.LogSafe($"[INIファイルツール] データ暗号化処理が失敗しました。");
                return "";
            }
        }

        /// <summary> 
        /// 複号化処理
        /// </summary> 
        public string MD5Decrypt(string pToDecrypt, string sKey)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();

                byte[] inputByteArray = new byte[pToDecrypt.Length / 2];
                for (int x = 0; x < pToDecrypt.Length / 2; x++)
                {
                    int i = (Convert.ToInt32(pToDecrypt.Substring(x * 2, 2), 16));
                    inputByteArray[x] = (byte)i;
                }

                des.Key = ASCIIEncoding.ASCII.GetBytes(sKey);
                des.IV = ASCIIEncoding.ASCII.GetBytes(sKey);
                MemoryStream ms = new MemoryStream();
                CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(), CryptoStreamMode.Write);
                cs.Write(inputByteArray, 0, inputByteArray.Length);
                cs.FlushFinalBlock();

                StringBuilder ret = new StringBuilder();

                return System.Text.Encoding.Default.GetString(ms.ToArray());
            }
            catch
            {
                WriteLogSafe.LogSafe($"[INIファイルツール] データ複号化処理が失敗しました。");
                return "";
            }
        }

        /// <summary> 
        /// INIファイル書込 
        /// </summary> 
        /// <param name="Section">項目(例 [Atlas_info] )</param> 
        /// <param name="Key">キー</param> 
        /// <param name="Value">値</param> 
        public void IniWriteValue(string Section, string Key, string Value)
        {
            try
            {
                string EncryptValue = MD5Encrypt(Value, Key_Encrypt);
                WritePrivateProfileString(Section, Key, EncryptValue, this.inipath);
            }
            catch
            {
                WriteLogSafe.LogSafe($"[INIファイルツール] INIファイル書込に失敗しました。");
            }
        }
        /// <summary> 
        /// INIファイル読取
        /// </summary> 
        /// <param name="Section">項目(例 [Atlas_info] )</param> 
        /// <param name="Key">キー</param> 
        public string IniReadValue(string Section, string Key)
        {
            string DecryptStr = "";
            try
            {
                StringBuilder temp = new StringBuilder(500);
                int i = GetPrivateProfileString(Section, Key, "", temp, 500, this.inipath);

                DecryptStr = MD5Decrypt(temp.ToString(), Key_Encrypt);
                return DecryptStr;
            }
            catch
            {
                WriteLogSafe.LogSafe($"[INIファイルツール] INIファイル読取に失敗しました。");
                return DecryptStr;
            }
        }

        public string IniReadValueFromBackup(string Section, string Key, string backupIniPath)
        {
            string DecryptStr = "";
            try
            {
                StringBuilder temp = new StringBuilder(500);
                int i = GetPrivateProfileString(Section, Key, "", temp, 500, backupIniPath);

                DecryptStr = MD5Decrypt(temp.ToString(), Key_Encrypt);
                return DecryptStr;
            }
            catch
            {
                WriteLogSafe.LogSafe($"[INIファイルツール] INIファイル読取に失敗しました。");
                return DecryptStr;
            }
        }

        /// <summary> 
        /// ファイル位置存在するか判断
        /// </summary> 
        /// <returns>TRUE：存在　FLASE：存在しない</returns> 
        public bool ExistINIFile()
        {
            return File.Exists(inipath);
        }
    }
}
