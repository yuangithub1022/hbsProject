﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using Codeplex.Data;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// WriteBitmapLog.xaml の相互作用ロジック
    /// </summary>
    public partial class WriteBitmapLog : Window
    {
        private ObservableCollection<FaceAuthDataBean> Recordings = new ObservableCollection<FaceAuthDataBean>();
        public AtlasServerViewModel AtlasViewModel { get; set; }
        public int Limit = 100;
        public int Offset = 0;

        //Atlasの顔情報の数
        public int DataCount = 0;

        //Atlasの顔情報の数　÷  Limit
        public int PageCount = 0;

        //選択された出力数
        public int LogCount = 0;

        //選択された出力数　÷  Limit
        public int GetCount = 0;

        public bool GetLogError = false;
        public bool WriteBitmapError = false;

        public bool StopByExit = false;

        public string AtlasIp = "";
        public string Capture_csv_File = "";
        public string Capture_data_Path = "";

        public DateTime dt_start = new DateTime();
        public DateTime dt_stop = new DateTime();

        public WriteBitmapLog()
        {
            InitializeComponent();

            bool byWriteBitmap = true;
            this.AtlasViewModel = new AtlasServerViewModel(byWriteBitmap);

            this.com_log_atlas.DataContext = this.AtlasViewModel.Recordings;
            this.com_log_atlas.SelectedItem = this.AtlasViewModel.InitSelectedItem;

            this.date_start.Text = DateTime.Today.AddDays(-7).ToLongDateString();
            this.date_stop.Text = DateTime.Today.ToLongDateString();

            this.tpStartTime.Value = DateTime.Parse("00:00");
            this.tpStopTime.Value = DateTime.Parse("23:59");

        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            string msg = "ログファイルの出力を終了しますか?";
            
            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (messageBoxResult.Equals(MessageBoxResult.Yes))
            {
                StopByExit = true;

                System.Threading.Thread.Sleep(1000);
                WriteLogSafe.LogSafe($"[顔認証履歴出力画面] 顔認証履歴出力画面を閉じました。");
                base.OnClosing(e);
            }
            else
            {
                e.Cancel = true;
                base.OnClosing(e);
            }
        }

        private void btn_cencel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void btn_write_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                AtlasServerDataBean SelectAtlas = (AtlasServerDataBean)this.com_log_atlas.SelectedItem;

                bool log_path_error = false;
                bool log_date_error = false;

                if (this.txt_log_path.Text.Length == 0 || "".Equals(SelectAtlas.Server_Name))
                {
                    log_path_error = true;
                }

                if(this.date_start.SelectedDate > this.date_stop.SelectedDate || ((this.date_start.SelectedDate == this.date_stop.SelectedDate) && this.tpStartTime.Value > this.tpStopTime.Value))
                {
                    log_date_error = true;
                }

                if (log_path_error && log_date_error)
                {
                    System.Windows.MessageBox.Show($"・ 出力元または出力先が未指定です。\n\r \n\r・ 終了日時が開始日時より前になっています。\n\r   ログ出力期間を見直してください。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if (log_path_error)
                {
                    System.Windows.MessageBox.Show($"出力元または出力先が未指定です。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if (log_date_error)
                {
                    System.Windows.MessageBox.Show($"終了日時が開始日時より前になっています。\n\r   ログ出力期間を見直してください。", "情報",
                           MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                DateTime? dt_start_data = this.date_start.SelectedDate;
                DateTime? dt_stop_data = this.date_stop.SelectedDate;

                TimeSpan dt_start_time = this.tpStartTime.Value.TimeOfDay;
                TimeSpan dt_stop_time = this.tpStopTime.Value.TimeOfDay;

                dt_start = this.date_start.SelectedDate.Value.Add(dt_start_time);
                dt_stop = this.date_stop.SelectedDate.Value.Add(dt_stop_time);

                // # 271
                dt_stop = dt_stop.AddSeconds(59);

                var SelectPath = this.txt_log_path.Text;
                var SelectAtlasName = SelectAtlas.Server_Name;

                Capture_csv_File = SelectPath + "\\" + SelectAtlasName + "\\capture_log.csv";
                Capture_data_Path = SelectPath + "\\" + SelectAtlasName + "\\capture_data";

                if (File.Exists(Capture_csv_File) || Directory.Exists(Capture_data_Path))
                {
                    string msg = $"指定されたフォルダには既にログファイルが存在します。\n\rログファイルを上書きし、処理を継続しますか？";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                            MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.No))
                    {
                        return;
                    }

                    // # 265 削除をせずに、上書き保存にする
                    //if (File.Exists(Capture_csv_File))
                    //{
                    //    File.Delete(Capture_csv_File);
                    //}

                    //DeleteDir(Capture_data_Path);
                }

                var AtlasName_Path = SelectPath + "\\" + SelectAtlasName;
                if (!Directory.Exists(AtlasName_Path))
                {
                    Directory.CreateDirectory(AtlasName_Path);
                    Directory.CreateDirectory(Capture_data_Path);
                }
                if (!Directory.Exists(Capture_data_Path))
                {
                    Directory.CreateDirectory(Capture_data_Path);
                }


                LogCount = int.Parse(this.com_log_count.Text);
                AtlasIp = SelectAtlas.Server_Ip;

                if (LogCount % Limit > 0)
                {
                    GetCount = LogCount / Limit + 1;
                }
                else
                {
                    GetCount = LogCount / Limit;
                }


                var start_data = this.date_start.SelectedDate;
                var stop_data = this.date_stop.SelectedDate;
                var start_time = this.tpStartTime.Value;

                this.Recordings.Clear();
                GetLogError = false;
                WriteBitmapError = false;
                StopByExit = false;
                Read_Data_First();

            }
            catch (Exception)
            {
                System.Windows.MessageBox.Show($"出力にエラーが発生しました。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private async void Read_Data_First()
        {
            try
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                // # 266 ログを出力中はキーボードの操作を無効にする
                this.GD.IsEnabled = false;

                this.tpStartTime.Enabled = false;
                this.tpStopTime.Enabled = false;
                this.IconImage.Visibility = Visibility.Hidden;
                var Api = new AtlasApi();
                var Token = await Api.GetToken(AtlasIp);
                if ("".Equals(Token))
                {
                    System.Windows.MessageBox.Show($"装置への認証は失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    this.GD.IsEnabled = true;
                    this.tpStartTime.Enabled = true;
                    this.tpStopTime.Enabled = true;
                    this.IconImage.Visibility = Visibility.Visible;
                    return;
                }

                string UserInfo = await Api.ListCaptureResultsByTime(AtlasIp, Token, 0, Limit, dt_start, dt_stop);
                if ("".Equals(UserInfo))
                {
                    WriteLogSafe.LogSafe($"[顔認証履歴出力画面] 撮影画像の取得に失敗しました。");
                    System.Windows.MessageBox.Show("撮影画像の取得に失敗しました。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    this.GD.IsEnabled = true;
                    this.tpStartTime.Enabled = true;
                    this.tpStopTime.Enabled = true;
                    this.IconImage.Visibility = Visibility.Visible;
                    return;
                }

                var UserList = DynamicJson.Parse(UserInfo);
                DataCount = Convert.ToInt32(UserList.page_request.total);
                if (DataCount == 0)
                {
                    System.Windows.MessageBox.Show("顔認証履歴がありませんでした。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    this.GD.IsEnabled = true;
                    this.tpStartTime.Enabled = true;
                    this.tpStopTime.Enabled = true;
                    this.IconImage.Visibility = Visibility.Visible;
                    return;
                }

                if (DataCount % Limit > 0)
                {
                    PageCount = DataCount / Limit + 1;
                }
                else
                {
                    PageCount = DataCount / Limit;
                }

                Offset = DataCount;
                Read_Data();
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[顔認証履歴出力画面] 撮影画像の取得に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"撮影画像の取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                this.GD.IsEnabled = true;
                this.tpStartTime.Enabled = true;
                this.tpStopTime.Enabled = true;
                this.IconImage.Visibility = Visibility.Visible;
            }
        }

        private async void Read_Data()
        {
            try
            {
                
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                this.tpStartTime.Enabled = false;
                this.tpStopTime.Enabled = false;

                var Api = new AtlasApi();
                var Token = await Api.GetToken(AtlasIp);
                if ("".Equals(Token))
                {
                    System.Windows.MessageBox.Show($"装置への認証は失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    this.GD.IsEnabled = true;
                    this.tpStartTime.Enabled = true;
                    this.tpStopTime.Enabled = true;
                    this.IconImage.Visibility = Visibility.Visible;
                    return;
                }

                for (int PageNo = 0; PageNo < PageCount; PageNo++)
                {
                    // #267 画面終了後、認証履歴出力を停止するようにします
                    if (StopByExit)
                    {
                        return;
                    }

                    if ((PageNo + 1) > GetCount)
                    {
                        break;
                    }

                    Offset = DataCount - PageNo * Limit;

                    int StartIndex = 0;
                    int LimitTemp = Limit;
                    if (Offset < LimitTemp)
                    {
                        LimitTemp = Offset;
                    }
                    if (Offset > LimitTemp)
                    {
                        StartIndex = Offset - LimitTemp;
                    }

                    //string UserInfo2 = await Api.ListExportCaptureResults(AtlasIp, Token, StartIndex, Limit);

                    string UserInfo = await Api.ListCaptureResultsByTime(AtlasIp, Token, StartIndex, Limit, dt_start, dt_stop);
                    if ("".Equals(UserInfo))
                    {
                        //#264対応　顔認証履歴を出力中にLANケーブルを抜いた場合、その時点でのCSVファイルを作成できるとよいです。
                        Read_To_Csv();

                        var count_writed_getlog = this.Recordings.Distinct(new Compare()).OrderBy(item => item.Idx).Count();
                        WriteLogSafe.LogSafe($"[顔認証履歴出力画面] 撮影画像の取得に失敗しました。総件数: {DataCount}");
                        var message_getlog = $"ログファイルを失敗しました。\n\r指定期間の件数: {DataCount}件。\n\r出力件数: {count_writed_getlog}件。\n\r指定期間の全てのログを出力できませんでした。\n\r通信環境を見直してください。";
                        System.Windows.MessageBox.Show(message_getlog, "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        this.GD.IsEnabled = true;
                        this.tpStartTime.Enabled = true;
                        this.tpStopTime.Enabled = true;
                        this.IconImage.Visibility = Visibility.Visible;
                        return;
                    }

                    int Idx_ = DataCount - StartIndex;
                    var UserList = DynamicJson.Parse(UserInfo);
                    foreach (var user in UserList.results)
                    {
                        // #267 画面終了後、認証履歴出力を停止するようにします
                        if (StopByExit)
                        {
                            return;
                        }

                        var ImageId = user.capture_result.face.portrait.url;
                        BitmapImage TempImage = await Api.DownloadImage(AtlasIp, Token, ImageId, Convert.ToString(user.id));
                        System.Threading.Thread.Sleep(10);

                        if (TempImage == null)
                        {
                            //#264対応　顔認証履歴を出力中にLANケーブルを抜いた場合、その時点でのCSVファイルを作成できるとよいです。
                            Read_To_Csv();

                            var count_writed_getbitmap = this.Recordings.Distinct(new Compare()).OrderBy(item => item.Idx).Count();
                            WriteLogSafe.LogSafe($"[顔認証履歴出力画面] 撮影画像の取得に失敗しました。総件数: {DataCount}");
                            var message_getbitmapg = $"ログファイルを失敗しました。\n\r指定期間の件数: {DataCount}件。\n\r出力件数: {count_writed_getbitmap}件。\n\r指定期間の全てのログを出力できませんでした。\n\r通信環境を見直してください。";
                            System.Windows.MessageBox.Show(message_getbitmapg, "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                            loading.IsActive = false;
                            loadingPart.Visibility = Visibility.Hidden;
                            this.GD.IsEnabled = true;
                            this.tpStartTime.Enabled = true;
                            this.tpStopTime.Enabled = true;
                            this.IconImage.Visibility = Visibility.Visible;
                            return;
                        }

                        string CardId = "";
                        string UserName = "";
                        if (user.capture_result.face.most_similar_user != null)
                        {
                            CardId = user.capture_result.face.most_similar_user.card_id;
                            UserName = user.capture_result.face.most_similar_user.name;
                        }

                        DateTime dt = Convert.ToDateTime(user.capture_time);

                        DirectoryInfo theFolder = new DirectoryInfo(Capture_data_Path);
                        FileInfo[] fileInfo = theFolder.GetFiles();
                        foreach (FileInfo NextFile in fileInfo) //遍历文件
                        {
                            string[] Values = NextFile.Name.Split('_');
                            if (Values[0].Equals(Idx_.ToString())){
                                NextFile.Delete();
                            }
                        }

                        string BitmapFileName = Idx_.ToString() + "_" + string.Format("{0:yyyyMMdd_HHmmss}", dt) + @".jpg";

                        string ImagePath = Capture_data_Path + "\\" + BitmapFileName;
                        bool result = ImageHelper.SaveBitmapImageIntoFile(TempImage, ImagePath);
                        if (!result)
                        {
                            WriteBitmapError = true;
                        }

                        FaceAuthDataBean FaceItem = new FaceAuthDataBean()
                        {
                            Idx = Idx_--,
                            TicketId = "",
                            FaceId = CardId,
                            ManageId = "",
                            StaffName = UserName,
                            StaffNameKN = "",
                            FigureId = "",
                            FigureStatus = "",
                            Thresholds = "",
                            StartDate = "",
                            StaffImgPath = ImagePath,
                            StaffImgName = BitmapFileName
                            //Staff_Image = TempImage
                        };
                        FaceItem.ValidDate = string.Format("{0:yyyy/MM/dd HH:mm:ss}", dt);

                        this.Recordings.Add(FaceItem);
                    }

                    System.Threading.Thread.Sleep(1000);
                }

                //Write to csv
                Read_To_Csv();

                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                this.GD.IsEnabled = true;
                this.tpStartTime.Enabled = true;
                this.tpStopTime.Enabled = true;
                this.IconImage.Visibility = Visibility.Visible;
                var count_writed = this.Recordings.Distinct(new Compare()).OrderBy(item => item.Idx).Count();

                WriteLogSafe.LogSafe($"[顔認証履歴出力画面] ログファイルを出力しました。顔認証履歴:{count_writed}件。");

                var message = $"ログファイルを出力しました。\n\r顔認証履歴: {count_writed}件。";
                if (DataCount > LogCount)
                {
                    message = $"ログファイルを出力しました。\n\r指定期間の件数: {DataCount}件。\n\r出力件数: {count_writed}件。\n\r※指定期間の全てのログを出力できませんでした。\n\r適宜開始日時／終了日時および出力件数を見直してください。";
                }

                if (WriteBitmapError)
                {
                    message = $"ログファイルを失敗しました。\n\r指定期間の件数: {DataCount}件。\n\r出力件数: {count_writed}件。\n\r※指定期間の全てのログを出力できませんでした。\n\r上書きできないログファイルがありました。";
                }
                System.Windows.MessageBox.Show(message, "情報", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                //#264対応　顔認証履歴を出力中にLANケーブルを抜いた場合、その時点でのCSVファイルを作成できるとよいです。
                Read_To_Csv();

                WriteLogSafe.LogSafe($"[顔認証履歴出力画面] 撮影画像の取得に失敗しました。総件数: {DataCount}。{ex.Message}");
                System.Windows.MessageBox.Show($"撮影画像の取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                this.GD.IsEnabled = true;
                this.tpStartTime.Enabled = true;
                this.tpStopTime.Enabled = true;
                this.IconImage.Visibility = Visibility.Visible;
            }
        }

        public bool Read_To_Csv()
        {
            try
            {
                List<List<string>> csvInfo = new List<List<string>>();

                if (File.Exists(Capture_csv_File))
                {
                    csvInfo = Read_CSV_info();
                }

                using (FileStream _stream = new FileStream(Capture_csv_File, FileMode.Create, FileAccess.ReadWrite))
                {
                    StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);

                    // # 272 ログ出力結果(capture_log.csv)の一番上の行を追加
                    string sline;

                    sline = "No.,顔ID,氏名,撮影日,撮影画像";
                    _writer.WriteLine(sline);

                    //foreach (FaceAuthDataBean beanTable in this.Recordings.Distinct(new Compare()).OrderBy(item => item.Idx))
                    foreach (FaceAuthDataBean beanTable in this.Recordings.OrderBy(item => item.Idx))
                    {
                        if ("".Equals(beanTable.FaceId) && "".Equals(beanTable.StaffName))
                        {
                            beanTable.FaceId = "未登録ID";
                            beanTable.StaffName = "未登録";
                        }

                        sline = beanTable.Idx + "," + beanTable.FaceId + "," + beanTable.StaffName + "," + beanTable.ValidDate + "," + beanTable.StaffImgPath;
                        
                        _writer.WriteLine(sline);
                    }

                    if (csvInfo != null && csvInfo.Count != 0)
                    {
                        bool IsUpdate = false;

                        foreach (List<string> cardInfo in csvInfo)
                        {
                            IsUpdate = false;
                            string[] Values = cardInfo.ToArray();
                            foreach (FaceAuthDataBean beanTable in this.Recordings)
                            {
                                if (Values[0].Equals(beanTable.Idx.ToString()))
                                {
                                    IsUpdate = true;
                                    break;
                                }
                            }

                            if (!IsUpdate)
                            {
                                sline = Values[0] + "," + Values[1] + "," + Values[2] + "," + Values[3] + "," + Values[4];

                                _writer.WriteLine(sline);
                            }

                        }
                    }                

                    _writer.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[顔認証履歴出力画面] CSVファイルへの出力が失敗しました。{ex.Message}");
                return false;
            }
        }

        public List<List<string>> Read_CSV_info()
        {
            try
            {
                List<List<string>> csvLines;
                List<List<string>> csvInfo = new List<List<string>>();

                CsvFile Csv = new CsvFile(Capture_csv_File);
                csvLines = Csv.Read(0, "UTF-8");

                foreach (List<string> line in csvLines)
                {
                    string[] Values = line.ToArray();

                    if (Values[0] == "No.")
                    {
                        continue;
                    }

                    csvInfo.Add(line);
                }

                return csvInfo;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[顔認証履歴出力画面] ファイルから顔認証履歴の読込は失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"ファイルから顔認証履歴の読込は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);

                List<List<string>> csvInfo_null = new List<List<string>>();
                return csvInfo_null;
            }
        }

        public bool DeleteDir(string file)
        {
            try
            {
                System.IO.DirectoryInfo fileInfo = new DirectoryInfo(file);
                fileInfo.Attributes = FileAttributes.Normal & FileAttributes.Directory;

                System.IO.File.SetAttributes(file, System.IO.FileAttributes.Normal);

                if (Directory.Exists(file))
                {
                    foreach (string f in Directory.GetFileSystemEntries(file))
                    {
                        if (File.Exists(f))
                        {
                            File.Delete(f);
                        }
                        else
                        {
                            DeleteDir(f);
                        }

                    }
                    Directory.Delete(file);

                }
                return true;

            }
            catch (Exception)
            {
                return false;
            }

        }

        private void IconImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FolderBrowserDialog folderBrowser = new FolderBrowserDialog();

            System.Windows.Forms.DialogResult result = folderBrowser.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.Cancel)
            {
                return;
            }
            else if (result == System.Windows.Forms.DialogResult.OK)
            {
                var SelectCconfigFile = folderBrowser.SelectedPath;

                if (SelectCconfigFile.Length > 214)
                {
                    System.Windows.MessageBox.Show($"出力先のパスが長すぎます。\n\r出力先を指定し直してください。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);

                    this.txt_log_path.Text = "";
                    return;
                }
                else
                {
                    this.txt_log_path.Text = SelectCconfigFile;
                }
            }
        }
    }

    public class Compare : IEqualityComparer<FaceAuthDataBean>
    {
        public bool Equals(FaceAuthDataBean x, FaceAuthDataBean y)
        {
            return x.Idx == y.Idx;
        }

        public int GetHashCode(FaceAuthDataBean obj)
        {
            return obj.Idx.GetHashCode();
        }
    }
}


