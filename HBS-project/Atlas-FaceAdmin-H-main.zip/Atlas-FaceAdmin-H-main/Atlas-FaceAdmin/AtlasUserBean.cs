﻿using System.Collections.Generic;

namespace RegisterFaceAuthTool
{
    public class AtlasUserBean
    {
        public Dictionary<string, int> page_response { get; set; }
        public string Id { get; set; }
        public Dictionary<string, object>[] Users { get; set; }
    }
}
