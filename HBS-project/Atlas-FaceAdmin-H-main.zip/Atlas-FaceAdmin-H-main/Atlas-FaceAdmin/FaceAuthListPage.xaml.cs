﻿using Codeplex.Data;
using MahApps.Metro.Controls;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using OpenFileDialog = System.Windows.Forms.OpenFileDialog;
using Newtonsoft.Json;
using System.Windows.Threading;
using System.IO.Compression;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// FaceAuthListPage.xaml の相互作用ロジック
    /// </summary>
    public partial class FaceAuthListPage : Window
    {
        public enum SystemMenuClose
        {
            Enabled,
            Disabled
        }

        private const int SC_CLOSE = 0xF060;

        private const int MF_GRAYED = 0x0001;

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("user32.dll")]
        private static extern int EnableMenuItem(IntPtr hMenu, int wIDEnableItem, int wEnable);

        [DllImport("User32.Dll")]
        public static extern int GetMenuItemCount(IntPtr hMenu);

        IntPtr hMenu;

        public void handlingCloseButton(SystemMenuClose HandleSystemMenuClose, IntPtr hwnd)
        {
            switch (HandleSystemMenuClose)
            {
                case SystemMenuClose.Disabled:

                    hMenu = GetSystemMenu(hwnd, false);

                    if (hMenu != IntPtr.Zero)
                    {

                        EnableMenuItem(hMenu, SC_CLOSE, MF_GRAYED);

                        int n = GetMenuItemCount(hMenu);
                    }

                    break;

                case SystemMenuClose.Enabled:

                    GetSystemMenu(hwnd, true);

                    EnableMenuItem(IntPtr.Zero, 0xF120, 1024);

                    break;


                default:

                    break;
            }
        }
        private void button1_Click(object sender, EventArgs e, IntPtr hwnd)
        {
            handlingCloseButton(SystemMenuClose.Disabled, hwnd);
        }

        private void button2_Click(object sender, EventArgs e, IntPtr hwnd)
        {
            handlingCloseButton(SystemMenuClose.Enabled, hwnd);
        }
        // for 登録チェック機能
        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Csv = new ObservableCollection<FaceAuthDataBean>();
        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Atlas = new ObservableCollection<FaceAuthDataBean>();
        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>();

        // for 疎通処理
        private ObservableCollection<FaceAuthDataBean> Recordings_Ping = new ObservableCollection<FaceAuthDataBean>();
        private ObservableCollection<AtlasServerDataBean> AtlasListNoError = new ObservableCollection<AtlasServerDataBean>();

        public FaceAuthViewModel ViewModel { get; set; }
        public AtlasServerViewModel AtlasViewModel { get; set; }
        public ReadSrcViewModel ReadViewModel { get; set; }

        private readonly string LibraryDesp = @"01.00.00";
        private readonly bool IsBackupMode = false;
        private bool IsRecoveryMode = false;
        private readonly int IsFaceTransmitMode = 0;
        private readonly bool IsLoginByHitachiadmin = false;

        private bool IsNeedMatchErrorShow = true;
        private bool IsNeedMatchErrorShowAfterWrite = false;
        private bool IsNeedBackupErrorShow = false;

        // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
        private bool IsNeedMatchErrorShowType3 = false;

        // No.107 Atlas読み出しを行ったところ、すべての画像ファイルが表示されず、一部の画像しか表示されない対応
        private bool IsReadFromAtlasRun = false;

        // for 疎通処理
        private bool pingJudegError = false;

        // No.67 メモリ対策
        private int scrolloffset = 1;
        // Np.149 検索をしても、対象の顔IDにスクロールしないことを修正
        public bool SearchFlag = false;

        // No.99 画面サイズを変更しないように対応
        // No.99 画面サイズを変えると、マウスアイコンが「⇔」のままとなりマウスが効かなくなることを修正
        //private double scrollOffsetBefore = -1;
        //private int faceDataCount = -1;

        // 2.2.xx対応対策一覧　No.6
        private int preOffsetTop = 0;


        public FaceAuthListPage(int IsFaceTransmitMode = 0, bool IsLoginByHitachiadmin = false, bool IsNeedMatchErrorShow = true)
        {
            InitializeComponent();

            this.IsFaceTransmitMode = IsFaceTransmitMode;
            this.IsLoginByHitachiadmin = IsLoginByHitachiadmin;

            this.ViewModel = new FaceAuthViewModel();
            this.AtlasViewModel = new AtlasServerViewModel();
            this.ReadViewModel = new ReadSrcViewModel(this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);

            this.combo_atlas.DataContext = this.AtlasViewModel.Recordings;
            this.combo_atlas.SelectedItem = this.AtlasViewModel.InitSelectedItem;

            this.combo_file.DataContext = this.ReadViewModel.Recordings;
            this.combo_file.SelectedItem = this.ReadViewModel.InitSelectedItem;

            this.DG1.DataContext = this.ViewModel.Recordings;
            this.DG1.CanUserAddRows = false;

            this.IsBackupMode = false;
            this.IsRecoveryMode = false;

            // ログインユーザがHitachiadmin以外の場合、読出先関連と削除ボタンを隠す。
            if (!this.IsLoginByHitachiadmin)
            {
                // Thickness(left, top, right, bottom)
                Thickness margin = new Thickness(-120, 0, 0, 0);
                this.btn_search.Margin = margin;

                this.combo_file.Visibility = Visibility.Hidden;
                this.lable_read_from.Visibility = Visibility.Hidden;
                this.btn_read_csv.Visibility = Visibility.Hidden;
                // No.88 hitachiadmin権限でログインした場合のみ、登録者一覧画面に「顔情報出力」釦を追加する
                this.btn_facedata_output.Visibility = Visibility.Hidden;

                this.btn_delete.Visibility = Visibility.Hidden;
            }
            // コンフィグファイルにベリファイ設定が0の場合、登録チェックボタンを隠す。
            if (Configure.CheckFlag == 0)
            {
                this.btn_check_csv.Visibility = Visibility.Hidden;
            }
        }

        public FaceAuthListPage(string path, int IsFaceTransmitMode = 0, bool IsLoginByHitachiadmin = false, bool IsNeedMatchErrorShow = true)
        {
            InitializeComponent();

            this.IsFaceTransmitMode = IsFaceTransmitMode;
            this.IsLoginByHitachiadmin = IsLoginByHitachiadmin;

            this.ViewModel = new FaceAuthViewModel(path);
            this.AtlasViewModel = new AtlasServerViewModel();
            this.ReadViewModel = new ReadSrcViewModel(this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);

            this.combo_atlas.DataContext = this.AtlasViewModel.Recordings;
            this.combo_atlas.SelectedItem = this.AtlasViewModel.InitSelectedItem;

            this.combo_file.DataContext = this.ReadViewModel.Recordings;
            this.combo_file.SelectedItem = this.ReadViewModel.InitSelectedItem;

            // No.99 画面サイズを変えると、マウスアイコンが「⇔」のままとなりマウスが効かなくなることを修正
            //this.DG1.DataContext = this.ViewModel.Recordings;
            this.DG1.CanUserAddRows = false;

            this.IsBackupMode = true;
            this.IsRecoveryMode = false;

            // 接点連動、かつログインユーザがHitachiadmin以外の場合、読出先関連項目を隠す。
            if ((this.IsFaceTransmitMode == 1 || this.IsFaceTransmitMode == 2) && !this.IsLoginByHitachiadmin)
            {
                // Thickness(left, top, right, bottom)
                Thickness margin = new Thickness(-120, 0, 0, 0);
                this.btn_search.Margin = margin;

                this.combo_file.Visibility = Visibility.Hidden;
                this.lable_read_from.Visibility = Visibility.Hidden;
                this.btn_read_csv.Visibility = Visibility.Hidden;
            }

            // ログインユーザがHitachiadmin以外の場合、顔情報出力ボタンを隠す。
            if (!this.IsLoginByHitachiadmin)
            {
                this.btn_facedata_output.Visibility = Visibility.Hidden;
            }

            // コンフィグファイルにベリファイ設定が0の場合、登録チェックボタンを隠す。
            if (Configure.CheckFlag == 0)
            {
                this.btn_check_csv.Visibility = Visibility.Hidden;
            }

            //string ConfigFileName = System.IO.Path.GetFileNameWithoutExtension(Configure.ConfigFileNew);
            string ConfigFileName = System.IO.Path.GetFileName(Configure.ConfigFileNew);
            this.textblock_config_name.Text = ConfigFileName;

            // #257 ログ出力機能　一旦非表示
            this.btn_log_write.Visibility = Visibility.Hidden;

            // 不具合一覧　No.38対応
            this.IsNeedMatchErrorShow = IsNeedMatchErrorShow;
        }

        public void Content_Rendered(object sender, EventArgs e)
        {
            loading.IsActive = true;
            loadingPart.Visibility = Visibility.Visible;
            this.ViewModel.ReadViewDelay(this.IsFaceTransmitMode);
            this.DG1.DataContext = this.ViewModel.Recordings;
            GC.Collect();
            SetRecordsCount();
            if (this.IsFaceTransmitMode == 2)
            {
                this.DG1.Columns[5].Visibility = Visibility.Visible;
                this.btn_edit_batch.Visibility = Visibility.Visible;
            }
            WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者一覧画面を表示しました。");
            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
            loading.IsActive = false;
            loadingPart.Visibility = Visibility.Hidden;
        }

        private void SetRecordsCount()
        {
            int Count = this.ViewModel.Recordings.Where(item => { return "1".Equals(item.LoginStatusCode); }).Count();
            string RecordsCnt = $"登録件数: {Count}/{Configure.MaxFaceCount}";
            this.Invoke(new Action(() =>
            {
                this.txtb_cnt.Text = RecordsCnt;
            }));
            WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者一覧件数: {this.ViewModel.Recordings.Count()}, 登録済み件数: {Count}");
        }

        private void TextBox_Name_Change(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;
            if (this.IsFaceTransmitMode != 0)
            {
                txb.IsReadOnly = false;
                txb.SelectionStart = txb.Text.Length;
                txb.Cursor = System.Windows.Input.Cursors.IBeam;
            }
        }

        private void TextBox_FloorNum_Change(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;
            if (this.IsFaceTransmitMode == 2)
            {
                txb.IsReadOnly = false;
                txb.SelectionStart = txb.Text.Length;
                txb.Cursor = System.Windows.Input.Cursors.IBeam;
            }
        }

        private void TextBox_FloorNum_Changed(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;

            if (txb.IsReadOnly)
            {
                return;
            }
            FaceAuthDataBean face_data = (FaceAuthDataBean)txb.DataContext;

            int aout = 0;
            if (int.TryParse(txb.Text, out aout))
            {
                if (txb.Text.StartsWith("0"))
                {
                    txb.Text = aout.ToString();
                }
            }

            if (txb.Text != face_data.FloorNum)
            {
                string msg = $"登録者の行き先階情報を({face_data.FloorNum})から({txb.Text})に変更しますか？";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                          MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.No))
                {
                    txb.Text = face_data.FloorNum;
                }
                else
                {
                    int a = 0;
                    if (int.TryParse(txb.Text, out a))
                    {
                        if (int.Parse(txb.Text) > 24 || int.Parse(txb.Text) < 1)
                        {
                            System.Windows.MessageBox.Show("入力は数値(1-24)でなければなりません。", "情報",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                            txb.Text = face_data.FloorNum;
                            return;
                        }
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 選択した登録者の行き先階の情報は({face_data.FloorNum})から({txb.Text})に変更されました。");
                        face_data.FloorNum = txb.Text;
                        face_data.IsUpdated = true;
                        face_data.IsDeleted = false;
                        face_data.IsInserted = false;
                        face_data.IsSelected = true;
                        CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    }
                    else
                    {
                        System.Windows.MessageBox.Show($"入力は数値(1-24)でなければなりません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                        txb.Text = face_data.FloorNum;
                        return;
                    }
                }
            }
            txb.Cursor = System.Windows.Input.Cursors.Arrow;
            txb.IsReadOnly = true;
        }

        private void TextBox_Name_Changed(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;

            if (txb.IsReadOnly)
            {
                return;
            }

            // デグレ対応　接点連動の場合、指名を変更状態でスクロール時の不具合対応
            try
            {
                FaceAuthDataBean face_data = (FaceAuthDataBean)txb.DataContext;
                if (txb.Text != face_data.StaffName)
                {
                    if (txb.Text.IndexOf(',') != -1)
                    {
                        string msgComma = $"登録者の名前情報にカンマがありますので、更新できません。";
                        MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                        txb.Text = face_data.StaffName;
                    }
                    else
                    {
                        string msg = $"登録者の名前情報を({face_data.StaffName})から({txb.Text})に変更しますか？";
                        MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                                  MessageBoxButton.YesNo, MessageBoxImage.Information);
                        if (messageBoxResult.Equals(MessageBoxResult.No))
                        {
                            txb.Text = face_data.StaffName;
                        }
                        else
                        {
                            WriteLogSafe.LogSafe($"[登録者一覧画面] 選択した登録者の名前情報は({face_data.StaffName})から({txb.Text})に変更されました。");
                            face_data.StaffName = txb.Text;
                            face_data.IsUpdated = true;
                            face_data.IsDeleted = false;
                            face_data.IsInserted = false;
                            face_data.IsSelected = true;
                            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                        }
                    }
                }
                txb.Cursor = System.Windows.Input.Cursors.Arrow;
                txb.IsReadOnly = true;
            }
            catch
            {
                return;
            }
        }

        private void TextBox_Name_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool isComma = e.Key == Key.OemComma;

            if (isComma)
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void TextBox_FloorNum_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool isNumber = e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9;
            bool isBack = e.Key == Key.Back;
            bool isTab = e.Key == Key.Tab;
            bool isEnter = e.Key == Key.Enter;
            bool isLeftOrRight = e.Key == Key.Left || e.Key == Key.Right;
            bool isKeyupOrKeydown = e.Key == Key.Up || e.Key == Key.Down;
            bool isCtrlA = e.Key == Key.A && e.KeyboardDevice.Modifiers == ModifierKeys.Control;

            if (isNumber || isCtrlA || isBack || isTab || isLeftOrRight || isKeyupOrKeydown || isEnter)
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void RadioBtn_Checked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.RadioButton btn = (System.Windows.Controls.RadioButton)sender;
            try
            {
                // No.136 上から順に押下していくとアプリが落ちる対応
                FaceAuthDataBean face_data = btn.DataContext as FaceAuthDataBean;
                if (face_data == null)
                {
                    return;
                }
                if (!face_data.IsChecked)
                {
                    IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => item.IsChecked);
                    foreach (FaceAuthDataBean face_data_item in FaceDatas)
                    {
                        face_data_item.IsChecked = false;
                    }
                    face_data.IsChecked = true;
                }
            }
            catch
            {
                return;
            }
        }

        private void RadioBtn_UnChecked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.RadioButton btn = (System.Windows.Controls.RadioButton)sender;
            try
            {
                // No.136 上から順に押下していくとアプリが落ちる対応
                FaceAuthDataBean face_data = btn.DataContext as FaceAuthDataBean;
                if (face_data == null)
                {
                    return;
                }
                face_data.IsChecked = false;
            }
            catch
            {
                return;
            }
        }
        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.CheckBox btn = (System.Windows.Controls.CheckBox)sender;
            try 
            {
                // No.136 上から順に押下していくとアプリが落ちる対応
                FaceAuthDataBean face_data = btn.DataContext as FaceAuthDataBean;
                if (face_data == null)
                {
                    return;
                }
                face_data.IsSelected = true;
            }
            catch
            {
                return;
            }
        }

        private void CheckBox_UnChecked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.CheckBox btn = (System.Windows.Controls.CheckBox)sender;
            // No.136 上から順に押下していくとアプリが落ちる対応
            try
            {
                FaceAuthDataBean face_data = btn.DataContext as FaceAuthDataBean;
                if (face_data == null)
                {
                    return;
                }
                face_data.IsSelected = false;
            }
            catch
            {
                return;
            }
        }

        private void CheckBox_All_Checked(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => false == item.IsSelected);
                foreach (FaceAuthDataBean face_data in FaceDatas)
                {
                    face_data.IsSelected = true;
                }
                // No.112 登録一括のチェックボックス付近にて、連続でダブルクリックをしていると、アプリが落ちることを修正
                this.DG1.CommitEdit();
                this.DG1.CommitEdit();
                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
            }
            catch
            {
                return;
            }
        }

        private void CheckBox_All_UnChecked(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => true == item.IsSelected);
                foreach (FaceAuthDataBean face_data in FaceDatas)
                {
                    face_data.IsSelected = false;
                }
                // No.112 登録一括のチェックボックス付近にて、連続でダブルクリックをしていると、アプリが落ちることを修正
                this.DG1.CommitEdit();
                this.DG1.CommitEdit();
                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
            }
            catch
            {
                return;
            }
        }

        private void Btn_Edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FaceAuthDataBean FaceData = this.ViewModel.Recordings.Where(item => { return item.IsChecked; }).FirstOrDefault();
                if (FaceData == null)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                AtlasServerDataBean select_atlas = (AtlasServerDataBean)this.combo_atlas.SelectedItem;
                string atlas_ip = select_atlas.Server_Ip;
                if ("".Equals(atlas_ip) && this.AtlasViewModel.Recordings.Count > 1)
                {
                    atlas_ip = this.AtlasViewModel.Recordings[1].Server_Ip;
                }
                EditFaceAuthPage editFaceAuthPage = new EditFaceAuthPage(FaceData, atlas_ip, this.IsFaceTransmitMode);
                editFaceAuthPage.Owner = this;
                editFaceAuthPage.ShowDialog();
                if (true == editFaceAuthPage.HasChanged)
                {
                    FaceData.IsUpdated = true;
                    FaceData.IsDeleted = false;
                    FaceData.IsInserted = false;
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者({FaceData.FaceId})の顔情報を編集しました。");
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者顔情報の編集に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者顔情報の編集に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                int FaceCount = FaceDatas.Count();
                if (FaceCount == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                // modify by #217  文言「登録者の顔情報を削除しますか？」に統一
                string msg = "登録者の顔情報を削除しますか？";
                // # 282 対応
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg + "\r\n" + "\t" + FaceCount + "件", "確認",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.Yes))
                {
                    foreach (FaceAuthDataBean FaceData in FaceDatas)
                    {
                        FaceData.StaffImgName = "";
                        FaceData.Staff_Image = null;
                        FaceData.IsDeleted = true;
                        FaceData.IsUpdated = false;
                        FaceData.IsSelected = false;
                        if (IsFaceTransmitMode != 0)
                        {
                            FaceData.StaffName = "";
                        }
                        if (IsFaceTransmitMode == 2)
                        {
                            FaceData.FloorNum = "";
                        }
                    }
                    this.CheckBox_All.IsChecked = false;
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 選択した登録者の顔情報({FaceCount}件)は正常に削除されました。");
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者顔情報の削除に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者顔情報の削除に失敗しました。{ex.Message}", "情報",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private async void Btn_Read_Click(object sender, RoutedEventArgs e)
        {
            int AtlasKeyCheck = 0;
            bool resultFirst;
            // 念のため、接点連動、かつログインユーザがHitachiadmin以外の場合、「読出」ボタン押下を無効にする
            // 読出の選択肢がないので、下記の処理を実行すると、異常終了を防ぐのため、returnにする
            if ((this.IsFaceTransmitMode == 1 || this.IsFaceTransmitMode == 2) && !this.IsLoginByHitachiadmin)
            {
                return;
            }

            ReadSrcDataBean select_read = (ReadSrcDataBean)this.combo_file.SelectedItem;

            if (select_read.Key == 1)
            {
                OpenFileDialog openFile = new OpenFileDialog
                {
                    Multiselect = false,
                    Filter = "CSVファイル(*.csv)|*.csv"
                };
                DialogResult result = openFile.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.Cancel)
                {
                    return;
                }

                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                var SelectCSVFile = openFile.FileName;
                WriteLogSafe.LogSafe($"[登録者一覧画面] センターCSVファイル({SelectCSVFile})から登録者データを読み込みます。");
                ReadFromCenterFile(SelectCSVFile);
                WriteLogSafe.LogSafe($"[登録者一覧画面] センターCSVファイルからの読み込みは完了しました。");
                SetRecordsCount();

                this.ViewModel.Recordings = new ObservableCollection<FaceAuthDataBean>(this.ViewModel.Recordings.OrderBy(item => item.FaceId));
                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.ViewModel.Recordings)
                {
                    Bean.Idx = ++Idx_;
                }
                this.DG1.DataContext = this.ViewModel.Recordings;

                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
            else
            {
                int AtlasCount = this.AtlasViewModel.Recordings.Count();
                if (AtlasCount <= 1)
                {
                    System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);

                    return;
                }

                AtlasServerDataBean SelectAtlas = (AtlasServerDataBean)this.combo_atlas.SelectedItem;
                if ("".Equals(SelectAtlas.Server_Ip))
                {
                    try
                    {
                        // # 288
                        loading.IsActive = true;
                        loadingPart.Visibility = Visibility.Visible;

                        // デグレ対応
                        ObservableCollection<FaceAuthDataBean> AtlasDatasCheck = new ObservableCollection<FaceAuthDataBean>();
                        this.DG1.DataContext = AtlasDatasCheck;

                        // No.107 Atlas読み出しを行ったところ、すべての画像ファイルが表示されず、一部の画像しか表示されない対応
                        IsReadFromAtlasRun = true;

                        for (int i = 1; i < this.AtlasViewModel.Recordings.Count; i++)
                        {
                            if (i == 1)
                            {
                                // デグレ対応
                                FaceAuthViewModel ViewModelForReadFromAtlas = new FaceAuthViewModel();
                                AtlasKeyCheck = int.Parse(this.AtlasViewModel.Recordings[i].Server_Name);
                                resultFirst = await ViewModelForReadFromAtlas.ReadFromAtlas(this.AtlasViewModel.Recordings[i].Server_Ip, AtlasKeyCheck, i);
                                if (!resultFirst)
                                {
                                    // No.106 Atlas読出し後、エラーメッセージを、もともとの条件に応じて、表示してください。
                                    System.Windows.MessageBox.Show($"装置からの読み込みは失敗しました。\r\n装置への認証は失敗しました。\r\n装置IPアドレス：{this.AtlasViewModel.Recordings[i].Server_Ip}", "エラー",
                                                        MessageBoxButton.OK, MessageBoxImage.Error);

                                    loading.IsActive = false;
                                    loadingPart.Visibility = Visibility.Hidden;
                                    return;
                                }
                                AtlasDatasCheck = ViewModelForReadFromAtlas.Recordings;
                            }
                            if (i > 1)
                            {
                                AtlasKeyCheck = int.Parse(this.AtlasViewModel.Recordings[i].Server_Name);

                                AtlasApi Api = new AtlasApi();
                                string Token = await Api.GetToken(this.AtlasViewModel.Recordings[i].Server_Ip);
                                if ("".Equals(Token))
                                {
                                    System.Windows.MessageBox.Show($"装置からの読み込みは失敗しました。\r\n装置への認証は失敗しました。\r\n装置IPアドレス：{this.AtlasViewModel.Recordings[i].Server_Ip}", "エラー",
                                                        MessageBoxButton.OK, MessageBoxImage.Error);

                                    loading.IsActive = false;
                                    loadingPart.Visibility = Visibility.Hidden;
                                    return;
                                }

                                string DBId = await Api.GetDBIdByName(this.AtlasViewModel.Recordings[i].Server_Ip, Token, Configure.LibraryName);
                                if ("".Equals(DBId))
                                {
                                    DBId = await Api.NewDBByName(this.AtlasViewModel.Recordings[i].Server_Ip, Token, Configure.LibraryName, LibraryDesp);
                                    if ("".Equals(DBId))
                                    {
                                        System.Windows.MessageBox.Show($"装置からの読み込みは失敗しました。\r\n装置には顔認証ライブラリが見つかりませんでした。\r\n装置IPアドレス：{this.AtlasViewModel.Recordings[i].Server_Ip}", "エラー",
                                                            MessageBoxButton.OK, MessageBoxImage.Error);

                                        loading.IsActive = false;
                                        loadingPart.Visibility = Visibility.Hidden;
                                        return;
                                    }
                                }

                                List<FaceAuthDataBean> UserList = new List<FaceAuthDataBean>();
                                bool FlagCheck = await Api.GetUserList(this.AtlasViewModel.Recordings[i].Server_Ip, Token, DBId, AtlasKeyCheck, i, UserList);
                                if (FlagCheck)
                                {
                                    foreach (FaceAuthDataBean bean in AtlasDatasCheck)
                                    {
                                        foreach (var user in UserList)
                                        {
                                            if (bean.FaceId == user.FaceId)
                                            {
                                                // No.89 ipaddrを連番にすると正常にKeyIDが記載されていましたが、歯抜けの場合でも正常にKeyIDが記載されるように、実装の修正
                                                this.UpdateUserId(bean, AtlasKeyCheck, user.UserIds[AtlasKeyCheck - 1]);
                                                break;
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    System.Windows.MessageBox.Show($"装置からの読み込みは失敗しました。\r\n顔データ取得が失敗しました。\r\n装置IPアドレス：{this.AtlasViewModel.Recordings[i].Server_Ip}", "エラー",
                                                MessageBoxButton.OK, MessageBoxImage.Error);

                                    loading.IsActive = false;
                                    loadingPart.Visibility = Visibility.Hidden;
                                    return;
                                }
                            }
                        }
                        SetRecordsCount();
                        this.DG1.DataContext = AtlasDatasCheck;
                        // No.89 AtlasのAll読出しの歯抜け対応
                        this.ViewModel.Recordings = AtlasDatasCheck;
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;

                        return;
                    }
                    catch (Exception ex)
                    {
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 装置から顔データの読込が失敗しました。{ex.Message}");
                        System.Windows.MessageBox.Show($"装置から顔データの読込が失敗しました。{ex.Message}", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);

                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        return;
                    }
                }

                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置({SelectAtlas.Server_Name}:{SelectAtlas.Server_Ip})から登録者データを読み込みます。");
                int AtlasKey = int.Parse(SelectAtlas.Server_Name);
                this.IsRecoveryMode = true;
                var result = await this.ViewModel.ReadFromAtlas(SelectAtlas.Server_Ip, AtlasKey, AtlasCount - 1);

                if (!result)
                {
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }

                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置からの読み込みは完了しました。");
                SetRecordsCount();
                this.DG1.DataContext = this.ViewModel.Recordings;
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }

        private async Task<bool> Ping_Retry()
        {
            var AtlasList = this.AtlasViewModel.Recordings;

            var ping = new System.Net.NetworkInformation.Ping();

            await Task.Delay(1000);

            // No.84 確認のとれた装置のみ登録チェックを行います
            // No.128「リトライ」後に全台のベリファイチェックを行っているかの見直し
            AtlasListNoError.Clear();

            for (int i = 1; i < AtlasList.Count; i++)
            {
                string[] AtlasIpInfo = AtlasList[i].Server_Ip.Split(':');
                string AtlasNumber = AtlasList[i].Server_Name;
                string AtlasIpNoPort = AtlasIpInfo[0];

                await Task.Delay(100);

                try
                {
                    // No.99 画面を移動させてマウスが効かなくなることを修正
                    var result = await ping.SendPingAsync(AtlasIpNoPort);

                    if (result.Status != System.Net.NetworkInformation.IPStatus.Success)
                    {
                        pingJudegError = true;

                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "疎通失敗",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasNumber,
                        };

                        Recordings_Ping.Add(item);
                    }
                    // No.84 確認のとれた装置のみ登録チェックを行います
                    else
                    {
                        AtlasListNoError.Add(AtlasList[i]);
                    }
                }
                catch (Exception)
                {
                    pingJudegError = true;

                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasNumber,
                    };

                    Recordings_Ping.Add(item);
                }
            }

            return true;
        }

        public void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(ExitFrames), frame);
            Dispatcher.PushFrame(frame);
        }

        public object ExitFrames(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }

        private void Btn_Write_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 登録後閉じるボタンを非活性にする
                var hwnd = new WindowInteropHelper(this).Handle;
                button1_Click(sender, e, hwnd);
                if (this.AtlasViewModel.Recordings.Count() <= 1)
                {
                    System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    // 登録一覧画面に戻るボタンを活性にする
                    button2_Click(sender, e, hwnd);
                    return;
                }

                AtlasServerDataBean SelectAtlas = (AtlasServerDataBean)this.combo_atlas.SelectedItem;
                if (!"".Equals(SelectAtlas.Server_Ip))
                {
                    System.Windows.MessageBox.Show("設定先をALLに指定してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    // 登録一覧画面に戻るボタンを活性にする
                    button2_Click(sender, e, hwnd);
                    return;
                }

                // No.67 メモリ対策
                List<FaceAuthDataBean> FaceDatasToDelete = this.ViewModel.Recordings.Where(item =>
                {
                    return item.IsSelected && item.IsDeleted;
                }).ToList();
                List<FaceAuthDataBean> FaceDatasToUpdate = this.ViewModel.Recordings.Where(item =>
                {
                    return item.IsSelected && !item.IsInserted && !item.IsDeleted && (item.IsEditSuccess || ((item.IsUpdated || "0".Equals(item.LoginStatusCode)) && !"".Equals(item.StaffImgPath) && item.StaffImgPath != null && File.Exists(item.StaffImgPath)));
                }).ToList();

                List<FaceAuthDataBean> FaceDatasNotChange = this.ViewModel.Recordings.Where(item =>
                {
                    return item.IsSelected && (!item.IsUpdated && !item.IsDeleted);
                }).ToList();
                if (FaceDatasToDelete.Count() == 0 && FaceDatasToUpdate.Count() == 0)
                {
                    System.Windows.MessageBox.Show("選択された登録者データは変更されていません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    // 登録一覧画面に戻るボタンを活性にする
                    button2_Click(sender, e, hwnd);
                    return;
                }
                else
                {
                    string msg = $"下記の情報を登録します。\n\rよろしいですか。\n\r\n\r　追加変更　{FaceDatasToUpdate.Count()}件\n\r　　　削除　{FaceDatasToDelete.Count()}件";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                        MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.No))
                    {
                        // 登録一覧画面に戻るボタンを活性にする
                        button2_Click(sender, e, hwnd);
                        return;
                    }

                    // 登録開始のログを出力する
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 装置へ顔データの登録処理が開始しました。追加変更{FaceDatasToUpdate.Count()}件、削除{FaceDatasToDelete.Count()}件です。");
                }

                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                // flush frame wait loading visible
                DoEvents();

                IsNeedMatchErrorShow = true;
                IsNeedMatchErrorShowAfterWrite = false;

                // #273対応
                List<Task<bool>> tasks = new List<Task<bool>>();

                // # 273 対応
                foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                {
                    // # 273 対応
                    for (int i = 0; i < bean.IsUpdatedSuccess.Length; i++)
                    {
                        bean.IsUpdatedSuccess[i] = false;
                    }
                }

                var AtlasList = this.AtlasViewModel.Recordings;

                // 疎通処理追加
                pingJudegError = false;
                bool runContinue = true;

                Recordings_Ping.Clear();

                List<Task<bool>> task_ping = new List<Task<bool>>();

                task_ping.Add(Ping_Retry());

                Task.Run(() => { Task.WaitAll(task_ping.ToArray()); }).ContinueWith(t1 =>
                {
                    this.Invoke(new Action(() =>
                    {
                        if (pingJudegError)
                        {
                            // 登録時の疎通確認に関しての文言を変更
                            int errorType = 5;
                            PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasList.Count, errorType, AtlasListNoError);
                            pingJudge.Owner = this;
                            pingJudge.ShowDialog();

                            runContinue = pingJudge.HasRunContinue;

                            if (!runContinue)
                            {
                                loading.IsActive = false;
                                loadingPart.Visibility = Visibility.Hidden;
                                // 登録一覧画面に戻るボタンを活性にする
                                button2_Click(sender, e, hwnd);
                                return;
                            }
                        }

                        pingJudegError = false;
                        Recordings_Ping.Clear();

                        foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                        {
                            bean.IsImageDataUpdateSuccess = false;
                            bean.CheckResultForFlag = false;
                            if (bean.IsEditSuccess)
                            {
                                continue;
                            }
                            else
                            {
                                // 2.2.xx対応対策一覧 No.3 登録する顔画像が500kBを超えている場合、顔登録アプリで500kBに縮小して登録する。
                                if ((long)((double)ImageHelper.DecryptFileToBase64(bean.StaffImgPath).Length * 0.75) > 512000)
                                {
                                    ImageHelper.JpgFileToBase64(bean.StaffImgPath, bean.FaceId);
                                }
                            }
                        }

                        for (int i = 1; i < AtlasList.Count; i++)
                        {
                            // No.142 
                            bool AtlasIsNoError = false;
                            for (int j = 0; j < AtlasListNoError.Count; j++)
                            {
                                if (AtlasList[i].Server_Name == AtlasListNoError[j].Server_Name)
                                {
                                    tasks.Add(UploadData(AtlasList[i].Server_Name, AtlasList[i].Server_Ip, FaceDatasToDelete, FaceDatasToUpdate, int.Parse(AtlasList[i].Server_Name)));
                                    AtlasIsNoError = true;
                                    break;
                                }
                            }

                            if (!AtlasIsNoError)
                            {
                                foreach (FaceAuthDataBean bean in FaceDatasToDelete.Concat(FaceDatasToUpdate))
                                {
                                    this.UpdateUserId(bean, int.Parse(AtlasList[i].Server_Name), "");
                                }
                            }
                        }
                        Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
                        {
                            // Check all results
                            int deletedCount = 0;
                            foreach (FaceAuthDataBean Bean in FaceDatasToDelete)
                            {
                                bool detetedResult = true;
                                for (int i = 0; i < AtlasListNoError.Count; i++)
                                {
                                    string userId = ReturnUserId(Bean, int.Parse(AtlasListNoError[i].Server_Name));
                                    if (!"".Equals(userId))
                                    {
                                        detetedResult = false;
                                        break;
                                    }
                                }
                                if (detetedResult)
                                {
                                    deletedCount++;
                                    if (this.IsBackupMode && this.IsFaceTransmitMode == 0)
                                    {
                                        this.Invoke(new Action(() =>
                                        {
                                            this.ViewModel.Recordings.Remove(Bean);
                                        }));
                                        continue;
                                    }
                                    Bean.StaffImgPath = "";
                                    Bean.LoginStatus = "無";
                                    Bean.LoginStatusCode = "0";
                                    Bean.IsDeleted = false;
                                    Bean.IsUpdated = false;
                                    Bean.IsInserted = false;
                                    Bean.IsSelected = false;
                                    // 2.2.xx対応対策一覧 No.9 削除時、nullへ設定
                                    Bean.HasFilePath = "";
                                }
                            }

                            int updatedCount = 0;
                            foreach (FaceAuthDataBean Bean in FaceDatasToUpdate)
                            {
                                // No.113 未登録顔画像も登録失敗として顔画像を保存しないように対応致します。
                                // No.68 登録失敗時は、失敗した顔画像はface_data_jpgに保存しない
                                if (Bean.IsImageDataUpdateSuccess == true)
                                {
                                    // No.67 メモリ対策
                                    if (Bean.IsEditSuccess)
                                    {
                                        string imagePath = Path.Combine(Configure.FaceDataPath, Bean.StaffImgName);
                                        bool imageRes = ImageHelper.EncryptFile((BitmapImage)Bean.Staff_Image, imagePath);
                                        if (imageRes)
                                        {
                                            Bean.StaffImgPath = imagePath;
                                        }
                                    }
                                }

                                bool updatedResult = true;
                                for (int i = 0; i < AtlasListNoError.Count; i++)
                                {
                                    string userId = ReturnUserId(Bean, int.Parse(AtlasListNoError[i].Server_Name));
                                    if ("".Equals(userId))
                                    {
                                        updatedResult = false;
                                        break;
                                    }

                                    // # 273
                                    if (!Bean.IsUpdatedSuccess[int.Parse(AtlasListNoError[i].Server_Name) - 1])
                                    {
                                        updatedResult = false;
                                        break;
                                    }
                                }

                                if (updatedResult)
                                {
                                    // No.14
                                    if (!Bean.IsImageDataUpdateSuccess)
                                    {
                                        continue;
                                    }
                                    updatedCount++;
                                    Bean.LoginStatus = "有";
                                    Bean.LoginStatusCode = "1";
                                    Bean.IsDeleted = false;
                                    Bean.IsUpdated = false;
                                    Bean.IsInserted = false;
                                    Bean.IsSelected = false;
                                    // 2.2.xx対応対策一覧 No.9 登録時、1へ設定
                                    Bean.HasFilePath = "1";
                                }
                                else
                                {
                                    // No.43 登録失敗しているので、登録有無を「有」から「無」に変更する
                                    Bean.LoginStatus = "無";
                                    Bean.LoginStatusCode = "0";
                                }
                            }

                            foreach (FaceAuthDataBean Bean in FaceDatasNotChange)
                            {
                                Bean.IsSelected = false;
                            }

                            if (deletedCount < FaceDatasToDelete.Count())
                            {
                                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置へ顔データの削除が失敗しました。{FaceDatasToDelete.Count()}件の削除が必要ですが、{deletedCount}件だけが削除成功しました。");
                            }
                            if (updatedCount < FaceDatasToUpdate.Count())
                            {
                                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置へ顔データの更新が失敗しました。{FaceDatasToUpdate.Count()}件の更新が必要ですが、{updatedCount}件だけが更新成功しました。");
                            }

                            if (deletedCount >= FaceDatasToDelete.Count() && updatedCount >= FaceDatasToUpdate.Count())
                            {
                                this.IsRecoveryMode = false;
                                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置へ顔データの登録({deletedCount}件の削除、{updatedCount}件の更新)が成功しました。");
                            }

                            // Save csv file
                            bool csvResult = ToToolCSV();

                            int FaceDataCount = FaceDatasToDelete.Count() + FaceDatasToUpdate.Count();
                            int FaceDataSuccess = deletedCount + updatedCount;
                            int FaceDataError = FaceDataCount - FaceDataSuccess;

                            if (!IsNeedMatchErrorShowAfterWrite && (!pingJudegError && Recordings_Ping.Count == 0))
                            {
                                // No.69 バックアップ判断用フラグ
                                if (FaceDataSuccess > 0)
                                {
                                    IsNeedBackupErrorShow = true;
                                }

                                // No.68 Face not found(もしくは通信系以外のエラーの場合)を検出したら、全ベリファイチェック促さずに、以下のメッセージを表示します。
                                IEnumerable<FaceAuthDataBean> ImageUnsuccessFaceDatas = FaceDatasToUpdate.Where(item => { return (!item.IsImageDataUpdateSuccess); });
                                if (ImageUnsuccessFaceDatas.Count() > 0)
                                {
                                    System.Windows.MessageBox.Show($"成功{FaceDataSuccess}件、失敗{FaceDataError}件\n\r\n\r顔画像の登録に失敗しています。\n\r顔画像を見直して、再登録してください。", "エラー",
                                            MessageBoxButton.OK, MessageBoxImage.Error);
                                }
                                else
                                {
                                    System.Windows.MessageBox.Show($"　登録完了しました。　　　\n\r\n\r　　成功　{FaceDataSuccess}件 \n\r　　失敗　{FaceDataError}件", "情報",
                                                                                MessageBoxButton.OK, MessageBoxImage.Information);
                                }
                            }

                            this.Invoke(new Action(() =>
                            {
                                SetRecordsCount();
                                int Idx_ = 0;
                                foreach (FaceAuthDataBean Bean in this.ViewModel.Recordings)
                                {
                                    Bean.Idx = ++Idx_;
                                }
                                loading.IsActive = false;
                                loadingPart.Visibility = Visibility.Hidden;
                                this.CheckBox_All.IsChecked = false;
                                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();

                                // 登録一覧画面に戻るボタンを活性にする
                                button2_Click(sender, e, hwnd);

                                if (IsNeedMatchErrorShowAfterWrite || (pingJudegError && Recordings_Ping.Count > 0))
                                {
                                    int errorType = 2;
                                    PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasListNoError.Count + 1, errorType, AtlasListNoError);
                                    pingJudge.Owner = this;
                                    pingJudge.ShowDialog();

                                    runContinue = pingJudge.HasRunContinue;

                                    if (!runContinue)
                                    {
                                        loading.IsActive = false;
                                        loadingPart.Visibility = Visibility.Hidden;
                                        // 登録一覧画面に戻るボタンを活性にする
                                        button2_Click(sender, e, hwnd);
                                        return;
                                    }
                                    else
                                    {
                                        WithoutCheckFlag(sender, e, FaceDatasToUpdate, FaceDatasToDelete);
                                    }
                                }
                            }));
                        });
                    }));
                });
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置への登録が失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"装置への登録が失敗しました。{ex.Message}", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                // 登録一覧画面に戻るボタンを活性にする
                var hwnd = new WindowInteropHelper(this).Handle;
                button2_Click(sender, e, hwnd);
            }
        }

        private void WithoutCheckFlag(object sender, RoutedEventArgs e, List<FaceAuthDataBean> faceDatasToUpdate, List<FaceAuthDataBean> faceDatasToDelete)
        {
            Recordings_Check_Sum.Clear();
            foreach (FaceAuthDataBean bean_update in faceDatasToUpdate)
            {
                if (bean_update.CheckResultForFlag)
                {
                    bean_update.StaffImgPath = Path.Combine(Configure.FaceDataPath, bean_update.FaceId + @".jpg");
                    Recordings_Check_Sum.Add(bean_update);
                }
            }
            foreach (FaceAuthDataBean bean_delete in faceDatasToDelete.Distinct(new Compare()).OrderBy(item => item.FaceId))
            {
                if (bean_delete.CheckResultForFlag)
                {
                    bean_delete.StaffName = "未登録";
                    bean_delete.StaffImgName = "画像なし";
                    bean_delete.IsDeleted = true;
                    bean_delete.StaffImgPath = Path.Combine(Configure.FaceDataPath, bean_delete.FaceId + @".jpg");
                    Recordings_Check_Sum.Add(bean_delete);
                }
            }
            Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>(Recordings_Check_Sum.OrderBy(item => item.FaceId));

            IsNeedMatchErrorShow = true;
            // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
            this.IsNeedMatchErrorShowType3 = true;

            foreach (FaceAuthDataBean beanTable in Recordings_Check_Sum)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 不整合顔情報が見つかりました。顔ID:{beanTable.FaceId})");
            }

            bool HasChangedOnCheckPage = false;

            FaceCheckLIstPage faceCheck = new FaceCheckLIstPage(Recordings_Check_Sum, AtlasListNoError);
            faceCheck.Owner = this;
            faceCheck.ShowDialog();

            HasChangedOnCheckPage = faceCheck.HasChanged;

            if (HasChangedOnCheckPage)
            {
                IsNeedMatchErrorShow = false;
                // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
                this.IsNeedMatchErrorShowType3 = false;
                // No.69 バックアップ判断フラグ
                IsNeedBackupErrorShow = true;

                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                // メモリーオーバー問題を防止
                this.ViewModel.Recordings.Clear();
                this.DG1.DataContext = "";

                // for メモリーオーバー防止
                GC.Collect();

                this.ViewModel.ReadViewDelay(this.IsFaceTransmitMode);
                this.DG1.DataContext = this.ViewModel.Recordings;
                SetRecordsCount();
                if (this.IsFaceTransmitMode == 2)
                {
                    this.DG1.Columns[5].Visibility = Visibility.Visible;
                    this.btn_edit_batch.Visibility = Visibility.Visible;
                }
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者一覧画面を表示しました。");
                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;

                Recordings_Check_Sum.Clear();
                Recordings_Check_Csv.Clear();
                Recordings_Check_Atlas.Clear();

                // for メモリーオーバー防止
                GC.Collect();
            }
        }
        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            // No.69 登録者一覧画面の閉じる釦押下時のメッセージの表示内容修正
            string msg = "アプリを終了しますか?";

            if (Configure.CheckFlag == 1)
            {
                // No.123 文言の修正
                string msgBase = "以下の項目が未実施です。\r\n本当にアプリを終了しますか？\r\n";
                string msg1 = "";
                string msg2 = "";
                string msg3 = "";
                int errorCount = 0;
                IEnumerable<FaceAuthDataBean> UnsavedFaceDatas = this.ViewModel.Recordings.Where(item => { return (item.IsDeleted || item.IsUpdated); });
                IEnumerable<FaceAuthDataBean> ImageUnsuccessFaceDatas = this.ViewModel.Recordings.Where(item => { return (!item.IsImageDataUpdateSuccess); });

                if (IsNeedMatchErrorShow)
                {
                    errorCount++;
                    msg1 = "\r\n　・登録チェック";
                }
                if (UnsavedFaceDatas.Count() > 0)
                {
                    errorCount++;
                    msg2 = "\r\n　・変更内容の反映";
                }
                // No.68 登録エラーの未解決時はNo.69の「閉じる」釦の判定で、「登録チェック」と「変更内容が未反映」の対象にします
                if (ImageUnsuccessFaceDatas.Count() > 0)
                {
                    errorCount += 2;
                    msg1 = "\r\n　・登録チェック";
                    msg2 = "\r\n　・変更内容の反映";
                }
                if (IsNeedBackupErrorShow)
                {
                    errorCount++;
                    msg3 = "\r\n　・バックアップファイル作成";
                }

                // 全条件を満たした場合または2件を満たした場合
                if (errorCount > 1)
                {
                    msg = msgBase + msg1 + msg2 + msg3;
                }
                // 1件を満たした場合
                else
                {
                    if (IsNeedMatchErrorShow)
                    {
                        msg = "登録チェック未実施です。\r\n実施せずアプリを終了しますか？\r\n\r\n登録チェックを行うには、\r\n「いいえ」-「登録チェック」を押下してください。";
                        // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
                        if (IsNeedMatchErrorShowType3)
                        {
                            msg = "登録された顔情報に問題があります。\r\n再登録せずにアプリを終了しますか？\r\n\r\n再登録を行うには、\r\n「いいえ」-「登録チェック」-「再登録」を押下してください。";
                        }
                    }
                    else if (UnsavedFaceDatas.Count() > 0)
                    {
                        msg = "装置に変更内容が反映されていません。\r\nアプリを終了しますか？";
                    }
                    else if (IsNeedBackupErrorShow)
                    {
                        msg = "顔情報が更新されていますが、\r\nバックアップファイル作成していません。\r\nアプリを終了しますか？";
                    }
                }
            }

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (messageBoxResult.Equals(MessageBoxResult.Yes))
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者一覧画面を閉じました。");
                base.OnClosing(e);
            }
            else
            {
                e.Cancel = true;
                base.OnClosing(e);
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            System.Environment.Exit(0);
            base.OnClosed(e);
        }

        private void Btn_CSV_Click(object sender, RoutedEventArgs e)
        {
            // No.103 下記のファイルとフォルダが存在しない場合、エラーMsgを表示する
            if (!Directory.Exists(Configure.FaceDataPath))
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] バックアップファイルの作成に失敗しました。face_data_jpgフォルダが存在しません。");
                System.Windows.MessageBox.Show("バックアップファイルの作成に失敗しました。\r\nファイルが欠損している可能性があります。\r\n\r\nアプリを再起動して、正しく動作するか確認してください。", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (!File.Exists(Configure.BasePath + @"\settings.ini"))
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] バックアップファイルの作成に失敗しました。settings.iniファイルが存在しません。");
                System.Windows.MessageBox.Show("バックアップファイルの作成に失敗しました。\r\nファイルが欠損している可能性があります。\r\n\r\nアプリを再起動して、正しく動作するか確認してください。", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (!File.Exists(Configure.ToolCsvPath + @"\tool_csv.csv"))
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] バックアップファイルの作成に失敗しました。tool_csvファイルが存在しません。");
                System.Windows.MessageBox.Show("バックアップファイルの作成に失敗しました。\r\nファイルが欠損している可能性があります。\r\n\r\nアプリを再起動して、正しく動作するか確認してください。", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            if (!File.Exists(Configure.ConfigFileNew))
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] バックアップファイルの作成に失敗しました。config.iniファイルが存在しません。");
                System.Windows.MessageBox.Show("バックアップファイルの作成に失敗しました。\r\nファイルが欠損している可能性があります。\r\n\r\nアプリを再起動して、正しく動作するか確認してください。", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            loading.IsActive = true;
            loadingPart.Visibility = Visibility.Visible;

            var srcPath = Configure.BasePath;

            DateTime dt = DateTime.Now;
            string dummyFileName = "Atlas_Tool_backup_" + string.Format("{0:yyyyMMdd_HHmmss}", dt);

            Microsoft.Win32.SaveFileDialog Dlg = new Microsoft.Win32.SaveFileDialog();
            //{
            //    Filter = "圧縮ファイル(*.zip)|*.zip"
            //};
            // Feed the dummy name to the save dialog
            Dlg.FileName = dummyFileName;

            Dlg.Title = "バックアップファイルの出力先とファイル名の指定";

            if (Dlg.ShowDialog() == true)
            {
                string aimPath = Dlg.FileName;
                // No.80 バックアップのフォルダをZipファイルに圧縮する
                string FilePath = aimPath.Substring(0, aimPath.LastIndexOf("\\"));
                string zipPath = FilePath + "\\" + dummyFileName + @".zip";

                // No.78
                List<Task<bool>> task_backup_copy = new List<Task<bool>>();

                task_backup_copy.Add(CopyBackup(srcPath, aimPath, zipPath));

                Task.Run(() => { Task.WaitAll(task_backup_copy.ToArray()); }).ContinueWith(t =>
                {
                    this.Invoke(new Action(() =>
                    {
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                    }));
                });
            }
            else
            {
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }

        private async Task<bool> CopyBackup(string srcPath, string aimPath, string zipPath)
        {
            try
            {
                await Task.Delay(3000);

                // No.143 空き容量がない場合は、バックアップ押下時にメッセージを表示します。
                string volume = aimPath.Substring(0, System.Windows.Forms.Application.StartupPath.IndexOf(':'));

                long freeSize = GetHardDiskFreeSpace(volume);
                long totalSize = 32 * 1024 * 1024 * 1024L;
                if (freeSize < totalSize)
                {
                    System.Windows.MessageBox.Show($"PCの空き容量が32GB未満のため、\r\nバックアップファイルを作成できません。\r\n\r\n空き容量を確保してから再度バックアップを押下してください。", "空き容量不足",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }

                // 检查目标目录是否以目录分割字符结束如果不是则添加之
                if (aimPath[aimPath.Length - 1] != Path.DirectorySeparatorChar)
                {
                    aimPath += Path.DirectorySeparatorChar;
                }
                // 判断目标目录是否存在如果不存在则新建之
                if (!Directory.Exists(aimPath))
                {
                    Directory.CreateDirectory(aimPath);
                }

                // イメージのバックアップ
                string jpgAimPath = aimPath + @"face_data_jpg\";
                if (!Directory.Exists(jpgAimPath))
                {
                    Directory.CreateDirectory(jpgAimPath);
                }

                string[] jpgFileList = Directory.GetFiles(Configure.FaceDataPath);
                foreach (string jpgFile in jpgFileList)
                {
                    await Task.Delay(10);
                    // ファイルのタイプはjpgかどうかを判断する
                    string strExt = System.IO.Path.GetExtension(jpgFile);
                    if (strExt == ".jpg")
                    {
                        File.Copy(jpgFile, jpgAimPath + Path.GetFileName(jpgFile), true);
                    }
                }

                // tool_csvのバックアップ
                string toolCsvAimPath = aimPath + @"tool_csv\";
                if (!Directory.Exists(toolCsvAimPath))
                {
                    Directory.CreateDirectory(toolCsvAimPath);
                }

                File.Copy(Configure.ToolCsvPath + @"\tool_csv.csv", toolCsvAimPath + @"\tool_csv.csv", true);

                // コンフィグファイルのバックアップ
                // No.103 バックアップ作成時はXXXXconfig.ini のまま保存する
                File.Copy(Configure.ConfigFileNew, aimPath + Path.GetFileName(Configure.ConfigFileNew), true);

                // settings.iniファイルのバックアップ
                File.Copy(Configure.BasePath + @"\settings.ini", aimPath + @"\settings.ini", true);

                // No.69 バックアップ判断用フラグ
                IsNeedBackupErrorShow = false;
                // No.80 バックアップのフォルダをZipファイルに圧縮する
                ZipFile.CreateFromDirectory(aimPath, zipPath);
                // No.80 バックアップのフォルダをZipファイルに圧縮後、バックアップフォルダ（ファイル含む）を削除する
                DirectoryInfo di = new DirectoryInfo(aimPath);
                di.Delete(true);
                WriteLogSafe.LogSafe($"[登録者一覧画面] バックアップが成功しました。");
                System.Windows.MessageBox.Show("バックアップが成功しました。", "情報",
                    MessageBoxButton.OK, MessageBoxImage.Information);

                return true;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] バックアップが失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show("バックアップファイルの作成に失敗しました。\r\nファイルが欠損している可能性があります。\r\n\r\nアプリを再起動して、正しく動作するか確認してください。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }
        }

        // No.143 空き容量がない場合は、バックアップ押下時にメッセージを表示します。
        public long GetHardDiskFreeSpace(string str_HardDiskName)
        {
            long freeSpace = new long();
            str_HardDiskName = str_HardDiskName + ":\\";
            System.IO.DriveInfo[] drives = System.IO.DriveInfo.GetDrives();
            foreach (System.IO.DriveInfo drive in drives)
            {
                if (drive.Name == str_HardDiskName)
                {
                    freeSpace = drive.TotalFreeSpace;
                }
            }
            return freeSpace;
        }

        // No.143 空き容量がない場合は、バックアップ押下時にメッセージを表示します。
        public async Task<long> GetBackupFileTotalSize()
        {
            long TotalSize = 0;

            TotalSize += GetFileSize(Configure.BasePath + @"\settings.ini");

            TotalSize += GetFileSize(Configure.ConfigFileNew);

            TotalSize += GetFileSize(Configure.ToolCsvPath + @"\tool_csv.csv");

            string[] jpgFileList = Directory.GetFiles(Configure.FaceDataPath);
            foreach (string jpgFile in jpgFileList)
            {
                await Task.Delay(10);
                // ファイルのタイプはjpgかどうかを判断する
                string strExt = System.IO.Path.GetExtension(jpgFile);
                if (strExt == ".jpg")
                {
                    TotalSize += GetFileSize(jpgFile);
                }
            }

            return TotalSize;
        }

        // No.143 空き容量がない場合は、バックアップ押下時にメッセージを表示します。
        public long GetFileSize(string path)
        {
            System.IO.FileInfo fileInfo = null;
            try
            {
                fileInfo = new System.IO.FileInfo(path);
            }
            catch
            {
                return 0;
            }
            if (fileInfo != null && fileInfo.Exists)
            {
                return (long)fileInfo.Length;
            }
            else
            {
                return 0;
            }
        }

        // No.143 空き容量がない場合は、バックアップ押下時にメッセージを表示します。
        public string ToTalSizeChangeToString(long size)
        {
            var num = 1024.00; //byte

            if (size < num)
                return size + "B";
            if (size < Math.Pow(num, 2))
                return (size / num).ToString("f1") + "K"; //KB
            if (size < Math.Pow(num, 3))
                return (size / Math.Pow(num, 2)).ToString("f1") + "M"; //MB
            if (size < Math.Pow(num, 4))
                return (size / Math.Pow(num, 3)).ToString("f1") + "G"; //GB

            return (size / Math.Pow(num, 4)).ToString("f1") + "T"; //TB
        }

        public bool ToToolCSV()
        {
            string FilePathToolCSV = Configure.ToolCsvPath + @"\tool_csv.csv";

            try
            {
                using (FileStream _stream = WriteToolCsv.fs)
                {
                    _stream.SetLength(0);
                    StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);
                    foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                    {
                        string sline;
                        if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                        {
                            ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                        }
                        if (this.IsFaceTransmitMode == 2)
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + beanTable.FloorNum + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        else
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        _writer.WriteLine(sline);
                    }
                    _writer.Close();
                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                    return true;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] CSVファイルへの出力が失敗しました。{ex.Message}");
                return false;
            }
        }

        private async Task<bool> UploadData(string AtlasName, string AtlasIp, List<FaceAuthDataBean> FaceDatasToDelete, List<FaceAuthDataBean> FaceDatasToUpdate, int No)
        {
            // for 疎通処理
            string[] AtlasIpInfo = AtlasIp.Split(':');
            string AtlasIpNoPort = AtlasIpInfo[0];

            int AtlasCount = this.AtlasViewModel.Recordings.Count();
            int AtlasKey = No;

            var Api = new AtlasApi();
            var Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);

                foreach (FaceAuthDataBean bean in FaceDatasToDelete.Concat(FaceDatasToUpdate))
                {
                    this.UpdateUserId(bean, No, "");
                }

                return false;
            }

            bool IsDBNew = false;
            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
            if ("".Equals(DBId))
            {
                DBId = await Api.NewDBByName(AtlasIp, Token, Configure.LibraryName, LibraryDesp);
                if ("".Equals(DBId))
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);

                    foreach (FaceAuthDataBean bean in FaceDatasToDelete.Concat(FaceDatasToUpdate))
                    {
                        this.UpdateUserId(bean, No, "");
                    }

                    return false;
                }
                IsDBNew = true;
            }
            else if (this.IsRecoveryMode)
            {
                List<FaceAuthDataBean> UserList = new List<FaceAuthDataBean>();
                bool FlagCheck = await Api.GetUserList(AtlasIp, Token, DBId, No, this.AtlasViewModel.Recordings.Count() - 1, UserList);
                foreach (var user in UserList)
                {
                    bool exists = false;
                    string userIdAtlas = ReturnUserId(user, No);
                    foreach (FaceAuthDataBean bean in this.ViewModel.Recordings)
                    {
                        if (userIdAtlas.Equals(ReturnUserId(bean, No)))
                        {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists)
                    {
                        await Api.DelUserByUserID(AtlasIp, Token, DBId, userIdAtlas);
                    }
                }
            }

            //No.43 再登録成功後のみ、古い顔データを削除する
            foreach (FaceAuthDataBean bean in FaceDatasToDelete)
            {
                string UserId_Temp = ReturnUserId(bean, No);
                if (UserId_Temp != null && !"".Equals(UserId_Temp))
                {
                    if (IsDBNew)
                    {
                        this.UpdateUserId(bean, No, "");
                        continue;
                    }
                    Boolean Flag = await Api.DelUserByUserID(AtlasIp, Token, DBId, UserId_Temp);
                    if (!Flag)
                    {
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ(顔ID:{bean.FaceId})の削除が失敗しました。");
                        // 削除失敗しても、Tool_csvのUserIDをクリア
                        this.UpdateUserId(bean, No, "");
                    }
                    else
                    {
                        // # 287 対応　削除成功のメッセージを追加
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの削除が成功しました。(Atlas Ip:{AtlasIp},KeyID:{bean.UserIds[No - 1]},顔ID:{bean.FaceId})");
                        this.UpdateUserId(bean, No, "");
                    }
                }
            }

            // 登録データ存在する場合、登録データを再登録する
            if (FaceDatasToUpdate.Count() != 0)
            {
                // 顔なしの画像データ登録時、対応
                //bool UpdateDatasErrorExist = false;

                int loginAddCount = 50;
                int totalCount = FaceDatasToUpdate.Count();

                for (int i = 0; i <= totalCount / loginAddCount; i++)
                {
                    IEnumerable<FaceAuthDataBean> FaceDatasTemp;
                    if (i == totalCount / loginAddCount)
                    {
                        if (totalCount > loginAddCount)
                        {
                            if (i * loginAddCount < totalCount)
                            {
                                FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, totalCount % loginAddCount);
                            }
                            else
                            {
                                continue;
                            }
                        }
                        else
                        {
                            FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, totalCount);
                        }
                    }
                    else
                    {
                        FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, loginAddCount);
                    }

                    // # 253
                    long totalImageSize = 0;

                    var Template = FaceDatasTemp.ToArray();

                    for (int j = 0; j < Template.Length; j++)
                    {
                        // No.68 base 64から直接ファイルサイズの理論値を計算する方法

                        // No.67 メモリ対策
                        if (Template[j].IsEditSuccess)
                        {
                            if (Template[j].Staff_Image != null)
                            {
                                totalImageSize += (long)((double)ImageHelper.BitmapToBase64((BitmapImage)Template[j].Staff_Image).Length * 0.75);
                            }
                        }
                        else
                        {
                            // 2.2.xx対応対策一覧 No.3 登録する顔画像が500kBを超えている場合、顔登録アプリで500kBに縮小して登録する。
                            //totalImageSize += (long)((double)ImageHelper.BitmapToBase64(ImageHelper.DecryptFile(Template[j].StaffImgPath)).Length * 0.75);
                            totalImageSize += (long)((double)ImageHelper.DecryptFileToBase64(Template[j].StaffImgPath).Length * 0.75);
                        }
                    }

                    if (totalImageSize <= 15 * 1024 * 1024)
                    {
                        string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTemp);
                        if ("".Equals(response))
                        {
                            WriteLogSafe.LogSafe($"[登録者一覧画面] Atlas装置({AtlasIp})への顔データ登録は中断されました。(顔ID Max50件、Size15MB以下登録)");

                            // for 疎通処理
                            pingJudegError = true;
                            FaceAuthDataBean item = new FaceAuthDataBean()
                            {
                                StaffName = "登録時にエラー応答",
                                OnlyExistAtlas = AtlasIpNoPort,
                                FigureId = AtlasName,
                            };
                            Recordings_Ping.Add(item);

                            // No.43 登録失敗しても、tool_csvのKeyIDを削除する
                            FaceDatasToUpdate = FaceDatasToUpdate.Where(itemReturn =>
                            {
                                return itemReturn.IsUpdatedSuccess[No - 1] == false;
                            }).ToList();

                            foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                            {
                                this.UpdateUserId(bean, No, "");
                            }

                            return false;
                        }

                        var jsonArr = DynamicJson.Parse(response).results;
                        foreach (FaceAuthDataBean bean in FaceDatasTemp)
                        {
                            foreach (var json in jsonArr)
                            {
                                if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                                {
                                    //No.43 再登録成功後のみ、古い顔データを削除する
                                    string UserId_Temp = ReturnUserId(bean, No);
                                    if (UserId_Temp != null && !"".Equals(UserId_Temp))
                                    {
                                        if (IsDBNew)
                                        {
                                            this.UpdateUserId(bean, No, "");
                                        }
                                        Boolean Flag = await Api.DelUserByUserID(AtlasIp, Token, DBId, UserId_Temp);
                                        if (!Flag)
                                        {
                                            WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ(顔ID:{bean.FaceId})の削除が失敗しました。");
                                            // 削除失敗しても、Tool_csvのUserIDをクリア
                                            this.UpdateUserId(bean, No, "");
                                        }
                                        else
                                        {
                                            // # 287 対応　削除成功のメッセージを追加
                                            WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの削除が成功しました。(Atlas Ip:{AtlasIp},KeyID:{bean.UserIds[No - 1]},顔ID:{bean.FaceId})");
                                            this.UpdateUserId(bean, No, "");
                                        }
                                    }

                                    this.UpdateUserId(bean, No, json.user.user_id);

                                    // # 273
                                    bean.IsUpdatedSuccess[No - 1] = true;

                                    // No.133 
                                    bean.IsImageDataUpdateSuccess = true;

                                    break;
                                }
                            }
                        }
                    }
                    else
                    {
                        long lSendInfoSizeToCheck = 0;
                        ObservableCollection<FaceAuthDataBean> FaceDatasTempCheck = new ObservableCollection<FaceAuthDataBean>();
                        List<FaceAuthDataBean> FaceDatasTempCheckList = FaceDatasTempCheck.ToList();
                        for (int k = 0; k < Template.Length; k++)
                        {
                            // No.68 base 64から直接ファイルサイズの理論値を計算する方法
                            // No.67 メモリ対策
                            if (Template[k].IsEditSuccess)
                            {
                                if (Template[k].Staff_Image != null)
                                {
                                    lSendInfoSizeToCheck += (long)((double)ImageHelper.BitmapToBase64((BitmapImage)Template[k].Staff_Image).Length * 0.75);
                                }
                            }
                            else
                            {
                                // 2.2.xx対応対策一覧 No.3 登録する顔画像が500kBを超えている場合、顔登録アプリで500kBに縮小して登録する。
                                //lSendInfoSizeToCheck += (long)((double)ImageHelper.BitmapToBase64(ImageHelper.DecryptFile(Template[k].StaffImgPath)).Length * 0.75);
                                lSendInfoSizeToCheck += (long)((double)ImageHelper.DecryptFileToBase64(Template[k].StaffImgPath).Length * 0.75);
                            }

                            if (lSendInfoSizeToCheck < 15 * 1024 * 1024)
                            {
                                FaceDatasTempCheckList.Add(Template[k]);

                                // 15MB未満の最後の総データ
                                if (k == Template.Length - 1)
                                {
                                    string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTempCheckList);
                                    if ("".Equals(response))
                                    {
                                        WriteLogSafe.LogSafe($"[登録者一覧画面] Atlas装置({AtlasIp})への顔データ登録は中断されました。(Size15MB超えたため、顔ID 件数を50件以下にして(最終回)登録)");

                                        // for 疎通処理
                                        pingJudegError = true;
                                        FaceAuthDataBean item = new FaceAuthDataBean()
                                        {
                                            StaffName = "登録時にエラー応答",
                                            OnlyExistAtlas = AtlasIpNoPort,
                                            FigureId = AtlasName,
                                        };
                                        Recordings_Ping.Add(item);

                                        // No.43 登録失敗しても、tool_csvのKeyIDを削除する
                                        FaceDatasToUpdate = FaceDatasToUpdate.Where(itemReturn =>
                                        {
                                            return itemReturn.IsUpdatedSuccess[No - 1] == false;
                                        }).ToList();

                                        foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                                        {
                                            this.UpdateUserId(bean, No, "");
                                        }

                                        return false;
                                    }
                                    var jsonArr = DynamicJson.Parse(response).results;
                                    foreach (FaceAuthDataBean bean in FaceDatasTempCheckList)
                                    {
                                        foreach (var json in jsonArr)
                                        {
                                            if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                                            {
                                                //No.43 再登録成功後のみ、古い顔データを削除する
                                                string UserId_Temp = ReturnUserId(bean, No);
                                                if (UserId_Temp != null && !"".Equals(UserId_Temp))
                                                {
                                                    if (IsDBNew)
                                                    {
                                                        this.UpdateUserId(bean, No, "");
                                                    }
                                                    Boolean Flag = await Api.DelUserByUserID(AtlasIp, Token, DBId, UserId_Temp);
                                                    if (!Flag)
                                                    {
                                                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ(顔ID:{bean.FaceId})の削除が失敗しました。");
                                                        // 削除失敗しても、Tool_csvのUserIDをクリア
                                                        this.UpdateUserId(bean, No, "");
                                                    }
                                                    else
                                                    {
                                                        // # 287 対応　削除成功のメッセージを追加
                                                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの削除が成功しました。(Atlas Ip:{AtlasIp},KeyID:{bean.UserIds[No - 1]},顔ID:{bean.FaceId})");
                                                        this.UpdateUserId(bean, No, "");
                                                    }
                                                }

                                                this.UpdateUserId(bean, No, json.user.user_id);

                                                // # 273
                                                bean.IsUpdatedSuccess[No - 1] = true;

                                                // No.133 
                                                bean.IsImageDataUpdateSuccess = true;

                                                break;
                                            }
                                        }
                                    }
                                }
                                continue;
                            }
                            else
                            {
                                // Size15MB超えたため、顔ID 件数を50件以下にして登録
                                string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTempCheckList);
                                if ("".Equals(response))
                                {
                                    WriteLogSafe.LogSafe($"[登録者一覧画面] Atlas装置({AtlasIp})への顔データ登録は中断されました。(Size15MB超えたため、顔ID 件数を50件以下にして登録)");

                                    // for 疎通処理
                                    pingJudegError = true;
                                    FaceAuthDataBean item = new FaceAuthDataBean()
                                    {
                                        StaffName = "登録時にエラー応答",
                                        OnlyExistAtlas = AtlasIpNoPort,
                                        FigureId = AtlasName,
                                    };
                                    Recordings_Ping.Add(item);

                                    // No.43 登録失敗しても、tool_csvのKeyIDを削除する
                                    FaceDatasToUpdate = FaceDatasToUpdate.Where(itemReturn =>
                                    {
                                        return itemReturn.IsUpdatedSuccess[No - 1] == false;
                                    }).ToList();

                                    foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                                    {
                                        this.UpdateUserId(bean, No, "");
                                    }

                                    return false;
                                }
                                var jsonArr = DynamicJson.Parse(response).results;
                                foreach (FaceAuthDataBean bean in FaceDatasTempCheckList)
                                {
                                    foreach (var json in jsonArr)
                                    {
                                        if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                                        {
                                            //No.43 再登録成功後のみ、古い顔データを削除する
                                            string UserId_Temp = ReturnUserId(bean, No);
                                            if (UserId_Temp != null && !"".Equals(UserId_Temp))
                                            {
                                                if (IsDBNew)
                                                {
                                                    this.UpdateUserId(bean, No, "");
                                                }
                                                Boolean Flag = await Api.DelUserByUserID(AtlasIp, Token, DBId, UserId_Temp);
                                                if (!Flag)
                                                {
                                                    WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ(顔ID:{bean.FaceId})の削除が失敗しました。");
                                                    // 削除失敗しても、Tool_csvのUserIDをクリア
                                                    this.UpdateUserId(bean, No, "");
                                                }
                                                else
                                                {
                                                    // # 287 対応　削除成功のメッセージを追加
                                                    WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの削除が成功しました。(Atlas Ip:{AtlasIp},KeyID:{bean.UserIds[No - 1]},顔ID:{bean.FaceId})");
                                                    this.UpdateUserId(bean, No, "");
                                                }
                                            }

                                            this.UpdateUserId(bean, No, json.user.user_id);

                                            // # 273
                                            bean.IsUpdatedSuccess[No - 1] = true;

                                            // No.133 
                                            bean.IsImageDataUpdateSuccess = true;

                                            break;
                                        }
                                    }
                                }
                                FaceDatasTempCheckList.Clear();
                                lSendInfoSizeToCheck = 0;
                                k--;
                            }
                        }
                    }
                }
            }
            // 登録処理 終了


            // ベリファイチェック 開始
            bool VerifyResult = false;

            // ベリファイチェック 対象：削除データ
            foreach (FaceAuthDataBean bean in FaceDatasToDelete)
            {
                string UserId_Temp = ReturnUserId(bean, No);

                List<FaceAuthDataBean> UserListToCheck = new List<FaceAuthDataBean>();

                bool FlagCheck_ByCardId = await Api.GetUserListByCardId(AtlasIp, Token, DBId, AtlasKey, AtlasCount, bean.FaceId, UserListToCheck);

                if (FlagCheck_ByCardId)
                {
                    if (UserListToCheck.Count > 0)
                    {
                        IsNeedMatchErrorShowAfterWrite = true;
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 不整合顔情報が見つかりました(削除)。(Atlas Ip:{AtlasIp},顔ID:{bean.FaceId})");

                        VerifyResult = true;
                        bean.CheckResultForFlag = true;
                    }

                    if (UserListToCheck.Count == 0 && !"".Equals(UserId_Temp))
                    {
                        IsNeedMatchErrorShowAfterWrite = true;
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 不整合顔情報が見つかりました(削除)。(Atlas Ip:{AtlasIp},顔ID:{bean.FaceId})");

                        VerifyResult = true;
                        bean.CheckResultForFlag = true;
                    }
                }
                else
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "ベリファイエラー",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);

                    return false;
                }
            }

            // 登録データ存在する場合のみ、登録データをベリファイチェックを行う

            if (FaceDatasToUpdate.Count() != 0)
            {
                List<FaceAuthDataBean> FaceDatasToUpdateForCheck = FaceDatasToUpdate.Where(item =>
               {
                   return item.IsImageDataUpdateSuccess;
               }).ToList();

                // ベリファイチェック 対象：登録データ
                foreach (FaceAuthDataBean bean in FaceDatasToUpdateForCheck)
                {
                    string UserId_Temp = ReturnUserId(bean, No);

                    List<FaceAuthDataBean> UserListToCheck = new List<FaceAuthDataBean>();

                    // for ベリファイチェック
                    bool FlagCheck = await Api.GetUserListByCardId(AtlasIp, Token, DBId, AtlasKey, AtlasCount, bean.FaceId, UserListToCheck);

                    if (FlagCheck)
                    {
                        if (UserListToCheck.Count != 1)
                        {
                            IsNeedMatchErrorShowAfterWrite = true;
                            WriteLogSafe.LogSafe($"[登録者一覧画面] 不整合顔情報が見つかりました(登録)。(Atlas Ip:{AtlasIp},顔ID:{bean.FaceId})");
                            bean.IsUpdatedSuccess[No - 1] = false;

                            VerifyResult = true;
                            bean.CheckResultForFlag = true;
                        }
                        else
                        {
                            if (!UserId_Temp.Equals(UserListToCheck[0].UserIds[No - 1]))
                            {
                                IsNeedMatchErrorShowAfterWrite = true;
                                WriteLogSafe.LogSafe($"[登録者一覧画面] 不整合顔情報が見つかりました(登録)。(Atlas Ip:{AtlasIp},顔ID:{bean.FaceId})");
                                bean.IsUpdatedSuccess[No - 1] = false;

                                VerifyResult = true;
                                bean.CheckResultForFlag = true;
                            }
                        }
                    }
                    else
                    {
                        // for 疎通処理
                        pingJudegError = true;
                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "ベリファイエラー",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasName,
                        };
                        Recordings_Ping.Add(item);

                        return false;
                    }
                }
            }

            if (VerifyResult)
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "ベリファイエラー",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);

                return false;
            }

            return true;
        }

        public void ReadFromCenterFile(string FilePath)
        {
            try
            {
                List<FaceAuthDataBean> TempList = new List<FaceAuthDataBean>();
                CsvFile Csv = new CsvFile(FilePath);
                List<List<string>> Lines = Csv.Read(0, "Shift_JIS");
                int Count = 0;
                int OriginCount = 0;
                bool ChangeToRecoveryMode = false;
                bool OverMaxFaceCount = false;

                if (!this.IsBackupMode && !this.IsRecoveryMode)
                {
                    int loginCount = this.ViewModel.Recordings.Where(item => { return "1".Equals(item.LoginStatusCode); }).Count();
                    if (loginCount >= 1)
                    {
                        ChangeToRecoveryMode = true;
                    }
                    this.ViewModel.Recordings.Clear();
                    this.DG1.DataContext = "";
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                else
                {
                    OriginCount = this.ViewModel.Recordings.Count();
                    foreach (FaceAuthDataBean bean in this.ViewModel.Recordings)
                    {
                        bean.IsLossed = true;
                    }
                }

                // No.39 センターファイル内容が3行以内になる場合、フォーマット異常と認識
                if (Lines.Count < 3)
                {
                    //No.39 改行コードを入れる
                    System.Windows.MessageBox.Show($"ファイルフォーマットが異常です。" + "\r\n" + "センターＣＳＶファイルを指定してください。", "エラー",
                       MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                // # 289 対応
                string[] Data1 = Lines[0].ToArray();
                string[] Data2 = Lines[1].ToArray();
                string[] Data3 = Lines[2].ToArray();

                if (Data1.Length != 1 || Data2.Length != 1 || Data3.Length != 10)
                {
                    //No.39 改行コードを入れる
                    System.Windows.MessageBox.Show($"ファイルフォーマットが異常です。" + "\r\n" + "センターＣＳＶファイルを指定してください。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }
                if (Data1[0] == "ＣＳＶダウンロード種別" && Data2[0] == "2" && (Data3[0] == "券面番号" && Data3[1] == "カードＩＤ" &&
                    Data3[2] == "管理コード" && Data3[3] == "項目１" && Data3[4] == "項目２" && Data3[5] == "指登録ＩＤ" &&
                    Data3[6] == "指登録状態" && Data3[7] == "認証用閾値" && Data3[8] == "使用開始日" && Data3[9] == "有効期限"))
                {
                    WriteLogSafe.LogSafe("[登録者一覧画面] センターＣＳＶファイル ファイルフォーマット異常なし。");
                }
                else
                {
                    //No.39 改行コードを入れる
                    System.Windows.MessageBox.Show($"ファイルフォーマットが異常です。" + "\r\n" + "センターＣＳＶファイルを指定してください。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                foreach (List<string> line in Lines)
                {
                    string[] Values = line.ToArray();
                    if (Values.Length < 10)
                    {
                        continue;
                    }
                    if (ViewModel.CheckBytes(Values[0], 32) || ViewModel.CheckBytes(Values[1], 32) || ViewModel.CheckBytes(Values[2], 16)
                        || ViewModel.CheckBytes(Values[3], 50) || ViewModel.CheckBytes(Values[4], 50) || ViewModel.CheckBytes(Values[5], 4)
                        || ViewModel.CheckBytes(Values[6], 1) || ViewModel.CheckBytes(Values[7], 4) || ViewModel.CheckBytes(Values[8], 10)
                        || ViewModel.CheckBytes(Values[9], 10))
                    {
                        continue;
                    }
                    FaceAuthDataBean FaceItem = new FaceAuthDataBean()
                    {
                        TicketId = Values[0],
                        FaceId = Values[1],
                        ManageId = Values[2],
                        StaffName = Values[3],
                        StaffNameKN = Values[4],
                        FigureId = Values[5],
                        FigureStatus = Values[6],
                        Thresholds = Values[7],
                        StartDate = Values[8],
                        ValidDate = Values[9],
                        HasFilePath = "",
                        StaffImgPath = "",
                        StaffImgName = "",
                        Staff_Image = null,
                        UserIds = new string[64],
                        LoginStatus = "無",
                        LoginStatusCode = "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsInserted = false,
                        IsUpdated = false,
                        IsDeleted = false,
                        IsUpdatedSuccess = new bool[64],
                        OnlyExistType = "",
                        OnlyExistAtlas = "",
                        // No.68
                        IsImageDataUpdateSuccess = false
                    };

                    // # 273 対応
                    for (int i = 0; i < FaceItem.IsUpdatedSuccess.Length; i++)
                    {
                        FaceItem.IsUpdatedSuccess[i] = false;
                    }

                    if (!IsBackupMode && !IsRecoveryMode)
                    {
                        Count++;
                        if (Count > Configure.MaxFaceCount)
                        {
                            OverMaxFaceCount = true;
                            break;
                        }
                        this.ViewModel.Recordings.Add(FaceItem);
                        continue;
                    }

                    FaceAuthDataBean OriginFaceItem = null;
                    foreach (FaceAuthDataBean bean in this.ViewModel.Recordings)
                    {
                        if (FaceItem.FaceId.Equals(bean.FaceId))
                        {
                            OriginFaceItem = bean;
                            break;
                        }
                    }
                    if (OriginFaceItem == null)
                    {
                        FaceItem.IsInserted = true;
                        FaceItem.IsLossed = false;
                        Count++;
                        if (Count + OriginCount > Configure.MaxFaceCount)
                        {
                            OverMaxFaceCount = true;
                            continue;
                        }
                        this.ViewModel.Recordings.Add(FaceItem);
                    }
                    else
                    {
                        OriginFaceItem.TicketId = FaceItem.TicketId;
                        OriginFaceItem.ManageId = FaceItem.ManageId;
                        OriginFaceItem.StaffNameKN = FaceItem.StaffNameKN;
                        OriginFaceItem.FigureId = FaceItem.FigureId;
                        OriginFaceItem.FigureStatus = FaceItem.FigureStatus;
                        OriginFaceItem.Thresholds = FaceItem.Thresholds;
                        OriginFaceItem.StartDate = FaceItem.StartDate;
                        OriginFaceItem.ValidDate = FaceItem.ValidDate;
                        OriginFaceItem.IsLossed = false;
                        if (!FaceItem.StaffName.Equals(OriginFaceItem.StaffName))
                        {
                            OriginFaceItem.StaffName = FaceItem.StaffName;
                            OriginFaceItem.IsUpdated = true;
                        }
                    }
                }

                if (OverMaxFaceCount)
                {
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                    System.Windows.MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }

                if (IsBackupMode || IsRecoveryMode)
                {
                    List<FaceAuthDataBean> FaceDatasLossed = this.ViewModel.Recordings.Where(item => { return item.IsLossed; }).ToList();
                    foreach (FaceAuthDataBean bean in FaceDatasLossed)
                    {
                        bean.StaffImgPath = "";
                        bean.StaffImgName = "";
                        bean.Staff_Image = null;
                        bean.IsDeleted = true;
                        bean.IsLossed = false;
                    }
                }

                if (ChangeToRecoveryMode)
                {
                    this.IsRecoveryMode = true;
                }

                this.DG1.DataContext = this.ViewModel.Recordings;
                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] センターCSVファイルの読出に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show("センターCSVファイルの読出に失敗しました。" + ex.Message, "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private string ReturnUserId(FaceAuthDataBean Bean, int Index)
        {
            string UserId;
            if (Index >= 1 && Index <= 64)
            {
                UserId = Bean.UserIds[Index - 1];
            }
            else
            {
                UserId = "";
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
            return UserId;
        }

        private void UpdateUserId(FaceAuthDataBean Bean, int Index, string UserId)
        {
            if (Index >= 1 && Index <= 64)
            {
                Bean.UserIds[Index - 1] = UserId;
            }
            else
            {
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (this.loading.IsActive)
            {
                e.Handled = true;
            }
        }

        private void Btn_ClearLoginStatus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                int FaceCount = FaceDatas.Count();
                if (FaceCount == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                string msg = "登録者の登録状態をクリアしますか？";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.Yes))
                {
                    foreach (FaceAuthDataBean FaceData in FaceDatas)
                    {
                        FaceData.LoginStatus = "無";
                        FaceData.LoginStatusCode = "0";
                        FaceData.IsUpdated = true;
                    }
                    this.CheckBox_All.IsChecked = false;
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 選択した登録者の登録状態({FaceCount}件)は正常にクリアされました。");
                    System.Windows.MessageBox.Show($"選択した登録者の登録状態({FaceCount}件)は正常にクリアされました", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者登録状態のクリアに失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者登録状態のクリアに失敗しました。{ex.Message}", "情報",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Btn_Search_Click(object sender, RoutedEventArgs e)
        {
            Search SearchPage = new Search(this);
            SearchPage.Show();
            this.btn_search.IsEnabled = false;
        }

        private void Btn_AtlasSetting_Click(object sender, RoutedEventArgs e)
        {
            AtlasSetting AtlasSettingPage = new AtlasSetting();
            AtlasSettingPage.ShowDialog();
        }

        private void Btn_batchEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                if (FaceDatas.Count() == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                EditFloorNum editFloorNum = new EditFloorNum(FaceDatas);
                editFloorNum.Owner = this;
                editFloorNum.ShowDialog();
                if (true == editFloorNum.HasChanged)
                {
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    //WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者({FaceData.FaceId})の顔情報を編集しました。");
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者の行き先階の情報の編集に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者の行き先階の情報の編集に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Btn_logWrite_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                WriteBitmapLog writeBitmapLog = new WriteBitmapLog();
                writeBitmapLog.Owner = this;
                writeBitmapLog.ShowDialog();
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者の顔情報履歴出力画面の起動に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者の顔情報履歴出力画面の起動に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        // for 登録チェック機能
        private void Btn_Check_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string msg = "登録状態をチェックしますか？\n\r\n\r装置台数や登録件数により\n\rかなり時間がかかる場合があります";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.Yes))
                {
                    // ログイン後閉じるボタンを非活性にする
                    var hwnd = new WindowInteropHelper(this).Handle;
                    button1_Click(sender, e, hwnd);
                    
                    // No.51 はい釦を押下したログを残す
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 登録状態をチェックしますか？「はい」押下。");
                    try
                    {
                        loading.IsActive = true;
                        loadingPart.Visibility = Visibility.Visible;
                        MessageChecking.Visibility = Visibility.Visible;

                        this.IsNeedMatchErrorShow = false;

                        // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
                        this.IsNeedMatchErrorShowType3 = false;

                        // No.47 ベリファイ処理開始のログを出力する
                        WriteLogSafe.LogSafe($"[登録者一覧画面] ベリファイ処理が開始しました。");

                        Recordings_Check_Sum.Clear();
                        Recordings_Check_Csv.Clear();
                        Recordings_Check_Atlas.Clear();

                        // for メモリーオーバー防止
                        GC.Collect();

                        //　最新のtool_csvの顔データを読出し
                        FaceAuthViewModel ViewModelTemp = new FaceAuthViewModel();
                        //　No.2
                        ViewModelTemp.ReadViewDelayWithoutImage(this.IsFaceTransmitMode);
                        Recordings_Check_Csv = ViewModelTemp.Recordings_WithoutImage;

                        if (this.AtlasViewModel.Recordings.Count() <= 1)
                        {
                            System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                                MessageBoxButton.OK, MessageBoxImage.Error);

                            loading.IsActive = false;
                            loadingPart.Visibility = Visibility.Hidden;
                            MessageChecking.Visibility = Visibility.Hidden;

                            Recordings_Check_Sum.Clear();
                            Recordings_Check_Csv.Clear();
                            Recordings_Check_Atlas.Clear();

                            // for メモリーオーバー防止
                            GC.Collect();
                            // ログイン画面に戻るボタンを活性にする
                            button2_Click(sender, e, hwnd);
                            return;
                        }

                        var AtlasList = this.AtlasViewModel.Recordings;

                        // 疎通処理追加
                        pingJudegError = false;
                        bool runContinue = true;

                        Recordings_Ping.Clear();

                        List<Task<bool>> task_ping = new List<Task<bool>>();

                        task_ping.Add(Ping_Retry());

                        Task.Run(() => { Task.WaitAll(task_ping.ToArray()); }).ContinueWith(t1 =>
                        {
                            this.Invoke(new Action(() =>
                            {
                                if (pingJudegError)
                                {
                                    // No.102 登録チェック時に、1台も疎通に成功してない場合は疎通エラー画面に文言とボタン修正
                                    int errorType = 1;

                                    // No.128 リトライ処理後が正しくない問題を修正
                                    PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasList.Count, errorType, AtlasListNoError);
                                    pingJudge.Owner = this;
                                    pingJudge.ShowDialog();

                                    runContinue = pingJudge.HasRunContinue;

                                    if (!runContinue)
                                    {

                                        Recordings_Check_Sum.Clear();
                                        Recordings_Check_Csv.Clear();
                                        Recordings_Check_Atlas.Clear();

                                        // for メモリーオーバー防止
                                        GC.Collect();

                                        loading.IsActive = false;
                                        loadingPart.Visibility = Visibility.Hidden;
                                        MessageChecking.Visibility = Visibility.Hidden;

                                        // ログイン画面に戻るボタンを活性にする
                                        button2_Click(sender, e, hwnd);

                                        return;
                                    }
                                }

                                pingJudegError = false;
                                Recordings_Ping.Clear();

                                List<Task<bool>> tasks = new List<Task<bool>>();

                                // No.84 確認のとれた装置のみ登録チェックを行います
                                for (int i = 0; i < AtlasListNoError.Count; i++)
                                {
                                    tasks.Add(CheckData(AtlasListNoError[i].Server_Name, AtlasListNoError[i].Server_Ip, int.Parse(AtlasListNoError[i].Server_Name)));
                                }
                                Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
                                {
                                    this.Invoke(new Action(() =>
                                    {
                                        // 不整合の顔情報の種類①
                                        foreach (FaceAuthDataBean Bean_Csv in Recordings_Check_Csv)
                                        {
                                            if ("CSVと装置データ不一致".Equals(Bean_Csv.OnlyExistType))
                                            {
                                                // No.62 アプリ側の画像が無い場合「画像なし」と表示するように修正
                                                Bean_Csv.StaffImgPath = Path.Combine(Configure.FaceDataPath, Bean_Csv.FaceId + @".jpg");
                                                
                                                Recordings_Check_Sum.Add(Bean_Csv);
                                            }
                                        }

                                        // 不具合一覧　No.18　同じCARDID（顔ID）の顔情報が複数表示されている
                                        // 不整合の顔情報の種類②
                                        foreach (FaceAuthDataBean Bean_Atlas in Recordings_Check_Atlas.Distinct(new Compare()).OrderBy(item => item.FaceId))
                                        {
                                            Bean_Atlas.StaffName = "未登録";
                                            Bean_Atlas.StaffImgName = "画像なし";
                                            Bean_Atlas.IsDeleted = true;
                                            Recordings_Check_Sum.Add(Bean_Atlas);
                                        }

                                        // 不具合一覧 No.9　登録チェック結果が表示されたら、くるくる と 情報取得中です ポップアップを消します。
                                        loading.IsActive = false;
                                        loadingPart.Visibility = Visibility.Hidden;
                                        MessageChecking.Visibility = Visibility.Hidden;

                                        //　疎通処理追加
                                        if (pingJudegError && Recordings_Ping.Count > 0)
                                        {
                                            int errorType = 3;
                                            PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasListNoError.Count + 1, errorType, AtlasListNoError);
                                            pingJudge.Owner = this;
                                            pingJudge.ShowDialog();

                                            Recordings_Check_Sum.Clear();
                                            Recordings_Check_Csv.Clear();
                                            Recordings_Check_Atlas.Clear();

                                            // for メモリーオーバー防止
                                            GC.Collect();
                                            
                                            // ログイン画面に戻るボタンを活性にする
                                            button2_Click(sender, e, hwnd);
                                            return;
                                        }

                                        Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>(Recordings_Check_Sum.OrderBy(item => item.FaceId));

                                        // No.47 ベリファイ処理終了のログを出力する
                                        WriteLogSafe.LogSafe($"[登録者一覧画面] ベリファイ処理が終了しました。不整合は{Recordings_Check_Sum.Count}件です。");

                                        if (Recordings_Check_Sum.Count == 0)
                                        {
                                            System.Windows.MessageBox.Show("登録状態に問題はありませんでした。", "情報",
                                            MessageBoxButton.OK, MessageBoxImage.Information);
                                        }
                                        else
                                        {
                                            IsNeedMatchErrorShow = true;
                                            // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
                                            this.IsNeedMatchErrorShowType3 = true;

                                            foreach (FaceAuthDataBean beanTable in Recordings_Check_Sum)
                                            {
                                                WriteLogSafe.LogSafe($"[登録者一覧画面] 不整合顔情報が見つかりました。顔ID:{beanTable.FaceId})");
                                            }

                                            bool HasChangedOnCheckPage = false;
                                            // No.84 確認のとれた装置のみ登録チェックを行います
                                            // No.121 以下のメッセージボックスを表示しない
                                            FaceCheckLIstPage faceCheck = new FaceCheckLIstPage(Recordings_Check_Sum, AtlasListNoError);
                                            faceCheck.Owner = this;
                                            faceCheck.ShowDialog();

                                            HasChangedOnCheckPage = faceCheck.HasChanged;

                                            if (HasChangedOnCheckPage)
                                            {
                                                IsNeedMatchErrorShow = false;
                                                // No.123 「登録チェック未実施」と判定する条件 ③不整合を検出したが、その後再登録（不整合の解消）をしていない。 文言内容を変更
                                                this.IsNeedMatchErrorShowType3 = false;
                                                // No.69 バックアップ判断フラグ
                                                IsNeedBackupErrorShow = true;

                                                loading.IsActive = true;
                                                loadingPart.Visibility = Visibility.Visible;

                                                // メモリーオーバー問題を防止
                                                this.ViewModel.Recordings.Clear();
                                                this.DG1.DataContext = "";

                                                // for メモリーオーバー防止
                                                GC.Collect();

                                                this.ViewModel.ReadViewDelay(this.IsFaceTransmitMode);
                                                this.DG1.DataContext = this.ViewModel.Recordings;
                                                SetRecordsCount();
                                                if (this.IsFaceTransmitMode == 2)
                                                {
                                                    this.DG1.Columns[5].Visibility = Visibility.Visible;
                                                    this.btn_edit_batch.Visibility = Visibility.Visible;
                                                }
                                                WriteLogSafe.LogSafe($"[登録者一覧画面] 登録者一覧画面を表示しました。");
                                                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                                                loading.IsActive = false;
                                                loadingPart.Visibility = Visibility.Hidden;

                                                Recordings_Check_Sum.Clear();
                                                Recordings_Check_Csv.Clear();
                                                Recordings_Check_Atlas.Clear();

                                                // for メモリーオーバー防止
                                                GC.Collect();
                                            }
                                        }

                                        loading.IsActive = false;
                                        loadingPart.Visibility = Visibility.Hidden;
                                        MessageChecking.Visibility = Visibility.Hidden;

                                        Recordings_Check_Sum.Clear();
                                        Recordings_Check_Csv.Clear();
                                        Recordings_Check_Atlas.Clear();

                                        // for メモリーオーバー防止
                                        GC.Collect();

                                        // ログイン画面に戻るボタンを活性にする
                                        button2_Click(sender, e, hwnd);
                                    }));
                                });
                            }));
                        });
                    }
                    catch (Exception ex)
                    {
                        WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの取得に失敗しました。{ex.Message}");
                        System.Windows.MessageBox.Show($"顔データの取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        MessageChecking.Visibility = Visibility.Hidden;

                        Recordings_Check_Sum.Clear();
                        Recordings_Check_Csv.Clear();
                        Recordings_Check_Atlas.Clear();

                        // for メモリーオーバー防止
                        GC.Collect();

                        // ログイン画面に戻るボタンを活性にする
                        button2_Click(sender, e, hwnd);
                    }
                }
                else
                {
                    // No.51 いいえ釦を押下したログを残す
                    WriteLogSafe.LogSafe($"[登録者一覧画面] 登録状態をチェックしますか？「いいえ」押下。");
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 顔認証データ登録チェック画面の起動に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"顔認証データ登録チェック画面の起動に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                MessageChecking.Visibility = Visibility.Hidden;

                Recordings_Check_Sum.Clear();
                Recordings_Check_Csv.Clear();
                Recordings_Check_Atlas.Clear();

                // for メモリーオーバー防止
                GC.Collect();

                // ログイン画面に戻るボタンを活性にする
                var hwnd = new WindowInteropHelper(this).Handle;
                button2_Click(sender, e, hwnd);
            }
        }

        // for 登録チェック機能
        private async Task<bool> CheckData(string AtlasName, string AtlasIp, int No)
        {
            // for 疎通処理
            string AtlasIpNoPort = "";
            string[] AtlasIpInfo = AtlasIp.Split(':');
            AtlasIpNoPort = AtlasIpInfo[0];

            int AtlasCount = this.AtlasViewModel.Recordings.Count();
            int AtlasKey = No;

            ObservableCollection<FaceAuthDataBean> Recordings_Check_Atlas_One = new ObservableCollection<FaceAuthDataBean>();

            AtlasApi Api = new AtlasApi();
            string Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);

                WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの取得に失敗しました。AtlasIp:{AtlasIp}");
                return false;
            }
            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
            if ("".Equals(DBId))
            {
                DBId = await Api.NewDBByName(AtlasIp, Token, Configure.LibraryName, LibraryDesp);
                if ("".Equals(DBId))
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);
                    return false;
                }
            }

            List<FaceAuthDataBean> UserList = new List<FaceAuthDataBean>();

            bool FlagCheck = await Api.GetUserList(AtlasIp, Token, DBId, AtlasKey, AtlasCount, UserList);

            if (FlagCheck)
            {
                foreach (var user in UserList)
                {
                    Recordings_Check_Atlas_One.Add(user);
                }
            }
            else
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);
                return false;
            }

            Recordings_Check_Atlas_One = new ObservableCollection<FaceAuthDataBean>(Recordings_Check_Atlas_One.OrderBy(item => item.FaceId));

            // 不整合の顔情報の種類②　チェック
            foreach (FaceAuthDataBean bean_atlas in Recordings_Check_Atlas_One)
            {
                bool OnlyAtlasExist = true;

                foreach (FaceAuthDataBean bean_csv in this.Recordings_Check_Csv)
                {
                    if (bean_csv.FaceId.Equals(bean_atlas.FaceId))
                    {
                        OnlyAtlasExist = false;
                        break;
                    }
                }

                if (OnlyAtlasExist)
                {
                    bean_atlas.OnlyExistType = "装置のみ存在する";
                    Recordings_Check_Atlas.Add(bean_atlas);
                }
            }

            // 不整合の顔情報の種類①　チェック
            foreach (FaceAuthDataBean bean_csv in this.Recordings_Check_Csv)
            {
                string UserId_Csv = ReturnUserId(bean_csv, No);

                List<FaceAuthDataBean> UserListToCheck = new List<FaceAuthDataBean>();

                // for ベリファイチェック
                bool FlagCheck_ByCardId = await Api.GetUserListByCardId(AtlasIp, Token, DBId, AtlasKey, AtlasCount, bean_csv.FaceId, UserListToCheck);

                if (FlagCheck_ByCardId)
                {
                    //　Tool_csvに顔IDがある、Atlasに該当顔IDが一つ以上の場合、UseriIDチェック必要なし、不一致と認識
                    if (UserListToCheck.Count > 1)
                    {
                        bean_csv.OnlyExistType = "CSVと装置データ不一致";
                    }
                    else if (UserListToCheck.Count == 0)
                    {
                        //  Tool_csvに顔IDがある、Atlasに該当顔IDがない場合、Tool_csvのUserIDチェックが必要、一つUserIDがあれば、不一致と認識
                        bool FlagUserId = false;
                        for (int i = 0; i < 64; i++)
                        {
                            if (bean_csv.UserIds[i] != null && bean_csv.UserIds[i] != "")
                            {
                                FlagUserId = true;
                                break;
                            }
                        }

                        if (FlagUserId)
                        {
                            bean_csv.OnlyExistType = "CSVと装置データ不一致";
                        }
                    }
                    else
                    {
                        //　Atlasに該当顔IDが一つのみ存在する場合、UseriID一致するかをチェック
                        if (!UserId_Csv.Equals(UserListToCheck[0].UserIds[No - 1]))
                        {
                            bean_csv.OnlyExistType = "CSVと装置データ不一致";
                        }
                    }
                }
                else
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "ベリファイエラー",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);

                    return false;
                }
            }

            return true;
        }

        public class Compare : IEqualityComparer<FaceAuthDataBean>
        {
            public bool Equals(FaceAuthDataBean x, FaceAuthDataBean y)
            {
                return x.FaceId == y.FaceId;
            }

            public int GetHashCode(FaceAuthDataBean obj)
            {
                return obj.FaceId.GetHashCode();
            }
        }

        // No.67 メモリ対策
        private void scrollViewer_ScrollChanged(object sender, System.Windows.Controls.ScrollChangedEventArgs e)
        {
            // 滚动条偏移量
            var offsetTop = e.VerticalOffset;
            // 滚动条总体高度
            var totalHeight = e.ExtentHeight;
            // 滚动条可视高度
            var viewHeight = e.ViewportHeight;

            // No.99 画面サイズを変えると、マウスアイコンが「⇔」のままとなりマウスが効かなくなることを修正
            if (this.ViewModel.Recordings.Count == 0)
            {
                return;
            }

            // 初期化の場合、処理を終了
            if (totalHeight != this.ViewModel.Recordings.Count)
            {
                return;
            }

            // No.129　登録チェックで再登録した後、画像データがない問題を対応、下記の内容が注釈すれば、No.129が自動的に対応されます。
            // No.99 画面サイズを変更しないように対応
            // No.99 画面サイズを変えると、マウスアイコンが「⇔」のままとなりマウスが効かなくなることを修正
            //if (scrollOffsetBefore == offsetTop && faceDataCount == this.ViewModel.Recordings.Count)
            //{
            //    return;
            //}
            // No.99 画面サイズを変えると、マウスアイコンが「⇔」のままとなりマウスが効かなくなることを修正
            //scrollOffsetBefore = offsetTop;
            //faceDataCount = this.ViewModel.Recordings.Count;

            int offsetTopShow = (int)offsetTop + 1;

            // hitachiadmin権限の場合、スクロールでメモリ保持しない
            if (IsReadFromAtlasRun)
            {
                return;
            }

            this.Invoke(new Action(() =>
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                DoEvents();
            }));

            //　スクロールバーの位置により、画像データを読込/クリア
            foreach (FaceAuthDataBean Bean in this.ViewModel.Recordings)
            {
                if (Bean.IsEditSuccess == true || Bean.IsDeleted == true || Bean.IsInserted == true)
                {
                    continue;
                }

                if (Bean.Idx < offsetTopShow || Bean.Idx > offsetTopShow + (int)viewHeight)
                {
                    // スクロール外には、更新、削除データ以外の画像データをクリア
                    Bean.StaffImgName = "";
                    Bean.Staff_Image = null;
                }
                else
                {
                    // スクロール内には、画像データなしの登録者の画像データを再度読込
                    if (Bean.Staff_Image == null)
                    {
                        // 2.2.xx対応対策一覧 No.9 tool_csvに画像ファイルのパスの記載がないとき（センターCSVファイル読み込み直後など顔画像未登録時）・・・「空欄」
                        if ("".Equals(Bean.HasFilePath) || Bean.HasFilePath == null)
                        {
                            Bean.StaffImgName = @"";
                        }
                        else
                        {
                            BitmapImage image = ImageHelper.DecryptFile(Bean.StaffImgPath);
                            if (image != null)
                            {
                                // No.100 tool_csvに画像ファイルのパスの記載があり画像ファイルの読み込みに成功したとき（顔画像登録時）・・・画像を表示
                                Bean.StaffImgName = Bean.FaceId + @".jpg";
                                Bean.Staff_Image = image;
                            }
                            else
                            {
                                // No.100 tool_csvに画像ファイルのパスの記載があるが画像ファイルの読み込みに失敗したとき（ファイルがない場合含み）・・・「取得失敗」
                                Bean.StaffImgName = @"取得失敗";
                            }
                        }
                    }
                }
            }
            GC.Collect();
            // No.111 ダブルクリックをした後にマウスホイールでスクロール操作をすると、登録アプリが落ちることを修正
            this.DG1.CommitEdit();
            this.DG1.CommitEdit();
            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();

            // DisconnectedItem問題を解決
            if (Math.Abs(scrolloffset - ((int)offsetTop + 1)) != 1)
            {
                this.DG1.Focusable = true;
                this.DG1.Focus();
            }

            scrolloffset = (int)offsetTop + 1;

            this.Invoke(new Action(() =>
            {
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }));

            // No.67 No.105（Key動作無効）を対応する為に、一旦保留
            this.DG1.UpdateLayout();
            this.DG1.Focusable = false;
            this.DG1.Focusable = true;
            this.DG1.Focus();

            FrameworkElement row = null;

            if ((int)offsetTop <= preOffsetTop)
            {
                row = this.DG1.ItemContainerGenerator.ContainerFromIndex((int)offsetTop) as FrameworkElement;
            }
            else if ((int)offsetTop > preOffsetTop)
            {
                row = this.DG1.ItemContainerGenerator.ContainerFromIndex((int)offsetTop + (int)viewHeight - 1) as FrameworkElement;
            }
            if (row != null)
            {
                row.Focusable = false;
                row.Focusable = true;
                row.Focus();
                // 2.2.xx対応対策一覧　No.6
                SendKeys.SendWait("{RIGHT}");
            }
            preOffsetTop = (int)offsetTop;
        }

        // No.88 hitachiadmin権限でログインした場合のみ、登録者一覧画面に「顔情報出力」釦を追加する
        private void Btn_FacedataOutput_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog Dlg = new Microsoft.Win32.SaveFileDialog
            {
                FileName = "Tool_backup",
                DefaultExt = ".csv",
                Filter = "CSV documents (.csv)|*.csv"
            };
            Nullable<bool> result = Dlg.ShowDialog();
            if (result == true)
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                bool res = ToCSV(Dlg.FileName);

                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;

                if (res == true)
                {
                    System.Windows.MessageBox.Show("顔情報出力が成功しました。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    System.Windows.MessageBox.Show("顔情報出力が失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        public bool ToCSV(string FilePath)
        {
            try
            {
                if (File.Exists(FilePath))
                {
                    File.Delete(FilePath);
                }

                if (!Directory.Exists(Configure.FaceDataPath))
                {
                    Directory.CreateDirectory(Configure.FaceDataPath);
                }

                using (FileStream _stream = new FileStream(FilePath, FileMode.Create, FileAccess.ReadWrite))
                {
                    StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);
                    foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                    {
                        string sline;
                        // No.107 Atlas読み出しを行ったところ、すべての画像ファイルが表示されず、一部の画像しか表示されない対応
                        if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath))
                        {
                            // No.107 Atlas読み出しを行ったところ、すべての画像ファイルが表示されず、一部の画像しか表示されない対応
                            if (IsReadFromAtlasRun)
                            {
                                ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                            }
                        }
                        if (this.IsFaceTransmitMode == 2)
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + beanTable.FloorNum + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        else
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        _writer.WriteLine(sline);
                    }
                    _writer.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] CSVファイルへの出力が失敗しました。{ex.Message}");
                return false;
            }
        }

        // No.105「↑/↓」Key動作や「Enter」「Tab」「PgUp/PgDn」Key動作の抑制する
        private void Grid_Keydown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            //bool isUp = e.Key == Key.Up;
            //bool isDown = e.Key == Key.Down;
            //bool isEnter = e.Key == Key.Enter;
            //bool isPageUp = e.Key == Key.PageUp;
            //bool isPageDown = e.Key == Key.PageDown;
            //bool isTab = e.Key == Key.Tab;
            //if (isUp || isDown || isEnter || isPageUp || isPageDown || isTab)
            //{
            //    e.Handled = true;
            //}
            //else
            //{
            //    e.Handled = false;
            //}
        }
        
        private void DataGrid_Documents_RequestBringIntoView(object sender, RequestBringIntoViewEventArgs e)
        {
            // Np.149 検索をしても、対象の顔IDにスクロールしないことを修正
            if (SearchFlag == false)
            {
                e.Handled = true;
            }
            else
            {
                e.Handled = false;
            }
        }
    }
}
