﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Drawing;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// EditFaceAuthPage.xaml の相互作用ロジック
    /// </summary>
    public partial class EditFaceAuthPage : Window
    {
        public FaceAuthDataBean FaceData { get; set; }
        private string SelectImage { get; set; }
        public bool HasChanged { get; set; }
        private string AtlasIp { get; set; }
        private string StaffName { get; set; }

        private int IsFaceTransmitMode = 0;

        private string savePath500kb = "";
        public EditFaceAuthPage()
        {
            InitializeComponent();
            this.DataContext = this.FaceData;
        }

        public EditFaceAuthPage(FaceAuthDataBean data, string atlasIp, int IsFaceTransmitMode = 0) : this()
        {
            this.IsFaceTransmitMode = IsFaceTransmitMode;
            this.FaceData = data;

            // No.67 メモリ対策
            if (data.IsEditSuccess == false)
            {
                // 該当登録者の画像データが編集しなければ、もとサイズの画像データを読込。
                BitmapImage image = ImageHelper.DecryptFileOriginalSize(data.StaffImgPath);
                if (image != null)
                {
                    this.face_image.Source = image;
                }                
            }
            else if(data.Staff_Image != null)
            {
                this.face_image.Source = data.Staff_Image;
            }

            this.StaffName = "";
            this.AtlasIp = atlasIp;
            this.SelectImage = "";
            this.face_image_name.Text = this.FaceData.FaceId + @".jpg";
            this.HasChanged = false;
            if (IsFaceTransmitMode !=0)
            {
                this.txt_staff_name.IsReadOnly = false;
            }
            if(IsFaceTransmitMode == 2){
                this.txt_staff_name.IsReadOnly = false;
                this.txt_floor_num.IsReadOnly = false;
                this.txt_floor_num.Visibility = Visibility.Visible;
                this.label_floor_num.Visibility = Visibility.Visible;
            }
            WriteLogSafe.LogSafe($"[顔情報登録画面] 顔情報登録画面を開きました。");
        }

        private void Btn_File_Click(object sender, RoutedEventArgs e)
        {
            var jpgFileName = "";
            OpenFileDialog openFile = new OpenFileDialog
            {
                Multiselect = false,
                Filter = "画像ファイル(*.jpg)|*.jpg"
            };
            DialogResult result = openFile.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.Cancel)
            {
                return;
            }
            var imageSize = ImageHelper.GetImageSize(openFile.FileName);
            if (imageSize > 5242880)
            {
                System.Windows.MessageBox.Show("画像ファイルのサイズは上限を超えています。", "エラー",
                    System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                return;
            }
            if (imageSize > 512000)
            {
                // 一時ファイルのパスをタイムスタンプ別から設定する
                DateTime dt = DateTime.Now;
                savePath500kb = Configure.FaceDataPath + @"\" + this.FaceData.FaceId + @"_temp_" + string.Format("{0:yyyyMMdd_HHmmss}", dt) + @".jpg";

                // ローカル画像を取得する
                var image = Image.FromFile(openFile.FileName);
                // 画像を500KBに縮小する
                var scaled = ImageHelper.ScaleDownToKb(image, 500, 80);
                // 縮小した画像を一時ファイルとして、ローカルフォルダに保存する
                ImageHelper.SaveJpeg(scaled, savePath500kb, 80);
                // 一時ファイルを隠しファイルに設定する
                File.SetAttributes(savePath500kb, FileAttributes.Hidden);
                jpgFileName = savePath500kb;
            }
            else
            {
                jpgFileName = openFile.FileName;
            }
            // No.67 メモリ対策
            var staffImgSource = ImageHelper.GetBitmapImageOriginalSize(jpgFileName);
            if (staffImgSource == null)
            {
                System.Windows.MessageBox.Show("画像ファイルに問題があります。正しいJPG画像ファイルを選択してください。", "エラー",
                    System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Error);
                return;
            }
            
            this.SelectImage = jpgFileName;
            this.face_image.Source = staffImgSource;
            WriteLogSafe.LogSafe($"[顔情報登録画面] 画像ファイル({this.SelectImage})を選択しました。");
        }

        private void TextBox_staff_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool isComma = e.Key == Key.OemComma;

            if (isComma)
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void Btn_Login_Click(object sender, RoutedEventArgs e)
        {
            if (this.IsFaceTransmitMode == 2)
            {
                int aout = 0;
                if (int.TryParse(this.txt_floor_num.Text, out aout))
                {
                    if (this.txt_floor_num.Text.StartsWith("0"))
                    {
                        this.txt_floor_num.Text = aout.ToString();
                    }
                }

                if (this.txt_floor_num.Text == this.FaceData.FloorNum && this.txt_staff_name.Text == this.FaceData.StaffName && this.SelectImage == "")
                {
                    System.Windows.MessageBox.Show("画像、行き先階、氏名の情報は変更されていません。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }
            else if(this.IsFaceTransmitMode == 1)
            {
                if (this.txt_staff_name.Text == this.FaceData.StaffName && this.SelectImage == "")
                {
                    System.Windows.MessageBox.Show("画像または氏名は変更されていません。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }
            else
            {
                if (this.SelectImage == "")
                {
                    System.Windows.MessageBox.Show("画像は変更されていません。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
            }

            

            if (this.IsFaceTransmitMode == 1)
            {
                if (this.txt_staff_name.Text != this.FaceData.StaffName)
                {
                    if (this.txt_staff_name.Text.IndexOf(',') != -1)
                    {
                        string msgComma = $"登録者の名前情報にカンマがありますので、更新できません。";
                        MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                        this.txt_staff_name.Text = this.FaceData.StaffName;
                    }
                    else
                    {
                        string msg = $"登録者の名前情報を({this.FaceData.StaffName})から({this.txt_staff_name.Text})に変更しますか？";
                        MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                                  MessageBoxButton.YesNo, MessageBoxImage.Information);
                        if (messageBoxResult.Equals(MessageBoxResult.No))
                        {
                            this.txt_staff_name.Text = this.FaceData.StaffName;
                        }
                        else
                        {
                            WriteLogSafe.LogSafe($"[顔情報登録画面] 選択した登録者の名前情報は({this.FaceData.StaffName})から({this.txt_staff_name.Text})に変更されました。");
                            this.FaceData.StaffName = this.txt_staff_name.Text;
                            this.FaceData.IsSelected = true;
                            this.HasChanged = true;
                        }
                    }
                }  
            }

            if (this.IsFaceTransmitMode == 2)
            {
                if (this.txt_staff_name.Text != this.FaceData.StaffName)
                {
                    if (this.txt_staff_name.Text.IndexOf(',') != -1)
                    {
                        string msgComma = $"登録者の名前情報にカンマがありますので、更新できません。";
                        MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                        this.txt_staff_name.Text = this.FaceData.StaffName;
                    }
                    else
                    {
                        string msg = $"登録者の名前情報を({this.FaceData.StaffName})から({this.txt_staff_name.Text})に変更しますか？";
                        MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                                  MessageBoxButton.YesNo, MessageBoxImage.Information);
                        if (messageBoxResult.Equals(MessageBoxResult.No))
                        {
                            this.txt_staff_name.Text = this.FaceData.StaffName;
                        }
                        else
                        {
                            WriteLogSafe.LogSafe($"[顔情報登録画面] 選択した登録者の名前情報は({this.FaceData.StaffName})から({this.txt_staff_name.Text})に変更されました。");
                            this.FaceData.StaffName = this.txt_staff_name.Text;
                            this.FaceData.IsSelected = true;
                            this.HasChanged = true;
                        }
                    }
                }

                if (this.txt_floor_num.Text != this.FaceData.FloorNum)
                {
                    string msg = $"登録者の行き先階の情報を({this.FaceData.FloorNum})から({this.txt_floor_num.Text})に変更しますか？";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                              MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.No))
                    {
                        this.txt_floor_num.Text = this.FaceData.FloorNum;
                    }
                    else
                    {
                        int a = 0;
                        if (int.TryParse(this.txt_floor_num.Text, out a))
                        {
                            if (int.Parse(this.txt_floor_num.Text) > 24 || int.Parse(this.txt_floor_num.Text) < 1)
                            {
                                System.Windows.MessageBox.Show("入力は数値(1-24)でなければなりません。", "情報",
                                        MessageBoxButton.OK, MessageBoxImage.Information);
                                this.txt_floor_num.Text = this.FaceData.FloorNum;
                            }
                            WriteLogSafe.LogSafe($"[顔情報登録画面] 選択した登録者の行き先階の情報は({this.FaceData.FloorNum})から({this.txt_floor_num.Text})に変更されました。");
                            this.FaceData.FloorNum = this.txt_floor_num.Text;
                            this.FaceData.IsSelected = true;
                            this.HasChanged = true;
                        }
                        else
                        {
                            System.Windows.MessageBox.Show($"入力は数値(1-24)でなければなりません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                            this.txt_floor_num.Text = this.FaceData.FloorNum;
                        }
                    }
                }
                
            }

            if (this.SelectImage != "")
            {
                string ImageName = this.FaceData.FaceId + @".jpg";
                this.FaceData.Staff_Image = this.face_image.Source;
                this.FaceData.StaffImgName = ImageName;
                this.FaceData.IsSelected = true;
                // No.67 メモリ対策
                this.FaceData.IsEditSuccess = true;
                this.HasChanged = true;
                // 一時ファイルを削除する
                try
                {
                    if (File.Exists(savePath500kb))
                    {
                        File.Delete(savePath500kb);
                    }
                }
                catch (Exception ex)
                {
                    WriteLogSafe.LogSafe($"[顔情報登録画面] 縮小した画像{savePath500kb}の削除に失敗しました。{ex.Message}");
                }
                WriteLogSafe.LogSafe($"[顔情報登録画面] 顔情報を登録しました。");
                System.Windows.MessageBox.Show("顔情報を登録しました。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
            }

            this.Close();
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            WriteLogSafe.LogSafe($"[顔情報登録画面] 顔情報登録画面を閉じました。");
            this.Close();
        }

        private void Btn_Image_Click(object sender, RoutedEventArgs e)
        {
            if (this.AtlasIp == "")
            {
                System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            FaceImageListPage FaceImageListPage = new FaceImageListPage(this.AtlasIp)
            {
                SendMsg = Recevie
            };
            FaceImageListPage.Owner = this;
            FaceImageListPage.ShowDialog();
        }

        public void Recevie(FaceAuthDataBean value)
        {
            if (value.StaffImgName != null && !"".Equals(value.StaffImgName))
            {
                this.SelectImage = value.StaffImgName;
                this.face_image.Source = value.Staff_Image;
                WriteLogSafe.LogSafe($"[顔情報登録画面] 撮影画像(Atlas: {this.AtlasIp})を選択しました。");
            }
        }

        private void txt_floor_num_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool isNumber = e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9;
            bool isBack = e.Key == Key.Back;
            bool isTab = e.Key == Key.Tab;
            bool isEnter = e.Key == Key.Enter;
            bool isLeftOrRight = e.Key == Key.Left || e.Key == Key.Right;
            bool isKeyupOrKeydown = e.Key == Key.Up || e.Key == Key.Down;
            bool isCtrlA = e.Key == Key.A && e.KeyboardDevice.Modifiers == ModifierKeys.Control;

            if (isNumber || isCtrlA || isBack || isTab || isLeftOrRight || isKeyupOrKeydown || isEnter)
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }
    }
}
