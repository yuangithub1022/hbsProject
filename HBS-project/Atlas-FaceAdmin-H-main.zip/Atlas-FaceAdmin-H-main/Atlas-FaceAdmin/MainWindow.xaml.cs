﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media.Imaging;
using System.Windows.Threading;
using MahApps.Metro.Controls;
using Microsoft.Win32;
using System.Collections;
using System.Windows.Media;
using System.IO.Compression;
using System.Security.AccessControl;
using System.Threading;
using System.Runtime.InteropServices;
using System.Windows.Interop;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        public enum SystemMenuClose
        {
            Enabled,
            Disabled
        }

        private const int SC_CLOSE = 0xF060;

        private const int MF_GRAYED = 0x0001;

        [DllImport("user32.dll")]
        private static extern IntPtr GetSystemMenu(IntPtr hWnd, bool bRevert);

        [DllImport("user32.dll")]
        private static extern int EnableMenuItem(IntPtr hMenu, int wIDEnableItem, int wEnable);

        [DllImport("User32.Dll")]
        public static extern int GetMenuItemCount(IntPtr hMenu);

        IntPtr hMenu;

        public void handlingCloseButton(SystemMenuClose HandleSystemMenuClose, IntPtr hwnd)
        {
            switch (HandleSystemMenuClose)
            {
                case SystemMenuClose.Disabled:

                    hMenu = GetSystemMenu(hwnd, false);

                    if (hMenu != IntPtr.Zero)
                    {

                        EnableMenuItem(hMenu, SC_CLOSE, MF_GRAYED);

                        int n = GetMenuItemCount(hMenu);
                    }

                    break;

                case SystemMenuClose.Enabled:

                    GetSystemMenu(hwnd, true);

                    EnableMenuItem(IntPtr.Zero, 0xF120, 1024);

                    break;


                default:

                    break;
            }
        }

        private void button1_Click(object sender, EventArgs e, IntPtr hwnd)
        {
            handlingCloseButton(SystemMenuClose.Disabled, hwnd);
        }

        private void button2_Click(object sender, EventArgs e, IntPtr hwnd)
        {
            handlingCloseButton(SystemMenuClose.Enabled, hwnd);
        }

        private InfoSettingIniFile m_infoSettingIniFile = null;

        private WriteLog m_writeLog = null;
        private WriteToolCsv m_writeToolCsv = null;
        private bool IsLoginByHitachiadmin = false;
        private bool IsNeedMatchErrorShow = true;
        // No.81
        private bool IsIpAddressExist = true;

        private readonly int IsFaceTransmitMode = 0;

        // for 登録チェック機能
        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Csv = new ObservableCollection<FaceAuthDataBean>();
        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Atlas = new ObservableCollection<FaceAuthDataBean>();
        private ObservableCollection<FaceAuthDataBean> Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>();
        // for 疎通処理
        private ObservableCollection<FaceAuthDataBean> Recordings_Ping = new ObservableCollection<FaceAuthDataBean>();

        private ObservableCollection<AtlasServerDataBean> AtlasListNoError = new ObservableCollection<AtlasServerDataBean>();
        private ObservableCollection<FaceAuthDataBean> AtlasDatasCheck = new ObservableCollection<FaceAuthDataBean>();
        public FaceAuthViewModel ViewModel { get; set; }
        public AtlasServerViewModel AtlasViewModel { get; set; }

        private readonly string LibraryDesp = @"01.00.00";

        // for 疎通処理
        private bool pingJudegError = false;

        // for PC復旧
        private string user_id_backup = "";
        private string password_backup = "";
        // 2.2.xx対応対策一覧　No.12 復旧方法選択画面にて「OK」押下時に「face_data_jpg」フォルダが存在するかチェックをします
        private bool jpgCopyFlag = true;
        // for ログイン時に「×」を押下した時 確認のメッセージを出力する
        private bool isCloseByUser = true;


        public MainWindow()
        {
            InitializeComponent();

            // 2.2.xx対応対策一覧　No.8 アプリ起動時に、任意のconfig.iniを選択後、顔登録アプリが最小化される対応
            this.WindowState = WindowState.Normal;

            this.IsFaceTransmitMode = CheckIsFaceTransmitMode();

            // No.101 「すでに起動しています。」のメッセージ表示の後、後のメッセージを表示させないようにする
            if (App.isStart == true)
            {
                this.Close();
                return;
            }

            // ベースパスが存在するかをチェック
            if (!Directory.Exists(Configure.BasePath))
            {
                // # 275 対応
                //MessageBox.Show($"指定ディレクトリ({Configure.BasePath})が存在しません。", "エラー",
                //            MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }
            // コンフィグファイルが存在するかをチェック
            if (!File.Exists(Configure.ConfigFileNew))
            {
                MessageBox.Show($"コンフィグファイル({Configure.ConfigFileNew})が存在しません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }
            // No.57 config.iniにエッジ端末のIPアドレスがコメントアウトなどで、1台も有効になっていない場合、アプリを終了
            // ⇒ No.81 メッセージ内容と画面遷移動作を変わる
            if (!Configure.FlagAtlas)
            {
                // No.119 画面左上にあるメッセージの文言"エラー”とアイコンが一致していないので”確認”で統一/文言内容の修正
                MessageBox.Show($"装置のIPアドレスがコンフィグファイルに記載されていません。\r\n以下の何れかの対応をしてください。\r\n" +
                    $"・アプリ終了後、コンフィグファイルを差し替えて再起動してください。\r\n・ログイン画面からバックアップ読出し操作をしてください。", "確認",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                IsIpAddressExist = false;
            }
            try
            {
                if (string.IsNullOrEmpty(Configure.ToolCsvPath))
                {
                    MessageBox.Show($"アプリCSVファイル格納先(tool_csv)がコンフィグファイルに設定されていません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }
                if (!Directory.Exists(Configure.ToolCsvPath))
                {
                    Directory.CreateDirectory(Configure.ToolCsvPath);
                }
                if (string.IsNullOrEmpty(Configure.FaceDataPath))
                {
                    MessageBox.Show($"顔データ格納先(face_data_jpg)がコンフィグファイルに設定されていません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }
                if (!Directory.Exists(Configure.FaceDataPath))
                {
                    Directory.CreateDirectory(Configure.FaceDataPath);
                }
                if (string.IsNullOrEmpty(Configure.ToolLogPath))
                {
                    MessageBox.Show($"ログファイル格納先(tool_log)がコンフィグファイルに設定されていません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }
                if (!Directory.Exists(Configure.ToolLogPath))
                {
                    Directory.CreateDirectory(Configure.ToolLogPath);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"プログラムが使用するフォルダの作成に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }
            // # 283 ログファイルの排他処理
            try
            {
                m_writeLog = new WriteLog();
            }
            catch
            {
                System.Windows.MessageBox.Show($"{Configure.ToolLogPath + @"\log." + DateTime.Today.ToString("yyyy-MM-dd") + ".txt"}を開いているため、アプリを起動できません。上記のファイルを閉じてから起動してください。", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }

            // No.54 画素数やメモリサイズのログを出力する
            if (Configure.FlagImage && Configure.FlagMemory)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] 画素数の上限サイズ:{Configure.MaxPixel}pixel、メモリクリアサイズ：{Configure.ImageSizeMb}MB。");
            }
            else if (Configure.FlagImage)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] 画素数の上限サイズ:{Configure.MaxPixel}pixel。");
            }
            else if (Configure.FlagMemory)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] メモリクリアサイズ：{Configure.ImageSizeMb}MB。");
            }

            // # 285 CSVファイルの排他処理
            try
            {
                m_writeToolCsv = new WriteToolCsv();
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"{Configure.ToolCsvPath + @"\tool_csv.csv"}を開いているため、アプリを起動できません。上記のファイルを閉じてから起動してください。", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
                WriteLogSafe.LogSafe($"[ログイン画面] アプリCSVファイルの権限が取得できません。{ex.Message}");
                this.Close();
                return;
            }

            WriteLogSafe.LogSafe("[ログイン画面] アプリを起動しました。");

            // No.81 IPがアドレスが取得できていない場合、「ログイン」釦および、「ログイン情報変更」釦は文字色を薄いグレー(非活性のような状態)にします
            if (!IsIpAddressExist)
            {
                this.btn_login.Foreground = Brushes.Gray;
                this.btn_password.Foreground = Brushes.Gray;
            }

            try
            {
                m_infoSettingIniFile = new InfoSettingIniFile();
            }
            catch (Exception ex)
            {
                m_infoSettingIniFile = null;
                WriteLogSafe.LogSafe($"[ログイン画面] ユーザIDとパスワードが保存されたINIファイルの初期化処理に失敗しました。{ex.Message}");
            }
        }

        public void Txt_User_Name_Change(object sender, RoutedEventArgs e)
        {
            this.btn_login.IsEnabled = true;
        }

        private void Btn_Login_Click(object sender, RoutedEventArgs e)
        {
            // No.81 IPがアドレスが取得できていない場合、釦を押下した場合の画面表示は無効にして、メッセージの表示部に情報を表示する
            if (!IsIpAddressExist)
            {
                this.txt_err_msg.Text = "PCの状態を復元したい場合は、「バックアップ読出し」を選択してください。";
                return;
            }

            string user_id = this.txt_user_id.Text.Trim();
            string password = this.txt_password.Password;

            Users User = new Users(m_infoSettingIniFile);
            bool rtn = User.CheckPassword(user_id, password);

            // ログイン認証成功
            if (rtn)
            {
                // ログイン後閉じるボタンを非活性にする
                var hwnd = new WindowInteropHelper(this).Handle;
                button1_Click(sender, e, hwnd);
                //IntPtr hMenu = GetSystemMenu(hwnd, 0);
                //RemoveMenu(hMenu, SC_CLOSE, MF_BYCOMMAND);

                // ログイン　ユーザーがhitachiadmin以外の場合、読出し設定先から「設置Atlas」を隠す
                if (user_id == "hitachiadmin")
                {
                    this.IsLoginByHitachiadmin = true;
                }

                // for ベリファイフラグ設定
                if (Configure.CheckFlag == 1)
                {
                    // ベリファイ処理
                    string msg = "登録状態をチェックしますか？\n\r\n\r装置台数や登録件数により\n\rかなり時間がかかる場合があります";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                        MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.Yes))
                    {
                        // No.51 はい釦を押下したログを残す
                        WriteLogSafe.LogSafe($"[ログイン画面] 登録状態をチェックしますか？「はい」押下。");
                        try
                        {
                            loading.IsActive = true;
                            loadingPart.Visibility = Visibility.Visible;
                            MessageChecking.Visibility = Visibility.Visible;
                            // ログを出力中はキーボードの操作を無効にする
                            this.GD.IsEnabled = false;

                            // No.47 ベリファイ処理開始のログを出力する
                            WriteLogSafe.LogSafe($"[ログイン画面] ベリファイ処理が開始しました。");

                            Recordings_Check_Sum.Clear();
                            Recordings_Check_Csv.Clear();
                            Recordings_Check_Atlas.Clear();

                            //　最新のtool_csvの顔データを読出し
                            FaceAuthViewModel ViewModelTemp = new FaceAuthViewModel();
                            //　No.2
                            ViewModelTemp.ReadViewDelayWithoutImage(this.IsFaceTransmitMode);
                            Recordings_Check_Csv = ViewModelTemp.Recordings_WithoutImage;

                            this.AtlasViewModel = new AtlasServerViewModel();
                            if (this.AtlasViewModel.Recordings.Count() <= 1)
                            {
                                System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                                    MessageBoxButton.OK, MessageBoxImage.Error);

                                loading.IsActive = false;
                                loadingPart.Visibility = Visibility.Hidden;
                                MessageChecking.Visibility = Visibility.Hidden;
                                this.GD.IsEnabled = true;

                                // ログイン画面戻るボタンを活性にする
                                button2_Click(sender, e, hwnd);

                                return;
                            }
                            var AtlasList = this.AtlasViewModel.Recordings;

                            // 疎通処理追加
                            pingJudegError = false;
                            bool runContinue = true;

                            Recordings_Ping.Clear();

                            List<Task<bool>> task_ping = new List<Task<bool>>();

                            task_ping.Add(Ping_Retry());

                            Task.Run(() => { Task.WaitAll(task_ping.ToArray()); }).ContinueWith(t1 =>
                            {
                                this.Invoke(new Action(() =>
                                {
                                    if (pingJudegError)
                                    {
                                        int errorType = 1;
                                        PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasList.Count, errorType, AtlasListNoError);
                                        pingJudge.Owner = this;
                                        pingJudge.ShowDialog();

                                        runContinue = pingJudge.HasRunContinue;

                                        if (!runContinue)
                                        {
                                            String PathCsv = Configure.ToolCsvPath + "\\tool_csv.csv";

                                            WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({PathCsv})で登録者一覧画面を表示します。");
                                            FaceAuthListPage FaceListPage = new FaceAuthListPage(PathCsv, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
                                            FaceListPage.Show();

                                            // for ログイン時に「×」を押下した時 確認のメッセージを出力する
                                            isCloseByUser = false;
                                            this.Close();

                                            return;
                                        }

                                        // No.46 疎通成功した装置が0台の場合、すぐに一覧画面に遷移します。
                                        bool runCountineForAllError = pingJudge.HasRunCoutinueForAllError;
                                        if (runCountineForAllError)
                                        {
                                            WriteLogSafe.LogSafe($"[ログイン画面] 疎通成功した装置が0台の場合、すぐに一覧画面に遷移します。");

                                            String PathCsv = Configure.ToolCsvPath + "\\tool_csv.csv";

                                            WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({PathCsv})で登録者一覧画面を表示します。");
                                            FaceAuthListPage FaceListPage = new FaceAuthListPage(PathCsv, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
                                            FaceListPage.Show();

                                            // for ログイン時に「×」を押下した時 確認のメッセージを出力する
                                            isCloseByUser = false;
                                            this.Close();

                                            return;
                                        }
                                    }

                                    pingJudegError = false;
                                    Recordings_Ping.Clear();

                                    List<Task<bool>> tasks = new List<Task<bool>>();

                                    // No.84 確認のとれた装置のみ登録チェックを行います
                                    for (int i = 0; i < AtlasListNoError.Count; i++)
                                    {
                                        tasks.Add(CheckData(AtlasListNoError[i].Server_Name, AtlasListNoError[i].Server_Ip, int.Parse(AtlasListNoError[i].Server_Name)));
                                    }
                                    Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
                                    {
                                        this.Invoke(new Action(() =>
                                        {
                                            // 不整合の顔情報の種類①
                                            foreach (FaceAuthDataBean Bean_Csv in Recordings_Check_Csv)
                                            {
                                                if ("CSVと装置データ不一致".Equals(Bean_Csv.OnlyExistType))
                                                {
                                                    // No.62 アプリ側の画像が無い場合「画像なし」と表示するように修正
                                                    Bean_Csv.StaffImgPath = Path.Combine(Configure.FaceDataPath, Bean_Csv.FaceId + @".jpg");
                                                    //BitmapImage image = ImageHelper.DecryptFile(StaffImgPath);
                                                    //if (image != null)
                                                    //{
                                                    //    Bean_Csv.StaffImgName = Bean_Csv.FaceId + @".jpg";
                                                    //    Bean_Csv.StaffImgPath = Path.Combine(Configure.FaceDataPath, Bean_Csv.StaffImgName);
                                                    //    Bean_Csv.Staff_Image = image;
                                                    //}
                                                    //else
                                                    //{
                                                    //    Bean_Csv.StaffImgName = @"画像なし";
                                                    //    Bean_Csv.Staff_Image = null;
                                                    //}
                                                    Recordings_Check_Sum.Add(Bean_Csv);
                                                }
                                            }

                                            // 不具合一覧　No.18　同じCARDID（顔ID）の顔情報が複数表示されている
                                            // 不整合の顔情報の種類②
                                            foreach (FaceAuthDataBean Bean_Atlas in Recordings_Check_Atlas.Distinct(new Compare()).OrderBy(item => item.FaceId))
                                            {
                                                Bean_Atlas.StaffName = "未登録";
                                                Bean_Atlas.StaffImgName = "画像なし";
                                                Bean_Atlas.IsDeleted = true;
                                                Recordings_Check_Sum.Add(Bean_Atlas);
                                            }

                                            // 不具合一覧 No.9　登録チェック結果が表示されたら、くるくる と 情報取得中です ポップアップを消します。
                                            loading.IsActive = false;
                                            loadingPart.Visibility = Visibility.Hidden;
                                            MessageChecking.Visibility = Visibility.Hidden;

                                            //　疎通処理追加
                                            if (pingJudegError && Recordings_Ping.Count > 0)
                                            {
                                                int errorType = 3;
                                                PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasListNoError.Count + 1, errorType);
                                                pingJudge.Owner = this;
                                                pingJudge.ShowDialog();

                                                String PathCsvAfterJudegError = Configure.ToolCsvPath + "\\tool_csv.csv";

                                                WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({PathCsvAfterJudegError})で登録者一覧画面を表示します。");
                                                FaceAuthListPage FaceListPageAfterJudegError = new FaceAuthListPage(PathCsvAfterJudegError, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
                                                FaceListPageAfterJudegError.Show();

                                                // for ログイン時に「×」を押下した時 確認のメッセージを出力する
                                                isCloseByUser = false;
                                                this.Close();

                                                return;
                                            }

                                            Recordings_Check_Sum = new ObservableCollection<FaceAuthDataBean>(Recordings_Check_Sum.OrderBy(item => item.FaceId));

                                            // No.47 ベリファイ処理終了のログを出力する
                                            WriteLogSafe.LogSafe($"[ログイン画面] ベリファイ処理が終了しました。不整合は{Recordings_Check_Sum.Count}件です");

                                            if (Recordings_Check_Sum.Count == 0)
                                            {
                                                IsNeedMatchErrorShow = false;
                                                System.Windows.MessageBox.Show("登録状態に問題はありませんでした。", "情報",
                                                MessageBoxButton.OK, MessageBoxImage.Information);
                                            }
                                            else
                                            {
                                                foreach (FaceAuthDataBean beanTable in Recordings_Check_Sum)
                                                {
                                                    WriteLogSafe.LogSafe($"[ログイン画面] 不整合顔情報が見つかりました。顔ID:{beanTable.FaceId})");
                                                }

                                                // No.121 以下のメッセージボックスを表示しない
                                                FaceCheckLIstPage faceCheck = new FaceCheckLIstPage(Recordings_Check_Sum, AtlasListNoError);
                                                faceCheck.Owner = this;
                                                faceCheck.ShowDialog();

                                                // 不整合一覧画面で「登録」ボタン押下
                                                if (faceCheck.HasChanged)
                                                {
                                                    IsNeedMatchErrorShow = false;
                                                }

                                                //string msg2 = "不整合データが見つかりました\n\r内容を確認しますか？";
                                                //MessageBoxResult messageBoxResult2 = System.Windows.MessageBox.Show(msg2, "確認",
                                                //    MessageBoxButton.YesNo, MessageBoxImage.Information);
                                                //if (messageBoxResult2.Equals(MessageBoxResult.Yes))
                                                //{
                                                //    // No.51 はい釦を押下したログを残す
                                                //    WriteLogSafe.LogSafe($"[ログイン画面] 不整合データが見つかりました「はい」押下。");
                                                //    FaceCheckLIstPage faceCheck = new FaceCheckLIstPage(Recordings_Check_Sum, AtlasListNoError);
                                                //    faceCheck.Owner = this;
                                                //    faceCheck.ShowDialog();

                                                //    // 不整合一覧画面で「登録」ボタン押下
                                                //    if (faceCheck.HasChanged)
                                                //    {
                                                //        IsNeedMatchErrorShow = false;
                                                //    }
                                                //}
                                                //else
                                                //{
                                                //    // No.51 いいえ釦を押下したログを残す
                                                //    WriteLogSafe.LogSafe($"[ログイン画面] 不整合データが見つかりました「いいえ」押下。");
                                                //    string msg3 = "本当に登録チェックを行わなくてもよろしいですか？";
                                                //    MessageBoxResult messageBoxResult3 = System.Windows.MessageBox.Show(msg3, "確認",
                                                //        MessageBoxButton.OKCancel, MessageBoxImage.Information);
                                                //    if (messageBoxResult3.Equals(MessageBoxResult.Cancel))
                                                //    {
                                                //        // No.51 キャンセル釦を押下したログを残す
                                                //        WriteLogSafe.LogSafe($"[ログイン画面] 本当に登録チェックを行わなくてもよろしいですか？「キャンセル」押下。");
                                                //        FaceCheckLIstPage faceCheck = new FaceCheckLIstPage(Recordings_Check_Sum, AtlasListNoError);
                                                //        faceCheck.Owner = this;
                                                //        faceCheck.ShowDialog();
                                                //    }
                                                //    // No.51 OK釦を押下したログを残す
                                                //    WriteLogSafe.LogSafe($"[ログイン画面] 本当に登録チェックを行わなくてもよろしいですか？「OK」押下。");
                                                //}
                                            }

                                            loading.IsActive = false;
                                            loadingPart.Visibility = Visibility.Hidden;
                                            MessageChecking.Visibility = Visibility.Hidden;
                                            this.GD.IsEnabled = true;

                                            WriteLogSafe.LogSafe($"[ログイン画面] ユーザー({user_id})がログイン成功しました。");

                                            String PathCsv = Configure.ToolCsvPath + "\\tool_csv.csv";

                                            WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({PathCsv})で登録者一覧画面を表示します。");
                                            FaceAuthListPage FaceListPage = new FaceAuthListPage(PathCsv, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin, this.IsNeedMatchErrorShow);
                                            FaceListPage.Show();

                                            // for ログイン時に「×」を押下した時 確認のメッセージを出力する
                                            isCloseByUser = false;

                                            this.Close();
                                        }));
                                    });
                                }));
                            });
                        }
                        catch (Exception ex)
                        {
                            WriteLogSafe.LogSafe($"[ログイン画面] 顔データの取得に失敗しました。{ex.Message}");
                            System.Windows.MessageBox.Show($"顔データの取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                            loading.IsActive = false;
                            loadingPart.Visibility = Visibility.Hidden;
                            MessageChecking.Visibility = Visibility.Hidden;
                            this.GD.IsEnabled = true;
                            // ログイン画面に戻るボタンを活性にする
                            button2_Click(sender, e, hwnd);
                        }
                    }
                    else
                    {
                        // No.51 いいえ釦を押下したログを残す
                        WriteLogSafe.LogSafe($"[ログイン画面] 登録状態をチェックしますか？「いいえ」押下。");
                        WriteLogSafe.LogSafe($"[ログイン画面] ユーザー({user_id})がログイン成功しました。");
                        //LoginFaceAuthSelect LoginSelectPage = new LoginFaceAuthSelect(IsLoginByHitachiadmin);
                        //LoginSelectPage.Show();
                        //this.Close();

                        loading.IsActive = true;
                        loadingPart.Visibility = Visibility.Visible;
                        this.GD.IsEnabled = false;

                        String PathCsv = Configure.ToolCsvPath + "\\tool_csv.csv";

                        WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({PathCsv})で登録者一覧画面を表示します。");
                        FaceAuthListPage FaceListPage = new FaceAuthListPage(PathCsv, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
                        FaceListPage.Show();

                        // for ログイン時に「×」を押下した時 確認のメッセージを出力する
                        isCloseByUser = false;
                        this.Close();
                    }
                }
                else if (Configure.CheckFlag == 0)
                {
                    WriteLogSafe.LogSafe($"[ログイン画面] ユーザー({user_id})がログイン成功しました。");
                    //LoginFaceAuthSelect LoginSelectPage = new LoginFaceAuthSelect(IsLoginByHitachiadmin);
                    //LoginSelectPage.Show();
                    //this.Close();

                    loading.IsActive = true;
                    loadingPart.Visibility = Visibility.Visible;
                    this.GD.IsEnabled = false;

                    String PathCsv = Configure.ToolCsvPath + "\\tool_csv.csv";

                    WriteLogSafe.LogSafe($"[バックアップファイル選択画面] バックアップファイル({PathCsv})で登録者一覧画面を表示します。");
                    FaceAuthListPage FaceListPage = new FaceAuthListPage(PathCsv, this.IsFaceTransmitMode, this.IsLoginByHitachiadmin);
                    FaceListPage.Show();

                    // for ログイン時に「×」を押下した時 確認のメッセージを出力する
                    isCloseByUser = false;
                    this.Close();
                }
            }
            // ログイン認証失敗
            else
            {
                // No.120 ユーザID＆パスワードが未入力の時は、[ユーザIDを入力してください]メッセージを表示するようにする
                if (User.ErrCode == 1 || User.ErrCode == 4)
                {
                    this.txt_err_msg.Text = "ユーザIDを入力してください";
                }
                else if (User.ErrCode == 2)
                {
                    this.txt_err_msg.Text = "パスワードを入力してください";
                }
                else if (User.ErrCode == 3)
                {
                    this.txt_err_msg.Text = $"ユーザID又はパスワードが間違っています。\r\nエラーコード:{User.ErrCode}";
                }
                WriteLogSafe.LogSafe($"[ログイン画面] ユーザー({user_id})がログイン失敗しました。");
            }
        }

        private void Btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        // for ログイン時に「×」を押下した時 確認のメッセージを出力する
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            if (!isCloseByUser)
            {
                base.OnClosing(e);
                return;
            }

            // No.69 登録者一覧画面の閉じる釦押下時のメッセージの表示内容修正
            string msg = "アプリを終了しますか?";

            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (messageBoxResult.Equals(MessageBoxResult.Yes))
            {
                WriteLogSafe.LogSafe("[ログイン画面] アプリを終了しました。");
                base.OnClosing(e);
            }
            else
            {
                //if (!isCloseByUser)
                //{
                //    base.OnClosing(e);
                //    return;
                //}

                e.Cancel = true;
                base.OnClosing(e);
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            if (isCloseByUser)
            {
                System.Environment.Exit(0);
            }
            base.OnClosed(e);
        }

        private void Btn_Setting_Change_Click(object sender, RoutedEventArgs e)
        {
            // No.81 IPがアドレスが取得できていない場合、釦を押下した場合の画面表示は無効にして、メッセージの表示部に情報を表示する
            if (!IsIpAddressExist)
            {
                this.txt_err_msg.Text = "PCの状態を復元したい場合は、「バックアップ読出し」を選択してください。";
                return;
            }

            if (m_infoSettingIniFile != null)
            {
                LoginSetting LoginSettingPage = new LoginSetting(this);
                LoginSettingPage.ShowDialog();
            }
            else
            {
                System.Windows.MessageBox.Show($"ユーザIDとパスワードが保存されたINIファイルの初期化処理に失敗しました。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
        }

        public int CheckIsFaceTransmitMode()
        {
            string path_regedit = "SOFTWARE\\Atlas_face\\Setting";
            string key = "FaceTransmit";
            try
            {
                RegistryKey root = Registry.LocalMachine;
                RegistryKey rk = root.OpenSubKey(path_regedit);
                if (rk != null)
                {
                    string value = (string)rk.GetValue(key, null);
                    if (value != null && value.Trim() == "1")
                    {
                        return 1;
                    }
                    else if (value != null && value.Trim() == "2")
                    {
                        return 2;
                    }
                    else
                        return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] レジストリキーの読取に失敗しました。{ex.Message}");
                return 0;
            }

            return 0;
        }

        private async Task<bool> CheckData(string AtlasName, string AtlasIp, int No)
        {
            // for 疎通処理
            string AtlasIpNoPort = "";
            string[] AtlasIpInfo = AtlasIp.Split(':');
            AtlasIpNoPort = AtlasIpInfo[0];

            int AtlasCount = this.AtlasViewModel.Recordings.Count();
            int AtlasKey = No;

            ObservableCollection<FaceAuthDataBean> Recordings_Check_Atlas_One = new ObservableCollection<FaceAuthDataBean>();

            AtlasApi Api = new AtlasApi();
            string Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);

                WriteLogSafe.LogSafe($"[登録者一覧画面] 顔データの取得に失敗しました。AtlasIp:{AtlasIp}");
                return false;
            }

            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
            if ("".Equals(DBId))
            {
                DBId = await Api.NewDBByName(AtlasIp, Token, Configure.LibraryName, LibraryDesp);
                if ("".Equals(DBId))
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);
                    return false;
                }
            }

            List<FaceAuthDataBean> UserListToCheck_Atlas = new List<FaceAuthDataBean>();

            bool FlagCheck = await Api.GetUserList(AtlasIp, Token, DBId, AtlasKey, AtlasCount, UserListToCheck_Atlas);

            if (FlagCheck)
            {
                foreach (var user in UserListToCheck_Atlas)
                {
                    Recordings_Check_Atlas_One.Add(user);
                }
            }
            else
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);
                return false;
            }

            Recordings_Check_Atlas_One = new ObservableCollection<FaceAuthDataBean>(Recordings_Check_Atlas_One.OrderBy(item => item.FaceId));

            // 不整合の顔情報の種類②　チェック
            foreach (FaceAuthDataBean bean_atlas in Recordings_Check_Atlas_One)
            {
                bool OnlyAtlasExist = true;

                foreach (FaceAuthDataBean bean_csv in this.Recordings_Check_Csv)
                {
                    if (bean_csv.FaceId.Equals(bean_atlas.FaceId))
                    {
                        OnlyAtlasExist = false;
                        break;
                    }
                }

                if (OnlyAtlasExist)
                {
                    bean_atlas.OnlyExistType = "装置のみ存在する";
                    Recordings_Check_Atlas.Add(bean_atlas);
                }
            }

            // 不整合の顔情報の種類①　チェック
            foreach (FaceAuthDataBean bean_csv in this.Recordings_Check_Csv)
            {
                string UserId_Csv = ReturnUserId(bean_csv, No);

                List<FaceAuthDataBean> UserListToCheck = new List<FaceAuthDataBean>();

                // for ベリファイチェック
                bool FlagCheck_ByCardId = await Api.GetUserListByCardId(AtlasIp, Token, DBId, AtlasKey, AtlasCount, bean_csv.FaceId, UserListToCheck);

                if (FlagCheck_ByCardId)
                {
                    //　Tool_csvに顔IDがある、Atlasに該当顔IDが一つ以上の場合、UseriIDチェック必要なし、不一致と認識
                    if (UserListToCheck.Count > 1)
                    {
                        bean_csv.OnlyExistType = "CSVと装置データ不一致";
                    }
                    else if (UserListToCheck.Count == 0)
                    {
                        //  Tool_csvに顔IDがある、Atlasに該当顔IDがない場合、Tool_csvのUserIDチェックが必要、一つUserIDがあれば、不一致と認識
                        bool FlagUserId = false;
                        for (int i = 0; i < 64; i++)
                        {
                            if (bean_csv.UserIds[i] != null && bean_csv.UserIds[i] != "")
                            {
                                FlagUserId = true;
                                break;
                            }
                        }

                        if (FlagUserId)
                        {
                            bean_csv.OnlyExistType = "CSVと装置データ不一致";
                        }
                    }
                    else
                    {
                        //　Atlasに該当顔IDが一つのみ存在する場合、UseriID一致するかをチェック
                        if (!UserId_Csv.Equals(UserListToCheck[0].UserIds[No - 1]))
                        {
                            bean_csv.OnlyExistType = "CSVと装置データ不一致";
                        }
                    }
                }
                else
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "ベリファイエラー",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);

                    return false;
                }
            }

            return true;
        }

        private string ReturnUserId(FaceAuthDataBean Bean, int Index)
        {
            string UserId;
            if (Index >= 1 && Index <= 64)
            {
                UserId = Bean.UserIds[Index - 1];
            }
            else
            {
                UserId = "";
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
            return UserId;
        }

        public class Compare : IEqualityComparer<FaceAuthDataBean>
        {
            public bool Equals(FaceAuthDataBean x, FaceAuthDataBean y)
            {
                return x.FaceId == y.FaceId;
            }

            public int GetHashCode(FaceAuthDataBean obj)
            {
                return obj.FaceId.GetHashCode();
            }
        }

        private async Task<bool> Ping_Retry()
        {
            var AtlasList = this.AtlasViewModel.Recordings;

            var ping = new System.Net.NetworkInformation.Ping();

            await Task.Delay(1000);

            // No.84 確認のとれた装置のみ登録チェックを行います
            // No.128「リトライ」後に全台のベリファイチェックを行っているかの見直し
            AtlasListNoError.Clear();

            for (int i = 1; i < AtlasList.Count; i++)
            {
                string[] AtlasIpInfo = AtlasList[i].Server_Ip.Split(':');
                string AtlasNumber = AtlasList[i].Server_Name;
                string AtlasIpNoPort = AtlasIpInfo[0];

                await Task.Delay(100);

                try
                {
                    // No.99 画面を移動させてマウスが効かなくなることを修正
                    var result = await ping.SendPingAsync(AtlasIpNoPort);

                    if (result.Status != System.Net.NetworkInformation.IPStatus.Success)
                    {
                        pingJudegError = true;

                        FaceAuthDataBean item = new FaceAuthDataBean()
                        {
                            StaffName = "疎通失敗",
                            OnlyExistAtlas = AtlasIpNoPort,
                            FigureId = AtlasNumber,
                        };

                        Recordings_Ping.Add(item);
                    }
                    // No.84 確認のとれた装置のみ登録チェックを行います
                    else
                    {
                        AtlasListNoError.Add(AtlasList[i]);
                    }
                }
                catch (Exception)
                {
                    pingJudegError = true;

                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasNumber,
                    };

                    Recordings_Ping.Add(item);
                }
            }

            return true;
        }

        public object ExitFrames(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }
        // 2.2.xx対応対策一覧　No.7 クアップ読出時にファイルを選択後、数秒応答なしと表示されます。応答なしの表示をさせないように対応
        private void zipFileFree(object sender, RoutedEventArgs e, System.Windows.Forms.OpenFileDialog Dlg, string fileName, string zipFilePath, string aimPath)
        {
            ZipFile.ExtractToDirectory(fileName, zipFilePath);
            string srcPath = zipFilePath;
            List<Task<int>> task_restore_copy = new List<Task<int>>();

            task_restore_copy.Add(CopyDir(srcPath, aimPath));

            Task.Run(() => { Task.WaitAll(task_restore_copy.ToArray()); }).ContinueWith(t =>
            {
                this.Invoke(new Action(() =>
                {
                    int res = task_restore_copy[0].Result;

                    try
                    {
                        if (Directory.Exists(zipFilePath))
                        {
                            // No.80 解凍したバックアップフォルダ（ファイル含む）を削除する
                            DirectoryInfo di = new DirectoryInfo(zipFilePath);
                            di.Delete(true);
                        }
                    }
                    catch
                    {
                        WriteLogSafe.LogSafe($"[ログイン画面] 解凍したバックアップフォルダの削除に失敗しました。");
                    }

                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;

                    if (res == 0)
                    {
                        System.Windows.MessageBox.Show("バックアップファイルの読出しが完了しました。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        // No.103 バックアップ読出し時はsetting.iniじゃないファイル(上記ではXXXXconfig.ini)をconfig.iniとして動作させる。
                        Configure.ConfigureIni(Configure.ConfigFileForBakup);
                        WriteToolCsv.fs.Close();
                        WriteToolCsv.fs = new FileStream(Configure.ToolCsvPath + @"\tool_csv.csv", FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                        WriteLog.UpdateFs();
                        WriteLogSafe.LogSafe($"[ログイン画面] PC復旧が成功しました。");
                        IsIpAddressExist = true;
                        this.btn_login.Foreground = Brushes.Black;
                        this.btn_password.Foreground = Brushes.Black;
                        // No.103 バックアップ読出し時はsetting.iniじゃないファイル(上記ではXXXXconfig.ini)をconfig.iniとして動作させる。
                        Configure.ConfigFileNew = Configure.ConfigFileForBakup;
                        Btn_Login_Click(sender, e);
                    }
                    else
                    {
                        string msg = "";
                        if (res == 1)
                        {
                            msg = $"バックアップフォルダ内のファイルに不正があります。\n\rバックアップフォルダを再度選択しますか？";
                            WriteLogSafe.LogSafe($"[ログイン画面] PC復旧が失敗しました。バックアップフォルダ内のファイルに不正があります。");
                        }
                        if (res == 2)
                        {
                            msg = $"PC復旧に異常が発生しました。\n\r別のプログラムがファイルを開いている可能性があります。\n\rファイルを閉じてからバックアップフォルダを再度選択しますか？";
                            WriteLogSafe.LogSafe($"[ログイン画面] PC復旧が失敗しました。PC復旧に異常が発生しました。別のプログラムがファイルを開いている可能性があります。");
                        }
                        if (res == 3)
                        {

                            // ログイン画面に戻るボタンを活性にする
                            var hwnd = new WindowInteropHelper(this).Handle;
                            button2_Click(sender, e, hwnd);
                            return;
                        }

                        MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                            MessageBoxButton.YesNo, MessageBoxImage.Information);
                        if (messageBoxResult.Equals(MessageBoxResult.Yes))
                        {
                            // はい釦を押下したログを残す
                            WriteLogSafe.LogSafe($"[ログイン画面] バックアップフォルダを再度選択しますか？「はい」押下。");
                            DlgOpen(sender, e, Dlg, aimPath);
                        }
                        else
                        {
                            // いいえ釦を押下したログを残す
                            WriteLogSafe.LogSafe($"[ログイン画面] バックアップフォルダを再度選択しますか？「いいえ」押下。");
                            // ログイン画面に戻るボタンを活性にする
                            var hwnd = new WindowInteropHelper(this).Handle;
                            button2_Click(sender, e, hwnd);
                            return;
                        }
                    }
                }));
            });
        }
        private void DlgOpen(object sender, RoutedEventArgs e, System.Windows.Forms.OpenFileDialog Dlg, string aimPath)
        {
            try
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                // ログイン後閉じるボタンを非活性にする
                var hwnd = new WindowInteropHelper(this).Handle;
                button1_Click(sender, e, hwnd);

                //var aimPath = Configure.BasePath;
                if (Dlg.ShowDialog() == System.Windows.Forms.DialogResult.OK)
                {
                    // No.80 PC復旧操作時はZipを解凍する
                    string selectPath = System.IO.Path.GetDirectoryName(Dlg.FileName);
                    string zipToFilePath = selectPath + "\\temp";
                    // No.108 バックアップ読み出す前に、tempフォルダが存在する場合、削除する
                    try
                    {
                        if (Directory.Exists(zipToFilePath))
                        {
                            // No.80 解凍したバックアップフォルダ（ファイル含む）を削除する
                            DirectoryInfo di = new DirectoryInfo(zipToFilePath);
                            di.Delete(true);
                        }
                    }
                    catch
                    {
                        System.Windows.MessageBox.Show($"PC復旧に異常が発生しました。\n\r解凍したバックアップフォルダの削除に失敗しました。", "エラー",
                                    MessageBoxButton.OK, MessageBoxImage.Error);
                        WriteLogSafe.LogSafe($"[ログイン画面] 解凍したバックアップフォルダの削除に失敗しました。");
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        // ログイン画面に戻るボタンを活性にする
                        button2_Click(sender, e, hwnd);
                        return;
                    }

                    // 2.2.xx対応対策一覧　No.7 クアップ読出時にファイルを選択後、数秒応答なしと表示されます。応答なしの表示をさせないように対応
                    Thread thread = new Thread(() => zipFileFree(sender, e, Dlg, Dlg.FileName, zipToFilePath, aimPath));
                    thread.Start();
                }
                else
                {
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;

                    // ログイン画面に戻るボタンを活性にする
                    button2_Click(sender, e, hwnd);
                }
            }
            catch (Exception ex)
            {
                System.Windows.MessageBox.Show($"PC復旧に異常が発生しました。+ {ex.Message}", "エラー",
                                    MessageBoxButton.OK, MessageBoxImage.Error);
                WriteLogSafe.LogSafe($"[ログイン画面] PC復旧に異常が発生しました。+ {ex.Message}");
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                // ログイン画面に戻るボタンを活性にする
                var hwnd = new WindowInteropHelper(this).Handle;
                button2_Click(sender, e, hwnd);
            }
        }
        private void Btn_Restore(object sender, RoutedEventArgs e)
        {
            // No.97 復旧方法を選択する
            BackupSelect BackupSelectPage = new BackupSelect();
            BackupSelectPage.Owner = this;
            BackupSelectPage.ShowDialog();

            // No.97 バックアップファイルから復旧の場合、既存のZipファイル読み出しを行う
            if (BackupSelect.BackupFlag == 1)
            {
                BackupSelect.BackupFlag = 0;
                this.txt_err_msg.Text = "";
                // バックアップファイルから復旧の場合のみ、ユーザー名とパスワードの認証を行う
                user_id_backup = this.txt_user_id.Text.Trim();
                password_backup = this.txt_password.Password;

                // 復旧認証失敗
                if (user_id_backup == "" || password_backup == "")
                {
                    // No.90 ID・パスワード 未入力時のエラーメッセージを修正する
                    if (user_id_backup == "")
                    {
                        this.txt_err_msg.Text = "バックアップ作成時のユーザIDを入力してください。";
                    }
                    else if (password_backup == "")
                    {
                        this.txt_err_msg.Text = "バックアップ作成時のパスワードを入力してください。";
                    }

                    WriteLogSafe.LogSafe($"[ログイン画面] ユーザID又はパスワードが未入力のため、復旧認証が失敗しました。");
                    return;
                }

                // 復旧認証成功
                this.txt_err_msg.Text = "";

                // バックアップファイルから復旧開始
                var aimPath = Configure.BasePath;
                //string dummyFileName = "読出すバックアップファイルの指定";

                System.Windows.Forms.OpenFileDialog Dlg = new System.Windows.Forms.OpenFileDialog()
                {
                    DefaultExt = ".zip",
                    Filter = "zip files (.zip)|*.zip"
                };
                // Feed the dummy name to the save dialog
                //Dlg.Description = dummyFileName;
                Dlg.Title = "読出すバックアップファイルの指定";

                DlgOpen(sender, e, Dlg, aimPath);
            }
            // No.97 Atlas装置から復旧の場合
            else if (BackupSelect.BackupFlag == 2)
            {
                // 装置から復旧処理開始のログを出力する
                WriteLogSafe.LogSafe($"[ログイン画面] 装置から復旧処理が開始しました。");

                BackupSelect.BackupFlag = 0;
                this.txt_err_msg.Text = "";
                user_id_backup = this.txt_user_id.Text.Trim();
                password_backup = this.txt_password.Password;

                // ユーザIとパスワードをチェック
                Users User = new Users(m_infoSettingIniFile);
                bool rtn = User.CheckPassword(user_id_backup, password_backup);
                if (!rtn)
                {
                    // 復旧認証失敗
                    if (User.ErrCode == 1 || User.ErrCode == 4)
                    {
                        this.txt_err_msg.Text = "ユーザIDを入力してください";
                        WriteLogSafe.LogSafe($"[ログイン画面] ユーザID又はパスワードが未入力のため、装置から復旧処理が終了しました。");
                    }
                    else if (User.ErrCode == 2)
                    {
                        this.txt_err_msg.Text = "パスワードを入力してください";
                        WriteLogSafe.LogSafe($"[ログイン画面] ユーザID又はパスワードが未入力のため、装置から復旧処理が終了しました。");
                    }
                    else if (User.ErrCode == 3)
                    {
                        this.txt_err_msg.Text = $"ユーザID又はパスワードが間違っています。\r\nエラーコード:{User.ErrCode}";
                        WriteLogSafe.LogSafe($"[ログイン画面] ユーザID又はパスワードが間違っています。ユーザー({user_id_backup})装置から復旧処理が終了しました。");
                    }
                    return;
                }

                // 復旧認証成功
                this.txt_err_msg.Text = "";

                // 2.2.xx対応対策一覧　No.13
                jpgCopyFlag = true;

                // 2.2.xx対応対策一覧　No.12 復旧方法選択画面にて「OK」押下時に「face_data_jpg」フォルダが存在するかチェックをします
                try
                {
                    if (!Directory.Exists(Configure.FaceDataPath))
                    {
                        Directory.CreateDirectory(Configure.FaceDataPath);
                    }
                }
                catch
                {
                    WriteLogSafe.LogSafe($"[ログイン画面] {Configure.FaceDataPath}フォルダの作成に失敗しました、PCの復旧に失敗しました。");
                    System.Windows.MessageBox.Show($"{Configure.FaceDataPath}フォルダの作成に失敗しました、PCの復旧に失敗しました。", "エラー",
                                            MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                // ログを出力中はキーボードの操作を無効にする
                this.GD.IsEnabled = false;

                this.AtlasViewModel = new AtlasServerViewModel();
                if (this.AtlasViewModel.Recordings.Count() <= 1)
                {
                    System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);

                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    this.GD.IsEnabled = true;

                    return;
                }
                var AtlasList = this.AtlasViewModel.Recordings;
                // 疎通処理追加
                pingJudegError = false;
                bool runContinue = true;

                Recordings_Ping.Clear();

                List<Task<bool>> task_ping = new List<Task<bool>>();

                task_ping.Add(Ping_Retry());

                Task.Run(() => { Task.WaitAll(task_ping.ToArray()); }).ContinueWith(t1 =>
                {
                    this.Invoke(new Action(() =>
                    {
                        if (pingJudegError)
                        {
                            int errorType = 9;
                            PingJudge pingJudge = new PingJudge(Recordings_Ping, AtlasList.Count, errorType, AtlasListNoError);
                            pingJudge.Owner = this;
                            pingJudge.ShowDialog();

                            runContinue = pingJudge.HasRunContinue;

                            if (!runContinue)
                            {
                                pingJudge.Close();
                                loading.IsActive = false;
                                loadingPart.Visibility = Visibility.Hidden;
                                this.GD.IsEnabled = true;

                                WriteLogSafe.LogSafe($"[ログイン画面] [疎通結果画面] 閉じるを押下しました。PC復旧を中断します。");
                                return;
                            }
                        }

                        pingJudegError = false;
                        Recordings_Ping.Clear();

                        getDataFromAtlas(sender, e, AtlasListNoError);
                    }));
                });
            }
        }
        // No.97 AtlasのALL読出し＆バックアップ」の機能対応、Atlasから顔情報を取得する
        private async void getDataFromAtlas(object sender, RoutedEventArgs e, ObservableCollection<AtlasServerDataBean> atlasListNoError = null)
        {
            await Task.Delay(1000);

            int AtlasKeyCheck = 0;
            string AtlasIpForCsv = "";

            if (atlasListNoError != null)
            {
                AtlasListNoError = atlasListNoError;
            }
            else
            {
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                this.GD.IsEnabled = true;
                return;
            }

            try
            {
                bool hasDataToCheck = false;
                AtlasDatasCheck.Clear();

                for (int i = 0; i < this.AtlasListNoError.Count; i++)
                {
                    FaceAuthViewModel ViewModelForReadFromAtlas = new FaceAuthViewModel();
                    if (AtlasDatasCheck.Count == 0)
                    {
                        while (true)
                        {
                            pingJudegError = false;
                            Recordings_Ping.Clear();
                            bool resultFirst = await getFirstFromAtlas(AtlasListNoError, ViewModelForReadFromAtlas, i);

                            if (pingJudegError && Recordings_Ping.Count > 0)
                            {
                                ObservableCollection<AtlasServerDataBean> AtlasListNoErrorForOne = new ObservableCollection<AtlasServerDataBean>();
                                AtlasListNoErrorForOne.Add(AtlasListNoError[i]);
                                bool btnClosedYes = false;
                                int errorType = 8;
                                PingJudge pingJudge = new PingJudge(Recordings_Ping, 2, errorType, AtlasListNoErrorForOne);
                                pingJudge.Owner = this;
                                pingJudge.ShowDialog();

                                btnClosedYes = pingJudge.HasBtnClosedYes;
                                if (btnClosedYes)
                                {
                                    // 疎通エラー画面で「中止」ボタン押下しました。PC復旧中止
                                    pingJudge.Close();
                                    WriteLogSafe.LogSafe($"[ログイン画面] PC復旧に失敗しました。");
                                    System.Windows.MessageBox.Show($"PC復旧に失敗しました。", "エラー",
                                                            MessageBoxButton.OK, MessageBoxImage.Error);
                                    loading.IsActive = false;
                                    loadingPart.Visibility = Visibility.Hidden;
                                    this.GD.IsEnabled = true;

                                    return;
                                }
                            }
                            else
                            {
                                break;
                            }
                        }

                        if (ViewModelForReadFromAtlas.Recordings.Count < 1)
                        {
                            continue;
                        }
                        else
                        {
                            hasDataToCheck = true;
                        }
                        // 顔IDが重複時、「create_time」が新しい方を正とし、古い方は保存しない
                        for (int j = 0; j < ViewModelForReadFromAtlas.Recordings.Count; j++)
                        {
                            for (int k = ViewModelForReadFromAtlas.Recordings.Count - 1; k > j; k--)
                            {
                                if (ViewModelForReadFromAtlas.Recordings[j].FaceId == ViewModelForReadFromAtlas.Recordings[k].FaceId)
                                {
                                    if (ViewModelForReadFromAtlas.Recordings[j].CreateTime > ViewModelForReadFromAtlas.Recordings[k].CreateTime)
                                    {
                                        ViewModelForReadFromAtlas.Recordings.RemoveAt(k);
                                    }
                                    else
                                    {
                                        ViewModelForReadFromAtlas.Recordings.RemoveAt(j);
                                    }
                                }
                            }
                        }
                        AtlasDatasCheck = ViewModelForReadFromAtlas.Recordings;
                        AtlasIpForCsv = AtlasListNoError[i].Server_Ip;
                    }
                    else
                    {
                        List<FaceAuthDataBean> UserList = new List<FaceAuthDataBean>();
                        AtlasKeyCheck = int.Parse(AtlasListNoError[i].Server_Name);

                        while (true)
                        {
                            pingJudegError = false;
                            Recordings_Ping.Clear();
                            bool resultOther = await getOtherFromAtlas(AtlasListNoError, UserList, i);
                            if (pingJudegError && Recordings_Ping.Count > 0)
                            {
                                ObservableCollection<AtlasServerDataBean> AtlasListNoErrorForOne = new ObservableCollection<AtlasServerDataBean>();
                                AtlasListNoErrorForOne.Add(AtlasListNoError[i]);
                                bool btnClosedYes = false;
                                int errorType = 8;
                                PingJudge pingJudge = new PingJudge(Recordings_Ping, 2, errorType, AtlasListNoErrorForOne);
                                pingJudge.Owner = this;
                                pingJudge.ShowDialog();

                                btnClosedYes = pingJudge.HasBtnClosedYes;
                                if (btnClosedYes)
                                {
                                    // 疎通エラー画面で「中止」ボタン押下しました。PC復旧中止
                                    pingJudge.Close();
                                    WriteLogSafe.LogSafe($"[ログイン画面] PC復旧に失敗しました。");
                                    System.Windows.MessageBox.Show($"PC復旧に失敗しました。", "エラー",
                                                            MessageBoxButton.OK, MessageBoxImage.Error);
                                    loading.IsActive = false;
                                    loadingPart.Visibility = Visibility.Hidden;
                                    this.GD.IsEnabled = true;

                                    return;
                                }
                            }
                            else
                            {
                                break;
                            }
                        }

                        if (UserList.Count < 1)
                        {
                            continue;
                        }
                        else
                        {
                            hasDataToCheck = true;
                        }
                        // 顔IDが重複時、「create_time」が新しい方を正とし、古い方は保存しない
                        for (int j = 0; j < UserList.Count; j++)
                        {
                            for (int k = UserList.Count - 1; k > j; k--)
                            {
                                if (UserList[j].FaceId == UserList[k].FaceId)
                                {
                                    if (UserList[j].CreateTime > UserList[k].CreateTime)
                                    {
                                        UserList.RemoveAt(k);
                                    }
                                    else
                                    {
                                        UserList.RemoveAt(j);
                                    }
                                }
                            }
                        }
                        // 顔情報を読み出す
                        foreach (FaceAuthDataBean bean in AtlasDatasCheck)
                        {
                            foreach (var user in UserList)
                            {
                                if (bean.FaceId == user.FaceId)
                                {
                                    // No.89 ipaddrを連番にすると正常にKeyIDが記載されていましたが、歯抜けの場合でも正常にKeyIDが記載されるように、実装の修正
                                    this.UpdateUserId(bean, AtlasKeyCheck, user.UserIds[AtlasKeyCheck - 1]);
                                    break;
                                }
                            }
                        }
                    }
                }

                // エッジ端末から読み出した顔情報を書き出す
                try
                {
                    // 全てのエッジ端末に顔情報が0の場合、PC復旧に失敗
                    if (!hasDataToCheck)
                    {
                        WriteLogSafe.LogSafe($"[ログイン画面] PC復旧に失敗しました。全装置に顔情報が存在しませんでした。");
                        System.Windows.MessageBox.Show($"PC復旧に失敗しました。\r\n\r\n全装置に顔情報が存在しませんでした。", "エラー",
                                                MessageBoxButton.OK, MessageBoxImage.Error);
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        this.GD.IsEnabled = true;
                        return;
                    }

                    // 2.2.xx対応対策一覧　No.11 PCの「face_data_jpg」フォルダ内の画像を全削除してから、装置の画像をPCに保存する
                    if (Directory.Exists(Configure.FaceDataPath))
                    {
                        string[] jpgFileList = Directory.GetFiles(Configure.FaceDataPath);
                        string deleteFailFile = "";
                        bool jpgDeleteFlag = true;

                        foreach (string jpgFile in jpgFileList)
                        {
                            // ファイルのタイプはjpgかどうかを判断する
                            string strExt = System.IO.Path.GetExtension(jpgFile);
                            if (strExt == ".jpg")
                            {
                                try
                                {
                                    File.Delete(jpgFile);
                                }
                                catch (Exception ex)
                                {
                                    WriteLogSafe.LogSafe($"[ログイン画面] {jpgFile}の削除に失敗しました。{ex.Message}");
                                    deleteFailFile = jpgFile;
                                    jpgDeleteFlag = false;
                                    break;
                                }
                            }
                        }
                        if (!jpgDeleteFlag)
                        {
                            if (File.Exists(Configure.ToolCsvPath + @"\tool_csv.csv"))
                            {
                                ClearCSV();
                            }
                            WriteLogSafe.LogSafe($"[ログイン画面] {deleteFailFile}が開かれているため、PC復旧に失敗しました。");
                            System.Windows.MessageBox.Show($"{deleteFailFile}が開かれているため、PC復旧に失敗しました。\r\n対象のファイルを閉じてから、再度PC復旧をしてください。", "エラー",
                                                    MessageBoxButton.OK, MessageBoxImage.Error);
                            loading.IsActive = false;
                            loadingPart.Visibility = Visibility.Hidden;
                            this.GD.IsEnabled = true;
                            return;
                        }
                    }

                    bool res = await ToCSV(AtlasDatasCheck, AtlasIpForCsv);

                    if (!jpgCopyFlag)
                    {
                        if (File.Exists(Configure.ToolCsvPath + @"\tool_csv.csv"))
                        {
                            ClearCSV();
                        }
                        if (Directory.Exists(Configure.FaceDataPath))
                        {
                            ClearImgFolder(Configure.FaceDataPath);
                        }
                        WriteLogSafe.LogSafe($"[ログイン画面] {Configure.FaceDataPath}フォルダが存在しません、PCの復旧に失敗しました。");
                        System.Windows.MessageBox.Show($"{Configure.FaceDataPath}フォルダが存在しません、PCの復旧に失敗しました。", "エラー",
                                                MessageBoxButton.OK, MessageBoxImage.Error);
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        this.GD.IsEnabled = true;
                        return;
                    }

                    if (res == true)
                    {
                        WriteLogSafe.LogSafe($"[ログイン画面] PC復旧が完了しました。");
                        System.Windows.MessageBox.Show("PC復旧が完了しました。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        this.GD.IsEnabled = true;
                        Btn_Login_Click(sender, e);
                    }
                    else
                    {
                        if (File.Exists(Configure.ToolCsvPath + @"\tool_csv.csv"))
                        {
                            ClearCSV();
                        }
                        if (Directory.Exists(Configure.FaceDataPath))
                        {
                            ClearImgFolder(Configure.FaceDataPath);
                        }
                        WriteLogSafe.LogSafe($"[ログイン画面] PCの復旧に失敗しました。");
                        System.Windows.MessageBox.Show($"PCの復旧に失敗しました。", "エラー",
                                                MessageBoxButton.OK, MessageBoxImage.Error);
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        this.GD.IsEnabled = true;
                        return;
                    }
                }
                catch (Exception ex)
                {
                    WriteLogSafe.LogSafe($"[ログイン画面] PCの復旧に失敗しました。{ex.Message}");
                    System.Windows.MessageBox.Show($"PCの復旧に失敗しました。\r\n{ex.Message}", "エラー",
                                            MessageBoxButton.OK, MessageBoxImage.Error);
                    if (File.Exists(Configure.ToolCsvPath + @"\tool_csv.csv"))
                    {
                        ClearCSV();
                    }
                    if (Directory.Exists(Configure.FaceDataPath))
                    {
                        ClearImgFolder(Configure.FaceDataPath);
                    }
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    this.GD.IsEnabled = true;
                    return;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] PCの復旧に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"PCの復旧に失敗しました。\r\n{ex.Message}", "エラー",
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
                this.GD.IsEnabled = true;
                return;
            }
        }

        public bool ClearCSV()
        {
            string FilePathToolCSV = Configure.ToolCsvPath + @"\tool_csv.csv";
            try
            {
                using (FileStream _stream = WriteToolCsv.fs)
                {
                    _stream.SetLength(0);
                    StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);
                    _writer.WriteLine("");
                    _writer.Close();
                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                    return true;
                }
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] CSVファイルのクレアに失敗しました。{ex.Message}");
                return false;
            }
        }

        public bool ClearImgFolder(string imgPath)
        {
            try
            {
                DirectoryInfo di = new System.IO.DirectoryInfo(imgPath);
                di.Delete(true);
                Directory.CreateDirectory(imgPath);

                return true;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] イメージフォルダのクリアに失敗しました。{ex.Message}");
                return false;
            }
        }

        public async Task<bool> ToCSV(ObservableCollection<FaceAuthDataBean> AtlasDatasCheck, string AtlasIp)
        {
            string FilePathToolCSV = Configure.ToolCsvPath + @"\tool_csv.csv";

            AtlasApi Api = new AtlasApi();
            string Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                WriteLogSafe.LogSafe($"[登録者一覧画面] 装置への認証は失敗しました。");
                return false;
            }

            using (FileStream _stream = WriteToolCsv.fs)
            {
                _stream.SetLength(0);
                StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);
                try
                {
                    foreach (FaceAuthDataBean beanTable in AtlasDatasCheck)
                    {
                        string sline;

                        beanTable.StaffImgPath = Path.Combine(Configure.FaceDataPath, beanTable.FaceId + @".jpg");
                        // No.107 Atlas読み出しを行ったところ、すべての画像ファイルが表示されず、一部の画像しか表示されない対応
                        if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath))
                        {
                            // 画像を読み出す
                            var ImageId = beanTable.StaffImgName;
                            BitmapImage image = await Api.DownloadImage(AtlasIp, Token, ImageId, beanTable.FaceId);
                            if (image != null)
                            {
                                beanTable.StaffImgName = beanTable.FaceId + @".jpg";
                                if (!ImageHelper.EncryptFile(image, beanTable.StaffImgPath))
                                {
                                    jpgCopyFlag = false;
                                    // 2.2.xx対応対策一覧　No.13
                                    _writer.Close();
                                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                                    return false;
                                }
                            }
                            else
                            {
                                return false;
                            }
                        }
                        if (this.IsFaceTransmitMode == 2)
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + beanTable.FloorNum + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        else
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.HasFilePath + "," + beanTable.LoginStatus + "," + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        _writer.WriteLine(sline);
                    }
                    _writer.Close();
                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                    return true;
                }
                catch (Exception ex)
                {
                    WriteLogSafe.LogSafe($"[ログイン画面] CSVファイルへの出力が失敗しました。{ex.Message}");
                    // 2.2.xx対応対策一覧　No.13
                    _writer.Close();
                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                    return false;
                }

            }
        }

        private void UpdateUserId(FaceAuthDataBean Bean, int Index, string UserId)
        {
            if (Index >= 1 && Index <= 64)
            {
                Bean.UserIds[Index - 1] = UserId;
            }
            else
            {
                WriteLogSafe.LogSafe($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
        }

        private async Task<bool> getFirstFromAtlas(ObservableCollection<AtlasServerDataBean> AtlasListNoError, FaceAuthViewModel ViewModelForReadFromAtlas, int No)
        {
            // for 疎通処理
            string AtlasIpNoPort = "";
            string[] AtlasIpInfo = AtlasListNoError[No].Server_Ip.Split(':');
            AtlasIpNoPort = AtlasIpInfo[0];
            string AtlasName = AtlasListNoError[No].Server_Name;
            var resultFirst = false;
            var AtlasIp = AtlasListNoError[No].Server_Ip;
            var AtlasKeyCheck = int.Parse(AtlasListNoError[No].Server_Name);

            resultFirst = await ViewModelForReadFromAtlas.ReadFromAtlas(AtlasIp, AtlasKeyCheck, 1);
            if (!resultFirst)
            {
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);
                return false;
            }
            return true;
        }
        private async Task<bool> getOtherFromAtlas(ObservableCollection<AtlasServerDataBean> AtlasListNoError, List<FaceAuthDataBean> UserList, int No)
        {
            // for 疎通処理
            string AtlasIpNoPort = "";
            string[] AtlasIpInfo = AtlasListNoError[No].Server_Ip.Split(':');
            AtlasIpNoPort = AtlasIpInfo[0];
            string AtlasName = AtlasListNoError[No].Server_Name;
            string AtlasIp = AtlasListNoError[No].Server_Ip;

            int AtlasCount = this.AtlasViewModel.Recordings.Count();
            int AtlasKey = int.Parse(AtlasListNoError[No].Server_Name);

            AtlasApi Api = new AtlasApi();
            string Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);
                WriteLogSafe.LogSafe($"[ログイン画面] 顔データの取得に失敗しました。AtlasIp:{AtlasIp}");
                return false;
            }

            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
            if ("".Equals(DBId))
            {
                DBId = await Api.NewDBByName(AtlasIp, Token, Configure.LibraryName, LibraryDesp);
                if ("".Equals(DBId))
                {
                    // for 疎通処理
                    pingJudegError = true;
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        StaffName = "疎通失敗",
                        OnlyExistAtlas = AtlasIpNoPort,
                        FigureId = AtlasName,
                    };
                    Recordings_Ping.Add(item);
                    return false;
                }
            }

            //List<FaceAuthDataBean> UserList = new List<FaceAuthDataBean>();
            bool FlagCheck = await Api.GetUserList(AtlasIp, Token, DBId, AtlasKey, 1, UserList);
            if (!FlagCheck)
            {
                // for 疎通処理
                pingJudegError = true;
                FaceAuthDataBean item = new FaceAuthDataBean()
                {
                    StaffName = "疎通失敗",
                    OnlyExistAtlas = AtlasIpNoPort,
                    FigureId = AtlasName,
                };
                Recordings_Ping.Add(item);
                return false;
            }
            return true;
        }
        public static void getContentToFile(String conpath)
        {
            string FilePathToolCSV = Configure.ToolCsvPath + @"\tool_csv.csv";

            using (FileStream _stream = WriteToolCsv.fs)
            {
                _stream.SetLength(0);
                StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);
                String content = String.Empty;
                int maxColumn = 20;

                //List<List<string>> Lines = WriteToolCsv.ReadToolCSV(0, "UTF-8");
                //int maxColumn = 20;

                //foreach (List<string> line in Lines)
                //{
                //    string[] Values = line.ToArray();

                //    if (Values.Length < maxColumn)
                //    {
                //        continue;
                //    }

                //    if (Values[10] != "")
                //    {
                //        Values[10] = "1";
                //    }

                //    var result = String.Join(",", Values);
                //    _writer.WriteLine(content);
                //}

                //_writer.Close();
                //WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                // Backup file Tool＿Csv　読み込み
                using (FileStream fs = new FileStream(conpath, FileMode.Open))
                {
                    StreamReader sr = new StreamReader(fs);
                    while ((content = sr.ReadLine()) != null)
                    {
                        content = content.Trim().ToString();

                        string[] Values = content.Split(',');
                        if (Values.Length < maxColumn)
                        {
                            continue;
                        }

                        if (Values[10] != "")
                        {
                            Values[10] = "1";
                        }

                        var result = String.Join(",", Values);
                        _writer.WriteLine(result);
                    }
                    sr.Close();
                    _writer.Close();
                    WriteToolCsv.fs = new FileStream(FilePathToolCSV, FileMode.OpenOrCreate, System.IO.FileAccess.ReadWrite, FileShare.Read);
                }
            }
        }

        private async Task<int> CopyDir(string srcPath, string aimPath)
        {
            int errorCode = 0;
            try
            {
                await Task.Delay(3000);

                // 检查目标目录是否以目录分割字符结束如果不是则添加之
                if (aimPath[aimPath.Length - 1] != Path.DirectorySeparatorChar)
                {
                    aimPath += Path.DirectorySeparatorChar;
                }
                // 判断目标目录是否存在如果不存在则新建之
                if (!Directory.Exists(aimPath))
                {
                    WriteLogSafe.LogSafe($"[ログイン画面] 復旧フォルダの作成が失敗しました。");
                    errorCode = 2;
                    return errorCode;
                }

                // 得到源目录的文件列表和目录列表
                string[] fileList = Directory.GetFiles(srcPath);
                string[] directoryList = Directory.GetDirectories(srcPath);

                // No.103 ファイルのタイプはiniかどうかを判断する
                foreach (string iniFile in fileList)
                {
                    string strExt = System.IO.Path.GetExtension(iniFile);
                    if (strExt != ".ini")
                    {
                        errorCode = 1;
                        return errorCode;
                    }
                }

                // バックアップのConfig不正かを判断
                if (fileList.Length == 2)
                {
                    if (!((IList)fileList).Contains(srcPath + @"\settings.ini"))
                    {
                        errorCode = 1;
                        return errorCode;
                    }
                }
                else
                {
                    errorCode = 1;
                    return errorCode;
                }

                // バックアップファイルのsettingsFileの内容を確認
                InfoSettingIniFile infoSettingIniFile = new InfoSettingIniFile();
                string StrUsername_info_1 = infoSettingIniFile.IniReadValueFromBackup("FaceAdmin_info_1", "Username", srcPath + @"\settings.ini");
                string StrUsername_info_2 = infoSettingIniFile.IniReadValueFromBackup("FaceAdmin_info_2", "Username", srcPath + @"\settings.ini");
                string StrPassword_info_1 = infoSettingIniFile.IniReadValueFromBackup("FaceAdmin_info_1", "Password", srcPath + @"\settings.ini");
                string StrPassword_info_2 = infoSettingIniFile.IniReadValueFromBackup("FaceAdmin_info_2", "Password", srcPath + @"\settings.ini");

                string[] UserNames = new string[] { StrUsername_info_1, StrUsername_info_2 };
                string[] Passwords = new string[] { StrPassword_info_1, StrPassword_info_2 };

                bool identifySuccess = false;
                for (int i = 0; i < UserNames.Length; i++)
                {
                    if (UserNames[i] == user_id_backup && Passwords[i] == password_backup)
                    {
                        identifySuccess = true;
                        break;
                    }
                }

                if (!identifySuccess)
                {
                    this.txt_err_msg.Text = $"ユーザID又はパスワードが間違っています。\r\nエラーコード:3";

                    WriteLogSafe.LogSafe($"[ログイン画面] 復旧認証が失敗しました。");
                    errorCode = 3;
                    return errorCode;
                }

                string srcConfigIniPath = "";
                for (int i = 0; i < fileList.Length; i++)
                {
                    if (fileList[i] != srcPath + @"\settings.ini")
                    {
                        srcConfigIniPath = fileList[i];
                    }
                }

                //　Conifg不正なし、読み込み
                Configure.ConfigureIni_BackUp(srcConfigIniPath);
                if (!Configure.FlagAtlas_BackUp)
                {
                    errorCode = 1;
                    return errorCode;
                }
                if (string.IsNullOrEmpty(Configure.ToolCsvPath_BackUp))
                {
                    errorCode = 1;
                    return errorCode;
                }
                if (string.IsNullOrEmpty(Configure.FaceDataPath_BackUp))
                {
                    errorCode = 1;
                    return errorCode;
                }
                if (string.IsNullOrEmpty(Configure.ToolLogPath_BackUp))
                {
                    errorCode = 1;
                    return errorCode;
                }

                // バックアップのフォルダが不正かを判断
                if (directoryList.Length == 2)
                {
                    if (!((IList)directoryList).Contains(srcPath + @"\face_data_jpg")
                        || !((IList)directoryList).Contains(srcPath + @"\tool_csv"))
                    {
                        errorCode = 1;
                        return errorCode;
                    }

                    //遍历所有的文件和目录
                    foreach (string directory in directoryList)
                    {
                        // イメージのバックアップ
                        if (directory == srcPath + @"\face_data_jpg")
                        {
                            string[] jpgFileList = Directory.GetFiles(directory);
                            string[] jpgDirectoryList = Directory.GetDirectories(directory);

                            if (jpgDirectoryList.Length > 0)
                            {
                                errorCode = 1;
                                return errorCode;
                            }

                            foreach (string jpgFile in jpgFileList)
                            {
                                // ファイルのタイプはjpgかどうかを判断する
                                string strExt = System.IO.Path.GetExtension(jpgFile);
                                if (strExt != ".jpg")
                                {
                                    errorCode = 1;
                                    return errorCode;
                                }
                            }
                        }
                        // tool_csvのバックアップ
                        else if (directory == srcPath + @"\tool_csv")
                        {
                            string[] toolCsvFileList = Directory.GetFiles(directory);
                            string[] toolCsvDirectoryList = Directory.GetDirectories(directory);
                            if (toolCsvDirectoryList.Length > 0)
                            {
                                errorCode = 1;
                                return errorCode;
                            }

                            if (toolCsvFileList.Length != 1 || (toolCsvFileList.Length == 1 && toolCsvFileList[0] != directory + @"\tool_csv.csv"))
                            {
                                errorCode = 1;
                                return errorCode;
                            }
                        }
                    }
                }
                else
                {
                    errorCode = 1;
                    return errorCode;
                }
                // 過不足判断終了               

                //遍历所有的文件和目录 进行复旧
                foreach (string directory in directoryList)
                {
                    // イメージのバックアップ
                    if (directory == srcPath + @"\face_data_jpg")
                    {
                        string[] jpgFileList = Directory.GetFileSystemEntries(directory);
                        string jpgAimPath = Configure.FaceDataPath_BackUp;
                        if (!Directory.Exists(jpgAimPath))
                        {
                            Directory.CreateDirectory(jpgAimPath);
                        }
                        foreach (string jpgFile in jpgFileList)
                        {
                            if (File.Exists(jpgFile))
                            {
                                await Task.Delay(10);
                                // ファイルのタイプはjpgかどうかを判断する
                                string strExt = System.IO.Path.GetExtension(jpgFile);
                                if (strExt == ".jpg")
                                {
                                    File.Copy(jpgFile, jpgAimPath + @"\" + Path.GetFileName(jpgFile), true);
                                }
                            }
                        }
                    }
                    // tool_csvのバックアップ
                    else if (directory == srcPath + @"\tool_csv")
                    {
                        string[] toolCsvFileList = Directory.GetFileSystemEntries(directory);
                        string toolCsvAimPath = Configure.ToolCsvPath_BackUp;
                        if (!Directory.Exists(toolCsvAimPath))
                        {
                            Directory.CreateDirectory(toolCsvAimPath);
                        }
                        foreach (string toolCsvFile in toolCsvFileList)
                        {
                            if (toolCsvFile == directory + @"\tool_csv.csv")
                            {
                                if (Configure.ToolCsvPath == Configure.ToolCsvPath_BackUp)
                                {
                                    getContentToFile(toolCsvFile);
                                }
                                else
                                {
                                    File.Copy(toolCsvFile, toolCsvAimPath + @"\" + Path.GetFileName(toolCsvFile), true);
                                }
                            }
                        }
                    }
                }

                foreach (string file in fileList)
                {
                    // コンフィグファイルのバックアップ
                    if (file == srcConfigIniPath)
                    {
                        File.Copy(file, aimPath + Path.GetFileName(file), true);

                        Configure.ConfigFileForBakup = Configure.BasePath + "\\" + Path.GetFileName(file);
                    }
                    // コンフィグファイルのバックアップ
                    if (file == srcPath + @"\settings.ini")
                    {
                        File.Copy(file, aimPath + Path.GetFileName(file), true);
                    }
                }

                return errorCode;
            }
            catch (Exception ex)
            {
                WriteLogSafe.LogSafe($"[ログイン画面] PC復旧に異常が発生しました。{ex.Message}");
                errorCode = 2;
                return errorCode;
            }
        }

        // No.104 バックアップ読み出し中（くるくる表示中）に、キーボード操作できないように対応する
        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (this.loading.IsActive)
            {
                e.Handled = true;
            }
        }
    }
}
