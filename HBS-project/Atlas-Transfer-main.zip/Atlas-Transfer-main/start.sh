#! /bin/sh
npm start