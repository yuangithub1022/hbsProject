
/*!
 * Atlas Message Transfer Library
 * Hitachi Building Systems - v1.0.0
 *
 * Include express (https://expressjs.com)
 * Include node-ftp (https://github.com/mscdex/node-ftp)
 * Include node-schedule (https://github.com/node-schedule/node-schedule)
 */

// Import system library
const fs = require('fs');
const os = require('os');
const ftp = require('ftp');
const http = require('http');
const path = require('path');
const schedule = require('node-schedule');

// Import third-party library
const express = require('express');
const body_parser = require('body-parser');

// Define common log method
// logger off or not
let log_off = false;
const log = (message) => {
  if (!log_off) {
    console.log(`${new Date().toLocaleString()}: ${message}`);
  }
};

// Initialize server instance
const app = express();
app.use(body_parser.urlencoded({ extended: false }));
app.use(body_parser.json());

// Global variables, store realtime headcount and segmentation result
let line_result = [];
let area_result = [];

const base_dir = os.platform() === 'win32' ? './' : '/var/transfer/';
const work_suffix = '.working';
const newline = '\r\n';

const column_camera = 'CAMERA_NO';
const column_date = 'YYYYMMDD';
const column_start = 'START_TIME';
const column_end = 'END_TIME';
const column_in = 'IN_NO';
const column_out = 'OUT_NO';
const column_area = 'AREA_NO';

// Get local config
const line_task = 'line';
const area_task = 'area';
const line_folder = 'camera_line';
const area_folder = 'camera_area';
const sending_folder = 'sending';
const sended_folder = 'sended';
const line_folder_sending = `${base_dir}${line_folder}/${sending_folder}/`;
const line_folder_sended = `${base_dir}${line_folder}/${sended_folder}/`;
const area_folder_sending = `${base_dir}${area_folder}/${sending_folder}/`;
const area_folder_sended = `${base_dir}${area_folder}/${sended_folder}/`;

const config_file = `${base_dir}config.json`;
const getServerConfig = () => {
  try {
    // Read config file and parse
    let content = fs.readFileSync(config_file, 'utf8');
    return JSON.parse(content);
  } catch (err) {
    log(`[Error] GetServerConfig - Failed reading config file: ${err.toString()}`);
    return null;
  }
};

// Initialize server path and port
const config_json = getServerConfig();
if (!config_json) {
  log(`[Error] App - Server App start failed, error when reading ${config_file}`);
  return;
}

const atlas_name = config_json['atlas_name'];
if (!atlas_name) {
  log(`[Error] App - Server App start failed, atlas_name should not be empty`);
  return;
}

const base_ip = config_json['base_ip'] ? config_json['base_ip'] : '0.0.0.0';
// 127.0.0.1: serve as localhost only
// 0.0.0.0: serve as public server
if (!['127.0.0.1', '0.0.0.0'].includes(base_ip)) {
  log(`[Error] App - Server App start failed, base_ip ${base_ip} is not one of ['127.0.0.1', '0.0.0.0']`);
  return;
}

const base_path = config_json['base_path'] ? config_json['base_path'] : '/transfer';
if (!base_path.startsWith('/') || base_path.endsWith('/')) {
  log(`[Error] App - Server App start failed, base_path ${base_path} is invalid (should like "/transfer")`);
  return;
}

const base_port = config_json['base_port'] ? config_json['base_port'] : 5005;
if (base_port < 1 || base_port > 65535) {
  log(`[Error] App - Server App start failed, base_port ${base_port} is invalid, should be in range 1 ~ 65535`);
  return;
}

const interval_minutes = config_json['interval_minutes'] ? config_json['interval_minutes'] : 1; // Unit(minutes)
if (interval_minutes < 1 || interval_minutes > 59) {
  log(`[Error] App - Server App start failed, interval_minutes ${interval_minutes} is invalid, should be in range 1 ~ 59`);
  return;
}

const transfer_seconds = config_json['transfer_seconds'] ? config_json['transfer_seconds'] : 1; // Unit(seconds)
if (transfer_seconds < 1 || transfer_seconds > 59) {
  log(`[Error] App - Server App start failed, transfer_seconds ${transfer_seconds} is invalid, should be in range 1 ~ 59`);
  return;
}

const file_number_once = config_json['file_number_once'] ? config_json['file_number_once'] : 100;
if (file_number_once < 2 || file_number_once > 10000) {
  log(`[Error] App - Server App start failed, file_number_once ${file_number_once} is invalid, should be in range 2 ~ 10000`);
  return;
}

const file_number_limit = config_json['file_number_limit'] ? config_json['file_number_limit'] : 4320;
if (file_number_limit < 2 || file_number_limit > 43200) {
  log(`[Error] App - Server App start failed, file_number_limit ${file_number_limit} is invalid, should be in range 2 ~ 43200`);
  return;
}

// FTP Info need not to check
log_off = !!config_json['log_off'];
const ftp_host = config_json['ftp_host'] ? config_json['ftp_host'] : '';
const ftp_port = config_json['ftp_port'] ? config_json['ftp_port'] : 21;
const ftp_user = config_json['ftp_user'] ? config_json['ftp_user'] : '';
const ftp_password = config_json['ftp_password'] ? config_json['ftp_password'] : '';

// Check local folder exists
if (!fs.existsSync(line_folder_sending)){
  fs.mkdirSync(line_folder_sending, {recursive: true});
}

if (!fs.existsSync(line_folder_sended)){
  fs.mkdirSync(line_folder_sended, {recursive: true});
}

if (!fs.existsSync(area_folder_sending)){
  fs.mkdirSync(area_folder_sending, {recursive: true});
}

if (!fs.existsSync(area_folder_sended)){
  fs.mkdirSync(area_folder_sended, {recursive: true});
}

// UploadCaptureResult API, be called by AI Service.
app.post(base_path + '/upload', (req, res) => {
  req.setEncoding('utf8');
  log(`[Info] UploadCaptureResult - New capture result coming`);

  // Get post data
  let buffer = '';
  req.on('data', (chunk) => {
    buffer += chunk;
  });

  // Process data
  req.on('end', () => {
    try {
      const post_data = JSON.parse(buffer);

      // Check task type
      if (post_data.task_type !== 'TASK_TYPE_CROWD') {
        throw new Error('Task Type must be TASK_TYPE_CROWD');
      }

      // Head count data process
      let cur_time = post_data.capture_time ? new Date(post_data.capture_time) : new Date();
      let pre_time = new Date(cur_time.getTime() - 60 * interval_minutes * 1000);
      let pre_year = String(pre_time.getFullYear());
      let pre_month = `0${pre_time.getMonth()+1}`.slice(-2);
      let pre_day = `0${pre_time.getDate()}`.slice(-2);
      let pre_hour = `0${pre_time.getHours()}`.slice(-2);
      let pre_minite = `0${pre_time.getMinutes()}`.slice(-2);
      let pre_second = `0${pre_time.getSeconds()}`.slice(-2);
      let cur_hour = `0${cur_time.getHours()}`.slice(-2);
      let cur_minite = `0${cur_time.getMinutes()}`.slice(-2);
      let cur_second = `0${cur_time.getSeconds()}`.slice(-2);

      let cur_date = pre_year + pre_month + pre_day;
      let cur_start = pre_hour + pre_minite + pre_second;
      let cur_end = cur_hour + cur_minite + cur_second;

      // Headcount data process (save to area_result)
      if (post_data.capture_result.crowd.type === 'CROWD_TYPE_HEADCOUNT') {
        let new_item = {};
        new_item[column_camera] = post_data.extra_info.task_name;
        new_item[column_date] = cur_date;
        new_item[column_start] = cur_start;
        new_item[column_end] = cur_end;
        new_item[column_area] = post_data.capture_result.crowd.subclass.headcount.count;

        log(`[Info] UploadCaptureResult - AreaData: ${JSON.stringify(new_item)}`);
        area_result.push(new_item);
      }

      // Segmentation data process (save to line_result)
      if (post_data.capture_result.crowd.type === 'CROWD_TYPE_SEGMENTATION') {
        let new_item = {};
        new_item[column_camera] = post_data.extra_info.task_name;
        new_item[column_date] = cur_date;
        new_item[column_start] = cur_start;
        new_item[column_end] = cur_end;
        new_item[column_in] = post_data.capture_result.crowd.subclass.segmentation.forward;
        new_item[column_out] = post_data.capture_result.crowd.subclass.segmentation.reverse;

        log(`[Info] UploadCaptureResult - LineData: ${JSON.stringify(new_item)}`);
        line_result.push(new_item);
      }

      // Send empty response
      res.send('{}');
    } catch (err) {
      // Catch Error and send error code
      log(`[Error] UploadCaptureResult - Process Error: ${err.toString()}`);
      res.send('{"code": -1}');
    }
  });
});

// get all csv files from a folder. sort csv files from files.
const get_file_list = (folder) => {
  let file_list = [];
  try {
    let files = fs.readdirSync(folder);
    if (files) {
      files.forEach((file) => {
        let fileObject = fs.statSync(`${folder}${file}`);
        if (fileObject.isFile() && /.*\.csv$/.test(file)) {
          file_list.push(file);
        }
      });
      // sort desc
      file_list.sort((a, b) => {
        return b > a ? 1 : -1;
      });
    }
  } catch (err) {
    log(`[Error] GetFileList - Get files failed, ${folder}, ${err.toString()}`);
  }
  return file_list;
};

const clear_local_file = (folder) => {
  let file_list = get_file_list(folder);
  if (file_list.length > file_number_limit) {
    let to_remove = file_list.slice(file_number_limit);
    to_remove.forEach((file) => {
      try {
        fs.unlinkSync(`${folder}${file}`);
      } catch (err) {
        log(`[Error] ClearLocalFile - Remove file failed, ${folder}${file}, ${err.toString()}`);
      }
    });
    log(`[Info] ClearLocalFile - Remove files over, ${folder}`);
  }
};

// Delete some extra files
const clear_local_folders = () => {
  // Remove local files if exceed the limits
  clear_local_file(line_folder_sending);
  clear_local_file(line_folder_sended);
  // Remove local files if exceed the limits
  clear_local_file(area_folder_sending);
  clear_local_file(area_folder_sended);
};

const transfer_file = (task_type, client) => {
  let abs_folder_sending = task_type === area_task ? area_folder_sending : line_folder_sending;
  let abs_folder_sended = task_type === area_task ? area_folder_sended : line_folder_sended;
  let folder_remote = task_type === area_task ? `${area_folder}/` : `${line_folder}/`;

  try {
    let file_list = get_file_list(abs_folder_sending);
    if (file_list.length < 1) {
      log(`[Error] TransferTask - List local files failed, files not found`);
      return Promise.resolve(false);
    }

    if (file_list.length > file_number_once) {
      file_list = file_list.slice(0, file_number_once);
    }

    return Promise.all(file_list.map((file) => {
      return new Promise((resolve) => {
        let local_src = `${abs_folder_sending}${file}`;
        let local_dst = `${abs_folder_sended}${file}`;
        let remote_dst_working = `${folder_remote}${file}${work_suffix}`;

        log(`[Info] TransferTask - Start transfer file: ${local_src}`);
        client.put(local_src, remote_dst_working, (err) => {
          if (err) {
            log(`[Error] TransferTask - FTP failed to put temp file: ${err.toString()}`);
            return resolve(false);
          }
          log(`[Info] TransferTask - FTP succeed to put temp file: ${remote_dst_working}`);
          let remote_dst_done = `${folder_remote}${file}`;
          client.rename(remote_dst_working, remote_dst_done, (err) => {
            if (err) {
              log(`[Error] TransferTask - FTP failed to rename file: ${err.toString()}`);
              return resolve(false);
            }
            log(`[Info] TransferTask - FTP succeed to rename file: ${remote_dst_done}`);
            try {
              fs.renameSync(local_src, local_dst);
              log(`[Info] TransferTask - Local succeed to move file: ${local_dst}`);
            } catch (err) {
              log(`[Error] TransferTask - Local failed to move file: ${err.toString()}`);
            }
            return resolve(true);
          });
        });
      });
    }));
  } catch (err) {
    log(`[Error] TransferTask - Transfer Task failed: ${task_type}, ${err.toString()}`);
    return Promise.resolve(false);
  }
};

const transfer_task = () => {
  log(`[Info] TransferTask - Task executed at ${new Date().toLocaleString()}!`);

  // Not transfer if no ftp info
  if (!ftp_host) {
    log(`[Info] TransferTask - Need not to transfer because there is no ftp info!`);
    // limit local file count
    clear_local_folders();
    return;
  }

  // Transfer by FTP
  try {
    // Initialize connect params
    let ftp_params = {
      host: ftp_host,
      port: ftp_port
    };

    // Use auth info if specified
    if (ftp_user) {
      ftp_params.user = ftp_user;
      ftp_params.password = ftp_password;
    }

    // Process connect ready event
    let client = new ftp();
    client.on('ready', async () => {
      log(`[Info] TransferTask - FTP connected`);
      // Transfer files in camera_line/sending folder
      transfer_file(line_task, client).then(() => {
        log(`[Info] TransferTask - FTP transfer line data over.`);
        // Remove local files if exceed the limits
        clear_local_file(line_folder_sending);
        clear_local_file(line_folder_sended);
        // Transfer files in camera_area/sending folder
        transfer_file(area_task, client).then(() => {
          log(`[Info] TransferTask - FTP transfer area data over.`);
          // Close FTP client
          client.end();
          client.destroy();
          // Remove local files if exceed the limits
          clear_local_file(area_folder_sending);
          clear_local_file(area_folder_sended);
          log(`[Info] TransferTask - Transfer Task over.`);
        });
      });
    });

    // Process connect error event
    client.on('error', (err) => {
      log(`[Error] TransferTask - FTP failed to connect: ${err.toString()}`);
      // limit local file count
      clear_local_folders();
    });

    // Start FTP connect
    client.connect(ftp_params);
  } catch (err) {
    log(`[Error] TransferTask - Transfer Task failed: ${err.toString()}`);
    // limit local file count
    clear_local_folders();
  }
};

const write_csv_if_no_data = !!config_json['write_csv_if_no_data'];
const aggregate_task = () => {
  // Get current time and interval_minutes min before
  let now = new Date();
  let cur_time = new Date(now.getTime() - 60 * 1000);
  let pre_time = new Date(now.getTime() - 60 * (interval_minutes + 1) * 1000);

  // Save result to temp array
  let tmp_line_result = line_result.slice();
  let tmp_area_result = area_result.slice();

  // Clear original array
  line_result = [];
  area_result = [];

  try {
    log(`[Info] AggregationTask - Task executed at ${now.toLocaleString()}!`);

    // Initialize file name
    let pre_year = String(pre_time.getFullYear());
    let pre_month = `0${pre_time.getMonth()+1}`.slice(-2);
    let pre_day = `0${pre_time.getDate()}`.slice(-2);
    let pre_hour = `0${pre_time.getHours()}`.slice(-2);
    let pre_minute = `0${pre_time.getMinutes()}`.slice(-2);
    let cur_hour = `0${cur_time.getHours()}`.slice(-2);
    let cur_minute = `0${cur_time.getMinutes()}`.slice(-2);
    let time_range = `${pre_year}${pre_month}${pre_day}${pre_hour}${pre_minute}-${cur_hour}${cur_minute}`;
    let line_file_name = `${atlas_name}_${line_task}_${time_range}.csv`;
    let area_file_name = `${atlas_name}_${area_task}_${time_range}.csv`;

    if (tmp_line_result.length > 0 || write_csv_if_no_data) {

      // Write temp line data to line csv file
      let line_file_content = [
        [column_camera, column_date, column_start, column_end, column_in, column_out].join(',')
      ];
      tmp_line_result.forEach(item => {
        line_file_content.push([
          item[column_camera],
          item[column_date],
          item[column_start],
          item[column_end],
          item[column_in],
          item[column_out]
        ].join(','));
      });

      try {
        // Save new line csv file in sending folder
        fs.writeFileSync(`${line_folder_sending}${line_file_name}`, line_file_content.join(newline));
      } catch (err) {
        log(`[Error] AggregationTask - Write line CSV file failed: ${line_folder_sending}, ${err.toString()}`);
      }
    }

    if (tmp_area_result.length > 0 || write_csv_if_no_data) {
      // Write temp area data to area csv file
      let area_file_content = [
        [column_camera, column_date, column_start, column_end, column_area].join(',')
      ];
      tmp_area_result.forEach(item => {
        area_file_content.push([
          item[column_camera],
          item[column_date],
          item[column_start],
          item[column_end],
          item[column_area]
        ].join(','));
      });

      try {
        // Save new area csv file in sending folder
        fs.writeFileSync(`${area_folder_sending}${area_file_name}`, area_file_content.join(newline));
      } catch (err) {
        log(`[Error] AggregationTask - Write area CSV file failed: ${area_folder_sending}, ${err.toString()}`);
      }
    }

    log(`[Info] AggregationTask - Aggregation Task over.`);
  } catch (err) {
    log(`[Error] AggregationTask - Aggregation Task failed: ${err.toString()}`);
  }
};

// Server start
app.listen(base_port, base_ip, () => {
  log(`[Info] App - Server App listening on ${base_ip}:${base_port}${base_path}!`);
});

// Scheduler start
log(`[Info] App - Schedule aggregation jobs at 0 seconds every ${interval_minutes} minutes!`);
schedule.scheduleJob(`0 */${interval_minutes} * * * *`, aggregate_task);

// Scheduler start
log(`[Info] App - Schedule transfer jobs at ${transfer_seconds} seconds every ${interval_minutes} minutes!`);
schedule.scheduleJob(`${transfer_seconds} */${interval_minutes} * * * *`, transfer_task);
