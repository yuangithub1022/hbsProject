/*!
 * Atlas Message Transfer Library
 * Hitachi Building Systems - v1.0.0
 */

const http = require('http');
const schedule = require('node-schedule');

const demo = (type, camera) => {
  const options = {
    method: 'POST',
    headers: {
      'Content-Type': 'text/plain; charset=utf-8'
    }
  }
  console.log(`UploadCaptureResult - ${type}: ${camera}`);
  post_data = {
    "task_id": "10002019090605114167101",
    "task_type": "TASK_TYPE_CROWD",
    "extra_info": {
      "task_name": camera,
    },
    "capture_time": new Date(),
    "capture_result": {
      "crowd": {
        
      }
    }
  };
  if (type==="line") {
    post_data.capture_result.crowd.type = "CROWD_TYPE_SEGMENTATION";
    post_data.capture_result.crowd.subclass = {
      segmentation: {
        forward: Math.ceil(Math.random() * 100),
        reverse: Math.ceil(Math.random() * 100)
      }
    };
  } else {
    post_data.capture_result.crowd.type = "CROWD_TYPE_HEADCOUNT";
    post_data.capture_result.crowd.subclass = {
      headcount: {
        count: Math.ceil(Math.random() * 100)
      }
    };
  }
  
  const request = http.request('http://localhost:5005/transfer/upload', options, response => {
    response.setEncoding('utf8');
    response.on('data', data => {
      console.log(`UploadCaptureResult - Simulate Result: ${data}`);
    });
  });
  request.on('error', error => {
    console.log(`UploadCaptureResult - Server Error: ${error.message}`);
  });
  console.log(JSON.stringify(post_data))
  request.write(JSON.stringify(post_data));
  request.end();
};

// Scheduler start
schedule.scheduleJob(`5 * * * * *`, ()=>{demo('line', '00000101')});

schedule.scheduleJob(`12 * * * * *`, ()=>{demo('line', '00000103')});

schedule.scheduleJob(`38 * * * * *`, ()=>{demo('line', '00000102')});

schedule.scheduleJob(`49 * * * * *`, ()=>{demo('line', '00000104')});

schedule.scheduleJob(`8 * * * * *`, ()=>{demo('area', '00000101')});

schedule.scheduleJob(`22 * * * * *`, ()=>{demo('area', '00000103')});

schedule.scheduleJob(`43 * * * * *`, ()=>{demo('area', '00000102')});

schedule.scheduleJob(`56 * * * * *`, ()=>{demo('area', '00000104')});
