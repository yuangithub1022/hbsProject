proc_name = 'AtlasFace-JsonTransmit'
bind = "0.0.0.0:5013"
workers = 3
worker_connections = 1000
