#!/bin/bash
PROJECT_PATH=/var/lib/docker/json
# scp -r huawei@192.168.40.216:"/home/huawei/json/source" "${PROJECT_PATH}/transfer"
scp -P 10092 -r root@172.30.50.101:"/home/huawei/json/source" "${PROJECT_PATH}/transfer"
rm -rf ${PROJECT_PATH}/source/*
mv ${PROJECT_PATH}/transfer/source/*  ${PROJECT_PATH}/source
${PROJECT_PATH}/util.sh -c stop
${PROJECT_PATH}/util.sh -c uninstall
docker build -t atlas_json:1.0.0 ${PROJECT_PATH}
${PROJECT_PATH}/util.sh -c start