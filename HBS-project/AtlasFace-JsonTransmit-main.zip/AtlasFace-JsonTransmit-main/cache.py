from expiringdict import ExpiringDict
from logger import logger


class Cache:
    def __init__(self, max_len=8, max_age_seconds=5):
        self.max_len = max_len
        self.cache = ExpiringDict(max_len=max_len, max_age_seconds=max_age_seconds)

    def add(self, key):
        self.cache[key] = 1

    def __clear_expired_keys(self):
        res = []
        for key in self.cache.keys():
            val = self.cache.get(key)
            if not val:
                res.append(val)
        if res:
            logger.info(f"{str(res)} expires")

    def __contains__(self, key):
        # update ttl if in cache
        if self.cache.get(key):
            self.cache[key] = 1
            return True
        return False

    def __len__(self):
        self.__clear_expired_keys()
        return len(self.cache)


# if __name__ == '__main__':
#     cache = Cache(2)
#     print(cache.get('1.1.1.1'))  # None
#     cache.add('1.1.1.1')
#     print(cache.get('1.1.1.1'))  # 1
#     cache.add('2.1.1.1')
#     cache.add('3.1.1.1')
#     print(len(cache.cache))   # 2
#     for key in cache.cache.keys():
#         print(key)
#
#     import time
#     for i in range(7):
#         if '1.1.1.1' in cache:
#             pass
#         time.sleep(1)
#
#     print(cache.get('1.1.1.1'))
#     print(cache.get('2.1.1.1'))
