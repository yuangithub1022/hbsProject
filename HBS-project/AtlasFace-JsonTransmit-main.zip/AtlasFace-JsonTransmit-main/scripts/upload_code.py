import paramiko
import glob
import os

machine = 'neu'
if machine == 'huawei':
    global_user_name = 'huawei'
    global_password = 'neusoftjapan'
else:
    global_user_name = 'root'
    global_password = 'NEVS0FT_12#$'


class MySFTPClient(paramiko.SFTPClient):
    def put_dir(self, source, target):
        """ Uploads the contents of the source directory to the target path. The
            target directory needs to exists. All subdirectories in source are
            created under target.
        """
        for item in os.listdir(source):
            if os.path.isfile(os.path.join(source, item)):
                self.put(os.path.join(source, item), f'{target}/{item}')
            else:
                self.mkdir(f'{target}/{item}', ignore_existing=True)
                self.put_dir(os.path.join(source, item), f'{target}/{item}')

    def mkdir(self, path, mode=511, ignore_existing=False):
        """ Augments mkdir by adding an option to not fail if the folder exists  """
        try:
            super(MySFTPClient, self).mkdir(path, mode)
        except IOError:
            if ignore_existing:
                pass
            else:
                raise


def upload_files(host, port, ftp_dir, local_dir, file_names):
    # Open a transport
    transport = paramiko.Transport((host, port))

    # Auth
    username,password = global_user_name, global_password
    transport.connect(None, username, password)

    # Go!
    sftp = paramiko.SFTPClient.from_transport(transport)

    # Upload
    for file_name in file_names:
        filepath = f'{ftp_dir}{file_name}'
        localpath = f'{local_dir}{file_name}'
        sftp.put(localpath, filepath)

    # Close
    if sftp:
        sftp.close()
    if transport:
        transport.close()


def upload_dir(host, port, ftp_dir, local_dir):
    # Open a transport
    transport = paramiko.Transport((host, port))

    # Auth
    username,password = global_user_name, global_password
    transport.connect(None, username, password)

    # Go!
    sftp = MySFTPClient.from_transport(transport)

    # Upload
    sftp.put_dir(local_dir, ftp_dir)

    # Close
    if sftp:
        sftp.close()
    if transport:
        transport.close()


if __name__ == "__main__":
    file_names = ['app.py', 'logger.py', 'api_calls.py', 'constants.py', 'cache.py',
                  'gunicorn_settings.py', 'wsgi.py', 'requirements.txt']
    if machine == 'huawei':
        upload_files("124.219.161.88", 21622, '/home/huawei/json/source/',
                     "C:\\Users\\datsm\\Desktop\\projects\\AtlasFace-JsonTransmit\\", file_names)
    elif machine == 'neu':
        upload_files("cloud.neusoft.co.jp", 10092, '/home/huawei/json/source/',
                     "C:\\Users\\datsm\\Desktop\\projects\\AtlasFace-JsonTransmit\\", file_names)
