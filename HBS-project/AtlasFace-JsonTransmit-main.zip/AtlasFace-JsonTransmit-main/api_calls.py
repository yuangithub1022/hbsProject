import warnings
import requests

warnings.filterwarnings('ignore', message='Unverified HTTPS request')


def post_json(url, data, headers=None, timeout=5):
    return requests.post(url, json=data, timeout=timeout, verify=False,
                         headers={} if headers is None else headers)


def get_call(url, headers=None, timeout=5):
    return requests.get(url, timeout=timeout, verify=False,
                        headers={} if headers is None else headers)


def face_api_log_in_call(face_api_ip):
    url = f'https://{face_api_ip}/components/operation-maintenance/v1/users/sign_in'
    data = {
        'user': 'admin',
        'password': 'Atlas@2019'
    }
    res = post_json(url, data)
    return res


def face_api_get_version_call(face_api_ip, token):
    url = f'https://{face_api_ip}/components/operation-maintenance/v1/version'
    res = get_call(url, headers={'Authorization': token})
    return res


def face_api_db_list_call(face_api_ip, token):
    url = f'https://{face_api_ip}/engine/alert-feature/v1/databases'
    res = get_call(url, headers={'Authorization': token})
    return res


def face_api_db_new_call(face_api_ip, token, db_name='stranger'):
    url = f'https://{face_api_ip}/engine/alert-feature/v1/databases'
    data = {
        'name': db_name
    }
    res = post_json(url, data, headers={'Authorization': token})
    return res


def face_api_db_1_to_n_call(face_api_ip, token, db_ids, portrait, min_score=0.8):
    url = f'https://{face_api_ip}/engine/alert-feature/v1/databases/image_search'
    data = {
       'id': db_ids,
       'min_score': min_score,
       'image': {
          'data': portrait
       }
    }
    res = post_json(url, data, headers={'Authorization': token})
    return res


def face_api_user_batch_add_call(face_api_ip, token, db_id, data):
    url = f'https://{face_api_ip}/engine/alert-feature/v1/databases/{db_id}/users'
    res = post_json(url, data, headers={'Authorization': token})
    return res


def face_api_set_storage_policy(face_api_ip, token):
    url = f'https://{face_api_ip}/engine/feature-process/v1/storage_policy'
    data = {
        'policy': 'REMOTE'
    }
    res = post_json(url, data, headers={'Authorization': token})
    return res


def face_api_download_image_call(face_api_ip, token, url):
    url = f'https://{face_api_ip}/components/osg-default/v1/objects/{url}'
    res = get_call(url, headers={'Authorization': token})
    return res


def http_server_upload_call(http_server_address, data):
    res = post_json(http_server_address, data)
    return res
