import atexit
import base64
import json
import os
import platform
import socket

from apscheduler.schedulers.background import BackgroundScheduler
from flask import Flask, request

from api_calls import *
from cache import Cache
from constants import *
from logger import logger

# Init app and default config
app = Flask(__name__)
app.config[FACE_API_IP] = ''
app.config[TOKEN] = ''
app.config[STRANGER_LIB_ID] = ''
app.config[HTTP_SERVER_ADDRESS] = ''
app.config[MAX_NUM_ADDRESSES] = 8
app.config[ADDRESS_TTL] = 5

# Update config if config file exists
base_dir = '.' if platform.system() == 'Windows' else '/var/json'
config_file = f'{base_dir}/config.json'

if os.path.isfile(config_file):
    with open(config_file) as f:
        try:
            config = json.load(f)
            if config:
                app.config.update(config)
        except Exception as err:
            logger.warning('Read config file error', err)

# cache to store recent ips
cache = Cache(app.config[MAX_NUM_ADDRESSES], app.config[ADDRESS_TTL])


def get_client_ip():
    client_ip = str(request.remote_addr)

    if client_ip not in cache and len(cache) >= app.config[MAX_NUM_ADDRESSES]:
        return ''

    cache.add(client_ip)
    return client_ip


@app.route('/upload', methods=['POST'])
def upload():
    # get client ip
    client_ip = get_client_ip()
    if not client_ip:
        err_msg = f'More than {app.config[MAX_NUM_ADDRESSES]} IP addresses'
        logger.error(err_msg)
        return err_msg, 403

    # get json
    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
    except Exception as e:
        err_msg = f'Cannot get json from frontend atlas, {e}'
        logger.warning(err_msg)
        return err_msg, 400

    # check face result from frontend atlas
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_FACE':
        return 'Invalid task_type', 400
    if 'extra_info' not in post_data or 'task_name' not in post_data['extra_info']:
        return 'Invalid extra_info', 400
    if 'capture_result' not in post_data or 'face' not in post_data['capture_result']:
        return False

    extra_info = post_data['extra_info']
    min_score = extra_info['min_score'] if 'min_score' in extra_info else 0
    face_result = post_data['capture_result']['face']

    # get portrait
    try:
        portrait = post_data['capture_result']['face']['portrait']['data']
    except:
        return 'Cannot get portrait', 400

    # get min_score
    try:
        min_score = float(min_score)
    except:
        err_msg = 'min_score is not a number'
        logger.warning(err_msg)
        return err_msg, 400

    # get db ids
    res = None
    try:
        res = face_api_db_list_call(app.config[FACE_API_IP], app.config[TOKEN])
        if res.status_code != 200:
            logger.warning(f'db_list call status code is {res.status_code}')
        db_list = res.json()['databases']
        db_ids = [db['id'] for db in db_list]
    except Exception as e:
        if res:
            err_msg = f'Cannot get db list, {res.content}'
        else:
            err_msg = f'Cannot get db list, {e}'
        logger.warning(err_msg)
        return err_msg, 500

    # 1 to n call -> check if not found
    try:
        res = face_api_db_1_to_n_call(app.config[FACE_API_IP], app.config[TOKEN], db_ids, portrait, min_score)
        res = res.json()
    except Exception as e:
        err_msg = f'Cannot make 1-n call, {e}'
        logger.warning(err_msg)
        return err_msg, 500

    # add card id if unidentified
    is_unidentified = 'error' in res
    if is_unidentified:
        # get card_id from extra_info
        if 'card_id' not in extra_info:
            err_msg = 'card_id is not in extra_info'
            logger.warning(err_msg)
            return err_msg, 400
        card_id = extra_info['card_id']

        # set card_id
        if 'most_similar_user' not in face_result or not face_result['most_similar_user']:
            face_result['most_similar_user'] = {'card_id': card_id}
        else:
            face_result['most_similar_user']['card_id'] = card_id

        # get gender, age, respirator
        try:
            gender = face_result['attributes']['gender']
        except:
            gender = 'UNKNOWN'

        try:
            age = face_result['attributes']['age']
        except:
            age = 0

        # add to stranger db
        data = {
            'db_id': app.config[STRANGER_LIB_ID],
            'users': [{
                'card_id': card_id,
                'gender': gender,
                'age': age,
                'image': {
                    'data': portrait,
                }
            }]
        }

        if app.config[STRANGER_LIB_ID] not in db_ids:
            if app.config[STRANGER_LIB_ID]:
                logger.warning('Original stranger lib id not in current db ids')
            init_stranger_db()

        try:
            res = face_api_user_batch_add_call(app.config[FACE_API_IP], app.config[TOKEN],
                                               app.config[STRANGER_LIB_ID], data)
            if res.status_code != 200:
                logger.warning(f'user_batch_add_call status code is {res.status_code}')
        except Exception as e:
            err_msg = f'Cannot make the batch add call, {e}'
            logger.warning(err_msg)
            return err_msg, 500

    # use the response to set
    else:
        if 'id' in res:
            face_result['db_id'] = res['id']
        if 'score' in res:
            face_result['score'] = res['score']
        if 'user' in res:
            face_result['most_similar_user'] = res['user']

        most_similar_user = face_result['most_similar_user'] if 'most_similar_user' in face_result else {}
        try:
            data = most_similar_user['image']['data']
            url = most_similar_user['image']['url']
        except:
            data = url = None

        if not data and url:
            try:
                resp = face_api_download_image_call(app.config[FACE_API_IP], app.config[TOKEN], url)
            except Exception as e:
                resp = None
                logger.info(f'Cannot make the call of downloading image, {e}')

            if resp:
                try:
                    base64_str = base64.b64encode(resp.content).decode('utf-8')
                except Exception as e:
                    base64_str = ''
                    logger.info(f'Unable to parse downloaded image, {e}')
                most_similar_user['image']['data'] = base64_str

    # send json
    if not app.config[HTTP_SERVER_ADDRESS]:
        err_msg = 'HTTP_SERVER_ADDRESS is empty'
        logger.warning(err_msg)
        return err_msg, 500

    # add client_ip to extra_info client_ip
    extra_info['client_ip'] = client_ip

    # add atlas_ip to extra_info
    extra_info['host_ip'] = get_ip()

    try:
        http_server_upload_call(app.config[HTTP_SERVER_ADDRESS], post_data)
    except Exception as e:
        err_msg = f'Cannot post to http server, {e}'
        logger.warning(err_msg)
        return err_msg, 500

    if is_unidentified:
        logger.info(f'Unidentified JSON sent to http server, {app.config[HTTP_SERVER_ADDRESS]}')
    else:
        logger.info(f'Identified JSON sent to http server, {app.config[HTTP_SERVER_ADDRESS]}')

    return 'success', 200


def get_token():
    try:
        res = face_api_log_in_call(app.config[FACE_API_IP])
    except Exception as e:
        err_msg = f'Cannot make the login call, {e}'
        logger.warning(err_msg)
        return

    # get token
    try:
        app.config[TOKEN] = res.json()['token']
    except Exception as e:
        err_msg = f'Cannot get token from response, {e}. Face device: {res.content}'
        logger.warning(err_msg)
        return


def get_new_stranger_db_id():
    try:
        res = face_api_db_new_call(app.config[FACE_API_IP], app.config[TOKEN])
        if res.status_code != 200:
            logger.warning(f'db_new_call status code is {res.status_code}')
    except Exception as e:
        err_msg = f'Cannot make the db new call, {e}'
        logger.warning(err_msg)
        return ''

    try:
        res = res.json()
    except Exception as e:
        err_msg = f'Cannot convert the response of db new call to json, {e}'
        logger.warning(err_msg)
        return ''

    if 'id' not in res:
        logger.warning(f'Cannot find id in db new call')
        return ''
    else:
        return res['id']


def init_stranger_db():
    # db list call
    try:
        res = face_api_db_list_call(app.config[FACE_API_IP], app.config[TOKEN])
        if res.status_code != 200:
            logger.warning(f'db_list call status code is {res.status_code}')
    except Exception as e:
        err_msg = f'Cannot make the db list call, {e}'
        logger.warning(err_msg)
        return

    # get face libs
    try:
        face_libs = res.json()['databases']
    except Exception as e:
        err_msg = f'Cannot get token from response, {e}. Face device: {res.content}'
        logger.warning(err_msg)
        return

    # check if the stranger lib exists
    for lib in face_libs:
        if 'name' not in lib:
            logger.warning(f'name not in lib: {lib}')
            continue
        if lib['name'] == 'stranger':
            logger.info('stranger lib already exists.')
            app.config[STRANGER_LIB_ID] = lib['id']
            return

    # db new call
    app.config[STRANGER_LIB_ID] = get_new_stranger_db_id()

# def set_remote_storage_policy():
#     try:
#         res = face_api_set_storage_policy(app.config[FACE_API_IP], app.config[TOKEN])
#         if res.status_code != 200:
#             logger.warning(f'Storage policy call status is not 200, {res}')
#     except Exception as e:
#         logger.warning(f'Cannot make the set storage policy call, {e}')


def get_version():
    try:
        res = face_api_get_version_call(app.config[FACE_API_IP], app.config[TOKEN])
        if res.status_code != 200:
            logger.warning(f'get_version_call status code is {res.status_code}.')
        logger.info(f'get_version_call to keep token alive: {res.json()}')
    except Exception as e:
        logger.warning(f'Cannot make the get version call, {e}')


def get_ip():
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        # doesn't even have to be reachable
        s.connect(('10.255.255.255', 1))
        ip = s.getsockname()[0]
    except Exception as e:
        logger.error(f'get_ip error: {e}')
        ip = '127.0.0.1'
    finally:
        s.close()
    return ip


# init scheduler for regular jobs
scheduler = BackgroundScheduler()
scheduler.add_job(func=get_version, trigger='interval', seconds=240)
scheduler.start()

# shut down the scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())
get_token()

if __name__ == '__main__':
    app.run(debug=False, host='0.0.0.0', port=5013)
