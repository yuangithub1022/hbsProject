顔登録アプリインストーラー
----

### 顔認証データ登録アプリインストーラー

## 事前準備
1. [Atlas-FaceAdmin]プロジェクトをクローンしてビルドする

2. 本プロジェクト(32bitと64bit両方)と[Atlas-FaceAdmin]プロジェクトを同一ディレクトリにコピペする

   ![same_dir](same_dir.png)

3. [Atlas-FaceAdmin]プロジェクトを開き、Microsoft Visual Studio Installer Projectsというエクステンションをインストールする

4. 「ソリューション追加」－「既存のプロジェクト」で本プロジェクト(32bitと64bit両方)を追加する

## 32bitインストーラーの作成
1. ビルド配置で「Release と Any CPU」を選択して、「RegisterFaceAuthToolSetup」をリビルドする

## 64bitインストーラーの作成
1. ビルド配置で「Release と x64」を選択して、「RegisterFaceAuthToolSetup(x64)」をリビルドする

