#!/bin/bash

AUTO_START_FILE=/var/lib/docker/APPPreInstall/app_autostart.sh

usage() {
    echo
    echo -e "usage: $(basename "$0") -c command -t task_type"
    echo -e "[M]\t-c  : command = install | uninstall | start | stop"
    echo -e "[O]\t-t  : task_type = ALL (default) | WEB_APP | DATABASE"
    echo -e "M=mandatory, O=optional"
    echo
    exit 1
}

parse_args() {
	  # global variable
	  typ="ALL"
	  while getopts "c:t:h" arg; do
	  	  case $arg in
	  		    c) readonly cmd="$OPTARG";;
	            t) readonly typ="$OPTARG";;
	  		    h) usage;;
	  		    ?) usage;;
	  	  esac
	  done

	  [[ $cmd != "install" && $cmd != "uninstall" && $cmd != "start" && $cmd != "stop" ]] && usage
	  [[ $typ != "ALL" && $typ != "WEB_APP" && $typ != "DATABASE" ]] && usage
}

install() {
    mkdir /home/store
    mount /dev/mmcblk0p9 /home/store
    mkdir /home/store/postgres_data

    if [[ "$typ" == "ALL" ]]; then
	    docker load -i atlas_temp.1.0.0.tar.gz
	    docker load -i postgres.12.3-alpine.tar.gz
	elif [[ "$typ" == "WEB_APP" ]]; then
	    docker load -i atlas_temp.1.0.0.tar.gz
	else
	    docker load -i postgres.12.3-alpine.tar.gz
	fi
    write_to_auto_start
}

uninstall() {
    if [[ "$typ" == "ALL" ]]; then
        docker rmi postgres:12.3-alpine
	    docker rmi atlas_temp:1.0.0
	elif [[ "$typ" == "WEB_APP" ]]; then
	    docker rmi atlas_temp:1.0.0
	else
	    docker rmi postgres:12.3-alpine
	fi
	    del_auto_start_commands
}

start() {
    mount /dev/mmcblk0p9 /home/store

    if [[ "$typ" == "ALL" ]]; then
        docker run -p 5432:5432 \
                   -v /home/store/postgres_data:/var/lib/postgresql/data \
                   --name=atlas_postgres \
                   --log-opt max-size=1m \
                   --log-opt max-file=3 \
                   -d postgres:12.3-alpine
        docker run -p 5020:5020 \
                   -v /home/store:/home/store \
                   -v /var/lib/docker/temp/config:/var/temp \
                   -v /usr/local/bin/elabel:/usr/local/bin/elabel \
                   -v /usr/lib64/libcommonbase.so:/usr/lib64/libcommonbase.so \
                   --device=/dev/i2c-8 \
                   --device=/dev/ttyAMA3 \
                   --name=atlas_temp \
                   --log-opt max-size=1m \
                   --log-opt max-file=3 \
                   -d atlas_temp:1.0.0

    elif [[ "$typ" == "WEB_APP" ]]; then
        docker run -p 5020:5020 \
                   -v /home/store:/home/store \
                   -v /var/lib/docker/temp/config:/var/temp \
                   -v /usr/local/bin/elabel:/usr/local/bin/elabel \
                   -v /usr/lib64/libcommonbase.so:/usr/lib64/libcommonbase.so \
                   --device=/dev/i2c-8 \
                   --device=/dev/ttyAMA3 \
                   --name=atlas_temp \
                   --log-opt max-size=1m \
                   --log-opt max-file=3 \
                   -d atlas_temp:1.0.0

    else
        docker run -p 5432:5432 \
                   -v /home/store/postgres_data:/var/lib/postgresql/data \
                   --name=atlas_postgres \
                   --log-opt max-size=1m \
                   --log-opt max-file=3 \
                   -d postgres:12.3-alpine
    fi
}


stop() {
    if [[ "$typ" == "ALL" ]]; then
	    docker stop atlas_temp
	    docker rm atlas_temp
	    docker stop atlas_postgres
	    docker rm atlas_postgres
	elif [[ "$typ" == "WEB_APP" ]]; then
	    docker stop atlas_temp
	    docker rm atlas_temp
	else
	    docker stop atlas_postgres
	    docker rm atlas_postgres
	fi
}

write_to_auto_start()
{
    if [ ! -f "$AUTO_START_FILE" ] ; then
        return
    fi

    DIR="$( cd "$( dirname "$0" )" && pwd )"

    if grep -q "${DIR}/util.sh -c start" "$AUTO_START_FILE"; then
        return
    fi
    
    sed -i "/user_custom_func(){/a\ \ \ \ ${DIR}/util.sh -c start" $AUTO_START_FILE
}

del_auto_start_commands()
{
    if [ ! -f "$AUTO_START_FILE" ] ; then
        return
    fi

    DIR="$( cd "$( dirname "$0" )" && pwd )"

    local command="${DIR}/util.sh -c start"

    sed -i "\:${command}:d" $AUTO_START_FILE
}

main() {
    parse_args "$@"
    [[ $cmd == "install" ]] && install
    [[ $cmd == "uninstall" ]] && uninstall
    [[ $cmd == "start" ]] && start
    [[ $cmd == "stop" ]] && stop
}

main "$@"
