#!/bin/bash

usage() {
    echo
    echo -e "usage: $(basename "$0") -c command"
    echo -e "[M]\t-c  : command = install | uninstall | start | stop"
    echo -e "M=mandatory, O=optional"
    echo
    exit 1
}

parse_args() {
	# global variable
	while getopts "c:h" arg; do
		case $arg in
			c) readonly cmd="$OPTARG";;
			h) usage;;
			?) usage;;
		esac
	done

	[[ $cmd != "install" && $cmd != "uninstall" && $cmd != "start" && $cmd != "stop" ]] && usage
}

install() {
	docker load -i postgres.12.3-alpine.tar.gz
}

uninstall() {
	docker rmi postgres:12.3-alpine
}

start() {
        docker run -p 5432:5432 \
            -v /var/temp/postgres_data:/var/lib/postgresql/data \
            -e POSTGRES_PASSWORD=admin \
            -e POSTGRES_DB=temp_backend \
            --name=atlas_postgres \
            --log-opt max-size=1m \
            --log-opt max-file=3 \
            -d postgres:12.3-alpine
    docker logs atlas_postgres
}


stop() {
	docker stop atlas_postgres
	docker rm atlas_postgres
}

main() {
        parse_args "$@"

        [[ $cmd == "install" ]] && install
        [[ $cmd == "uninstall" ]] && uninstall
        [[ $cmd == "start" ]] && start
        [[ $cmd == "stop" ]] && stop
}

main "$@"
