#!/bin/bash

usage() {
    echo
    echo -e "usage: $(basename "$0") -c command"
    echo -e "[M]\t-c  : command = install | uninstall | start | stop"
    echo -e "M=mandatory, O=optional"
    echo
    exit 1
}

parse_args() {
	# global variable
	while getopts "c:h" arg; do
		case $arg in
			c) readonly cmd="$OPTARG";;
			h) usage;;
			?) usage;;
		esac
	done

	[[ $cmd != "install" && $cmd != "uninstall" && $cmd != "start" && $cmd != "stop" ]] && usage
}

install() {
	docker load -i atlas_temp.1.0.0.tar.gz
}

uninstall() {
	docker rmi atlas_temp:1.0.0
}

start() {
        docker run -p 5020:5020 \
            -v /var/temp:/var/temp \
            -v /usr/local/bin/elabel:/usr/local/bin/elabel \
            -v /usr/lib64/libcommonbase.so:/usr/lib64/libcommonbase.so \
            --device=/dev/i2c-8 \
            --device=/dev/ttyAMA3 \
            --name=atlas_temp \
            --log-opt max-size=1m \
            --log-opt max-file=3 \
            -d atlas_temp:1.0.0
    docker logs atlas_temp
}


stop() {
	docker stop atlas_temp
	docker rm atlas_temp
}

main() {
        parse_args "$@"

        [[ $cmd == "install" ]] && install
        [[ $cmd == "uninstall" ]] && uninstall
        [[ $cmd == "start" ]] && start
        [[ $cmd == "stop" ]] && stop
}

main "$@"
