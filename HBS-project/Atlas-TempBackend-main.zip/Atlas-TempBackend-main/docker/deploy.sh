#!/bin/bash
PROJECT_PATH=/var/lib/docker/temp
scp -r huawei@192.168.40.216:"/home/huawei/temp/frontend /home/huawei/temp/backend" "${PROJECT_PATH}/transfer"
rm -rf ${PROJECT_PATH}/frontend/*
rm -rf ${PROJECT_PATH}/backend/*
mv ${PROJECT_PATH}/transfer/frontend/* ${PROJECT_PATH}/frontend
mv ${PROJECT_PATH}/transfer/backend/* ${PROJECT_PATH}/backend
${PROJECT_PATH}/util.sh -c stop -t WEB_APP
${PROJECT_PATH}/util.sh -c uninstall -t WEB_APP
docker build -t atlas_temp:1.0.0 ${PROJECT_PATH}
${PROJECT_PATH}/util.sh -c start -t WEB_APP

