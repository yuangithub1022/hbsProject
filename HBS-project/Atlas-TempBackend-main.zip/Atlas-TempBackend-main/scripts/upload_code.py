import paramiko
import glob
import os
import platform

machine = 'neu'
if machine == 'huawei':
    global_user_name = 'huawei'
    global_password = 'neusoftjapan'
else:
    global_user_name = 'root'
    global_password = 'NEVS0FT_12#$'


class MySFTPClient(paramiko.SFTPClient):
    def put_dir(self, source, target):
        """ Uploads the contents of the source directory to the target path. The
            target directory needs to exists. All subdirectories in source are
            created under target.
        """
        for item in os.listdir(source):
            if os.path.isfile(os.path.join(source, item)):
                self.put(os.path.join(source, item), f'{target}/{item}')
            else:
                self.mkdir(f'{target}/{item}', ignore_existing=True)
                self.put_dir(os.path.join(source, item), f'{target}/{item}')

    def mkdir(self, path, mode=511, ignore_existing=False):
        """ Augments mkdir by adding an option to not fail if the folder exists  """
        try:
            super(MySFTPClient, self).mkdir(path, mode)
        except IOError:
            if ignore_existing:
                pass
            else:
                raise


def upload_file(host, port, ftp_dir, local_dir, file_names):
    # Open a transport
    transport = paramiko.Transport((host, port))

    # Auth    
    username,password = global_user_name, global_password
    transport.connect(None, username, password)

    # Go!    
    sftp = paramiko.SFTPClient.from_transport(transport)

    # Upload
    for file_name in file_names:
        filepath = f'{ftp_dir}{file_name}'
        localpath = f'{local_dir}{file_name}'
        sftp.put(localpath, filepath)

    # Close
    if sftp: 
        sftp.close()
    if transport: 
        transport.close()


def upload_dir(host, port, ftp_dir, local_dir):
    # Open a transport
    transport = paramiko.Transport((host, port))

    # Auth    
    username,password = global_user_name, global_password
    transport.connect(None, username, password)

    # Go!    
    sftp = MySFTPClient.from_transport(transport)

    # Upload
    sftp.put_dir(local_dir, ftp_dir)

    # Close
    if sftp: 
        sftp.close()
    if transport: 
        transport.close()


if __name__ == "__main__":
    project_dir = 'C:\\Users\\datsm\\Desktop\\projects\\Atlas-TempBackend\\' \
        if platform.system() == 'Windows' else '/home/mai/projects/Atlas-TempBackend/'
    file_names = ['app.py', 'api_calls.py', 'facelib.so',
                  'constants.py', 'logger.py', 'lru_cache.py',
                  'requirements.txt', 'util.py']

    if machine == 'huawei':
        upload_file("124.219.161.88", 21622, '/home/huawei/temp/backend/',
                    project_dir, file_names)
    elif machine == 'neu':
        upload_file("cloud.neusoft.co.jp", 10092, '/home/huawei/temp/backend/',
                    project_dir, file_names)

    file_dir = project_dir + 'models\\' if platform.system() == 'Windows' else 'models/'
    file_names = [os.path.basename(file_path) for file_path in glob.glob(f'{file_dir}*.py')]
    if machine == 'huawei':
        upload_file("124.219.161.88", 21622, '/home/huawei/temp/backend/models/',
                    file_dir, file_names)
    elif machine == 'neu':
        upload_file("cloud.neusoft.co.jp", 10092, '/home/huawei/temp/backend/models/',
                    file_dir, file_names)

    file_dir = project_dir + 'resources\\' if platform.system() == 'Windows' else 'model/'
    file_names = [os.path.basename(file_path) for file_path in glob.glob(f'{file_dir}*.py')]
    if machine == 'huawei':
        upload_file("124.219.161.88", 21622, '/home/huawei/temp/backend/resources/',
                    file_dir, file_names)
    elif machine == 'neu':
        upload_file("cloud.neusoft.co.jp", 10092, '/home/huawei/temp/backend/resources/',
                    file_dir, file_names)

    # if machine == 'huawei':
    #     upload_dir("124.219.161.88", 21622, '/home/huawei/temp/backend/docker',
    #                'C:\\Users\\datsm\\Desktop\\Atlas-TempBackend\\docker')
    # elif machine == 'neu':
    #     upload_dir("cloud.neusoft.co.jp", 10092, '/home/huawei/temp/backend/docker',
    #                'C:\\Users\\datsm\\Desktop\\Atlas-TempBackend\\docker')

    # upload_dir("124.219.161.88", 21622, '/root/koshien/koshien/source/frontend/dist',
    #            'C:\\Users\\datsm\\Desktop\\AtlasFace-Koshien\\frontend\\dist')