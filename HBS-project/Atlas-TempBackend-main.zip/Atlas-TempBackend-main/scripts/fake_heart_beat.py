import asyncio
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
import requests
import time


def post_x_www_form_urlencoded(session, url, device_key, timeout=5):
    content = {
        'deviceKey': device_key,
        'time': int(datetime.now().timestamp() * 1000),
        'ip': '1.1.1.1'
    }
    headers = {'content-type': 'application/x-www-form-urlencoded'}
    with session.post(url, data=content, timeout=timeout, verify=False, headers=headers) as response:
        return response


async def fake_heartbeat_calls(api_ip, device_keys):
    num = len(device_keys)
    endpoints = [f'http://{api_ip}/backend/device/heartbeat'] * num

    with ThreadPoolExecutor(max_workers=10) as executor:
        with requests.Session() as session:
            loop = asyncio.get_event_loop()
            tasks = [
                loop.run_in_executor(
                    executor,
                    post_x_www_form_urlencoded,
                    *(session, endpoint, device_key)
                )
                for endpoint, device_key in zip(endpoints, device_keys)
            ]
            for response in await asyncio.gather(*tasks):
                print(response.content)


def main():
    device_keys = [
        '1234567890'
    ]
    # api_ip = 'localhost:5021'
    api_ip = 'cloud.neusoft.co.jp'
    while True:
        try:
            loop = asyncio.get_event_loop()
            future = asyncio.ensure_future(fake_heartbeat_calls(api_ip, device_keys))
            loop.run_until_complete(future)
        except Exception as e:
            print(f'Cannot post, {e}')
        time.sleep(60)


if __name__ == '__main__':
    main()
