import hashlib
import sys


def generate_key(argv):
    if len(argv) != 3:
        print('Usage: python generate_key.py [SERIAL_NUMBER] -a or python generate_key.py [SERIAL_NUMBER] -b or python generate_key.py [SERIAL_NUMBER] -s')
        return

    serial_number, command = argv[1], argv[2]

    if command != '-a' and command != '-b' and command != '-s':
        print('Usage: python generate_key.py [SERIAL_NUMBER] -a or python generate_key.py [SERIAL_NUMBER] -b or python generate_key.py [SERIAL_NUMBER] -s')
        return

    base_key = f'{serial_number}_base'
    standard_key = f'{serial_number}_standard'
    advance_key = f'{serial_number}_advanced'
    base_key = hashlib.sha256(base_key.encode('utf-8')).hexdigest()
    standard_key = hashlib.sha256(standard_key.encode('utf-8')).hexdigest()
    advance_key = hashlib.sha256(advance_key.encode('utf-8')).hexdigest()

    if command == '-b':
        try:
            with open('license.key', 'w') as f:
                f.write(base_key)
        except Exception as e:
            print(f'Cannot output key file, {e}')
    elif command == '-s':
        try:
            with open('license.key', 'w') as f:
                f.write(standard_key)
        except Exception as e:
            print(f'Cannot output key file, {e}')
    else:
        try:
            with open('license.key', 'w') as f:
                f.write(advance_key)
        except Exception as e:
            print(f'Cannot output key file, {e}')


if __name__ == '__main__':
    # # usage: python generate_key.py 1234 -a
    # generate_key(sys.argv)

    # call by function
    serial_num = '2102312NNU10KA000001'
    cmd = '-a'
    generate_key([0, serial_num, cmd])
