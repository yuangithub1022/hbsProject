# class Node:
#     def __init__(self, key):
#         self.prev = self.next = None
#         self.key = key
#
#
# class MyDeque:
#     def __init__(self):
#         self.h = {}  # key -> Node
#         self.d = Node(0)
#         self.d.prev = self.d.next = self.d
#
#     def append(self, key):
#         new_node = Node(key)
#         new_node.next = self.d
#         new_node.prev = self.d.prev
#         self.d.prev.next = new_node
#         self.d.prev = new_node
#         self.h[key] = new_node
#
#     def popleft(self):
#         if not self.d.next:
#             return None
#
#         head_node = self.d.next
#         new_head_node = head_node.next
#         head_node.next = head_node.prev = None
#         self.d.next = new_head_node
#         if new_head_node:
#             new_head_node.prev = self.d
#
#         key = head_node.key
#         del self.h[key]
#         return key
#
#     def remove(self, key):
#         if key not in self.h:
#             return
#
#         node = self.h[key]
#         prev_node, next_node = node.prev, node.next
#         prev_node.next = next_node
#         next_node.prev = prev_node
#         node.prev = node.next = None
#         del self.h[key]
import collections


class LRUCache:
    instance = None

    def __init__(self, capacity):
        if not LRUCache.instance:
            self.h = {}
            self.q = collections.deque()
            self.size = 0
            self.capacity = capacity
            LRUCache.instance = self
        else:
            LRUCache.instance.capacity = capacity

    def get_last_key(self):
        if not LRUCache.instance.q:
            return ''
        return LRUCache.instance.q[-1]

    def get(self, key):
        if key not in LRUCache.instance.h:
            return None

        LRUCache.instance.q.remove(key)
        LRUCache.instance.q.append(key)
        return LRUCache.instance.h[key]

    def put(self, key, value):
        if key in LRUCache.instance.h:
            LRUCache.instance.q.remove(key)
            LRUCache.instance.append(key)
            LRUCache.instance.h[key] = value
            return

        if LRUCache.instance.size == LRUCache.instance.capacity:
            old_key = LRUCache.instance.q.popleft()
            del LRUCache.instance.h[old_key]
            LRUCache.instance.size -= 1

        LRUCache.instance.h[key] = value
        LRUCache.instance.q.append(key)
        LRUCache.instance.size += 1

    def delete(self, key):
        if key not in LRUCache.instance.h:
            return

        LRUCache.instance.q.remove(key)
        del LRUCache.instance.h[key]
        LRUCache.instance.size -= 1

    def __contains__(self, key):
        return self.get(key)
