# Before Commit

Make sure all files take up less than 10 MB!

# Installation

```
pip install -r requirements.txt
```

# Run

```
python app.py
```



# Upload Code to Atlas

```
python ./scripts/upload_code.py
```
Customize upload contents and target device info in the main function. 

# Enum
License status:
```
-1: invalid
0: base
1: advanced
```

# Device maker
```buildoutcfg
1: new temp
2: iflyer
```

# Appendix
Linux find command location
```buildoutcfg
type -a elabel
```

Euler base
```buildoutcfg
docker run -it -v /usr/local/bin/elabel:/usr/local/bin/elabel atlas500_euleros2.8.0.270_64bit_aarch64_basic:latest /bin/bash
```

Run bash file
```buildoutcfg
sed -i -e 's/\r$//' scriptname.sh
```