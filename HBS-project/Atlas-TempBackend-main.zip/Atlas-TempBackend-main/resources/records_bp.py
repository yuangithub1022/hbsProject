import base64
import json
from datetime import datetime

from flask import Blueprint, jsonify, request, abort, Response
from flask import current_app as app
from flask_socketio import emit

from api_calls import delete_records_call
from constants import DEVICE_OFFLINE_TIMEOUT, FRONTEND_TOKEN, UNAUTHORIZED, LICENSE_STATUS, FC_SENSEPASS
from logger import logger
from models.device import Devices
from models.record import Records

records_bp = Blueprint('records_bp', __name__)


@records_bp.route('', methods=['POST'])
def get_records():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")

    # parse post data
    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
        start_date = post_data['time_range.start']
        end_date = post_data['time_range.end']

    except Exception as e:
        err_msg = f'Invalid request. {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        page_no = post_data['page_no']
        page_limit = post_data['page_limit']
    except:
        page_no = -1
        page_limit = -1

    try:
        dev_id = post_data['task_id']
    except:
        dev_id = ''

    try:
        user_identified_state = post_data['user_identified_state']
    except:
        user_identified_state = ''

    try:
        temperature_state = post_data['temperature_state']
    except:
        temperature_state = ''

    try:
        lib_ids = post_data['lib_ids'].split(',') if post_data['lib_ids'] else []
    except:
        lib_ids = []

    kwargs = {
        'start_date': int(datetime.strptime(start_date, '%Y-%m-%d %H:%M:%S').timestamp() * 1000),
        'end_date': int(datetime.strptime(end_date, '%Y-%m-%d %H:%M:%S').timestamp() * 1000),
        'order_by': 'desc',
        'user_identified_state': user_identified_state,
        'temperature_state': temperature_state,
        'lib_ids': lib_ids,
        'page_no': page_no,
        'page_limit': page_limit,
        'count': True
    }

    try:
        records, total = Records.get_records(dev_id, **kwargs)
    except Exception as e:
        err_msg = f'Cannot get records from database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # total = len(records)
    #
    # if records and page_limit != -1 and page_no != -1:
    #     st = (page_no - 1) * page_limit
    #     records = records[st: st + page_limit]

    result_json = {
        'code': 0,
        'msg': 'success',
        'data':  {
            "page_request": {
                "page_no": page_no,
                "limit": page_limit,
                "total": total
            },
            "time_range": {
                "start": start_date,
                "end": end_date
            },
            "results": [
                # {
                #    "id": record.id,
                #    "task_id": record.dev_id,
                #    "task_type": "TASK_TYPE_FACE",
                #    "capture_time": record.temp_dev_time,
                #    "panorama": {},
                #    "user_identified_state": record.user_identified_state,
                #    "temperature": record. temperature,
                #    "temperature_state": record.temperature_state,
                #    "capture_result": {
                #       "face": {
                #          "rectangle": {
                #             "vertices": [
                #                {
                #                   "x": 0,
                #                   "y": 0
                #                }
                #             ]
                #          },
                #          "portrait": {
                #             "format": "IMAGE_JPEG",
                #             "data": base64.b64encode(record.capture_image).decode('utf-8') if record.capture_image else ''
                #          },
                #          "feature": {
                #             "type": "",
                #             "version": "",
                #             "blob": ""
                #          },
                #          "quality": "",
                #          "attributes": {
                #              "age": record.attr_age,
                #              "gender": record.attr_gender,
                #          },
                #          "db_id": record.lib_id,
                #          "score": record.user_score,
                #          "most_similar_user": {
                #             "user_id": record.user_id,
                #             "card_id": record.user_card_id,
                #             "name": record.user_name,
                #             "gender": record.user_gender,
                #             "age": record.user_age,
                #             "address": record.user_address,
                #             "image": {
                #                "format": "IMAGE_JPEG",
                #                "data": base64.b64encode(record.user_image).decode('utf-8') if record.user_image else ''
                #             },
                #             "attributes": {
                #             },
                #             "create_time": record.user_created_time.strftime("%Y-%m-%d %H:%M:%S")
                #             if record.user_created_time else ''
                #          }
                #       }
                #    }
                # } for record in records
            ]
        }
    }

    def generate():
        prefix = json.dumps(result_json)[:-3]
        yield prefix
        for i, record in enumerate(records):
            yield json.dumps({
                "id": record.id,
                "task_id": record.dev_id,
                "task_type": "TASK_TYPE_FACE",
                "capture_time": record.temp_dev_time,
                "panorama": {},
                "user_identified_state": record.user_identified_state,
                "temperature": record.temperature,
                "temperature_state": record.temperature_state,
                "capture_result": {
                    "face": {
                        "rectangle": {
                            "vertices": [
                                {
                                    "x": 0,
                                    "y": 0
                                }
                            ]
                        },
                        "portrait": {
                            "format": "IMAGE_JPEG",
                            "data": base64.b64encode(record.capture_image).decode(
                                'utf-8') if record.capture_image else ''
                        },
                        "feature": {
                            "type": "",
                            "version": "",
                            "blob": ""
                        },
                        "quality": "",
                        "attributes": {
                            "age": record.attr_age,
                            "gender": record.attr_gender,
                        },
                        "db_id": record.lib_id,
                        "score": record.user_score,
                        "most_similar_user": {
                            "user_id": record.user_id,
                            "card_id": record.user_card_id,
                            "name": record.user_name,
                            "gender": record.user_gender,
                            "age": record.user_age,
                            "address": record.user_address,
                            "image": {
                                "format": "IMAGE_JPEG",
                                "data": base64.b64encode(record.user_image).decode('utf-8') if record.user_image else ''
                            },
                            "attributes": {
                            },
                            "create_time": record.user_created_time.strftime("%Y-%m-%d %H:%M:%S")
                            if record.user_created_time else ''
                        }
                    }
                }
            }) + (', ' if i < len(records) - 1 else '')
        yield ']}}'

    return Response(generate(), content_type='application/json')


@records_bp.route('/delete', methods=['DELETE'])
def delete_records():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")

    try:
        deleted_records = Records.del_records()
    except:
        logger.info('Unable to delete from database')
        return jsonify({'code': -1, 'msg': 'fail', 'data': None})

    # delete temp device
    failed_temp_dev_call = False
    for device in Devices.get_device_list():
        if device and device.protocol == FC_SENSEPASS:
            try:
                resp = delete_records_call(device.dev_address, device.password)
                if resp['success']:
                    msg = f'Successfully deleted records of device {device.dev_id}. Temperature Device info: {resp}'
                    logger.info(msg)
                else:
                    msg = f'Cannot delete records of {device.dev_id}. Temperature Device info: {resp}'
                    logger.info(msg)
                    failed_temp_dev_call = True
            except:
                msg = f'Cannot make the call of deleting records of device {device.dev_id}'
                logger.info(msg)
                failed_temp_dev_call = True

    summary_devices = Devices.get_summary_devices(timeout=app.config[DEVICE_OFFLINE_TIMEOUT])
    emit('notify', {'data': {'device_status': summary_devices}}, namespace='/message', broadcast=True)

    if failed_temp_dev_call:
        return jsonify({'code': -1, 'msg': 'Delete record calls to some devices failed', 'data': None})
    else:
        return jsonify({'code': 0, 'msg': 'success', 'data': deleted_records})
