import base64
from datetime import timezone

from flask import Blueprint, request
from flask import current_app as app
from flask_socketio import emit

from api_calls import *
from constants import *
from logger import logger
from models.device import Devices
from models.record import Records
from models.setting import Settings
from util import parse_img_post_data, is_identified, get_token_by_login
import threading

record_bp = Blueprint('record_bp', __name__)


def should_output_rs485(output_config, user_identified_state, temperature_state):
    res = [False, False]

    try:
        config = json.loads(output_config)
    except Exception as e:
        logger.warning(f'Cannot load output_config, {e}')
        return res

    if 'red' not in config:
        logger.warning(f'No "red" in output_config')
    else:
        red_config = config['red']
        if 'enable' in red_config and red_config['enable']:
            res[0] = True
        if 'face_recog' in red_config and red_config['face_recog']:
            res[0] = res[0] and user_identified_state == 'F'
        if 'temperature' in red_config and red_config['temperature']:
            res[0] = res[0] and temperature_state == '2'

    if 'green' not in config:
        logger.warning(f'No "green" in output_config')
    else:
        green_config = config['green']
        if 'enable' in green_config and green_config['enable']:
            res[1] = True
        if 'face_recog' in green_config and green_config['face_recog']:
            res[1] = res[1] and user_identified_state == 'T'
        if 'temperature' in green_config and green_config['temperature']:
            res[1] = res[1] and temperature_state == '1'

    return res


def output_rs485(output_value):
    import subprocess
    try:
        values = output_value.split(',')
        command = f'echo "{values[0]}" > /dev/ttyAMA3'
        logger.error(f'RS-485: {command}')
        subprocess.run(command, shell=True)

        if len(values) > 2 and int(values[2]) > 0:
            time.sleep(int(values[2]) / 1000.0)
            command = f'echo "{values[1]}" > /dev/ttyAMA3'
            logger.error(f'RS-485: {command}')
            subprocess.run(command, shell=True)
    except Exception as e:
        logger.error(f'Failed to output RS-485, {e}')


@record_bp.route('/face_upload', methods=['POST'])
def face_upload():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED or app.config[LICENSE_STATUS] == BASE_LICENSE:
        return ''

    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
        temp_dev_time = post_data['capture_time']
        dev_id = post_data['task_id']
    except Exception as e:
        logger.info(f'Cannot get post data from face device, {e}')
        return ''

    logger.info(f'/record/face_upload: received response from face device')

    # get the device by task_id
    try:
        device = Devices.get_device_by_dev_id(dev_id)
    except Exception as e:
        logger.error(f'Cannot get task from database, {e}')
        return ''

    if not device:
        logger.error(f'No task with task_id {dev_id} is in database')
        return ''

    # convert time to epoch time and search the record in database
    reparse = False
    try:
        temp_dev_time = datetime.strptime(temp_dev_time, '%Y-%m-%dT%H:%M:%SZ')
    except:
        logger.info(f'Reparsing time.')
        reparse = True

    if reparse:
        try:
            dot_pos = temp_dev_time.rfind('.')
            temp_dev_time = temp_dev_time[:dot_pos + 4]
            temp_dev_time = datetime.strptime(temp_dev_time, '%Y-%m-%dT%H:%M:%S.%f')
            temp_dev_time = temp_dev_time.replace(tzinfo=timezone.utc).astimezone(tz=None)
        except Exception as e:
            logger.error(f'Parse capture_time {post_data["capture_time"]} error: {e}')

    temp_dev_time = temp_dev_time.timestamp()
    temp_dev_time = str(int(temp_dev_time * 1000))

    acs_task = device.protocol == FC_SENSEPASS or device.protocol == TABLET_CAMERA
    mps_task = device.protocol == VN_RTSP

    if not acs_task and not mps_task:
        logger.error(f'Protocol "{device.protocol}" is not supported')
        return ''

    # get corresponding records from database if it is acs_task
    records = []
    if acs_task:
        logger.info(f'/record/face_upload: Search records with task_id {dev_id}, capture_time {temp_dev_time}')
        try:
            records = Records.get_records(dev_id=dev_id, **{'temp_dev_time': temp_dev_time})
        except Exception as e:
            logger.error(f'Cannot get records from database with task_id {dev_id}, {e}')
            return ''

    # check if identified
    user_identified_state = 'T' if device.protocol == FC_SENSEPASS else 'F'
    if mps_task or device.protocol == TABLET_CAMERA:
        try:
            if is_identified(post_data):
                user_identified_state = 'T'
        except Exception as e:
            logger.error(f'Cannot check if is identified data, {e}')
            user_identified_state = 'F'

    # check will add or update the record
    added_new_record = mps_task or not records
    if added_new_record:
        logger.info('/record/face_upload: Creating a new record')
        # Create a new record object
        try:
            records.append(Records(dev_id=dev_id, temp_dev_time=temp_dev_time,
                                   user_identified_state=user_identified_state,
                                   standard=app.config[ERROR_TEMPERATURE]))
        except Exception as e:
            logger.error(f'Cannot create a new record object, {e}')
            return ''

    record = records[0]
    if len(records) > 1:
        logger.warning(f'{len(records)} records have the same capture time {temp_dev_time}. '
                       f'Only update the first one')

    # update the current record object
    if 'extra_info' in post_data and 'temp' in post_data['extra_info']:
        temperature = post_data['extra_info']['temp']
        try:
            record.temperature = temperature
            record.temperature_state = '1' if float(temperature) < float(app.config[ERROR_TEMPERATURE]) else '2'
        except:
            logger.error(
                f'Invalid temp in extra_info: {temperature} or invalid error_temperature setting: {app.config[ERROR_TEMPERATURE]}')

    if user_identified_state == 'T':
        try:
            record.lib_id = post_data['capture_result']['face']['db_id']
            record.user_score = post_data['capture_result']['face']['score']
            record.attr_age = post_data['capture_result']['face']['attributes']['age']
            record.attr_gender = post_data['capture_result']['face']['attributes']['gender']
            record.user_age = post_data['capture_result']['face']['most_similar_user']['age']
            record.user_gender = post_data['capture_result']['face']['most_similar_user']['gender']
            record.user_id = post_data['capture_result']['face']['most_similar_user']['user_id']
            record.user_card_id = post_data['capture_result']['face']['most_similar_user']['card_id']
            record.user_name = post_data['capture_result']['face']['most_similar_user']['name']
            record.user_address = post_data['capture_result']['face']['most_similar_user']['address']
            user_created_time = post_data['capture_result']['face']['most_similar_user']['create_time']
            try:
                temp = datetime.strptime(user_created_time[:user_created_time.rfind('.') + 4], '%Y-%m-%dT%H:%M:%S.%f')
            except:
                # 2020-08-18T06:06:32Z
                temp = datetime.strptime(user_created_time, '%Y-%m-%dT%H:%M:%SZ')
            record.user_created_time = temp

        except Exception as e:
            logger.error(f'Cannot update the record object, {e}')
    else:
        try:
            record.user_score = 0
            record.attr_age = post_data['capture_result']['face']['attributes']['age']
            record.attr_gender = post_data['capture_result']['face']['attributes']['gender']
        except Exception as e:
            logger.error(f'Cannot update the record object, {e}')

    # inform front end of device status by web socket if mps_task or TABLET_CAMERA
    if mps_task or device.protocol == TABLET_CAMERA:
        # get capture image
        try:
            fid, data = post_data['capture_result']['face']['portrait']['url'], \
                        post_data['capture_result']['face']['portrait']['data']
            get_by_fid = not data and fid
        except Exception as e:
            fid = data = ''
            logger.error(f'Cannot get data for portrait, {e}')
            get_by_fid = False

        if get_by_fid:
            token = app.config[FRONTEND_TOKEN].get_last_key()
            # make login call if no token
            if not token:
                token = get_token_by_login(app)

            try:
                resp = face_dev_download_image_call(app.config[FACE_DEV_IP], fid, token)
            except Exception as e:
                resp = None
                record.capture_image = b''
                logger.error(f'Cannot make the call of downloading image, {e}')

            if resp:
                try:
                    base64_str = base64.b64encode(resp.content).decode('utf-8')
                    record.capture_image = base64.decodebytes(base64_str.encode('utf-8'))
                    if type(record.capture_image) != bytes:
                        record.capture_image = b''
                except Exception as e:
                    logger.info(resp.content)
                    record.capture_image = b''
                    logger.error(f'Unable to parse capture_image, {e}')
        else:
            try:
                base64_str = data
                record.capture_image = base64.decodebytes(base64_str.encode('utf-8'))
                if type(record.capture_image) != bytes:
                    record.capture_image = b''
            except Exception as e:
                record.capture_image = b''
                logger.error(f'Unable to parse capture_image, {e}')

        # get user image if identified
        if user_identified_state == 'T':
            try:
                fid, data = post_data['capture_result']['face']['most_similar_user']['image']['url'], \
                            post_data['capture_result']['face']['most_similar_user']['image']['data']
                get_by_fid = not data and fid
            except Exception as e:
                fid = data = ''
                logger.error(f'Cannot get data from capture_result, {e}')
                get_by_fid = False

            if get_by_fid:
                token = app.config[FRONTEND_TOKEN].get_last_key()

                # make login call if no token
                if not token:
                    token = get_token_by_login(app)

                try:
                    resp = face_dev_download_image_call(app.config[FACE_DEV_IP], fid, token)
                except Exception as e:
                    resp = None
                    logger.error(f'Cannot make the call of downloading image, {e}')

                if resp:
                    try:
                        base64_str = base64.b64encode(resp.content).decode('utf-8')
                        record.user_image = base64.decodebytes(base64_str.encode('utf-8'))
                        if type(record.user_image) != bytes:
                            record.user_image = b''
                    except Exception as e:
                        record.user_image = b''
                        logger.info(resp.content)
                        logger.error(f'Unable to parse user_image, {e}')
            else:
                try:
                    base64_str = data
                    record.user_image = base64.decodebytes(base64_str.encode('utf-8'))
                    if type(record.user_image) != bytes:
                        record.user_image = b''

                except Exception as e:
                    record.user_image = b''
                    logger.error(f'Unable to parse user_image, {e}')

        try:
            device_status = {
                dev_id: {
                    'record': record.json()
                }
            }
        except Exception as e:
            device_status = None
            logger.error(f'Cannot convert record to json, {e}')

        if device_status:
            emit('notify', {'data': {'device_status': device_status}}, namespace='/message', broadcast=True)

    # add or update the record in db
    if added_new_record:
        try:
            record.add_new_record()
        except Exception as e:
            logger.error(f'Cannot add new record, {e}')
            return ''
    else:
        try:
            record.upt_cur_record()
        except Exception as e:
            logger.error(f'Cannot update record, {e}')
            return ''

    # output to port if necessary
    if mps_task or device.protocol == TABLET_CAMERA:
        if device.output_type == 'RS-485' and device.output_value:
            red, green = should_output_rs485(device.output_config, record.user_identified_state, record.temperature_state)
            red_val, green_val = device.output_value.split(';')
            if red:
                output_rs485(red_val)
            if green:
                output_rs485(green_val)

    # inform db server
    try:
        db_servers = Settings.get_setting(name='db_server').value
    except Exception as e:
        logger.error(f'Cannot get db_server setting, {e}')
        return ''

    db_servers = db_servers.split(',') if db_servers else []
    for db_server in db_servers:
        try:
            post_json(db_server, post_data)
        except Exception as e:
            logger.error(f'Cannot post to db_server {db_server}, {e}')

    return ''


@record_bp.route('/temp_upload', methods=['POST'])
def temp_upload():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        return '{"result":1,"success":ture}'

    post_data = None
    try:
        post_data = request.form
        data = {
            'dev_sn': post_data['deviceKey'],
            'reported': datetime.now(),
            'type': post_data['type'],
            'temp_dev_time': post_data['time']
        }
    except:
        logger.info(f'Invalid upload data: {post_data}')
        return ''

    # get device from database
    try:
        device = Devices.get_device_by_dev_sn(data['dev_sn'])
    except:
        logger.info(f'Cannot get the device {data["dev_sn"]}')
        return ''
    if not device:
        logger.info(f'Cannot get the device {data["dev_sn"]}')
        return ''

    # parse other info from post data based on maker
    try:
        data_to_update = parse_img_post_data(device.maker, post_data, app)
    except Exception as e:
        data_to_update = None
        logger.info(f'Cannot parse image post data, {e}')
        logger.info(f'Post data: {post_data}')

    if not data_to_update:
        return ''

    data.update(data_to_update)

    # check if image is empty
    if not data['capture_image']:
        logger.info('Capture image is empty')
        return ''

    # add or update database
    records = Records.get_records(dev_id=device.dev_id, **{'temp_dev_time': data['temp_dev_time']})
    if not records:
        try:
            record = Records(dev_id=device.dev_id, reported=data['reported'],
                             temperature=data['temperature'], standard=data['standard'],
                             temperature_state=data['temperature_state'], record_type=data['type'],
                             capture_image=base64.decodebytes(data['capture_image'].encode('utf-8')),
                             temp_dev_time=data['temp_dev_time'])
            record.add_new_record()
            logger.info('New user record added to database')
        except Exception as e:
            logger.info(f'Cannot add a new record in database, {e}')
            return ''
    else:
        record = records[0]
    if len(records) > 1:
        logger.info(f'Warning: {len(records)} records have the same capture time {data["temp_dev_time"]}. '
                    f'Only update the first one')

    record.dev_id = device.dev_id

    # POST /v2/user/search/image if libs are not empty
    res = {}
    x1, y1, x2, y2 = 0, 0, 0, 0
    if device.libs and app.config[LICENSE_STATUS] != BASE_LICENSE:

        # get coordinates from facelib.so
        x1, y1, x2, y2, score = 488, 175, 889, 575, 0
        try:
            import facelib
            out = facelib.detect(base64.b64decode(data['capture_image']))
            for x, y, w, h, score in out:
                x1, y1, x2, y2 = int(x), int(y), int(x + w), int(y + h)
                logger.info(f'Got coordinates from facelib: {x1}, {y1}, {x2}, {y2}')
        except Exception as e:
            logger.info(f'facelib.so failed to get coordinates, {e}')

        # construct json
        to_face_dev = {
            "camera_info": {
                "device_id": device.dev_sn
            },
            "capture_time": int(data['temp_dev_time']),
            "full_image": {
                "data": data['capture_image'],
                "format": "IMAGE_JPEG"
            },
            "receive_time": data['temp_dev_time'],
            "target_images": [{
                "detection_mode": 0,
                "image_type": 0,
                "target_info": {
                    # "angle": {
                    #     "pitch": 8,
                    #     "roll": -89,
                    #     "yaw": 1
                    # },
                    # "quality": 0,
                    "rectangle": {
                        "vertices": [{
                            "x": x1,
                            "y": y1
                        }, {
                            "x": x2,
                            "y": y2
                        }]
                    },
                    "track_id": 0
                }
            }],
            "timestamp": int(data['temp_dev_time'])
        }

        logger.info('POST /v2/user/search/image start')
        # post call
        try:
            res = face_dev_search_image_call(app.config[FACE_DEV_IP], to_face_dev)
        except Exception as e:
            err_msg = f'Cannot search image in face device, {e}. Face device: {res}'
            logger.info(err_msg)
            return ''

        # convert res to json
        try:
            res = res.json()
        except:
            logger.info(f'Cannot convert res to json, {res.content}')
            return ''
        logger.info('POST /v2/user/search/image success')

    search_result = []
    record.user_identified_state = 'F'

    # iterate over (POST /v2/user/search/image) search_result to see if there is a match
    if device.libs and app.config[LICENSE_STATUS] != BASE_LICENSE:
        try:
            search_result = res['data']['search_result']
        except:
            logger.info(f'Cannot get search_result from face device response, Face device response is {res}')

        for user in search_result:
            record.user_id = user['user_id']
            record.user_name = user['user_name']
            record.user_card_id = user['user_card_id']
            record.user_score = user['score']
            if record.user_id != 0 and user['verify_code'] == 2 and record.user_score >= device.min_score:
                record.user_identified_state = 'T'
                if user['user_image']['data']:
                    record.user_image = base64.decodebytes(user['user_image']['data'].encode('utf-8'))
                break

    # update content in database
    try:
        record.upt_cur_record()
    except Exception as e:
        logger.info(f'Cannot update record, {e}')
        return ''

    # inform front end of device status
    device_status = {
        device.dev_id: device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])
    }
    device_status[device.dev_id]['record'] = record.json()
    emit('notify', {'data': {'device_status': device_status}}, namespace='/message', broadcast=True)

    # inform temp device
    if record.user_identified_state == 'F':
        content = app.config[TEMP_DEV_FAILED_MSG]
    else:
        content = app.config[TEMP_DEV_SUCCESS_MSG]

    content = content.replace('{temperature}', record.temperature)
    content = content.replace('{card_id}', record.user_card_id)
    content = content.replace('{name}', record.user_name)
    content = content.replace('{time}',
                              datetime.fromtimestamp(int(record.temp_dev_time) / 1000.0).strftime("%Y-%m-%d %H:%M:%S"))

    def temp_show_msg_call():
        try:
            resp = show_msg_call(device.dev_address, device.password, content)
        except Exception as e:
            logger.info(f'Cannot make the show message call, {e}')
            return

        if 'success' in resp and not resp['success']:
            logger.info(f'show message call failed. Temp device: {resp}')

    t = threading.Thread(target=temp_show_msg_call)
    t.daemon = True
    t.start()

    # output value via serial port
    if device.output_type == 'RS-485' and device.output_value:
        red, green = should_output_rs485(device.output_config, record.user_identified_state, record.temperature_state)
        red_val, green_val = device.output_value.split(';')
        if red:
            output_rs485(red_val)
        if green:
            output_rs485(green_val)

    # inform db server if not identified
    if record.user_identified_state == 'F':

        try:
            db_servers = Settings.get_setting(name='db_server').value
        except Exception as e:
            db_servers = ''
            logger.info(f'Cannot get db_server setting, {e}')

        db_servers = db_servers.split(',') if db_servers else []

        for db_server in db_servers:
            try:
                post_json(db_server, {
                    "id": 0,
                    "task_id": device.dev_id,
                    "task_type": "TASK_TYPE_FACE",
                    "capture_time": datetime.fromtimestamp(int(record.temp_dev_time) / 1000.0)
                          .strftime("%Y-%m-%dT%H:%M:%S.fZ"),
                    "panorama": {
                        "format": "IMAGE_JPEG",
                        "data": None,
                        "url": ""
                    },
                    "capture_result": {
                        "face": {
                            "rectangle": {
                                "vertices": [
                                    {
                                        "x": x1,
                                        "y": y1
                                    },
                                    {
                                        "x": x2,
                                        "y": y2
                                    }
                                ]
                            },
                            "portrait": {
                                "format": "IMAGE_JPEG",
                                "data": None,
                                "url": ""
                            },
                            "feature": None,
                            "quality": 0,
                            "attributes": {
                                "age": record.user_age,
                                "gender": record.user_gender
                            },
                            "db_id": "",
                            "score": 0,
                            "most_similar_user": None
                        }
                    }
                })
            except Exception as e:
                logger.info(f'Cannot post to db_server {db_server}, {e}')

    return '{"result":1,"success":ture}'
