import secrets

from flask import Blueprint, request, jsonify, abort
from flask import current_app as app

from api_calls import face_dev_log_in_call, face_dev_log_out_call
from constants import FACE_DEV_IP, FRONTEND_TOKEN, LICENSE_STATUS, UNAUTHORIZED, BASE_LICENSE
from logger import logger

user_bp = Blueprint('user_bp', __name__)


@user_bp.route('/login', methods=['POST'])
def login():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        err_msg = 'Invalid License'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': {'token': None, 'license_status': UNAUTHORIZED}})

    # parse post data
    try:
        post_data = request.get_json()
        user = post_data['user']
        password = post_data['password']
    except Exception as e:
        err_msg = f'Cannot parse post data, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # check user name and password
    if user != 'admin' or password != 'Atlas@2019':
        err_msg = f'Wrong user name or password'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # make login call
    if app.config[LICENSE_STATUS] == BASE_LICENSE:
        token = secrets.token_urlsafe()
    else:
        try:
            res = face_dev_log_in_call(app.config[FACE_DEV_IP])
        except Exception as e:
            err_msg = f'Cannot make the login call, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # get token
        try:
            token = res.json()['token']
        except Exception as e:
            err_msg = f'Cannot get token from response, {e}. Face device: {res.content}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # store token and send token to frontend
    app.config[FRONTEND_TOKEN].put(token, True)

    return jsonify({'code': 0, 'msg': 'success',
                    'data': {'token': token, 'license_status': app.config[LICENSE_STATUS]}})


@user_bp.route('/logout', methods=['POST'])
def logout():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    try:
        headers = request.headers
    except:
        err_msg = 'Cannot get headers from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        post_data = request.get_json()
        user = post_data['user']
        token = post_data['token']
    except Exception as e:
        err_msg = f'Cannot parse post data, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        app.config[FRONTEND_TOKEN].delete(token)
    except Exception as e:
        err_msg = f'Cannot delete token in backend, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if app.config[LICENSE_STATUS] != BASE_LICENSE:
        try:
            res = face_dev_log_out_call(app.config[FACE_DEV_IP], user, token, headers)
        except Exception as e:
            err_msg = f'Cannot make the sign out call, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        try:
            res = res.json()
        except:
            err_msg = f'Cannot make the sign out call. Face device: {res.content}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        logger.info(f'Face device response of sign out call: {res}')

    return jsonify({'code': 0, 'msg': 'success', 'data': {'token': token}})
