from flask import Blueprint, request, jsonify, abort
from flask import current_app as app

from constants import FRONTEND_TOKEN, LICENSE_STATUS, UNAUTHORIZED
from logger import logger
from models.setting import Settings

setting_bp = Blueprint('setting_bp', __name__)


@setting_bp.route('/<string:setting_name>', methods=['GET'])
def get_setting(setting_name=''):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    if not setting_name:
        err_msg = f'Setting_name is not specified'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        setting = Settings.get_setting(name=setting_name)
    except Exception as e:
        err_msg = f'Cannot get setting from database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if not setting:
        err_msg = 'Cannot get setting from database,'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    res_json = {
        'name': setting.name,
        'value': setting.value
    }

    logger.info(f'Retrieved setting from database: {res_json}')

    return jsonify({'code': 0, 'msg': 'Retrieved setting from database', 'data': res_json})


@setting_bp.route('/<string:setting_name>', methods=['POST'])
def post_setting(setting_name=''):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    if not setting_name:
        err_msg = f'Setting_name is not specified'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # get setting from database
    try:
        setting = Settings.get_setting(name=setting_name)
    except Exception as e:
        setting = None
        err_msg = f'Cannot get setting from database, {e}'
        logger.info(err_msg)

    # parse request value
    try:
        post_data = request.get_json()
        value = post_data['value']
    except Exception as e:
        err_msg = f'Cannot parse data from API call, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if not setting:
        # create a new setting object
        try:
            setting = Settings(name=setting_name, value=value)
        except Exception as e:
            err_msg = f'Cannot create new setting object, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # save in database
        try:
            setting.add_new_setting()
        except Exception as e:
            err_msg = f'Cannot save new setting in database, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    else:
        setting.value = value
        try:
            setting.upt_cur_setting()
        except Exception as e:
            err_msg = f'Cannot update setting in database, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    res_json = {
        'name': setting.name,
        'value': setting.value
    }

    return jsonify({'code': 0, 'msg': 'Created or updated setting in database', 'data': res_json})


@setting_bp.route('/<string:setting_name>', methods=['DELETE'])
def delete_setting(setting_name=''):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    if not setting_name:
        err_msg = f'Setting_name is not specified'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        setting = Settings.get_setting(name=setting_name)
    except Exception as e:
        err_msg = f'Cannot get setting from database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if not setting:
        err_msg = 'Cannot get setting from database,'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        setting.del_settings(name=setting_name)
    except Exception as e:
        err_msg = f'Cannot delete setting from database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    res_json = {
        'name': setting.name,
        'value': setting.value
    }

    logger.info(f'Deleted setting  from database: {res_json}')

    return jsonify({'code': 0, 'msg': 'Deleted setting from database', 'data': res_json})
