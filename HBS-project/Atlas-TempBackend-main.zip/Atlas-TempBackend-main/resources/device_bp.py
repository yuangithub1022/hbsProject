import base64
import subprocess

from flask import Blueprint, jsonify, request, abort
from flask import current_app as app

from api_calls import *
from constants import *
from logger import logger
from models.device import Devices
from models.record import Records

device_bp = Blueprint('device_bp', __name__)


@device_bp.route('/new', methods=['POST'])
def new_device():
    # verify frontend token and license
    try:
        post_data_headers = request.headers
        frontend_token = post_data_headers['Authorization']
    except Exception as e:
        err_msg = f'Cannot get token from post data, {e}'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if app.config[LICENSE_STATUS] == UNAUTHORIZED or frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description=err_msg)

    # parse post data from frontend
    try:
        post_data = request.get_json()
    except Exception as e:
        err_msg = f'Post data is not json, {e}'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # check protocol
    try:
        protocol = post_data['source']['type']
    except Exception as e:
        err_msg = f'Cannot get protocol from post data, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if protocol != FC_SENSEPASS and protocol != VN_RTSP:
        err_msg = f'Unknown protocol, {protocol}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if protocol == VN_RTSP and app.config[LICENSE_STATUS] != ADVANCED_LICENSE:
        abort(401, description="Unauthorized")

    # parse post data for different protocols
    measure_temp = True

    output_config = post_data['output_config'] if 'output_config' in post_data else ''  # output to port configuration
    if protocol == FC_SENSEPASS:
        try:
            measure_temp = post_data['measure_temp']
        except Exception as e:
            logger.info(f'Cannot get the measure_temp from post data, {e}')

        # only ADVANCED_LICENSE can create image streaming tasks
        if not measure_temp and app.config[LICENSE_STATUS] != ADVANCED_LICENSE:
            err_msg = f'LICENSE_STATUS {app.config[LICENSE_STATUS]} cannot create image streaming tasks'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse password
        password = ''
        if measure_temp:
            try:
                password = post_data['password']
            except Exception as e:
                err_msg = f'Cannot get password from post data, {e}'
                logger.info(err_msg)
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse maker
        maker = 1
        if measure_temp:
            try:
                maker = post_data['maker']
            except Exception as e:
                err_msg = f'Cannot get maker from post data, {e}'
                logger.info(err_msg)
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse dev_sn
        try:
            dev_sn = post_data['source']['parameter']['sensepass']['device_sn']
        except Exception as e:
            err_msg = f'Cannot get device_sn from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse extra_info
        try:
            extra_info = post_data['extra_info']
        except Exception as e:
            err_msg = f'Cannot get extra_info from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        try:
            min_score, output_type, output_value = 0, '', ''
            if app.config[LICENSE_STATUS] != BASE_LICENSE:
                min_score = extra_info['min_score']
                output_type = extra_info['output_type']
                output_value = extra_info['output_value']
            dev_name = extra_info['task_name']
            dev_address = extra_info['address'] if measure_temp else ''

        except Exception as e:
            err_msg = f'Cannot parse extra info from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse libs
        libs = post_data['task']['parameter']['face']['id_array']

        # BASE_LICENSE cannot create tasks with libs
        if libs and app.config[LICENSE_STATUS] == BASE_LICENSE:
            err_msg = f'BASE_LICENSE but face libs are not empty'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # transfer post data to face device
        dev_id, res = dev_sn, {}
        if app.config[LICENSE_STATUS] != BASE_LICENSE:
            try:
                res = access_control_new_task_call(app.config[FACE_DEV_IP], post_data, post_data_headers)
            except Exception as e:
                err_msg = f'Failed to create new task, {e}'
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})
            try:
                res = res.json()
            except Exception as e:
                err_msg = f'Failed to create new task in face device, {res.content}, {e}'
                logger.info(err_msg)
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

            try:
                dev_id = res['task_id']
            except Exception as e:
                err_msg = f'Failed to get task_id from face device response, {e}, {res["message"]}'
                logger.info(err_msg)
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        track_mode, roi = '', ''

    else:
        password, maker = '', 0
        # parse post data
        try:
            dev_address = post_data['source']['parameter']['rtsp']['url']
        except Exception as e:
            err_msg = f'Failed to get rtsp url from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        libs = post_data['task']['parameter']['face']['id_array']
        if libs and app.config[LICENSE_STATUS] == BASE_LICENSE:
            err_msg = f'BASE_LICENSE but face libs are not empty'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        try:
            extra_info = post_data['extra_info']
        except Exception as e:
            err_msg = f'Cannot get extra_info from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        try:
            min_score = extra_info['min_score']
            output_type = extra_info['output_type']
            output_value = extra_info['output_value']
            dev_name = extra_info['task_name']
        except Exception as e:
            err_msg = f'Cannot parse extra info from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse track_mode
        try:
            track_mode = post_data['task']['parameter']['face']['track_mode']
        except Exception as e:
            err_msg = f'Cannot parse track_mode from post data, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse roi
        try:
            roi = post_data['task']['parameter']['face']['roi']
            roi = json.dumps(roi) if roi else ''
        except:
            roi = ''

        # transfer post data to face device
        try:
            res = media_process_new_task_call(app.config[FACE_DEV_IP], post_data, post_data_headers)
        except Exception as e:
            err_msg = f'Failed to create new task, {e}'
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})
        try:
            res = res.json()
        except Exception as e:
            err_msg = f'Failed to create new task in face device, {res.content}, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        try:
            dev_id = dev_sn = res['task_id']
        except Exception as e:
            err_msg = f'Failed to get task_id from face device response, {e}, {res["message"]}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # create an object of current task
    try:
        database_protocol = protocol
        if protocol == FC_SENSEPASS and not measure_temp:
            database_protocol = TABLET_CAMERA
        device = Devices(dev_id=dev_id, dev_sn=dev_sn,
                         protocol=database_protocol, min_score=min_score, output_type=output_type,
                         output_config=output_config, output_value=output_value, libs=str(libs),
                         dev_name=dev_name, password=password, dev_address=dev_address, maker=maker,
                         track_mode=track_mode, roi=roi)
    except Exception as e:
        err_msg = f'Add device to database failed, response from face dev: {res}, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': res})

    # add to database
    try:
        device.add_new_device()
    except Exception as e:
        err_msg = f'Cannot add the device into database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': res})

    logger.info('Task created in face device and saved to database')

    # set call back and sync time on temp devices a
    if protocol == FC_SENSEPASS and measure_temp:
        # setup_calls: check password, set call back, set heartbeat...
        try:
            temp_dev_response = set_up_calls(device.dev_address, app.config[ATLAS_IP],
                                             device.password, app.config[ERROR_TEMPERATURE])
        except Exception as e:
            temp_dev_response = []
            logger.info(f'Cannot make set up calls, {e}')

        for r in temp_dev_response:
            try:
                logger.info(f'Temperature device: {r.json()}')
            except:
                try:
                    logger.info(f'Temperature device: {r.content}')
                except Exception as e:
                    logger.info(f'Cannot make set up calls, {e}')

        # set time
        try:
            resp = set_device_time_call(device.dev_address, device.password)
            if resp['success']:
                logger.info(f'Successfully set time of device {device.dev_sn}. Temperature Device info: {resp}')

            else:
                logger.info(f'Failed to set time of device {device.dev_sn}. Temperature Device info: {resp}')

        except Exception as e:
            err_msg = f'Cannot make the call of setting time of device {device.dev_sn}, {e}'
            logger.info(err_msg)

    return jsonify({'code': 0, 'msg': 'success', 'data': res})


@device_bp.route('/update/<string:dev_id>', methods=['PUT'])
def update_device(dev_id):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    if not dev_id:
        return jsonify({'code': -1, 'msg': 'device id is not specified', 'data': None})

    # get headers and body from post data
    try:
        post_data_headers = request.headers
        post_data = request.get_json()
    except Exception as e:
        err_msg = f'Cannot get post data, {e}'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # verify frontend token
    try:
        frontend_token = post_data_headers['Authorization']
    except Exception as e:
        err_msg = f'Cannot get token from post data, {e}'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")

    # get protocol
    try:
        protocol = post_data['source']['type']
    except Exception as e:
        err_msg = f'Cannot get protocol from post data, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if protocol != FC_SENSEPASS and protocol != VN_RTSP:
        err_msg = f'Unknown protocol, {protocol}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    measure_temp = True
    if protocol == FC_SENSEPASS:
        try:
            measure_temp = post_data['measure_temp']
        except Exception as e:
            logger.info(f'Cannot get measure_temp from post data, {e}')

        # only ADVANCED_LICENSE can create image streaming tasks
        if not measure_temp and app.config[LICENSE_STATUS] != ADVANCED_LICENSE:
            err_msg = f'LICENSE_STATUS {app.config[LICENSE_STATUS]} cannot edit image streaming tasks'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # get password
        new_password = ''
        if measure_temp:
            try:
                new_password = post_data['password']
            except:
                err_msg = 'Cannot get password from post data'
                logger.info(err_msg)
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    else:
        new_password = ''

    # get extra_info
    try:
        extra_info = post_data['extra_info']
    except:
        err_msg = 'Cannot get extra_info from post data'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    min_score, output_type, output_config, output_value = 0, '', '', ''
    try:
        if app.config[LICENSE_STATUS] != BASE_LICENSE:
            min_score = extra_info['min_score']
            output_type = extra_info['output_type']
            output_value = extra_info['output_value']
        dev_name = extra_info['task_name']
    except Exception as e:
        err_msg = f'Cannot parse extra info from post data, {extra_info}. {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': post_data})

    output_config = post_data['output_config'] if 'output_config' in post_data else ''

    try:
        new_libs = post_data['task']['parameter']['face']['id_array']
    except:
        new_libs = []

    if new_libs and app.config[LICENSE_STATUS] == BASE_LICENSE:
        err_msg = f'Unauthorized request: non-empty libs with base license'
        logger.error(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': post_data})

    # transfer request to face device
    res = {}
    if app.config[LICENSE_STATUS] != BASE_LICENSE:
        if protocol == FC_SENSEPASS:
            try:
                res = access_control_update_task_call(face_dev_ip=app.config[FACE_DEV_IP],
                                                      data=post_data, headers=post_data_headers,
                                                      task_id=dev_id)
            except Exception as e:
                err_msg = f'Failed to update task, {e}'
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})
        else:
            try:
                res = media_process_update_task_call(face_dev_ip=app.config[FACE_DEV_IP],
                                                     data=post_data, headers=post_data_headers,
                                                     task_id=dev_id)
            except Exception as e:
                err_msg = f'Failed to update task, {e}'
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse face device response to json
        try:
            res = res.json()
            logger.info('Task updated in face device')
        except:
            err_msg = f'Failed to update task, {res}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # get device from database
    device = Devices.get_device_by_dev_id(dev_id)
    if not device:
        err_msg = 'Device not found in database'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    try:
        if protocol == FC_SENSEPASS:
            device.dev_sn = post_data['source']['parameter']['sensepass']['device_sn']
        else:
            device.track_mode = post_data['task']['parameter']['face']['track_mode']
            device.roi = json.dumps(post_data['task']['parameter']['face']['roi'])
        device.min_score = min_score,
        device.output_type = output_type
        device.output_config = output_config
        device.output_value = output_value
        device.libs = str(new_libs)
        device.dev_name = dev_name

    except Exception as e:
        err_msg = f'Failed to update device object, {e}, face device response: {res}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if protocol == FC_SENSEPASS and measure_temp:
        set_pass_success = False
        password_updated = new_password and new_password != device.password
        if password_updated:
            try:
                set_pass_success = set_up_password(device.dev_address, device.password, new_password)
            except:
                set_pass_success = False

            if not set_pass_success:
                try:
                    set_pass_success = set_up_password(device.dev_address, new_password, new_password)
                except:
                    set_pass_success = False

            if set_pass_success:
                logger.info('Update password: success')
            else:
                logger.info('Update password: incorrect password')

            device.password = new_password
    else:
        set_pass_success = True
        password_updated = False

    device.min_score = float(device.min_score[0])  # device.min_score is originally tuple: e.g. (0.8,)
    try:
        device.upt_cur_device()
    except Exception as e:
        err_msg = f'Failed to update device in database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if not password_updated:
        return jsonify({'code': 0, 'msg': 'Update success',
                        'data': device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])})

    if not set_pass_success:
        return jsonify({'code': 1, 'msg': 'Update db success but password is not correct',
                        'data': device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])})
    else:
        return jsonify({'code': 0, 'msg': 'Update success',
                        'data': device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])})


@device_bp.route('/restart', methods=['POST'])
def restart_device():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    dev_id = None
    try:
        post_data = request.get_json()
        dev_id = post_data[DEV_ID]
        device = Devices.get_device_by_dev_id(dev_id)
    except Exception as e:
        err_msg = f'Failed to restart {dev_id}, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # make the restart call
    try:
        resp = restart_device_call(device.dev_address, device.password)
    except requests.exceptions.ConnectionError as e:
        err_msg = f'Restarting returns connection exception{device.dev_sn}, {e}'
        logger.info(err_msg)
        return jsonify({'code': 1, 'msg': err_msg, 'data': None})
    except Exception as e:
        err_msg = f'Failed to restart {device.dev_sn}, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if resp['success']:
        return jsonify({'code': 0,
                        'msg': f'Restart {device.dev_sn} success. Please note that restarting takes time.',
                        'data': None})
    else:
        err_msg = f'Failed to restart {device.dev_sn}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})


@device_bp.route('/set_time', methods=['POST'])
def set_device_time():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    try:
        post_data = request.get_json()
        dev_id = post_data[DEV_ID]
        device = Devices.get_device_by_dev_id(dev_id)
    except:
        return jsonify({'code': -1, 'msg': 'Invalid request. Should contain "dev_id"', 'data': None})

    try:
        resp = set_device_time_call(device.dev_address, device.password)
        if resp['success']:
            logger.info(f'Successfully set time of device {device.dev_sn}. Temperature Device info: {resp}')
            return jsonify({'code': 0,
                            'msg': f'Successfully set time of device {device.dev_sn}. Temperature Device info: {resp}',
                            'data': None})
        else:
            logger.info(f'Failed to set time of device {device.dev_sn}. Temperature Device info: {resp}')
            return jsonify({'code': -1,
                            'msg': f'Cannot set time of device {device.dev_sn}. Temperature Device info: {resp}',
                            'data': None})
    except Exception as e:
        err_msg = f'Cannot make the call of setting time of device {device.dev_sn}, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})


@device_bp.route('/delete/<string:dev_id>', methods=['DELETE'])
def delete_device(dev_id):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    if not dev_id:
        return jsonify({'code': -1, 'msg': 'device id is not specified', 'data': None})

    try:
        Records.del_records(dev_id=dev_id)
    except Exception as e:
        err_msg = f'Failed to delete all related records, {e}'
        logger.info(err_msg)

    logger.info('Deleted related records in database.')

    device = Devices.get_device_by_dev_id(dev_id)
    if not device:
        err_msg = f'Device {dev_id} not found in database'
        logger.info(err_msg)
        # return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if device:
        try:
            device.del_old_device()
        except Exception as e:
            err_msg = f'Failed to delete device {device.dev_sn} in the database, {e}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        logger.info('Deleted device from database.')

    if app.config[LICENSE_STATUS] != BASE_LICENSE:
        # get headers and data from post data
        try:
            post_data_headers = request.headers
            post_data = request.get_json()
        except Exception as e:
            err_msg = f'Cannot parse post data, {e}'
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        res = {}
        # transfer request to face device
        if (device and device.protocol in (FC_SENSEPASS, TABLET_CAMERA)) or not device:
            try:
                res = access_control_delete_task_call(face_dev_ip=app.config[FACE_DEV_IP],
                                                      data=post_data, headers=post_data_headers,
                                                      task_id=dev_id)
            except Exception as e:
                err_msg = f'Failed to delete task in face device, {e}'
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        if device and device.protocol == VN_RTSP or not device:
            try:
                res = media_process_delete_task_call(face_dev_ip=app.config[FACE_DEV_IP],
                                                     data=post_data, headers=post_data_headers,
                                                     task_id=dev_id)
            except Exception as e:
                err_msg = f'Failed to delete task in face device, {e}'
                return jsonify({'code': -1, 'msg': err_msg, 'data': None})

        # parse face device response to json
        try:
            res = res.json()
            logger.info('Task deleted in face device')
        except:
            err_msg = f'Failed to delete task, {res.content}'
            logger.info(err_msg)
            return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    return jsonify({'code': 0, 'msg': 'success', 'data': None})


@device_bp.route('/delete_records', methods=['POST'])
def delete_device_records():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    try:
        post_data = request.get_json()
        dev_id = post_data[DEV_ID]
        device = Devices.get_device_by_dev_id(dev_id)
    except:
        return jsonify({'code': -1, 'msg': 'Invalid request. Should contain "dev_id"', 'data': None})

    try:
        deleted_records = Records.del_records(dev_id)
    except:
        err_msg = f'Cannot deleted records in the database'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    logger.info(f'{deleted_records} records with task_id {dev_id} deleted.')

    if device and device.protocol == FC_SENSEPASS:
        try:
            resp = delete_records_call(device.dev_address, device.password)
            if resp['success']:
                msg = f'Successfully deleted records of device {dev_id}. Temperature Device info: {resp}'
                logger.info(msg)
                return jsonify({'code': 0, 'msg': msg,'data': None})
            else:
                msg = f'Cannot delete records of {dev_id}. Temperature Device info: {resp}'
                logger.info(msg)
                return jsonify({'code': -1, 'msg': msg, 'data': None})
        except:
            msg = f'Cannot make the call of deleting records of device {dev_id}'
            logger.info(msg)
            return jsonify({'code': -1, 'msg': msg, 'data': None})
    else:
        msg = f'Successfully deleted records of device {dev_id}'
        return jsonify({'code': 0, 'msg': msg, 'data': None})


@device_bp.route('/config/<string:dev_id>', methods=['GET'])
def get_device_config(dev_id):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    if not dev_id:
        return jsonify({'code': -1, 'msg': 'device id is not specified', 'data': None})

    # get device from database
    device = Devices.get_device_by_dev_id(dev_id)
    if not device:
        err_msg = f'Device {device.dev_sn} not found in database'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # make the call
    try:
        res = get_config_call(device.dev_address, device.password)
    except Exception as e:
        err_msg = f'Cannot make the call of getting device config, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # return result to frontend
    logger.info(f'Got device config')
    return jsonify({'code': 0, 'msg': 'success', 'data': res})


@device_bp.route('/config/<string:dev_id>', methods=['POST'])
def set_device_config(dev_id):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    if not dev_id:
        return jsonify({'code': -1, 'msg': 'device id is not specified', 'data': None})

    # parse post data
    try:
        post_data = request.get_json()
    except Exception as e:
        err_msg = f'Cannot get json from request, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # get device from database
    device = Devices.get_device_by_dev_id(dev_id)
    if not device:
        err_msg = f'Device {device.dev_sn} not found in database'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # set config call
    try:
        res = set_config_call(device.dev_address, device.password, post_data)
    except Exception as e:
        err_msg = f'Cannot make the call of setting config, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    logger.info('Set device config')
    # return response to frontend
    return jsonify({'code': 0, 'msg': 'success', 'data': res})


@device_bp.route('/heartbeat', methods=['POST'])
def get_heartbeat():
    try:
        request_data = request.form
        data = {
            'dev_sn': request_data['deviceKey'],
            'latest_heartbeat': request_data['time'],
            'dev_address': request_data['ip']
        }
    except:
        logger.info('Received invalid heartbeat info')
        return ''

    logger.info(f'Received heartbeat info: {str(data)}')

    # update device object
    device = Devices.get_device_by_dev_sn(data['dev_sn'])
    if not device:
        logger.info(f'Cannot get device with dev_sn {data["dev_sn"]}')
        return ''
    try:
        latest_heartbeat = int(data['latest_heartbeat']) / 1000.0
    except:
        latest_heartbeat = 0

    # update device in database
    device.latest_heartbeat = datetime.fromtimestamp(latest_heartbeat)
    try:
        device.upt_cur_device()
    except Exception as e:
        logger.info()
        return f'Cannot update device {data["dev_sn"]} in database, {e}'

    # try:
    #     res = access_control_config_update_call(device.dev_id)
    # except:
    #     res = None
    #     logger.info(f'Cannot make the call of acsKeeperConfigUpdate with {device.dev_id}')
    #
    # if res and res.status_code != 200:
    #     logger.iofo(f'acsKeeperConfigUpdate returned a status code: {res.status_code}')

    return ''


@device_bp.route('/video_capture/<string:dev_id>', methods=['GET'])
def video_capture(dev_id):
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")

    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")

    if not dev_id:
        return jsonify({'code': -1, 'msg': 'device id is not specified', 'data': None})

    # get device from database
    try:
        device = Devices.get_device_by_dev_id(dev_id)
    except Exception as e:
        err_msg = f'Cannot access database, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if not device:
        err_msg = f'Device {dev_id} not found in database'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if device.protocol != VN_RTSP:
        err_msg = f'Task type is {device.protocol} not found in database'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    # try:
    #     video_cap = cv2.VideoCapture(device.address)
    #     video_read_success, image = video_cap.read()
    #     encoded_success, encoded_img = cv2.imencode('.jpg', image)
    #     if encoded_success:
    #         base64_str = base64.b64encode(encoded_img).decode('utf-8')
    #     else:
    #         err_msg = 'OpenCV extract image failed'
    #         return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    # except Exception as e:
    #     err_msg = f'OpenCV extract image failed, {e}'
    #     return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    if not device.dev_address:
        return jsonify({'code': -1, 'msg': 'No Rtsp link is given', 'data': None})
    try:
        cmd = f"ffmpeg -rtsp_transport tcp -i {device.dev_address} -vframes 1 -f image2pipe -"
        img_bytes = subprocess.run(cmd.split(), capture_output=True, timeout=10).stdout
        base64_str = base64.b64encode(img_bytes).decode('utf-8')
    except Exception as e:
        err_msg = f'Cannot get base64_str from ffmpeg, {e}'
        logger.info(err_msg)
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})

    return jsonify({'code': 0, 'msg': 'success', 'data': base64_str})
