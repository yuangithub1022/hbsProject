from flask import Blueprint, jsonify, request, abort
from flask import current_app as app

from api_calls import media_process_task_status_call, access_control_task_status_call, \
                      access_control_task_list_call, media_process_task_list_call
from constants import DEVICE_OFFLINE_TIMEOUT, FRONTEND_TOKEN, \
                      UNAUTHORIZED, LICENSE_STATUS, FACE_DEV_IP, FC_SENSEPASS, TABLET_CAMERA, BASE_LICENSE
from logger import logger
from models.device import Devices

devices_bp = Blueprint('devices_bp', __name__)


@devices_bp.route('', methods=['GET'])
def list_devices():
    if app.config[LICENSE_STATUS] == UNAUTHORIZED:
        abort(401, description="Unauthorized")
    # verify frontend token
    try:
        request_headers = request.headers
        frontend_token = request_headers['Authorization']
    except:
        err_msg = 'Cannot get token from post data'
        return jsonify({'code': -1, 'msg': err_msg, 'data': None})
    if frontend_token not in app.config[FRONTEND_TOKEN]:
        err_msg = 'Unauthorized'
        logger.info(err_msg)
        abort(401, description="Unauthorized")
    # logger.info('Token checked.')

    res_json = {'tasks': []}
    res_tasks = res_json['tasks']

    # get the task list from the database
    try:
        db_task_list = Devices.get_device_list()
    except Exception as e:
        logger.info(e)
        return jsonify({'code': '-1', 'msg': str(e)})

    db_id_set = set()
    for device in db_task_list:
        db_id_set.add(device.dev_id)
        if device.protocol == FC_SENSEPASS:
            dev_json = device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])
            dev_json['measure_temp'] = True
            res_tasks.append(dev_json)
            continue

        if device.protocol == TABLET_CAMERA:
            dev_json = device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])
            dev_json['measure_temp'] = False
            res_tasks.append(dev_json)
        else:
            dev_json = device.mps_task_json()
            res_tasks.append(dev_json)

        if device.protocol == TABLET_CAMERA:
            try:
                resp = access_control_task_status_call(app.config[FACE_DEV_IP],
                                                       request_headers, device.dev_id)
            except Exception as e:
                logger.info(f'Cannot get media process tasks status, {e}')
                resp = None
        else:
            try:
                resp = media_process_task_status_call(app.config[FACE_DEV_IP],
                                                      request_headers, device.dev_id)
            except Exception as e:
                logger.info(f'Cannot get media process tasks status, {e}')
                resp = None
        try:
            dev_json['status']['status'] = resp.json()['status']['status'] if resp else 'SOURCE_ERROR'
        except Exception as e:
            logger.info(f'Cannot get device status from media process tasks status, {e}')

    # get the task list from SenseTime
    if app.config[LICENSE_STATUS] != BASE_LICENSE:
        try:
            resp = access_control_task_list_call(app.config[FACE_DEV_IP], request_headers)
            acs_tasks = resp.json()['tasks']
        except Exception as e:
            logger.info(f'Cannot get acs task list, {e}')
            acs_tasks = []

        try:
            resp = media_process_task_list_call(app.config[FACE_DEV_IP], request_headers)
            mps_tasks = resp.json()['tasks']
        except Exception as e:
            logger.info(f'Cannot get mps task list, {e}')
            mps_tasks = []

        sense_time_task_list = acs_tasks + mps_tasks
        sense_time_id_set = set()
        for task in sense_time_task_list:
            sense_time_id_set.add(task['task_id'])

        # not in db
        for task in res_tasks:
            if task['task_id'] not in sense_time_id_set:
                task['status']['status'] = 'INVALID'

        # not in sense_time
        for task in sense_time_task_list:
            if task['task_id'] not in db_id_set:
                task['status']['status'] = 'INVALID'
                task['password'] = ''
                task['maker'] = 1
                task['measure_temp'] = False
                res_tasks.append(task)

    return jsonify(res_json)

