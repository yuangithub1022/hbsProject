import asyncio
import json
import time
import warnings
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime

import requests

warnings.filterwarnings('ignore', message='Unverified HTTPS request')


def get_x_www_form_urlencoded(url, content, timeout=5):
    return requests.get(url, params=content, timeout=timeout, verify=False,
                        headers={'content-type': 'application/x-www-form-urlencoded'})


def post_x_www_form_urlencoded(url, content, timeout=5):
    return requests.post(url, data=content, timeout=timeout, verify=False,
                         headers={'content-type': 'application/x-www-form-urlencoded'})


def post_json(url, content, timeout=5):
    return requests.post(url, json=content, timeout=timeout, verify=False,
                         headers={'content-type': 'application/json'})


def get_x_auth(atlas_ip):
    url = f'https://{atlas_ip}/redfish/v1/SessionService/Sessions'
    data = {
        'UserName': 'admin',
        'Password': 'Huawei12#$'
    }
    res = requests.post(url, verify=False, json=data, timeout=1, headers={'content-type': 'application/json'})
    return res.headers.get('X-Auth-Token') if res.status_code == 201 else None


def get_atlas_info(atlas_ip, x_auth):
    url = f'https://{atlas_ip}/redfish/v1/EdgeSystem'
    res = requests.get(url, verify=False, timeout=1, headers={'X-Auth-Token': x_auth})
    return res.json()


def get_lte_status(lte_ip, x_auth):
    url = f'https://{lte_ip}/redfish/v1/EdgeSystem/lte/StatusInfo'
    res = requests.get(url, verify=False, timeout=1, headers={'X-Auth-Token': x_auth})
    return res.json() if res.status_code == 200 else None


def get_face_img(dev_ip, password, path):
    url = f'http://{dev_ip}/image/show'
    content = {
        'pass': password,
        'type': 'record',
        'path': path
    }
    return post_x_www_form_urlencoded(url, content, timeout=3)


def get_device_key(dev_ip):
    url = f'http://{dev_ip}/getDeviceKey'
    res = requests.post(url, verify=False, timeout=1, headers={'content-type': 'application/x-www-form-urlencoded'})
    return res.json()['data']


def restart_device_call(dev_ip, password):
    url = f'http://{dev_ip}/restartDevice'
    content = {
        'pass': password
    }
    res = post_x_www_form_urlencoded(url, content)
    return res.json()


def set_device_time_call(dev_ip, password):
    url = f'http://{dev_ip}/setTime'
    content = {
        'pass': password,
        'timestamp': str(int(round(time.time() * 1000)))
    }
    res = post_x_www_form_urlencoded(url, content)
    return res.json() if res.status_code == 200 else None


def delete_records_call(dev_ip, password):
    url = f'http://{dev_ip}/deleteRecords'
    content = {
        'pass': password,
        'time': datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    res = post_x_www_form_urlencoded(url, content)
    return res.json() if res.status_code == 200 else None


def set_up_password(dev_ip, old_password, new_password):
    url = f'http://{dev_ip}/setPassWord'
    content = {
        'oldPass': old_password,
        'newPass': new_password
    }
    res = post_x_www_form_urlencoded(url, content)
    return res.json()['success']


def set_up_calls(dev_ip, api_ip, password, error_temperature):
    def _post_to_site(session, url, data):
        headers = {'content-type': 'application/x-www-form-urlencoded'}
        with session.post(url, data=data, timeout=5, verify=False, headers=headers) as response:
            return response

    async def _set_up_calls():
        with ThreadPoolExecutor() as executor:
            with requests.Session() as session:
                _loop = asyncio.get_event_loop()
                tasks = [
                    _loop.run_in_executor(
                        executor,
                        _post_to_site,
                        *(session, endpoint, content)
                    )
                    for endpoint, content in zip(endpoints, contents)
                ]
                for response in await asyncio.gather(*tasks):
                    res.append(response)

    endpoints = [
        f'http://{dev_ip}/setDeviceHeartBeat',
        f'http://{dev_ip}/setIdentifyCallBack',
        f'http://{dev_ip}/setTemperatureConfig'
    ]
    # todo: when deployed, change to 5020
    contents = [
        {
            'pass': password,
            'url': f'http://{api_ip}:5020/backend/device/heartbeat'
        },
        {
            'pass': password,
            'callbackUrl': f'http://{api_ip}:5020/backend/record/temp_upload'
        },
        {
            'pass': password,
            'errorTemperature': error_temperature
        }
    ]
    # with ThreadPoolExecutor() as executor:
    #     for endpoint, content in zip(endpoints, contents):
    #         res.append(executor.submit(post_x_www_form_urlencoded, endpoint, content).result())
    res = []
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    future = asyncio.ensure_future(_set_up_calls())
    loop.run_until_complete(future)
    return res


def show_msg_call(dev_ip, password, content, speak=False):
    url = f'http://{dev_ip}/api/v2/device/showMessage'
    data = {
        'pass': password,
        'content': content,
        'speak': 'true' if speak else 'false'
    }
    res = post_x_www_form_urlencoded(url, data)
    return res.json()


def get_config_call(dev_ip, password):
    url = f'http://{dev_ip}/api/v2/device/config/get'
    data = {
        'pass': password
    }
    res = get_x_www_form_urlencoded(url, data)
    return res.json()


def set_config_call(dev_ip, password, config):
    url = f'http://{dev_ip}/setConfig'
    data = {
        'pass': password,
        'config': json.dumps(config)
    }
    res = post_x_www_form_urlencoded(url, data)
    return res.json()


def access_control_config_update_call(device_id):
    url = f'/engine/access-control/v1/configs/{device_id}'

    base_str = '{"mode":5,"open_door_type":0,"liveness":true,"liveness_threshold":0.98,"verify_threshold":0.83,"face_update_threshold":9.9,"admin_pwd":"123","device_run_type":1,' + \
    '"language_type":2,"yaw":30,"pitch":30,"roll":30,"recognition_distance":1.0,"hack_no_pass_count_threshold":10,"stranger_count_threshold":5,"network_relay_address":"",' + \
    '"use_mode":3,"ntp_server_address":"","logo":true,"welcome_tip":"","verify_success_tip":"","verify_fault_tip":"","use_show_avatar":true,"show_user_name":true,' + \
    '"auto_reboot":true,"reboot_time":"06:00:00","wait_time":5}'

    content = {
        'device_id': device_id,
        'base': json.loads(base_str),
        'extra': {}
    }

    res = requests.put(url, verify=False, json=content, timeout=1, headers={'content-type': 'application/json'})
    return res.json()


def access_control_new_task_call(face_dev_ip, data, headers):
    url = f'{face_dev_ip}/engine/access-control/v1/tasks'
    res = requests.post(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def access_control_update_task_call(face_dev_ip, data, headers, task_id):
    url = f'{face_dev_ip}/engine/access-control/v1/tasks/{task_id}'
    res = requests.put(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def access_control_delete_task_call(face_dev_ip, data, headers, task_id):
    url = f'{face_dev_ip}/engine/access-control/v1/tasks/{task_id}'
    res = requests.delete(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def access_control_task_status_call(face_dev_ip, headers, task_id):
    url = f'{face_dev_ip}/engine/access-control/v1/tasks/{task_id}'
    res = requests.get(url, verify=False, timeout=5, headers=headers)
    return res


def access_control_task_list_call(face_dev_ip, headers):
    payload = {
        'page_request.offset': 0,
        'page_request.limit': 10
    }
    url = f'{face_dev_ip}/engine/access-control/v1/tasks'
    res = requests.get(url, verify=False, params=payload, timeout=5, headers=headers)
    return res


def media_process_new_task_call(face_dev_ip, data, headers):
    url = f'{face_dev_ip}/engine/media-process/v1/tasks'
    res = requests.post(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def media_process_update_task_call(face_dev_ip, data, headers, task_id):
    url = f'{face_dev_ip}/engine/media-process/v1/tasks/{task_id}'
    res = requests.put(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def media_process_delete_task_call(face_dev_ip, data, headers, task_id):
    url = f'{face_dev_ip}/engine/media-process/v1/tasks/{task_id}'
    res = requests.delete(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def media_process_task_status_call(face_dev_ip, headers, task_id):
    url = f'{face_dev_ip}/engine/media-process/v1/tasks/{task_id}'
    res = requests.get(url, verify=False, timeout=5, headers=headers)
    return res


def media_process_task_list_call(face_dev_ip, headers):
    payload = {
        'page_request.offset': 0,
        'page_request.limit': 10
    }
    url = f'{face_dev_ip}/engine/media-process/v1/tasks'
    res = requests.get(url, verify=False, params=payload, timeout=5, headers=headers)
    return res


def face_dev_download_image_call(face_dev_ip, fid, token):
    url = f'{face_dev_ip}/components/osg-default/v1/objects/{fid}'
    res = requests.get(url, verify=False, timeout=5, headers={'Authorization': token})
    return res


def face_dev_search_image_call(face_dev_ip, data):
    url = f'{face_dev_ip}/engine/access-control/v2/user/search/image'
    res = requests.post(url, verify=False, json=data, timeout=5)
    return res


def face_dev_log_in_call(face_dev_ip):
    url = f'{face_dev_ip}/components/operation-maintenance/v1/users/sign_in'
    data = {
        'user': 'admin',
        'password': 'Atlas@2019'
    }
    res = requests.post(url, verify=False, json=data, timeout=5)
    return res


def face_dev_log_out_call(face_dev_ip, user, token, headers):
    url = f'{face_dev_ip}/components/operation-maintenance/v1/users/sign_out'
    data = {
        'user': user,
        'token': token
    }
    res = requests.post(url, verify=False, json=data, timeout=5, headers=headers)
    return res


def face_dev_get_lib_call(face_dev_ip, lib_id, token):
    url = f'{face_dev_ip}/engine/alert-feature/v1/databases/{lib_id}'
    res = requests.get(url, verify=False, timeout=5, headers={'Authorization': token})
    return res



# def access_control_task_list_call(face_dev_ip, payload, headers):
#     url = f'{face_dev_ip}/engine/access-control/v1/tasks'
#     res = requests.get(url, verify=False, params=payload, timeout=5, headers=headers)
#     return res.json()

# def get_device_key(dev_ip):
#     url = f'http://{dev_ip}/getDeviceKey'
#     res = requests.post(url, verify=False, timeout=1, headers={'content-type': 'application/x-www-form-urlencoded'})
#     return res.json()['data'] if res.status_code == 200 else None

# def get_face_img(dev_ip, password, path):
#     url = f'http://{dev_ip}/image/show'
#     content = {
#         'pass': password,
#         'type': 'record',
#         'path': path
#     }
#     return post_to_site(url, content, timeout=3)
