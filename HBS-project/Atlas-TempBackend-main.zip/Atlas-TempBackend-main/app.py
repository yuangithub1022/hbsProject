#!/usr/bin/env python
import atexit
import os
import platform
import sys
from datetime import timedelta
from threading import Timer

from gevent import monkey

monkey.patch_all()

from apscheduler.schedulers.background import BackgroundScheduler
from flask import Flask
from flask_socketio import SocketIO

from constants import *
from api_calls import *

from models.database import db
from models.device import Devices
from models.record import Records

from resources.device_bp import device_bp
from resources.devices_bp import devices_bp
from resources.records_bp import records_bp
from resources.record_bp import record_bp
from resources.setting_bp import setting_bp
from resources.user_bp import user_bp

from logger import logger
from lru_cache import LRUCache
from util import get_license_status, get_token_by_login

base_dir = '.' if platform.system() == 'Windows' else '/var/temp'
# db_file = f'{base_dir}/database.db' # todo: deploy
config_file = f'{base_dir}/config.json'
temp_dev_failed_msg_file = f'{base_dir}/temp_dev_failed_msg.txt'
temp_dev_success_msg_file = f'{base_dir}/temp_dev_success_msg.txt'

# todo: deploy
# # check database
# if not os.path.isfile(db_file):
#     logger.error(f'Failed to start, database file is not exist.')
#     sys.exit(1)


# init web app and socket io
app = Flask(__name__)
app.config['SECRET_KEY'] = 'atlas500!'
# todo: deploy
# app.config['SQLALCHEMY_DATABASE_URI'] = f'sqlite:///{db_file}'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config[ATLAS_IP] = ''
app.config[ERROR_TEMPERATURE] = '37.3'
app.config[DEVICE_OFFLINE_TIMEOUT] = 10
app.config[FACE_DEV_IP] = ''
app.config[FRONTEND_TOKEN] = LRUCache(100)
app.config[LICENSE_STATUS] = UNAUTHORIZED
app.config[TEMP_DEV_FAILED_MSG] = 'Guest<br>Temperature: {temperature} ℃<br>Time: {time}'
app.config[TEMP_DEV_SUCCESS_MSG] = 'Identified Person<br>ID: {card_id}<br>Name: {name}<br>' \
                                   'Temperature: {temperature} ℃<br>Time: {time}'
app.config[AUTO_BACKUP] = False
io = SocketIO(app, path='/backend/socket.io', async_mode="gevent", async_handlers=True, ping_interval=60,
              cors_allowed_origins='*')


# update config if config file exists
if os.path.isfile(config_file):
    with open(config_file) as f:
        try:
            config = json.load(f)
            if config:
                app.config.update(config)
        except Exception as err:
            logger.warning('Read config file error', err)


# update temperature device message format
if os.path.isfile(temp_dev_failed_msg_file):
    with open(temp_dev_failed_msg_file, encoding="utf-8") as f:
        try:
            msg = ''.join(f.read().splitlines())
            app.config[TEMP_DEV_FAILED_MSG] = msg
        except Exception as err:
            logger.warning('Read config temp_dev_failed_msg_file error', err)

if os.path.isfile(temp_dev_success_msg_file):
    with open(temp_dev_success_msg_file, encoding="utf-8") as f:
        try:
            msg = ''.join(f.read().splitlines())
            app.config[TEMP_DEV_SUCCESS_MSG] = msg
        except Exception as err:
            logger.warning('Read config temp_dev_success_msg_file error', err)


# todo: deploy
app.config['SQLALCHEMY_DATABASE_URI'] = f'postgresql://postgres:admin@{app.config[ATLAS_IP]}/temp_backend'

# Check current config
if type(app.config[DEVICE_OFFLINE_TIMEOUT]) != int or app.config[DEVICE_OFFLINE_TIMEOUT] < 5:
    logger.error(f'DEVICE_OFFLINE_TIMEOUT is not valid integer. It should be greater than 5.')
    sys.exit(1)


@app.before_first_request
def set_devices():
    # create tables if not exist
    db.create_all()

    # init db_server setting
    from models.setting import Settings
    try:
        db_server = Settings.get_setting('db_server')
        if not db_server:
            setting = Settings(name='db_server', value='')
            setting.add_new_setting()
    except Exception as e:
        logger.info(f'Cannot init db_server setting in database, {e}')

    # # get atlas serial number by HTTP request
    # try:
    #     app.config[X_AUTH] = get_x_auth(app.config[ATLAS_IP])
    # except Exception as e:
    #     app.config[X_AUTH] = ''
    #     logger.info(f'Cannot get x-auth from atlas, {e}')
    # try:
    #     atlas_info = get_atlas_info(app.config[ATLAS_IP], app.config[X_AUTH])
    # except Exception as e:
    #     atlas_info = {}
    #     logger.info(f'Cannot get atlas_info from atlas, {e}')
    # if 'SerialNumber' in atlas_info:
    #     app.config[ATLAS_SN] = atlas_info['SerialNumber']

    try:
        import subprocess
        resp = subprocess.run(['/usr/local/bin/elabel', 'get', '0x34'], stdout=subprocess.PIPE).stdout.decode('utf-8')
        logger.info(f'"elabel get 0x34": {resp}')
    except Exception as e:
        resp = ''
        if platform.system() == 'Windows':
            resp = 'win invalid'
        logger.info(f'Unable to get elabel, {e}')

    atlas_sn = ''
    if resp:
        temp, atlas_sn, *arg = resp.split()
        if temp != 'win' and atlas_sn == 'invalid':
            logger.info('Serial number of Atlas is invalid')
        if temp == 'win':
            logger.info('Debugging on Windows')

    app.config[LICENSE_STATUS] = get_license_status(atlas_sn)


app.register_blueprint(devices_bp, url_prefix='/backend/devices')
app.register_blueprint(device_bp, url_prefix='/backend/device')
app.register_blueprint(records_bp, url_prefix='/backend/records')
app.register_blueprint(record_bp, url_prefix='/backend/record')
app.register_blueprint(setting_bp, url_prefix='/backend/setting')
app.register_blueprint(user_bp, url_prefix='/backend/user')


@io.on('connect', namespace='/message')
def message_connect():
    logger.info('[Frontend] Connected with WebSocket')
    io.emit('notify', {'data': 'Connected'})


@io.on('disconnect', namespace='/message')
def message_disconnect():
    logger.info('[Frontend] Disconnected with WebSocket')


# @io.on('image_stream', namespace='/message')
# def image_stream(rtsp):
#     import cv2
#     import base64
#     logger.info(f'rtsp: {rtsp}')
#     logger.info(rtsp)
#     video_cap = cv2.VideoCapture(rtsp)
#
#     # while True:
#     #     io.emit('notify', {'data': 'Hello World'}, namespace='/image_stream', broadcast=True)
#     #     time.sleep(1)
#
#     video_read_success, image = video_cap.read()
#     while video_read_success:
#         video_read_success, frame = video_cap.read()
#         encoded_success, encoded_img = cv2.imencode('.jpg', frame)
#         if encoded_success:
#             b64 = base64.b64encode(encoded_img).decode()
#         else:
#             b64 = ''
#         logger.info(f'emit, {len(b64)}')
#         io.emit('image_stream', {'data': b64}, namespace='/message', broadcast=True)
#         time.sleep(0.01)


# @io.on('disconnect', namespace='/image_stream')
# def image_stream():
#     logger.info('[Frontend] Disconnected with WebSocket')

# def polling_maker_1():
#     with app.app_context():
#         summary_devices = Devices.get_summary_devices(app.config[DEVICE_OFFLINE_TIMEOUT], {'maker': MAKER_1})
#         io.emit('notify', {'data': {'device_status': summary_devices}},
#                 namespace='/message', broadcast=True)


def polling_maker_2():
    with app.app_context():
        for device in Devices.get_device_list(**{'maker': MAKER_2}):
            device.online = 'F'

            try:
                dev_sn = get_device_key(device.dev_address)
            except:
                dev_sn = None
                logger.info(f'Cannot get device key of {device.dev_address}')

            if dev_sn is not None:
                logger.info(f'Received device key of {device.dev_address}: {dev_sn}')
                device.online = 'T'

            try:
                device.upt_cur_device()
            except Exception as e:
                logger.info(f'polling_maker_2: Cannot update device, {e}')
        #     summary_devices[device.dev_id] = device.acs_task_json(app.config[DEVICE_OFFLINE_TIMEOUT])
        #
        # io.emit('notify', {'data': {'device_status': summary_devices}},
        #         namespace='/message', broadcast=True)


def backup():
    with app.app_context():
        # todo: error handling, check disk space, delete old
        now = datetime.now()
        directory = f"{'.' if platform.system() == 'Windows' else '/home/store'}/records_backup"

        if not os.path.exists(directory):
            os.makedirs(directory)

        file_path = f'{directory}/{now.strftime("%Y-%m-%d")}'
        if not os.path.exists(file_path):
            os.makedirs(file_path)

        for st in range(24):
            # get from database
            start_date = datetime(now.year, now.month, now.day, st, 0, 0, 0)
            end_date = datetime(now.year, now.month, now.day, st, 59, 59, 999)
            kwargs = {
                'start_date': start_date.timestamp() * 1000,
                'end_date': end_date.timestamp() * 1000,
                'order_by': 'desc',
                'user_identified_state': '',
                'temperature_state': '',
                'lib_ids': [],
                'page_no': -1,
                'page_limit': -1
            }

            try:
                records = Records.get_records('', **kwargs)
            except Exception as e:
                err_msg = f'Cannot get records from database, {e}'
                logger.error(err_msg)
                backup_init()
                return

            # write to files
            curr_path = f'{file_path}/{st:02d}-{st + 1:02d}'
            if not os.path.exists(curr_path):
                os.makedirs(curr_path)
            image_path = f'{curr_path}/images'
            if not os.path.exists(image_path):
                os.makedirs(image_path)

            to_write_csv = ['番号,検知日時,検知デバイス,近似度,検知対象,所属ライブラリ,性別,年齢,ID,部署,キャプチャー,体温,体温状況,認証結果\n']
            for i, record in enumerate(records):
                try:
                    temp_dev_time = datetime.fromtimestamp(int(record.temp_dev_time) / 1000.0)
                    is_identified = record.user_identified_state == 'T'
                    image_file_name = f'{i + 1}_{record.user_name}.jpg' if is_identified else f'{i + 1}_.jpg'

                    dev_name = Devices.get_device_by_dev_id(record.dev_id).dev_name
                    token = app.config[FRONTEND_TOKEN].get_last_key()
                    if not token:
                        token = get_token_by_login(app)
                    resp = face_dev_get_lib_call(app.config[FACE_DEV_IP], record.lib_id,
                                                 token).json()
                    lib_name = '' if 'error' in resp else resp['name']
                    to_write_csv.append(f'{i + 1},{temp_dev_time.strftime("%Y-%m-%d %H:%M:%S")},{dev_name},'
                                        f'{round(record.user_score * 100, 2)},{record.user_name},'
                                        f'{lib_name},{record.user_gender if is_identified else record.attr_gender},'
                                        f'{record.user_age if is_identified else record.attr_age},'
                                        f'{record.user_card_id},{record.user_address},{image_file_name},'
                                        f'{record.temperature},{"正常" if record.temperature_state == "1" else "異常"},'
                                        f'{"認証成功" if is_identified else "認証失敗"}\n')
                    with open(f'{image_path}/{image_file_name}', 'wb') as f:
                        f.write(record.capture_image)
                except Exception as e:
                    logger.error(f'Failed to backup record, {e}')

            with open(f'{curr_path}/records.csv', 'w', encoding='utf_8_sig') as f:
                f.writelines(to_write_csv)

        backup_init()


def backup_init():
    x = datetime.now()

    if x.hour == 23 and x.minute == 59 and x.second >= 50:
        y = x.replace(day=x.day, hour=23, minute=59, second=50, microsecond=0) + timedelta(days=1)
    else:
        y = x.replace(day=x.day, hour=23, minute=59, second=50, microsecond=0)

    delta_t = y - x
    secs = delta_t.total_seconds()
    t = Timer(secs, backup)
    t.start()


# init scheduler for regular jobs
scheduler = BackgroundScheduler()
# scheduler.add_job(func=polling_maker_1, trigger='interval', seconds=app.config[DEVICE_OFFLINE_TIMEOUT])
scheduler.add_job(func=polling_maker_2, trigger='interval', seconds=app.config[DEVICE_OFFLINE_TIMEOUT])
scheduler.start()
# shut down the scheduler when exiting the app
atexit.register(lambda: scheduler.shutdown())


if __name__ == '__main__':
    db.init_app(app)
    if app.config[AUTO_BACKUP]:
        backup_init()
    io.run(app, host='0.0.0.0', port=5021)
