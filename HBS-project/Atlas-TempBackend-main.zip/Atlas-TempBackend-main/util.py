import hashlib
import os
import platform
import urllib.parse

from api_calls import face_dev_log_in_call
from constants import UNAUTHORIZED, BASE_LICENSE, STANDARD_LICENSE, ADVANCED_LICENSE, \
    ERROR_TEMPERATURE, FACE_DEV_IP, FRONTEND_TOKEN, MAKER_1
from logger import logger


# import time
# import base64


def get_license_status(serial_number):
    base_key = f'{serial_number}_base'
    standard_key = f'{serial_number}_standard'
    advance_key = f'{serial_number}_advanced'
    base_key = hashlib.sha256(base_key.encode('utf-8')).hexdigest()
    standard_key = hashlib.sha256(standard_key.encode('utf-8')).hexdigest()
    advance_key = hashlib.sha256(advance_key.encode('utf-8')).hexdigest()

    base_dir = '.' if platform.system() == 'Windows' else '/var/temp'
    key_file = f'{base_dir}/license.key'

    license_key = ''
    if os.path.isfile(key_file):
        with open(key_file) as f:
            try:
                license_key = f.read().rstrip('\n')
            except:
                license_key = ''

    if base_key == license_key:
        return BASE_LICENSE
    elif standard_key == license_key:
        return STANDARD_LICENSE
    elif advance_key == license_key:
        return ADVANCED_LICENSE
    else:
        return UNAUTHORIZED


def parse_img_post_data(maker, post_data, app):
    if maker == MAKER_1:
        try:
            capture_image = urllib.parse.unquote(post_data['imgBase64'])
        except:
            capture_image = post_data['imgBase64']
    else:
        try:
            capture_image = post_data['imgBase64']
        except:
            capture_image = urllib.parse.unquote(post_data['imgBase64'])

    standard = post_data['standard'] if 'standard' in post_data else app.config[ERROR_TEMPERATURE]
    if 'temperature' in post_data:
        temperature = post_data['temperature']
    elif 'Temperature' in post_data:
        temperature = post_data['Temperature']
    else:
        temperature = '-1'

    if 'temperatureState' in post_data:
        temperature_state = post_data['temperatureState']
    else:
        temperature_state = '1' if float(temperature) < float(standard) else '2'

        # try:
        #     resp = get_face_img(device.dev_address, device.password, path)
        # except:
        #     logger.info(f'Cannot make the call of getting face image with ip: {device.dev_address}, '
        #                 f'password: {device.password}, path: {path}')
        #     return None
        #
        # try:
        #     capture_image = base64.b64encode(resp.content).decode('utf-8')
        # except:
        #     logger.info('Cannot encode message')
        #     capture_image = ''

    return {
        'temperature':  temperature,
        'standard':  standard,
        'temperature_state': temperature_state,
        'capture_image': capture_image
    }


def is_identified(post_data):
    # Check json data
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_FACE':
        return False

    if 'extra_info' not in post_data or 'task_name' not in post_data['extra_info']:
        return False

    if 'capture_result' not in post_data or 'face' not in post_data['capture_result']:
        return False

    extra_info = post_data['extra_info']
    min_score = extra_info['min_score'] if 'min_score' in extra_info else 0
    face_result = post_data['capture_result']['face']
    most_similar_user = face_result['most_similar_user'] if 'most_similar_user' in face_result else None
    most_similar_score = face_result['score'] if 'score' in face_result else 0

    try:
        min_score = float(min_score)
        most_similar_score = float(most_similar_score)
    except:
        return False

    # Check if recognize success
    return most_similar_score > 0 and most_similar_user and most_similar_score >= min_score


def get_token_by_login(app):
    token = ''
    # make login call
    try:
        res = face_dev_log_in_call(app.config[FACE_DEV_IP])
    except Exception as e:
        res = None
        err_msg = f'Cannot make the login call, {e}'
        logger.error(err_msg)

    # get token
    try:
        token = res.json()['token'] if res else ''
    except Exception as e:
        err_msg = f'Cannot get token from response, {e}. Face device: {res.content}'
        logger.error(err_msg)

    if token:
        app.config[FRONTEND_TOKEN].put(token, True)

    return token


