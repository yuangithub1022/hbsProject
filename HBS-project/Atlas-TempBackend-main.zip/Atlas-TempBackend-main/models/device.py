import json
from datetime import datetime

from constants import MAKER_1, MAKER_2
from models.database import db
from models.record import Records
from models.timestampmixin import TimestampMixin


class Devices(db.Model, TimestampMixin):
    __tablename__ = 'devices'

    id = db.Column(db.Integer, primary_key=True, autoincrement=True)
    dev_id = db.Column(db.String(64), unique=True, nullable=False)
    dev_sn = db.Column(db.String(64), unique=True, nullable=False)
    dev_name = db.Column(db.String(64), nullable=True, default='')  # extra info: taskName
    dev_address = db.Column(db.Text, nullable=True, default='')
    password = db.Column(db.String(15), nullable=True, default='123456')
    latest_heartbeat = db.Column(db.DateTime, nullable=True, default=datetime.now)
    online = db.Column(db.String(1), nullable=False, default='F')
    protocol = db.Column(db.String(50), nullable=True, default='')
    min_score = db.Column(db.REAL, nullable=True, default=0)
    output_type = db.Column(db.String(15), nullable=True, default='')
    output_config = db.Column(db.String(5000), nullable=True, default='')
    output_value = db.Column(db.Text, nullable=True, default='')
    libs = db.Column(db.Text, nullable=True, default='')
    new_task_json = db.Column(db.Text, nullable=True, default='')
    maker = db.Column(db.Integer, nullable=False, default=1)
    track_mode = db.Column(db.String(30), nullable=True, default='')
    roi = db.Column(db.Text, nullable=True, default='')

    def __init__(self, dev_id=None, dev_sn='', dev_name='', dev_address='', password='123456',
                 latest_heartbeat=datetime(1970, 1, 1), protocol='', min_score=0,
                 output_type='', output_config='', output_value='', libs='', new_task_json='', maker=0,
                 track_mode='', roi=''):
        self.dev_id = dev_id
        self.dev_sn = dev_sn
        # self.online = online
        self.dev_name = dev_name
        self.dev_address = dev_address
        self.password = password
        self.latest_heartbeat = latest_heartbeat
        self.protocol = protocol
        self.min_score = min_score
        self.output_type = output_type
        self.output_config = output_config
        self.output_value = output_value
        self.libs = libs
        self.new_task_json = new_task_json
        self.maker = maker
        self.track_mode = track_mode
        self.roi = roi

    def json(self):
        return {
            'id': self.id,
            'dev_id': self.dev_id,
            # 'status': 'OK' if self.online == 'Y' else 'OFFLINE',
            'dev_name': self.dev_name,
            'dev_address': self.dev_address,
            'latest_heartbeat': self.latest_heartbeat.strftime('%Y-%m-%d %H:%M:%S'),
            'dev_sn': self.dev_sn,
            'protocol': self.protocol,
            'output_type': self.output_type,
            'id_array': self.libs,
            'create_time': self.created,
            'min_score': self.min_score,
            'num_records': Records.get_records_count(self.dev_id),
            'num_abnormal': Records.get_records_count(self.dev_id, **{'temperature_state': '2'}),
            'maker': self.maker
        }

    def acs_task_json(self, timeout=-1):
        return {
            'password': self.password,
            'maker': self.maker,
            'output_config': self.output_config,

            'task_id': self.dev_id,
            'source': {
                'type': self.protocol,
                'parameter': {
                    'sensepass': {
                        'device_sn': self.dev_sn
                    }
                }
            },
            'task': {
                'parameter': {
                    'face': {
                        'min_score': self.min_score,
                        'id_array': self.libs[1:-1].replace('\'', '').replace(' ', '').split(',')
                        if self.libs and self.libs not in ('[]', "['']", '[""]')
                        else []
                    }
                }
            },
            'create_time': self.created.strftime('%Y-%m-%d %H:%M:%S'),
            'extra_info': {
                'output_type': self.output_type,
                'output_value': self.output_value,
                'task_name': self.dev_name,
                'min_score': self.min_score,
                'address': self.dev_address
            },
            'status': {
                'status': self._get_status(timeout),
                'error_message': '',
                'last_received_time': self.latest_heartbeat.strftime('%Y-%m-%d %H:%M:%S')
            }
        }

    def mps_task_json(self):
        return {
            'output_config': self.output_config,

            'task_id': self.dev_id,
            'source': {
                'type': self.protocol,
                'parameter': {
                    'rtsp': {
                        'url': self.dev_address,
                        'protocol_type': 'TCP'
                    }
                }
            },
            'task': {
                'type': 'TASK_TYPE_FACE',
                'parameter': {
                    'face': {
                        'track_mode': self.track_mode,
                        'min_score': self.min_score,
                        'id_array': self.libs[1:-1].replace('\'', '').replace(' ', '').split(',')
                        if self.libs and self.libs not in ('[]', "['']", '[""]')
                        else [],
                        'roi': json.loads(self.roi) if self.roi else None
                    }
                }
            },
            'create_time': self.created.strftime('%Y-%m-%d %H:%M:%S'),
            'extra_info': {
                'min_score': self.min_score,
                'output_type': self.output_type,
                'output_value': self.output_value,
                'task_name': self.dev_name
            },
            'status': {
                'status': 'OFFLINE',
                'error_message': '',
                'last_received_time': self.latest_heartbeat.strftime('%Y-%m-%d %H:%M:%S')
            }
        }

    def _get_status(self, timeout):
        if self.maker == MAKER_1:
            return 'OFFLINE' if datetime.now().timestamp() - self.latest_heartbeat.timestamp() > timeout else 'OK'
        elif self.maker == MAKER_2:
            return 'OK' if self.online == 'T' else 'OFFLINE'
        else:
            return 'OFFLINE'

    @classmethod
    def get_device_list(cls, **kwargs):
        sql = cls.query
        if 'status' in kwargs:
            sql = sql.filter_by(status=kwargs['status'])
        if 'maker' in kwargs and kwargs['maker']:
            sql = sql.filter_by(maker=kwargs['maker'])
        return sql.all()

    @classmethod
    def get_device_by_dev_id(cls, dev_id=None):
        assert dev_id
        if dev_id:
            sql = cls.query.filter_by(dev_id=dev_id)
            return sql.one_or_none()
        return None

    @classmethod
    def get_device_by_dev_sn(cls, dev_sn=None):
        if dev_sn:
            sql = cls.query.filter_by(dev_sn=dev_sn)
            return sql.one_or_none()
        return None

    @classmethod
    def get_device_by_id(cls, _id=None):
        assert _id
        if _id:
            sql = cls.query.filter_by(id=_id)
            return sql.one_or_none()
        return None

    @classmethod
    def get_summary_devices(cls, timeout, kwargs=None):
        summary_devices = {}
        if not kwargs:
            kwargs = {}
        for device in Devices.get_device_list(**kwargs):
            summary_devices[device.dev_id] = device.acs_task_json(timeout)
        return summary_devices

    def add_new_device(self):
        """
        Add new device info
        :return:
        """
        assert self.dev_id
        with db.session.begin_nested():
            db.session.add(self)
        db.session.commit()
        return self

    def upt_cur_device(self):
        """
        Update device info
        :return:
        """
        assert self.dev_id
        with db.session.begin_nested():
            db.session.merge(self)
        db.session.commit()
        return self

    def del_old_device(self):
        """
        Delete device info
        :return:
        """
        assert self.dev_id
        with db.session.begin_nested():
            db.session.delete(self)
        db.session.commit()
        return self