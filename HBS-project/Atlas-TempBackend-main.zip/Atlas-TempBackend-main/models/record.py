import base64
from datetime import datetime

import sqlalchemy
from sqlalchemy import desc
from sqlalchemy.sql.expression import cast

from models.database import db
from models.timestampmixin import TimestampMixin


class Records(db.Model, TimestampMixin):
    __tablename__ = 'records'

    id = db.Column(db.Integer, primary_key=True)
    dev_id = db.Column(db.String(64), index=True, nullable=False)
    reported = db.Column(db.DateTime, nullable=False, default=datetime.now)
    type = db.Column(db.String(32), nullable=True, default='0')
    temperature = db.Column(db.String(32), nullable=True, default='')
    standard = db.Column(db.String(32), nullable=True, default='37.3')
    temperature_state = db.Column(db.String(1), nullable=True, default='1')
    temp_dev_time = db.Column(db.String(15), nullable=True, default='') # todo: to 30
    capture_image = db.Column(db.LargeBinary, nullable=True, default=b'')
    user_image = db.Column(db.LargeBinary, nullable=True, default=b'')
    lib_id = db.Column(db.String(50), nullable=True, default='')
    user_identified_state = db.Column(db.String(1), nullable=True, default='F')
    user_id = db.Column(db.String(50), nullable=True, default='')
    user_card_id = db.Column(db.String(50), nullable=True, default='')
    user_score = db.Column(db.Float, nullable=False, default=0)
    user_name = db.Column(db.String(50), nullable=True, default='')
    user_gender = db.Column(db.String(10), nullable=True, default='U')
    user_age = db.Column(db.Integer, nullable=False, default=0)
    user_address = db.Column(db.String(50), nullable=True, default='')
    attr_age = db.Column(db.Integer, nullable=False, default=0)
    attr_gender = db.Column(db.String(10), nullable=True, default='')
    user_created_time = db.Column(db.DateTime, nullable=True)
    # capture_attributes = db.Column(db.Text, nullable=True, default='')
    # user_attributes = db.Column(db.Text, nullable=True, default='')

    def __init__(self, dev_id=None, reported=datetime.now(), record_type='0', temperature='', standard='37.3',
                 temperature_state='1', user_image=b'', capture_image=b'', temp_dev_time=datetime.now(),
                 user_identified_state='N'):
        self.dev_id = dev_id
        self.reported = reported
        self.type = record_type
        self.temperature = temperature
        self.standard = standard
        self.temperature_state = temperature_state
        self.capture_image = capture_image
        self.user_image = user_image
        self.temp_dev_time = temp_dev_time
        self.user_identified_state = user_identified_state

    def json(self):
        return {
            'task_id': self.dev_id,
            'reported': self.reported.strftime("%Y-%m-%d %H:%M:%S"),
            'type': self.type,
            'temperature': self.temperature,
            'standard': self.standard,
            'temperature_state': self.temperature_state,
            'capture_time': self.temp_dev_time,
            'capture_image': base64.b64encode(self.capture_image).decode('utf-8'),
            'user_image': base64.b64encode(self.user_image).decode('utf-8'),
            'lib_id': self.lib_id,
            'user_identified_state': self.user_identified_state,
            'user_card_id': self.user_card_id,
            'user_id': self.user_id,
            'user_age': self.user_age,
            'user_address': self.user_address,
            'user_score': self.user_score,
            'user_name': self.user_name,
            'user_gender': self.user_gender,
            'attr_age': self.attr_age,
            'attr_gender': self.attr_gender,
            'user_created_time': self.user_created_time.strftime("%Y-%m-%d %H:%M:%S") if self.user_created_time else ''
        }

    @classmethod
    def get_records(cls, dev_id='', **kwargs):
        query = cls.query
        if dev_id:
            dev_ids = dev_id.split(',')
            if len(dev_ids) == 1:
                query = query.filter_by(dev_id=dev_ids[0])
            else:
                query = query.filter(cls.dev_id.in_(tuple(dev_ids)))

        if 'temp_dev_time' in kwargs and kwargs['temp_dev_time']:
            query = query.filter_by(temp_dev_time=kwargs['temp_dev_time'])

        if 'user_identified_state' in kwargs and kwargs['user_identified_state']:
            query = query.filter_by(user_identified_state=kwargs['user_identified_state'])

        if 'temperature_state' in kwargs and kwargs['temperature_state']:
            query = query.filter_by(temperature_state=kwargs['temperature_state'])

        if 'lib_ids' in kwargs and kwargs['lib_ids']:
            query = query.filter(cls.lib_id.in_(tuple(kwargs['lib_ids'])))

        if 'start_date' in kwargs and 'end_date' in kwargs:
            query = query.filter(cast(cls.temp_dev_time, sqlalchemy.BIGINT) >= kwargs['start_date']). \
                filter(cast(cls.temp_dev_time, sqlalchemy.BIGINT) <= kwargs['end_date'])

        num = -1
        if 'count' in kwargs and kwargs['count']:
            num = query.count()

        if 'order_by' in kwargs:
            if kwargs['order_by'] == 'desc':
                query = query.order_by(desc(cast(cls.temp_dev_time, sqlalchemy.BIGINT)))

        if 'page_no' in kwargs and kwargs['page_no'] != -1:
            query = query.offset((kwargs['page_no'] - 1) * kwargs['page_limit'])

        if 'page_limit' in kwargs and kwargs['page_limit'] != -1:
            query = query.limit(kwargs['page_limit'])

        if num != -1:
            return query.all(), num
        return query.all()

    @classmethod
    def get_records_count(cls, dev_id='', **kwargs):
        query = cls.query
        if dev_id:
            query = query.filter_by(dev_id=dev_id)

        if 'temp_dev_time' in kwargs and kwargs['temp_dev_time']:
            query = query.filter_by(temp_dev_time=kwargs['temp_dev_time'])

        if 'user_identified_state' in kwargs and kwargs['user_identified_state']:
            query = query.filter_by(user_identified_state=kwargs['user_identified_state'])

        if 'temperature_state' in kwargs and kwargs['temperature_state']:
            query = query.filter_by(temperature_state=kwargs['temperature_state'])

        if 'lib_ids' in kwargs and kwargs['lib_ids']:
            query = query.filter(cls.lib_id.in_(tuple(kwargs['lib_ids'])))

        if 'start_date' in kwargs and 'end_date' in kwargs:
            query = query.filter(cast(cls.temp_dev_time, sqlalchemy.BIGINT) >= kwargs['start_date']). \
                filter(cast(cls.temp_dev_time, sqlalchemy.BIGINT) <= kwargs['end_date'])

        return query.count()

    def add_new_record(self):
        """
        Add new node info
        :return:
        """
        assert self.dev_id
        with db.session.begin_nested():
            db.session.add(self)
        db.session.commit()
        return self

    def upt_cur_record(self):
        """
        Update device info
        :return:
        """
        assert self.dev_id
        with db.session.begin_nested():
            db.session.merge(self)
        db.session.commit()
        return self

    @classmethod
    def del_records(cls, dev_id=None, **kwargs):
        query = cls.query
        if dev_id:
            query = query.filter_by(dev_id=dev_id)
        if 'start_date' in kwargs and 'end_date' in kwargs:
            query = query.filter(cls.reported >= kwargs['start_date']). \
                filter(cls.reported <= kwargs['end_date'])
        with db.session.begin_nested():
            deleted = query.delete()
        db.session.commit()
        return deleted
