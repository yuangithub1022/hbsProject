from models.database import db
from datetime import datetime


class TimestampMixin:
    """Timestamp model mix-in with fractional seconds support."""
    created = db.Column(db.DateTime, nullable=False, default=datetime.now)
    """Creation timestamp."""

    updated = db.Column(db.DateTime, nullable=False, default=datetime.now,
                        onupdate=datetime.now)
    """Updated timestamp."""

    status = db.Column(db.String(1), nullable=False, default='N', onupdate='U')
