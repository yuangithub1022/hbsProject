from models.database import db
from models.timestampmixin import TimestampMixin


class Settings(db.Model, TimestampMixin):
    __tablename__ = 'settings'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(15), nullable=False, unique=True)
    value = db.Column(db.Text, nullable=True, default='')

    def __init__(self, name, value=''):
        self.name = name
        self.value = value

    @classmethod
    def get_setting(cls, name=''):
        assert name
        if name:
            sql = cls.query.filter_by(name=name)
            return sql.one_or_none()
        return None

    def add_new_setting(self):
        assert self.name
        with db.session.begin_nested():
            db.session.add(self)
        db.session.commit()
        return self

    def upt_cur_setting(self):
        assert self.name
        with db.session.begin_nested():
            db.session.merge(self)
        db.session.commit()
        return self

    @classmethod
    def del_settings(cls, name=''):
        query = cls.query
        if name:
            query = query.filter_by(name=name)
        with db.session.begin_nested():
            deleted = query.delete()
        db.session.commit()
        return deleted
