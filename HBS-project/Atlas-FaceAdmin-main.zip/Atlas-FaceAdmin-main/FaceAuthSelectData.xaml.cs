﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Forms;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// Interaction logic for FaceAuthSelectData.xaml
    /// </summary>
    public partial class FaceAuthSelectData : Window
    {
        public String Path = "";
        private readonly int IsFaceTransmitMode = 0;
        public FaceAuthSelectData(int IsFaceTransmitMode = 0)
        {
            InitializeComponent();

            this.IsFaceTransmitMode = IsFaceTransmitMode;
        }

        private void Btn_UpdateData_Click(object sender, RoutedEventArgs e)
        {

            if ("".Equals(Path) || !File.Exists(Path))
            {
                System.Windows.MessageBox.Show("正しいバックアップファイルを選択してください。", "情報",
                       System.Windows.MessageBoxButton.OK, System.Windows.MessageBoxImage.Information);
                return;
            }

            WriteLog.Log($"[バックアップファイル選択画面] バックアップファイル({Path})で登録者一覧画面を表示します。");
            FaceAuthListPage FaceListPage = new FaceAuthListPage(Path, this.IsFaceTransmitMode);
            FaceListPage.Show();
            this.Close();
        }

        private void Btn_CancelData_Click(object sender, RoutedEventArgs e)
        {
            WriteLog.Log($"[バックアップファイル選択画面] キャンセルボタンで登録種別選択画面に戻ります。");
            LoginFaceAuthSelect LoginSelectPage = new LoginFaceAuthSelect();
            LoginSelectPage.Show();
            this.Close();
        }

        private void Btn_SelectFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog OpenFile = new OpenFileDialog
            {
                Multiselect = false,
                Filter = "CSVファイル(*.csv)|*.csv"
            };
            DialogResult result = OpenFile.ShowDialog();
            if (result == System.Windows.Forms.DialogResult.Cancel)
            {
                return;
            }
            this.showLabel.Text = OpenFile.FileName;
            Path = OpenFile.FileName;
        }
    }
}
