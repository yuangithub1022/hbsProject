﻿using System;
using System.IO;
using System.Windows;
using Microsoft.Win32;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// MainWindow.xaml の相互作用ロジック
    /// </summary>
    public partial class MainWindow : Window
    {
        private InfoSettingIniFile m_infoSettingIniFile = null;

        public MainWindow()
        {
            InitializeComponent();
            if (!Directory.Exists(Configure.BasePath))
            {
                MessageBox.Show($"指定ディレクトリ({Configure.BasePath})が存在しません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }
            if (!File.Exists(Configure.ConfigFile))
            {
                MessageBox.Show($"コンフィグファイル({Configure.ConfigFile})が存在しません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }
            try
            {
                if (string.IsNullOrEmpty(Configure.ToolCsvPath))
                {
                    MessageBox.Show($"アプリCSVファイル格納先(tool_csv)がコンフィグファイルに設定されていません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }
                if (!Directory.Exists(Configure.ToolCsvPath))
                {
                    Directory.CreateDirectory(Configure.ToolCsvPath);
                }
                if (string.IsNullOrEmpty(Configure.FaceDataPath))
                {
                    MessageBox.Show($"顔データ格納先(face_data_jpg)がコンフィグファイルに設定されていません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }
                if (!Directory.Exists(Configure.FaceDataPath))
                {
                    Directory.CreateDirectory(Configure.FaceDataPath);
                }
                if (string.IsNullOrEmpty(Configure.ToolLogPath))
                {
                    MessageBox.Show($"ログファイル格納先(tool_log)がコンフィグファイルに設定されていません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                    this.Close();
                    return;
                }
                if (!Directory.Exists(Configure.ToolLogPath))
                {
                    Directory.CreateDirectory(Configure.ToolLogPath);
                }

                //通行パターンの設定をマッチングする
                int IsFaceTransmitMode = CheckIsFaceTransmitMode();
                if (IsFaceTransmitMode == 3)
                {
                    if (Configure.isAtlasIpNotMatch)
                    {
                        MessageBox.Show($"ipaddr{Configure.numAtlasIpNotMatch}： AtlasのIPが設定されますが、通行パターンが設定されません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                        this.Close();
                        return;
                    }
                    else if (Configure.isTrafficPatternNotMatch)
                    {
                        MessageBox.Show($"ipaddr{Configure.numTrafficPatternNotMatch}： Atlasの通行パターンが設定されますが、IPが設定されません。", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                        this.Close();
                        return;
                    }
                }                    
            }
            catch (Exception ex)
            {
                MessageBox.Show($"プログラムが使用するフォルダの作成に失敗しました。{ex.Message}", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                this.Close();
                return;
            }
            WriteLog.Log("[ログイン画面] アプリを起動しました。");

            try
            {
                m_infoSettingIniFile = new InfoSettingIniFile();
            }
            catch (Exception ex)
            {
                m_infoSettingIniFile = null;
                WriteLog.Log($"[ログイン画面] ユーザIDとパスワードが保存されたINIファイルの初期化処理に失敗しました。{ex.Message}");
            }
        }

        public void Txt_User_Name_Change(object sender, RoutedEventArgs e)
        {
            this.btn_login.IsEnabled = true;
        }

        private void Btn_Login_Click(object sender, RoutedEventArgs e)
        {
            string user_id = this.txt_user_id.Text.Trim();
            string password = this.txt_password.Password;

            Users User = new Users(m_infoSettingIniFile);
            bool rtn = User.CheckPassword(user_id, password);
            if (rtn)
            {
                WriteLog.Log($"[ログイン画面] ユーザー({user_id})がログイン成功しました。");
                LoginFaceAuthSelect LoginSelectPage = new LoginFaceAuthSelect();
                LoginSelectPage.Show();
                this.Close();
            }
            else
            {
                if (User.ErrCode == 1)
                {
                    this.txt_err_msg.Text = "ユーザIDを入力してください";
                }
                else if (User.ErrCode == 2)
                {
                    this.txt_err_msg.Text = "パスワードを入力してください";
                }
                else
                {
                    this.txt_err_msg.Text = $"ユーザID又はパスワードが間違っています。\r\nエラーコード:{User.ErrCode}";
                }
                WriteLog.Log($"[ログイン画面] ユーザー({user_id})がログイン失敗しました。");
            }
        }

        private void Btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            WriteLog.Log("[ログイン画面] アプリを終了しました。");
            this.Close();
        }

        private void Btn_Setting_Change_Click(object sender, RoutedEventArgs e)
        {
            if (m_infoSettingIniFile != null)
            {
                LoginSetting LoginSettingPage = new LoginSetting(this);
                LoginSettingPage.ShowDialog();
            }
            else
            {
                System.Windows.MessageBox.Show($"ユーザIDとパスワードが保存されたINIファイルの初期化処理に失敗しました。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }            
        }

        public int CheckIsFaceTransmitMode()
        {
            string path = "SOFTWARE\\Atlas_face\\Setting";
            string key = "FaceTransmit";
            try
            {
                RegistryKey root = Registry.LocalMachine;
                RegistryKey rk = root.OpenSubKey(path);
                if (rk != null)
                {
                    string value = (string)rk.GetValue(key, null);
                    if (value != null && value.Trim() == "1")
                    {
                        return 1;
                    }
                    else if (value != null && value.Trim() == "2")
                    {
                        return 2;
                    }
                    else if (value != null && value.Trim() == "3")
                    {
                        return 3;
                    }
                    else
                        return 0;
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] レジストリキーの読取に失敗しました。{ex.Message}");
                return 0;
            }

            return 0;
        }

    }
}
