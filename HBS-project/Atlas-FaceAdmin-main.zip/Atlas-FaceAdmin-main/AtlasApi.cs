﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.Windows.Media.Imaging;
using Codeplex.Data;

namespace RegisterFaceAuthTool
{
    public class AtlasApi
    {
        private int request_count = 0;
        private static readonly HttpClient client = new HttpClient();

        public AtlasApi()
        {
            System.Net.ServicePointManager.ServerCertificateValidationCallback =
                    new System.Net.Security.RemoteCertificateValidationCallback(
                        (http_sender, certification, chain, errors) => true);
        }

        public async Task<string> GetToken(string atlas_ip)
        {
            try
            {
                string token = "";

                InfoSettingIniFile infoSettingIniFile = new InfoSettingIniFile();
                string TempUsername = infoSettingIniFile.IniReadValue("Atlas_info", "Username");
                string TempPassword = infoSettingIniFile.IniReadValue("Atlas_info", "Password");

                var user_pwd = new Dictionary<string, string>()
                {
                    {"user", TempUsername },
                    {"password", TempPassword },
                };
                var content = new StringContent(JsonConvert.SerializeObject(user_pwd), Encoding.UTF8, @"application/json");
                
                string url = $"https://{atlas_ip}/components/operation-maintenance/v1/users/sign_in";
                var result = await client.PostAsync(url, content);
                if (result.StatusCode == System.Net.HttpStatusCode.OK)
                {
                    request_count = 0;
                    var token_str = await result.Content.ReadAsStringAsync();
                    Dictionary<string, string> token_dict = JsonConvert.DeserializeObject<Dictionary<string, string>>(token_str);
                    token_dict.TryGetValue("token", out token);
                }

                if (token == "")
                {
                    WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})への認証は失敗しました。");
                }

                return token;
            }
            catch (Exception ex)
            {
                request_count++;
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})のトークン取得({request_count}回目)に失敗しました。{ex.Message}");
                if (request_count >= 3)
                {
                    request_count = 0;
                    return "";
                }
                return await GetToken(atlas_ip);
            }
        }

        public async Task<string> GetDBIdByName(string atlas_ip, string token, string db_name)
        {
            string db_id = "";
            if ("".Equals(token))
            {
                return db_id;
            }

            string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Authorization", token);
            var result = await client.SendAsync(request);
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var response_str = await result.Content.ReadAsStringAsync();
                var json = DynamicJson.Parse(response_str);
                foreach (var database in json.databases)
                {
                    if (database.name == db_name)
                    {
                        db_id = database.id;
                    }
                }
            }

            if (db_id == "")
            {
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})には顔認証ライブラリ({db_name})が見つかりませんでした。");
            }

            return db_id;
        }

        public async Task<string> NewDBByName(string atlas_ip, string token, string db_name, string db_desc)
        {
            string db_id = "";
            if ("".Equals(token))
            {
                return db_id;
            }

            var db_info = new Dictionary<string, string>()
            {
                {"name", db_name },
                {"description", db_desc },
            };
            var content = new StringContent(JsonConvert.SerializeObject(db_info), Encoding.UTF8, @"application/json");
            
            string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases";
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("Authorization", token);
            request.Content = content;
            var result = await client.SendAsync(request);
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var response_str = await result.Content.ReadAsStringAsync();
                db_id = DynamicJson.Parse(response_str).id;
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})へのライブラリー作成が成功しました。");
            }
            else
            {
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})へのライブラリー作成が失敗しました。 " + result.ReasonPhrase);
            }

            return db_id;
        }

        public async Task<List<FaceAuthDataBean>> GetUserList(string atlas_ip, string token, string db_id, int Index, int Count)
        {
            List<FaceAuthDataBean> user_list = new List<FaceAuthDataBean>();
            if ("".Equals(token) || "".Equals(db_id))
            {
                return user_list;
            }

            int offset = 0;
            int limit = 100;
            
            do
            {
                var query_obj = new Dictionary<string, string>()
                {
                    {"page_request.offset", Convert.ToString(offset) },
                    {"page_request.limit", Convert.ToString(limit) },
                };
                string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();
                    
                string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users?{query_str}";
                var request = new HttpRequestMessage(HttpMethod.Get, url);
                request.Headers.Add("Authorization", token);
                var result = await client.SendAsync(request);
                if (result.StatusCode != System.Net.HttpStatusCode.OK)
                {
                    WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データ取得が失敗しました。" + result.ReasonPhrase);
                    break;
                }

                var response_str = await result.Content.ReadAsStringAsync();
                var json = DynamicJson.Parse(response_str);

                int index = 0;
                foreach (var user in json.users)
                {
                    FaceAuthDataBean item = new FaceAuthDataBean()
                    {
                        UserIds = new string[64],
                        Idx = ++index + offset,
                        TicketId = user.attributes.ticket_id,
                        FaceId = user.card_id,
                        ManageId = user.attributes.manage_id,
                        StaffName = user.name,
                        StaffNameKN = user.attributes.name_kn,
                        FigureId = user.attributes.figure_id,
                        FigureStatus = user.attributes.figure_status,
                        Thresholds = user.attributes.thresholds,
                        StartDate = user.attributes.start_date,
                        ValidDate = user.attributes.valid_date,
                        StaffImgPath = "",
                        StaffImgName = user.image.url,
                        LoginStatus = Count == 1 ? "有" : "無",
                        LoginStatusCode = Count == 1 ? "1" : "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsDeleted = false,
                        TrafficPattern = "",
                    };
                    if (JsonConvert.SerializeObject(user.attributes).IndexOf("\"floor_num\":") > -1)
                    {
                        item.FloorNum = user.attributes.floor_num;
                    }
                    if (Index >= 1 && Index <= 64)
                    {
                        item.UserIds[Index - 1] = user.user_id;
                    }
                    else
                    {
                        WriteLog.Log($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
                    }
                    user_list.Add(item);
                }
                    
                if (index < limit)
                {
                    break;
                }
                offset += limit;
            } while (true);

            WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})からの顔データを{user_list.Count}件取得しました。");
            return user_list;
        }

        public async Task<BitmapImage> DownloadImage(string atlas_ip, string token, string image_id, string user_id)
        {
            if ("".Equals(token) || "".Equals(image_id))
            {
                return null;
            }

            BitmapImage bitmapImage = new BitmapImage();
            
            string url = $"https://{atlas_ip}/components/osg-default/v1/objects/{image_id}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Authorization", token);
            var result = await client.SendAsync(request);
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                using (var stream = await result.Content.ReadAsStreamAsync())
                {
                    bitmapImage.BeginInit();
                    bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                    bitmapImage.StreamSource = stream;
                    bitmapImage.EndInit();
                }
            }
            else
            {
                bitmapImage = null;
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})からの画像データ取得(画像ID:{image_id})が失敗しました。 " + result.ReasonPhrase);
            }

            return bitmapImage;
        }

        public async Task<string> AddUserBatch(string atlas_ip, string token, string db_id, IEnumerable<FaceAuthDataBean> recordings)
        {
            string response = "";
            if ("".Equals(token) || "".Equals(db_id))
            {
                return response;
            }

            var user_list = new HashSet<Dictionary<string, Object>>();
            foreach(FaceAuthDataBean record in recordings)
            {
                var obj = new Dictionary<string, Object>()
                {
                    { "card_id", record.FaceId},
                    { "name", record.StaffName},
                    { "image", 
                        new Dictionary<string, string>()
                        {
                            { "data", ImageHelper.BitmapToBase64((BitmapImage)record.Staff_Image) },
                        } 
                    },
                    { "attributes",
                        new Dictionary<string, string>()
                        {
                            { "ticket_id", record.TicketId },
                            { "manage_id", record.ManageId },
                            { "name_kn", record.StaffNameKN },
                            { "figure_id", record.FigureId },
                            { "figure_status", record.FigureStatus },
                            { "thresholds", record.Thresholds },
                            { "start_date", record.StartDate },
                            { "valid_date", record.ValidDate },
                            { "floor_num", record.FloorNum },
                        } 
                    },
                };
                user_list.Add(obj);
            }
            var body_list = new Dictionary<string, Object>()
            {
                { "db_id", db_id },
                { "users", user_list },
            };
            
            var content = new StringContent(JsonConvert.SerializeObject(body_list), Encoding.UTF8, @"application/json");
            
            string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users";
            var request = new HttpRequestMessage(HttpMethod.Post, url);
            request.Headers.Add("Authorization", token);
            request.Content = content;
            var result = await client.SendAsync(request);
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                response = await result.Content.ReadAsStringAsync();
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})への顔データ登録({user_list.Count}件)が成功しました。");
            }
            else
            {
                request_count++;
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})への顔データ登録({user_list.Count}件)が失敗しました。" + result.ReasonPhrase);
                if (request_count <= 3)
                {
                    System.Threading.Thread.Sleep(3000);
                    return await AddUserBatch(atlas_ip, token, db_id, recordings);
                }
            }

            request_count = 0;
            return response;
        }

        public async Task<Boolean> DelUserByUserID(string atlas_ip, string token, string db_id, string user_id)
        {
            Boolean rtn = false;
            if ("".Equals(token) || "".Equals(db_id) || "".Equals(user_id))
            {
                return rtn;
            }
            
            string url = $"https://{atlas_ip}/engine/alert-feature/v1/databases/{db_id}/users/{user_id}";
            var request = new HttpRequestMessage(HttpMethod.Delete, url);
            request.Headers.Add("Authorization", token);
            var result = await client.SendAsync(request);
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                rtn = true;
            }
            else
            {
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})の顔データ削除(USERID:{user_id})が失敗しました。" + result.ReasonPhrase);
            }

            return rtn;
        }

        public async Task<string> ListCaptureResults(string atlas_ip, string token, int offset, int limit)
        {
            string user_list = "";
            if ("".Equals(token))
            {
                return user_list;
            }

            var query_obj = new Dictionary<string, string>()
            {
                {"page_request.offset", Convert.ToString(offset) },
                {"page_request.limit", Convert.ToString(limit) },
                {"order", "ASC" },
            };
            string query_str = await new FormUrlEncodedContent(query_obj).ReadAsStringAsync();
            
            string url = $"https://{atlas_ip}/engine/feature-process/v1/capture_results?{query_str}";
            var request = new HttpRequestMessage(HttpMethod.Get, url);
            request.Headers.Add("Authorization", token);
            var result = await client.SendAsync(request);
            if (result.StatusCode == System.Net.HttpStatusCode.OK)
            {
                var response_str = await result.Content.ReadAsStringAsync();
                var json = DynamicJson.Parse(response_str);
                user_list = json.ToString();
            }
            else
            {
                WriteLog.Log($"[Atlas通信ログ] Atlas装置({atlas_ip})のキャプチャー取得が失敗しました。" + result.ReasonPhrase);
            }

            return user_list;
        }
    }
}
