﻿using System.IO;
using System.Windows;

namespace RegisterFaceAuthTool
{
    class Configure
    {
        public static readonly string BasePath = @"C:\Users\Atlas_tool";
        public static readonly string ConfigFile = BasePath + @"\config.ini";
        public static readonly string LibraryName = @"vivabivale";

        public static readonly int MaxFaceCount = 8000;

        public static readonly string ToolCsvPath;
        public static readonly string FaceDataPath;
        public static readonly string ToolLogPath;
        public static readonly string[] AtlasList;
        public static readonly string[] TrafficList;
        //通行パターンのマッチング
        public static readonly bool isAtlasIpNotMatch;
        public static readonly int numAtlasIpNotMatch;
        public static readonly bool isTrafficPatternNotMatch;
        public static readonly int numTrafficPatternNotMatch;

        static Configure()
        {
            if (!Directory.Exists(BasePath) || !File.Exists(ConfigFile))
            {
                return;
            }
            IniFile ini = new IniFile(ConfigFile);
            ToolCsvPath = ini["path", "tool_csv"];
            FaceDataPath = ini["path", "face_data_jpg"];
            ToolLogPath = ini["path", "tool_log"];

            //通行パターンのマッチング
            isAtlasIpNotMatch = false;
            numAtlasIpNotMatch = 0;
            isTrafficPatternNotMatch = false;
            numTrafficPatternNotMatch = 0;

            string[] List = new string[64];
            string[] List_Traffic = new string[64];
            for (int i = 0; i < List.Length; i++)
            {
                string item = ini["atlas", $"ipaddr{i+1}"];
                string item_traffic = ini["traffic_pattern", $"ipaddr{i + 1}"];
                List[i] = item;
                List_Traffic[i] = item_traffic;

                if ((item != "" && item_traffic == ""))
                {
                    isAtlasIpNotMatch = true;
                    numAtlasIpNotMatch = i + 1;
                }
                else if (item == "" && item_traffic != "")
                {
                    isTrafficPatternNotMatch = true;
                    numTrafficPatternNotMatch = i + 1;
                }
            }            
            AtlasList = List;
            TrafficList = List_Traffic;
        }
    }
}
