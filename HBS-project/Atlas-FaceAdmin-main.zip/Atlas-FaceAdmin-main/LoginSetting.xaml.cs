﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// LoginSetting.xaml の相互作用ロジック
    /// </summary>
    public partial class LoginSetting : Window
    {
        private MainWindow pParentWin = null;
        private InfoSettingIniFile m_infoSettingIniFile = new InfoSettingIniFile();

        public LoginSetting(MainWindow WinMain)
        {
            InitializeComponent();
            pParentWin = WinMain;
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Setting_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string StrUsername = this.Username.Text.Trim();
                if (StrUsername == "")
                {
                    System.Windows.MessageBox.Show($"ユーザIDを入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                string StrUsernameNew = this.Username_New.Text.Trim();
                if (StrUsernameNew == "")
                {
                    System.Windows.MessageBox.Show($"新しいユーザIDを入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                string StrPasswordNow = this.Password_Now.Password;
                if (StrPasswordNow == "")
                {
                    System.Windows.MessageBox.Show($"現在のパスワードを入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                string StrPasswordNew = this.Password_New.Password;
                if (StrPasswordNew == "")
                {
                    System.Windows.MessageBox.Show($"新しいパスワードを入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else if (StrPasswordNew.Length < 8)
                {
                    System.Windows.MessageBox.Show($"パスワードの長さは8文字以上必要です。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                string StrPasswordConfirm = this.Password_Confirm.Password;
                if (StrPasswordConfirm == "")
                {
                    System.Windows.MessageBox.Show($"確認用新しいパスワードを入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else if (StrPasswordConfirm.Length < 8)
                {
                    System.Windows.MessageBox.Show($"パスワードの長さは8文字以上必要です。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }

                if (StrPasswordNow == StrPasswordNew)
                {
                    System.Windows.MessageBox.Show($"現在のパスワードと新しいパスワードが同じです。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else if (StrPasswordNew != StrPasswordConfirm)
                {
                    System.Windows.MessageBox.Show($"新しいパスワードと確認用パスワードが一致しません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                else
                {
                    string StrUsername_info_1 = "";
                    string StrUsername_info_2 = "";
                    string StrPassword = "";
                    try
                    {
                        StrUsername_info_1 = m_infoSettingIniFile.IniReadValue("FaceAdmin_info_1", "Username");
                        StrUsername_info_2 = m_infoSettingIniFile.IniReadValue("FaceAdmin_info_2", "Username");
                    }
                    catch (Exception ex)
                    {
                        WriteLog.Log($"[ログイン情報変更画面] ユーザIDの読取は失敗しました。{ex.Message}");
                        MessageBox.Show($"顔認証登録アプリ登録用ユーザIDの読取は失敗しました。{ex.Message}", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (StrUsername != StrUsername_info_1 && StrUsername != StrUsername_info_2)
                    {
                        System.Windows.MessageBox.Show($"ユーザIDが正しくありません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }

                    try
                    {
                        if (StrUsername == StrUsername_info_1)
                        {
                            StrPassword = m_infoSettingIniFile.IniReadValue("FaceAdmin_info_1", "Password");
                        }
                        else
                        {
                            StrPassword = m_infoSettingIniFile.IniReadValue("FaceAdmin_info_2", "Password");
                        }
                    }
                    catch (Exception ex)
                    {
                        WriteLog.Log($"[ログイン情報変更画面] パスワードの読取は失敗しました。{ex.Message}");
                        MessageBox.Show($"顔認証登録アプリ登録用パスワードの読取は失敗しました。{ex.Message}", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                        return;
                    }

                    if (StrPassword != StrPasswordNow)
                    {
                        System.Windows.MessageBox.Show($"現在のパスワードが正しくありません。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        return;
                    }

                    string msg = $"ログイン情報を変更しますか？";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                        MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.Yes))
                    {
                        try
                        {
                            if (StrUsername == StrUsername_info_1)
                            {
                                m_infoSettingIniFile.IniWriteValue("FaceAdmin_info_1", "Username", StrUsernameNew);
                                m_infoSettingIniFile.IniWriteValue("FaceAdmin_info_1", "Password", StrPasswordNew);
                            }
                            else
                            {
                                m_infoSettingIniFile.IniWriteValue("FaceAdmin_info_2", "Username", StrUsernameNew);
                                m_infoSettingIniFile.IniWriteValue("FaceAdmin_info_2", "Password", StrPasswordNew);
                            }
                        }
                        catch (Exception ex)
                        {
                            WriteLog.Log($"[ログイン情報変更画面]ログイン情報変更は失敗しました。{ex.Message}");
                            MessageBox.Show($"ログイン情報変更は失敗しました。{ex.Message}", "エラー",
                                MessageBoxButton.OK, MessageBoxImage.Error);
                            return;
                        }

                        WriteLog.Log("[ログイン情報変更画面] ログイン情報変更は成功しました。");
                        System.Windows.MessageBox.Show($"ログイン情報変更は成功しました", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);

                        this.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[ログイン情報変更画面] パスワードの設定は失敗しました。{ex.Message}");
                MessageBox.Show($"顔認証登録アプリ登録用パスワードの設定は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UsernameText_TextChanged(object sender, TextChangedEventArgs e)
        {
            this.Username_New.Text = this.Username.Text;
        }

        private void Password_New_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            PasswordCheck(e);
        }

        private void Password_Confirm_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            PasswordCheck(e);
        }

        private void Password_Now_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            PasswordCheck(e);
        }

        private void PasswordCheck(KeyEventArgs e)
        {
            bool isNumber = e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9;
            bool isSymbol = e.Key >= Key.Oem1 && e.Key <= Key.Oem3 || e.Key >= Key.Oem4 && e.Key <= Key.Oem7 || e.Key == Key.Oem102;
            bool isLetter = (e.Key >= Key.A && e.Key <= Key.Z && e.KeyboardDevice.Modifiers != ModifierKeys.Control) || (e.Key >= Key.A && e.Key <= Key.Z && e.KeyboardDevice.Modifiers == ModifierKeys.Shift);
            bool isCtrlA = e.Key == Key.A && e.KeyboardDevice.Modifiers == ModifierKeys.Control;
            bool isBack = e.Key == Key.Back;
            bool isTab = e.Key == Key.Tab;
            bool isLeftOrRight = e.Key == Key.Left || e.Key == Key.Right;
            bool isKeyupOrKeydown = e.Key == Key.Up || e.Key == Key.Down;

            if (isNumber || isSymbol || isLetter || isCtrlA || isBack || isTab || isLeftOrRight || isKeyupOrKeydown)
                e.Handled = false;
            else
                e.Handled = true;
        }
    }
}
