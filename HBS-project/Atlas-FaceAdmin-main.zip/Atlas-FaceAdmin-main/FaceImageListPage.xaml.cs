﻿using Codeplex.Data;
using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// Interaction logic for FaceImageListPage.xaml
    /// </summary>
    public partial class FaceImageListPage : Window
    {
        private ObservableCollection<FaceAuthDataBean> Recordings = new ObservableCollection<FaceAuthDataBean>();

        public delegate void SendMessage(FaceAuthDataBean bean);
        public SendMessage SendMsg;

        public int Limit = 10;
        public int Offset = 0;
        public int PageNo = 1;
        public int PageCount = 0;
        public int DataCount = 0;
        public string AtlasIp = "";
        
        public FaceImageListPage(String ip)
        {
            InitializeComponent();
            AtlasIp = ip;
            WriteLog.Log($"[撮影画像選択画面] 撮影画像一覧(装置:{ip})を開きました。");
            Read_Data_First();
        }

        private async void Read_Data_First()
        {
            try
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                var Api = new AtlasApi();
                var Token = await Api.GetToken(AtlasIp);
                if ("".Equals(Token))
                {
                    MessageBox.Show($"装置への認証は失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }
                string UserInfo = await Api.ListCaptureResults(AtlasIp, Token, 0, Limit);
                if ("".Equals(UserInfo))
                {
                    WriteLog.Log($"[撮影画像選択画面] 撮影画像の取得に失敗しました。");
                    MessageBox.Show("撮影画像の取得に失敗しました。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }
                var UserList = DynamicJson.Parse(UserInfo);
                DataCount = Convert.ToInt32(UserList.page_request.total);
                if (DataCount == 0)
                {
                    btn_previou.IsEnabled = false;
                    btn_next.IsEnabled = false;
                    MessageBox.Show("撮影画像を見つかりませんでした。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }

                if (DataCount % Limit > 0)
                {
                    PageCount = DataCount / Limit + 1;
                }
                else
                {
                    PageCount = DataCount / Limit;
                }

                Offset = DataCount;
                Read_Data();
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[撮影画像選択画面] 撮影画像の取得に失敗しました。{ex.Message}");
                MessageBox.Show($"撮影画像の取得に失敗しました。{ex.Message}", "エラー",　MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }


        private async void Read_Data()
        {
            try
            {
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                int StartIndex = 0;
                int LimitTemp = Limit;
                if (Offset < LimitTemp)
                {
                    LimitTemp = Offset;
                }
                if (Offset > LimitTemp)
                {
                    StartIndex = Offset - LimitTemp;
                }

                var Api = new AtlasApi();
                var Token = await Api.GetToken(AtlasIp);
                if ("".Equals(Token))
                {
                    MessageBox.Show($"装置への認証は失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }
                string UserInfo = await Api.ListCaptureResults(AtlasIp, Token, StartIndex, LimitTemp);
                if ("".Equals(UserInfo))
                {
                    WriteLog.Log($"[撮影画像選択画面] 撮影画像の取得に失敗しました。ページ: {PageNo}, 総件数: {DataCount}");
                    MessageBox.Show("撮影画像の取得に失敗しました。", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }
                this.Recordings.Clear();
                
                int Idx_ = DataCount - StartIndex;
                var UserList = DynamicJson.Parse(UserInfo);
                foreach (var user in UserList.results)
                {
                    var ImageId = user.capture_result.face.portrait.url;
                    BitmapImage TempImage = await Api.DownloadImage(AtlasIp, Token, ImageId, Convert.ToString(user.id));
                    string CardId = "";
                    string UserName = "";
                    if (user.capture_result.face.most_similar_user != null)
                    {
                        CardId = user.capture_result.face.most_similar_user.card_id;
                        UserName = user.capture_result.face.most_similar_user.name;
                    }

                    FaceAuthDataBean FaceItem = new FaceAuthDataBean()
                    {
                        Idx = Idx_--,
                        TicketId = "",
                        FaceId = CardId,
                        ManageId = "",
                        StaffName = UserName,
                        StaffNameKN = "",
                        FigureId = "",
                        FigureStatus = "",
                        Thresholds = "",
                        StartDate = "",
                        StaffImgPath = "",
                        StaffImgName = $"himg_{user.id}" + @".jpg",
                        Staff_Image = TempImage
                    };

                    DateTime dt = Convert.ToDateTime(user.capture_time);
                    FaceItem.ValidDate = string.Format("{0:yyyy-MM-dd HH:mm:ss}", dt);

                    this.Recordings.Add(FaceItem);
                }
                SetButtonPage(PageNo);
                this.DG2.DataContext = this.Recordings.Reverse();
                //this.DG2.DataContext = this.Recordings;
                CollectionViewSource.GetDefaultView(this.DG2.ItemsSource).Refresh();
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[撮影画像選択画面] 撮影画像の取得に失敗しました。ページ: {PageNo}, 総件数: {DataCount}。{ex.Message}");
                MessageBox.Show($"撮影画像の取得に失敗しました。{ex.Message}", "エラー", MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }
        
        private void Btn_Previous_Click(object sender, RoutedEventArgs e)
        {
            PageNo -= 1;
            Offset = DataCount - (PageNo - 1) * Limit;
            Read_Data();
        }

        private void Btn_Next_Click(object sender, RoutedEventArgs e)
        {
            PageNo += 1;
            Offset = DataCount - (PageNo - 1) * Limit;
            Read_Data();
        }

        private void Btn_Login_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FaceAuthDataBean face_data = this.Recordings.Where(item => { return item.IsChecked; }).FirstOrDefault();
                if (face_data == null || face_data.Staff_Image == null)
                {
                    MessageBox.Show("撮影画像を選択してください。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                SendMsg(face_data);
                this.Close();
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[撮影画像選択画面] 撮影画像の選択に失敗しました。{ex.Message}");
                MessageBox.Show($"撮影画像の登録に失敗しました。{ex.Message}", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            WriteLog.Log($"[撮影画像選択画面] 撮影画像選択画面を閉じました。");
            this.Close();
        }

        private void RadioBtn_Checked(object sender, RoutedEventArgs e)
        {
            RadioButton btn = (RadioButton)sender;
            FaceAuthDataBean FaceData = (FaceAuthDataBean)btn.DataContext;
            FaceData.IsChecked = true;
        }

        private void RadioBtn_UnChecked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.RadioButton btn = (System.Windows.Controls.RadioButton)sender;
            FaceAuthDataBean FaceData = (FaceAuthDataBean)btn.DataContext;
            FaceData.IsChecked = false;
        }
        
        private void SetButtonPage(int PageNo)
        {
            if (PageNo == 1)
            {
                btn_previou.IsEnabled = false;
                btn_previou.Content = new TextBlock { Text = "◁前ページ" };
            }
            else
            {
                btn_previou.IsEnabled = true;
                btn_previou.Content = new TextBlock { Text = "◀前ページ" };
            }

            if (PageNo < PageCount)
            {
                btn_next.IsEnabled = true;
                btn_next.Content = new TextBlock { Text = "次ページ▶" };
            }
            else
            {
                btn_next.IsEnabled = false;
                btn_next.Content = new TextBlock { Text = "次ページ▷" };
            }
        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (this.loading.IsActive == true)
            {
                e.Handled = true;
            }
        }
    }
}
