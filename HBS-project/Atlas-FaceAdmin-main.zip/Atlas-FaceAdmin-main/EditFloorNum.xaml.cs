﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// Window1.xaml 的交互逻辑
    /// </summary>
    public partial class EditFloorNum : Window
    {
        public bool HasChanged = false;
        IEnumerable<FaceAuthDataBean> FaceDataList = null;
        public EditFloorNum(IEnumerable<FaceAuthDataBean> data)
        {
            InitializeComponent();
            this.FaceDataList = data;
        }

        private void Btn_OK_Click(object sender, RoutedEventArgs e)
        {
            if (this.floorNum.Text == "" && this.floorNum == null)
            {
                System.Windows.MessageBox.Show("行き先階の情報を入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }
            int a = 0;
            if (!int.TryParse(this.floorNum.Text, out a))
            {
                System.Windows.MessageBox.Show($"入力は数値(1-24)でなければなりません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                this.floorNum.Text = "";
                return;
            }

            int aout = 0;
            if (int.TryParse(this.floorNum.Text, out aout))
            {
                if (this.floorNum.Text.StartsWith("0"))
                {
                    this.floorNum.Text = aout.ToString();
                }
            }

            if (int.Parse(this.floorNum.Text) > 24 || int.Parse(this.floorNum.Text) < 1)
            {
                System.Windows.MessageBox.Show("入力は数値(1-24)でなければなりません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            foreach (FaceAuthDataBean FaceData in FaceDataList)
            {
                FaceData.FloorNum = this.floorNum.Text;
                FaceData.IsUpdated = true;
                FaceData.IsDeleted = false;
                FaceData.IsInserted = false;
                FaceData.IsSelected = true;
            }
            this.HasChanged = true;
            this.Close();
        }

        private void Btn_Cancel_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void floorNum_PreviewKeyDown(object sender, KeyEventArgs e)
        {
            bool isNumber = e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9;
            bool isBack = e.Key == Key.Back;
            bool isTab = e.Key == Key.Tab;
            bool isEnter = e.Key == Key.Enter;
            bool isLeftOrRight = e.Key == Key.Left || e.Key == Key.Right;
            bool isKeyupOrKeydown = e.Key == Key.Up || e.Key == Key.Down;
            bool isCtrlA = e.Key == Key.A && e.KeyboardDevice.Modifiers == ModifierKeys.Control;

            if (isNumber || isCtrlA || isBack || isTab || isLeftOrRight || isKeyupOrKeydown || isEnter)
            {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }
    }
}
