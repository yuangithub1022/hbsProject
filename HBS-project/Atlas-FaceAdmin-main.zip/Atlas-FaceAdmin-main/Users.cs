﻿
using System;
using System.Windows;

namespace RegisterFaceAuthTool
{
    class Users
    {
        private readonly string[] UserNames = null;
        private readonly string[] Passwords = null;
        public int ErrCode { get; private set; } = 0;

        public Users(InfoSettingIniFile infoSettingIniFile = null)
        {
            if(infoSettingIniFile == null)
            {
                infoSettingIniFile = new InfoSettingIniFile();
            }

            try
            {
                string StrUsername_info_1 = infoSettingIniFile.IniReadValue("FaceAdmin_info_1", "Username");
                string StrUsername_info_2 = infoSettingIniFile.IniReadValue("FaceAdmin_info_2", "Username");
                string StrPassword_info_1 = infoSettingIniFile.IniReadValue("FaceAdmin_info_1", "Password");
                string StrPassword_info_2 = infoSettingIniFile.IniReadValue("FaceAdmin_info_2", "Password");
                UserNames = new string[] { StrUsername_info_1, StrUsername_info_2 };
                Passwords = new string[] { StrPassword_info_1, StrPassword_info_2 };
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[ログイン画面] ユーザIDとパスワードの読取は失敗しました。{ex.Message}");
                MessageBox.Show($"顔認証登録アプリ登録用ユーザIDとパスワードの読取は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public bool CheckPassword(string userName, string password)
        {
            if (userName == "")
            {
                this.ErrCode = 1;
                return false;
            }
            if (password == "")
            {
                this.ErrCode = 2;
                return false;
            }

            for (int i = 0; i < UserNames.Length; i++)
            {
                if (UserNames[i] == userName && Passwords[i] == password)
                {
                    return true;
                }
            }
            this.ErrCode = 3;
            return false;
        }
    }
}
