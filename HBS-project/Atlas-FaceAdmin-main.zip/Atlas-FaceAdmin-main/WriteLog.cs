﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace RegisterFaceAuthTool
{
    public class WriteLog
    {
        public WriteLog()
        {
        }
        private static string LogPath
        {
            get
            {
                string OutPath = Configure.ToolLogPath;

                if (!Directory.Exists(OutPath))
                {
                    Directory.CreateDirectory(OutPath);
                }

                return OutPath + @"\log." + DateTime.Today.ToString("yyyy-MM-dd") + ".txt";
            }
        }

        // TODO: 加一个参数Level，分DEBUG、WARN、INFO、ERROR，
        // 调用Log函数的地方统一添加Level参数，用于区分重要度。
        // 日志里的错误类型和消息内容需要整理后给客户确认，而且后面还可能添加errorcode。如果有需要的话会把ErrorCode放到content中。
        public static void Log(string content)
        {
            if (File.Exists(LogPath))
            {
                using (FileStream fs = new FileStream(LogPath, FileMode.Append, System.IO.FileAccess.Write, FileShare.ReadWrite))
                {
                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                    {
                        string _tmp = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] - " + content;
                        sw.WriteLine(_tmp);
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
            else
            {
                using (FileStream fs = new FileStream(LogPath, FileMode.CreateNew, System.IO.FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                    {
                        string _tmp = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] - " + content;
                        sw.WriteLine(_tmp);
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
        }

        public static void Log(List<string> contents)
        {
            if (File.Exists(LogPath))
            {
                //追加文件
                using (FileStream fs = new FileStream(LogPath, FileMode.Append, System.IO.FileAccess.Write, FileShare.ReadWrite))
                {
                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                    {
                        foreach (string content in contents)
                        {
                            string _tmp = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] - " + content;
                            sw.WriteLine(_tmp);
                        }
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
            else
            {
                using (FileStream fs = new FileStream(LogPath, FileMode.CreateNew, System.IO.FileAccess.ReadWrite, FileShare.ReadWrite))
                {
                    using (StreamWriter sw = new StreamWriter(fs, Encoding.UTF8))
                    {
                        foreach (string content in contents)
                        {
                            string _tmp = "[" + DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss") + "] - " + content;
                            sw.WriteLine(_tmp);
                        }
                        sw.Flush();
                        sw.Close();
                    }
                }
            }
        }
    }
}
