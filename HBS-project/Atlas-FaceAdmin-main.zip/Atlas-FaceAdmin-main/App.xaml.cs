﻿using System.Windows;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// App.xaml の相互作用ロジック
    /// </summary>
    public partial class App : Application
    {
        private static System.Threading.Mutex mutex;
        protected override void OnStartup(StartupEventArgs e)
        {
            mutex = new System.Threading.Mutex(true, "OnlyRunOne_AtlasFaceAdmin");
            //ミューテックスの所有権を要求する
            if (mutex.WaitOne(0, false))
            {
                base.OnStartup(e);
            }
            else
            {
                MessageBox.Show("既に起動しています。", "情報", MessageBoxButton.OK, MessageBoxImage.Information);
                this.Shutdown();
            }
        }
    }
}
