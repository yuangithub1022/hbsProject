﻿using System.Collections.Generic;
using System.IO;
using System.Text;

namespace RegisterFaceAuthTool
{
    public class CsvFile
    {
        private readonly string FilePath;
        public CsvFile(string FilePath)
        {
            this.FilePath = FilePath;
        }

        public List<List<string>> Read(int Count, string Codeset)
        {
            List<List<string>> Lists = new List<List<string>>();
            var encoding = Encoding.GetEncoding(Codeset);
            // 読み込みたいCSVファイルのパスを指定して開く
            StreamReader Sr = new StreamReader(this.FilePath, encoding);
            {
                int CountTemp = 0;
                // 末尾まで繰り返す
                while (!Sr.EndOfStream)
                {
                    // CSVファイルの一行を読み込む
                    string line = Sr.ReadLine();
                    // 読み込んだ一行をカンマ毎に分けて配列に格納する
                    string[] Values = line.Split(',');
                    CountTemp++;
                    if (CountTemp >= Count)
                    {
                        // 配列からリストに格納する
                        List<string> List = new List<string>();
                        List.AddRange(Values);

                        Lists.Add(List);
                    }
                }
            }
            Sr.Close();
            return Lists;
        }
    }
}
