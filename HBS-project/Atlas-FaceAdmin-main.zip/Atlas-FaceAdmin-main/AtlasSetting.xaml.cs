﻿using System;
using System.Windows;


namespace RegisterFaceAuthTool
{
    /// <summary>
    /// AtlasSetting.xaml の相互作用ロジック
    /// </summary>
    public partial class AtlasSetting : Window
    {
        private InfoSettingIniFile m_infoSettingIniFile = new InfoSettingIniFile();

        public AtlasSetting()
        {
            InitializeComponent();
            ShowSettingInfo();
        }

        private void Button_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void Button_Setting_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string StrUsername = this.UsernameText.Text.Trim();
                string StrPassword = this.PasswordText.Text.Trim();

                if (StrUsername == "" || StrPassword == "")
                {
                    System.Windows.MessageBox.Show($"Atlas通信用ユーザ名、またはパスワードを入力してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    string msg = $"Atlas通信用ユーザ名({StrUsername})とパスワード({StrPassword})を設定しますか？";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                        MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.Yes))
                    {
                        if (StrUsername != "")
                        {
                            m_infoSettingIniFile.IniWriteValue("Atlas_info", "Username", StrUsername);
                        }
                        if (StrPassword != "")
                        {
                            m_infoSettingIniFile.IniWriteValue("Atlas_info", "Password", StrPassword);
                        }
                        WriteLog.Log("[Atlas通信設定画面] Atlas通信用ユーザ名とパスワードの設定は成功しました。");
                        System.Windows.MessageBox.Show($"Atlas通信用ユーザ名とパスワードの設定は成功しました", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);

                        this.Close();
                    }
                }                
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[Atlas通信設定画面] Atlas通信用ユーザ名とパスワードの設定は失敗しました。{ex.Message}");
                MessageBox.Show($"Atlas通信用ユーザ名とパスワードの設定は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void ShowSettingInfo()
        {
            try
            {
                string TempUsername = m_infoSettingIniFile.IniReadValue("Atlas_info", "Username");
                string TempPassword = m_infoSettingIniFile.IniReadValue("Atlas_info", "Password");
                if (TempUsername == "" && TempPassword == "")
                {
                    System.Windows.MessageBox.Show($"Atlas通信用ユーザ名とパスワードは未設定です", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    this.UsernameText.Text = TempUsername;
                    this.PasswordText.Text = TempPassword;
                }
            }
            catch (Exception ex)
            {
                this.UsernameText.Text = "";
                this.PasswordText.Text = "";
                WriteLog.Log($"[Atlas通信設定画面] Atlas通信用ユーザ名とパスワードの読込は失敗しました。{ex.Message}");
                MessageBox.Show($"Atlas通信用ユーザ名とパスワードの読込は失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
