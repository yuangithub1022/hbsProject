﻿using Codeplex.Data;
using MahApps.Metro.Controls;
using Microsoft.Win32;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Data;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Media.Imaging;
using OpenFileDialog = System.Windows.Forms.OpenFileDialog;

namespace RegisterFaceAuthTool
{
    /// <summary>
    /// FaceAuthListPage.xaml の相互作用ロジック
    /// </summary>
    public partial class FaceAuthListPage : Window
    {
        public FaceAuthViewModel ViewModel { get; set; }
        public AtlasServerViewModel AtlasViewModel { get; set; }
        public ReadSrcViewModel ReadViewModel { get; set; }
        
        private readonly string LibraryDesp = @"01.00.00";
        private readonly bool IsBackupMode = false;
        private bool IsRecoveryMode = false;
        private readonly int IsFaceTransmitMode = 0;

        // modify by yuan 2021/01/28 　　#223により、仕様変更
        private bool IsReadFromAtlas = false;

        MatchEvaluator matchEvaluWrite = delegate (Match m)
        {
            return @"\r\n";
        };
        MatchEvaluator matchEvaluWriteComma = delegate (Match m)
        {
            return ",";
        };

        public FaceAuthListPage(int IsFaceTransmitMode = 0)
        {
            InitializeComponent();

            this.IsFaceTransmitMode = IsFaceTransmitMode;

            this.ViewModel = new FaceAuthViewModel();
            this.AtlasViewModel = new AtlasServerViewModel();
            this.ReadViewModel = new ReadSrcViewModel(this.IsFaceTransmitMode);

            this.combo_atlas.DataContext = this.AtlasViewModel.Recordings;
            this.combo_atlas.SelectedItem = this.AtlasViewModel.InitSelectedItem;

            this.combo_file.DataContext = this.ReadViewModel.Recordings;
            this.combo_file.SelectedItem = this.ReadViewModel.InitSelectedItem;

            this.DG1.DataContext = this.ViewModel.Recordings;
            this.DG1.CanUserAddRows = false;

            this.IsBackupMode = false;
            this.IsRecoveryMode = false;
            // modify by yuan 2021/01/28 　　#223により、仕様変更
            this.IsReadFromAtlas = false;
        }

        public FaceAuthListPage(string path, int IsFaceTransmitMode = 0)
        {
            InitializeComponent();

            this.IsFaceTransmitMode = IsFaceTransmitMode;

            this.ViewModel = new FaceAuthViewModel(path);
            this.AtlasViewModel = new AtlasServerViewModel();
            this.ReadViewModel = new ReadSrcViewModel(this.IsFaceTransmitMode);

            this.combo_atlas.DataContext = this.AtlasViewModel.Recordings;
            this.combo_atlas.SelectedItem = this.AtlasViewModel.InitSelectedItem;

            this.combo_file.DataContext = this.ReadViewModel.Recordings;
            this.combo_file.SelectedItem = this.ReadViewModel.InitSelectedItem;

            this.DG1.DataContext = this.ViewModel.Recordings;
            this.DG1.CanUserAddRows = false;

            this.IsBackupMode = true;
            this.IsRecoveryMode = false;
            // modify by yuan 2021/01/28 　　#223により、仕様変更
            this.IsReadFromAtlas = false;
        }

        public void Content_Rendered(object sender, EventArgs e)
        {
            loading.IsActive = true;
            loadingPart.Visibility = Visibility.Visible;
            this.ViewModel.ReadViewDelay(this.IsFaceTransmitMode);
            this.DG1.DataContext = this.ViewModel.Recordings;
            SetRecordsCount();
            if (this.IsFaceTransmitMode == 2)
            {
                this.DG1.Columns[5].Visibility = Visibility.Visible;
                this.btn_edit_batch.Visibility = Visibility.Visible;
            }
            else if (this.IsFaceTransmitMode == 3)
            {
                //BIVALE連携モード 通行パータン対応
                this.DG1.Columns[6].Visibility = Visibility.Visible;
                this.btn_edit_traffic_batch.Visibility = Visibility.Visible;

                //columns長さを拡張
                this.DG1.Columns[4].Width = 150;
                this.DG1.Columns[6].Width = 245;
                this.DG1.Columns[7].Width = 65;
            }
            WriteLog.Log($"[登録者一覧画面] 登録者一覧画面を表示しました。");
            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
            loading.IsActive = false;
            loadingPart.Visibility = Visibility.Hidden;
        }

        private void SetRecordsCount()
        {
            int Count = this.ViewModel.Recordings.Where(item => { return "1".Equals(item.LoginStatusCode); }).Count();
            string RecordsCnt = $"登録件数: {Count}/{Configure.MaxFaceCount}";
            this.Invoke(new Action(() =>
            {
                this.txtb_cnt.Text = RecordsCnt;
            }));
            WriteLog.Log($"[登録者一覧画面] 登録者一覧件数: {this.ViewModel.Recordings.Count()}, 登録済み件数: {Count}");
        }

        private void TextBox_Name_Change(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;
            if (this.IsFaceTransmitMode == 1 || this.IsFaceTransmitMode == 2)
            {
                txb.IsReadOnly = false;
                txb.SelectionStart = txb.Text.Length;
                txb.Cursor = System.Windows.Input.Cursors.IBeam;
            }
        }

        private void TextBox_FloorNum_Change(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;
            if (this.IsFaceTransmitMode == 2)
            {
                txb.IsReadOnly = false;
                txb.SelectionStart = txb.Text.Length;
                txb.Cursor = System.Windows.Input.Cursors.IBeam;
            }
        }

        private void TextBox_Traffic_Change(object sender, MouseButtonEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;
            if (this.IsFaceTransmitMode == 3)
            {
                txb.IsReadOnly = false;
                txb.SelectionStart = txb.Text.Length;
                txb.Cursor = System.Windows.Input.Cursors.IBeam;
            }
        }

        private void TextBox_Traffic_Changed(object sender, RoutedEventArgs e)
        {
            try
            {
                System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;

                if (txb.IsReadOnly)
                {
                    return;
                }
                FaceAuthDataBean face_data = (FaceAuthDataBean)txb.DataContext;

                if (txb.Text != face_data.TrafficPattern)
                {
                    if (txb.Text.IndexOf(',') != -1)
                    {
                        string msgComma = $"登録者の通行パターン情報にカンマがあります。";
                        MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                  MessageBoxButton.OK, MessageBoxImage.Error);
                        txb.Text = face_data.TrafficPattern;
                    }
                    else
                    {
                        string oldTrafficPattern = face_data.TrafficPattern;
                        string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWriteComma);
                        string oldText = txb.Text;
                        string newText = Regex.Replace(oldText, @"\r\n", matchEvaluWriteComma);


                        string[] strarrTraffic = newText.Split(',');
                        bool isTrafficOutside = false;
                        string strTrafficOutside = "";
                        foreach (var i in strarrTraffic)
                        {
                            int iExists = Array.IndexOf(Configure.TrafficList, i.ToString());
                            if (iExists == -1)
                            {
                                isTrafficOutside = true;
                                strTrafficOutside = i.ToString();
                                break;
                            }
                        }

                        // 重複通行パターンと空白通行パターンをチェックする
                        Hashtable ht = new Hashtable();
                        for (int i = 0; i < strarrTraffic.Length; i++)
                        {
                            if (strarrTraffic[i] == "" && strarrTraffic.Length > 1)
                            {
                                string msgComma = $"空白通行パターンがあります。";
                                MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                          MessageBoxButton.OK, MessageBoxImage.Error);
                                txb.Text = face_data.TrafficPattern;
                                txb.Cursor = System.Windows.Input.Cursors.Arrow;
                                txb.IsReadOnly = true;
                                return;
                            }

                            if (ht.Contains(strarrTraffic[i]))
                            {
                                string msgComma = $"重複する通行パターンがあります。\r\n通行パターン：{strarrTraffic[i]}";
                                MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                          MessageBoxButton.OK, MessageBoxImage.Error);
                                txb.Text = face_data.TrafficPattern;
                                txb.Cursor = System.Windows.Input.Cursors.Arrow;
                                txb.IsReadOnly = true;
                                return;
                            }
                            else
                            {
                                ht.Add(strarrTraffic[i], strarrTraffic[i]);
                            }
                        }

                        if (isTrafficOutside)
                        {
                            string msgComma = $"登録者の通行パターン:({strTrafficOutside}) は設定されません。";
                            MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                                      MessageBoxButton.OK, MessageBoxImage.Error);
                            txb.Text = face_data.TrafficPattern;
                        }
                        else
                        {
                            string msg = $"登録者の通行パターン情報を\r\n({newTrafficPattern})\r\nから\r\n({newText})に変更しますか？";
                            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                                      MessageBoxButton.YesNo, MessageBoxImage.Information);
                            if (messageBoxResult.Equals(MessageBoxResult.No))
                            {
                                txb.Text = face_data.TrafficPattern;
                            }
                            else
                            {
                                WriteLog.Log($"[登録者一覧画面] 選択した登録者の通行パターン情報は({newTrafficPattern})から({newText})に変更されました。");
                                face_data.TrafficPattern = txb.Text;
                                face_data.IsUpdated = true;
                                face_data.IsDeleted = false;
                                face_data.IsInserted = false;
                                face_data.IsSelected = true;
                                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                            }
                        }
                    }
                }
                txb.Cursor = System.Windows.Input.Cursors.Arrow;
                txb.IsReadOnly = true;
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 登録者通行パターン情報の編集に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者通行パターン情報の編集に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void TextBox_FloorNum_Changed(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;

            if (txb.IsReadOnly)
            {
                return;
            }
            FaceAuthDataBean face_data = (FaceAuthDataBean)txb.DataContext;

            int aout = 0;
            if (int.TryParse(txb.Text, out aout))
            {
                if (txb.Text.StartsWith("0"))
                {
                    txb.Text = aout.ToString();
                }
            }

            if (txb.Text != face_data.FloorNum)
            {
                string msg = $"登録者の行き先階情報を({face_data.FloorNum})から({txb.Text})に変更しますか？";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                          MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.No))
                {
                    txb.Text = face_data.FloorNum;
                }
                else
                {
                    int a = 0;
                    if (int.TryParse(txb.Text, out a))
                    {
                        if (int.Parse(txb.Text) > 24 || int.Parse(txb.Text) < 1)
                        {
                            System.Windows.MessageBox.Show("入力は数値(1-24)でなければなりません。", "情報",
                                    MessageBoxButton.OK, MessageBoxImage.Information);
                            txb.Text = face_data.FloorNum;
                            return;
                        }
                        WriteLog.Log($"[登録者一覧画面] 選択した登録者の行き先階の情報は({face_data.FloorNum})から({txb.Text})に変更されました。");
                        face_data.FloorNum = txb.Text;
                        face_data.IsUpdated = true;
                        face_data.IsDeleted = false;
                        face_data.IsInserted = false;
                        face_data.IsSelected = true;
                        CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    }
                    else
                    {
                        System.Windows.MessageBox.Show($"入力は数値(1-24)でなければなりません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                        txb.Text = face_data.FloorNum;
                        return;
                    }
                }
            }
            txb.Cursor = System.Windows.Input.Cursors.Arrow;
            txb.IsReadOnly = true;
        }

        private void TextBox_Name_Changed(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.TextBox txb = (System.Windows.Controls.TextBox)sender;

            if(txb.IsReadOnly)
            {
                return;
            }
            FaceAuthDataBean face_data = (FaceAuthDataBean)txb.DataContext;

            if(txb.Text != face_data.StaffName)
            {
                if (txb.Text.IndexOf(',') != -1)
                {
                    string msgComma = $"登録者の名前情報にカンマがありますので、更新できません。";
                    MessageBoxResult messageBoxResultForComma = System.Windows.MessageBox.Show(msgComma, "確認",
                              MessageBoxButton.OK, MessageBoxImage.Error);
                    txb.Text = face_data.StaffName;
                }
                else
                {
                    string msg = $"登録者の名前情報を({face_data.StaffName})から({txb.Text})に変更しますか？";
                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                              MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.No))
                    {
                        txb.Text = face_data.StaffName;
                    }
                    else
                    {
                        WriteLog.Log($"[登録者一覧画面] 選択した登録者の名前情報は({face_data.StaffName})から({txb.Text})に変更されました。");
                        face_data.StaffName = txb.Text;
                        face_data.IsUpdated = true;
                        face_data.IsDeleted = false;
                        face_data.IsInserted = false;
                        face_data.IsSelected = true;
                        CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    }
                }
            }
            txb.Cursor = System.Windows.Input.Cursors.Arrow;
            txb.IsReadOnly = true;
        }

        private void TextBox_Name_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool isComma = e.Key == Key.OemComma;

            if (isComma)
                e.Handled = true;
            else
                e.Handled = false;
        }

        private void TextBox_FloorNum_PreviewKeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            bool isNumber = e.Key >= Key.D0 && e.Key <= Key.D9 || e.Key >= Key.NumPad0 && e.Key <= Key.NumPad9;
            bool isBack = e.Key == Key.Back;
            bool isTab = e.Key == Key.Tab;
            bool isEnter = e.Key == Key.Enter;
            bool isLeftOrRight = e.Key == Key.Left || e.Key == Key.Right;
            bool isKeyupOrKeydown = e.Key == Key.Up || e.Key == Key.Down;
            bool isCtrlA = e.Key == Key.A && e.KeyboardDevice.Modifiers == ModifierKeys.Control;

            if (isNumber || isCtrlA || isBack || isTab || isLeftOrRight || isKeyupOrKeydown || isEnter) {
                e.Handled = false;
            }
            else
                e.Handled = true;
        }

        private void RadioBtn_Checked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.RadioButton btn = (System.Windows.Controls.RadioButton)sender;
            FaceAuthDataBean face_data = (FaceAuthDataBean)btn.DataContext;
            if (!face_data.IsChecked)
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => item.IsChecked);
                foreach (FaceAuthDataBean face_data_item in FaceDatas)
                {
                    face_data_item.IsChecked = false;
                }
                face_data.IsChecked = true;
            }
        }

        private void RadioBtn_UnChecked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.RadioButton btn = (System.Windows.Controls.RadioButton)sender;
            FaceAuthDataBean face_data = (FaceAuthDataBean)btn.DataContext;
            face_data.IsChecked = false;
        }

        private void CheckBox_Checked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.CheckBox btn = (System.Windows.Controls.CheckBox)sender;
            FaceAuthDataBean face_data = (FaceAuthDataBean)btn.DataContext;
            face_data.IsSelected = true;
        }

        private void CheckBox_UnChecked(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.CheckBox btn = (System.Windows.Controls.CheckBox)sender;
            FaceAuthDataBean face_data = (FaceAuthDataBean)btn.DataContext;
            face_data.IsSelected = false;
        }

        private void CheckBox_All_Checked(object sender, RoutedEventArgs e)
        {
            IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => false == item.IsSelected);
            foreach (FaceAuthDataBean face_data in FaceDatas)
            {
                face_data.IsSelected = true;
            }
            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
        }

        private void CheckBox_All_UnChecked(object sender, RoutedEventArgs e)
        {
            IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => true == item.IsSelected);
            foreach (FaceAuthDataBean face_data in FaceDatas)
            {
                face_data.IsSelected = false;
            }
            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
        }

        private void Btn_Edit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                FaceAuthDataBean FaceData = this.ViewModel.Recordings.Where(item => { return item.IsChecked; }).FirstOrDefault();
                if (FaceData == null)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                AtlasServerDataBean select_atlas = (AtlasServerDataBean)this.combo_atlas.SelectedItem;
                string atlas_ip = select_atlas.Server_Ip;
                if ("".Equals(atlas_ip) && this.AtlasViewModel.Recordings.Count > 1)
                {
                    atlas_ip = this.AtlasViewModel.Recordings[1].Server_Ip;
                }
                EditFaceAuthPage editFaceAuthPage = new EditFaceAuthPage(FaceData, atlas_ip, this.IsFaceTransmitMode);
                editFaceAuthPage.Owner = this;
                editFaceAuthPage.ShowDialog();
                if (true == editFaceAuthPage.HasChanged)
                {
                    FaceData.IsUpdated = true;
                    FaceData.IsDeleted = false;
                    FaceData.IsInserted = false;
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLog.Log($"[登録者一覧画面] 登録者({FaceData.FaceId})の顔情報を編集しました。");
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 登録者顔情報の編集に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者顔情報の編集に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void Btn_Delete_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                int FaceCount = FaceDatas.Count();
                if (FaceCount == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                string msg = "登録者の顔情報(画像データ)を削除しますか？";
                if (IsFaceTransmitMode == 1)
                {
                    msg = "登録者の顔情報(画像データと氏名)を削除しますか？";
                }
                if (IsFaceTransmitMode == 2)
                {
                    msg = "登録者の顔情報を削除しますか？";
                }
                if (IsFaceTransmitMode == 3)
                {
                    msg = "登録者の顔情報を削除しますか？";
                }
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.Yes))
                {
                    foreach (FaceAuthDataBean FaceData in FaceDatas)
                    {
                        FaceData.StaffImgName = "";
                        FaceData.Staff_Image = null;
                        FaceData.IsDeleted = true;
                        FaceData.IsUpdated = false;
                        FaceData.IsSelected = false;
                        if (IsFaceTransmitMode == 1 || IsFaceTransmitMode == 2)
                        {
                            FaceData.StaffName = "";
                        }
                        if (IsFaceTransmitMode == 2)
                        {
                            FaceData.FloorNum = "";
                        }
                        if (IsFaceTransmitMode == 3)
                        {
                            FaceData.TrafficPattern = "";
                        }
                    }
                    this.CheckBox_All.IsChecked = false;
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLog.Log($"[登録者一覧画面] 選択した登録者の顔情報({FaceCount}件)は正常に削除されました。");
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 登録者顔情報の削除に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者顔情報の削除に失敗しました。{ex.Message}", "情報",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private async void Btn_Read_Click(object sender, RoutedEventArgs e)
        {
            ReadSrcDataBean select_read = (ReadSrcDataBean)this.combo_file.SelectedItem;
            
            if (select_read.Key == 1)
            {
                OpenFileDialog openFile = new OpenFileDialog
                {
                    Multiselect = false,
                    Filter = "CSVファイル(*.csv)|*.csv"
                };
                DialogResult result = openFile.ShowDialog();
                if (result == System.Windows.Forms.DialogResult.Cancel)
                {
                    return;
                }

                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                var SelectCSVFile = openFile.FileName;
                WriteLog.Log($"[登録者一覧画面] センターCSVファイル({SelectCSVFile})から登録者データを読み込みます。");
                ReadFromCenterFile(SelectCSVFile);
                WriteLog.Log($"[登録者一覧画面] センターCSVファイルからの読み込みは完了しました。");
                SetRecordsCount();

                this.ViewModel.Recordings = new ObservableCollection<FaceAuthDataBean>(this.ViewModel.Recordings.OrderBy(item => item.FaceId));
                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.ViewModel.Recordings)
                {
                    Bean.Idx = ++Idx_;
                }
                this.DG1.DataContext = this.ViewModel.Recordings;
                
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
            else
            {
                int AtlasCount = this.AtlasViewModel.Recordings.Count();
                if (AtlasCount <= 1)
                {
                    System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                AtlasServerDataBean SelectAtlas = (AtlasServerDataBean)this.combo_atlas.SelectedItem;
                if ("".Equals(SelectAtlas.Server_Ip))
                {
                    SelectAtlas = this.AtlasViewModel.Recordings[1];
                }
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;

                WriteLog.Log($"[登録者一覧画面] 装置({SelectAtlas.Server_Name}:{SelectAtlas.Server_Ip})から登録者データを読み込みます。");
                int AtlasKey = int.Parse(SelectAtlas.Server_Name);
                this.IsRecoveryMode = true;
                // modify by yuan 2021/01/28 　　#223により、仕様変更
                this.IsReadFromAtlas = true;
                var result = await this.ViewModel.ReadFromAtlas(SelectAtlas.Server_Ip, AtlasKey, AtlasCount-1);
                
                if (!result)
                {
                    loading.IsActive = false;
                    loadingPart.Visibility = Visibility.Hidden;
                    return;
                }

                WriteLog.Log($"[登録者一覧画面] 装置からの読み込みは完了しました。");
                SetRecordsCount();
                this.DG1.DataContext = this.ViewModel.Recordings;
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }

        private void Btn_Write_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // modify by yuan 2021/01/28 　　#223により、仕様変更
                if (this.IsReadFromAtlas)
                {
                    string msg = "端末の顔情報をPCに反映します。\nPCに端末への未反映の顔情報がある場合、\nPCの顔情報が完全に削除されても宜しいですか。";

                    MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                        MessageBoxButton.YesNo, MessageBoxImage.Information);
                    if (messageBoxResult.Equals(MessageBoxResult.No))
                    {
                        return;
                    }
                }

                if (this.AtlasViewModel.Recordings.Count() <= 1)
                {
                    System.Windows.MessageBox.Show("対象装置が見つかりませんでした。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                AtlasServerDataBean SelectAtlas = (AtlasServerDataBean)this.combo_atlas.SelectedItem;
                if (!"".Equals(SelectAtlas.Server_Ip))
                {
                    System.Windows.MessageBox.Show("設定先をALLに指定してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                
                List<FaceAuthDataBean> FaceDatasToDelete = this.ViewModel.Recordings.Where(item =>
                {
                    return item.IsSelected && (item.IsDeleted || (!item.IsUpdated && "1".Equals(item.LoginStatusCode) && item.Staff_Image==null) );
                }).ToList();
                List<FaceAuthDataBean> FaceDatasToUpdate = this.ViewModel.Recordings.Where(item =>
                {
                    return item.IsSelected && (item.IsUpdated || (!item.IsDeleted && "0".Equals(item.LoginStatusCode) && item.Staff_Image!=null));
                }).ToList();
                List<FaceAuthDataBean> FaceDatasNotChange = this.ViewModel.Recordings.Where(item =>
                {
                    return item.IsSelected && (!item.IsUpdated && !item.IsDeleted
                        && (("1".Equals(item.LoginStatusCode) && item.Staff_Image != null))
                        || ("0".Equals(item.LoginStatusCode) && item.Staff_Image == null));
                }).ToList();
                if (FaceDatasToDelete.Count() == 0 && FaceDatasToUpdate.Count() == 0)
                {
                    System.Windows.MessageBox.Show("選択された登録者データは変更されていません。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                
                loading.IsActive = true;
                loadingPart.Visibility = Visibility.Visible;
                List<Task<bool>> tasks = new List<Task<bool>>();
                var AtlasList = this.AtlasViewModel.Recordings;
                for (int i = 1; i < AtlasList.Count; i++)
                {
                    tasks.Add(UploadData(AtlasList[i].Server_Ip, FaceDatasToDelete, FaceDatasToUpdate, int.Parse(AtlasList[i].Server_Name)));
                }
                Task.Run(() => { Task.WaitAll(tasks.ToArray()); }).ContinueWith(t =>
                {
                    bool isAllTaskOK = true;
                    var taskList = tasks.ToArray();
                    for (int i = 0; i < taskList.Length; i++)
                    {
                        Task<bool> oneTask = taskList[i];

                        if(oneTask.Result == false)
                        {
                            isAllTaskOK = false;
                            break;
                        }
                    }
                    if (!isAllTaskOK && this.IsReadFromAtlas)
                    {
                        System.Windows.MessageBox.Show("装置への登録が失敗しました。", "エラー",
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                        this.Invoke(new Action(() =>
                        {
                            SetRecordsCount();
                            int Idx_ = 0;
                            foreach (FaceAuthDataBean Bean in this.ViewModel.Recordings)
                            {
                                Bean.Idx = ++Idx_;
                            }
                            loading.IsActive = false;
                            loadingPart.Visibility = Visibility.Hidden;
                            this.CheckBox_All.IsChecked = false;
                            CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                        }));
                        return;
                    }
                    

                    // Check all results
                    int deletedCount = 0;
                    foreach (FaceAuthDataBean Bean in FaceDatasToDelete)
                    {
                        bool detetedResult = true;
                        for (int i = 1; i < AtlasList.Count; i++)
                        {
                            string userId = ReturnUserId(Bean, int.Parse(AtlasList[i].Server_Name));
                            if (!"".Equals(userId)) {
                                detetedResult = false;
                                break;
                            }
                        }
                        if (detetedResult)
                        {
                            deletedCount++;
                            if (this.IsBackupMode && this.IsFaceTransmitMode == 0)
                            {
                                this.Invoke(new Action(() =>
                                {
                                    this.ViewModel.Recordings.Remove(Bean);
                                }));
                                continue;
                            }
                            // BIVALE連携モード　通行パータン対応
                            if (this.IsBackupMode && this.IsFaceTransmitMode == 3)
                            {
                                this.Invoke(new Action(() =>
                                {
                                    this.ViewModel.Recordings.Remove(Bean);
                                }));
                                continue;
                            }
                            Bean.StaffImgPath = "";
                            Bean.LoginStatus = "無";
                            Bean.LoginStatusCode = "0";
                            Bean.IsDeleted = false;
                            Bean.IsUpdated = false;
                            Bean.IsInserted = false;
                            Bean.IsSelected = false;
                        }
                    }

                    int updatedCount = 0;
                    foreach (FaceAuthDataBean Bean in FaceDatasToUpdate)
                    {
                        bool updatedResult = true;
                        // 通行パターン対応
                        if (this.IsFaceTransmitMode == 3)
                        {
                            for (int i = 1; i < AtlasList.Count; i++)
                            {
                                string traffic = Bean.TrafficPattern;

                                string oldTrafficPattern = Bean.TrafficPattern;
                                string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWriteComma);

                                string[] strarrTraffic = newTrafficPattern.Split(',');

                                int iExists = Array.IndexOf(strarrTraffic, Configure.TrafficList[int.Parse(AtlasList[i].Server_Name) - 1]);
                                if (iExists == -1 && Configure.TrafficList[int.Parse(AtlasList[i].Server_Name) - 1] != "共有")
                                {
                                    // 登録者の該当更新状態には、チェック必要がありません。
                                    continue;
                                }

                                string userId = ReturnUserId(Bean, int.Parse(AtlasList[i].Server_Name));
                                if ("".Equals(userId) || userId == null)
                                {
                                    updatedResult = false;
                                    break;
                                }
                            }
                        }
                        else
                        {
                            for (int i = 1; i < AtlasList.Count; i++)
                            {
                                string userId = ReturnUserId(Bean, int.Parse(AtlasList[i].Server_Name));
                                if ("".Equals(userId) || userId == null)
                                {
                                    updatedResult = false;
                                    break;
                                }
                            }
                        }
                        
                        if (updatedResult)
                        {
                            string imagePath = Path.Combine(Configure.FaceDataPath, Bean.StaffImgName);
                            bool imageRes = ImageHelper.EncryptFile((BitmapImage)Bean.Staff_Image, imagePath);
                            if (!imageRes)
                            {
                                continue;
                            }
                            updatedCount++;
                            Bean.StaffImgPath = imagePath;
                            Bean.LoginStatus = "有";
                            Bean.LoginStatusCode = "1";
                            Bean.IsDeleted = false;
                            Bean.IsUpdated = false;
                            Bean.IsInserted = false;
                            Bean.IsSelected = false;
                        }
                    }

                    foreach (FaceAuthDataBean Bean in FaceDatasNotChange)
                    {
                        Bean.IsSelected = false;
                    }

                    if (deletedCount < FaceDatasToDelete.Count())
                    {
                        WriteLog.Log($"[登録者一覧画面] 装置へ顔データの削除が失敗しました。{FaceDatasToDelete.Count()}件の削除が必要ですが、{deletedCount}件だけが削除成功しました。");
                    }
                    if (updatedCount < FaceDatasToUpdate.Count())
                    {
                        WriteLog.Log($"[登録者一覧画面] 装置へ顔データの更新が失敗しました。{FaceDatasToUpdate.Count()}件の更新が必要ですが、{updatedCount}件だけが更新成功しました。");
                    }

                    bool uploadResult = false;
                    if (deletedCount >= FaceDatasToDelete.Count() && updatedCount >= FaceDatasToUpdate.Count())
                    {
                        uploadResult = true;
                        this.IsRecoveryMode = false;
                        WriteLog.Log($"[登録者一覧画面] 装置へ顔データの登録({deletedCount}件の削除、{updatedCount}件の更新)が成功しました。");
                    }

                    // Save csv file
                    String csvPath = Configure.ToolCsvPath + "\\tool_csv.csv";
                    bool csvResult = ToCSV(csvPath);
                    if (uploadResult && csvResult)
                    {
                        System.Windows.MessageBox.Show("装置への登録が成功しました。", "情報",
                                        MessageBoxButton.OK, MessageBoxImage.Information);
                    }
                    else
                    {
                        System.Windows.MessageBox.Show("装置への登録が失敗しました。", "エラー",
                                        MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                    this.Invoke(new Action(() =>
                    {
                        SetRecordsCount();
                        int Idx_ = 0;
                        foreach (FaceAuthDataBean Bean in this.ViewModel.Recordings)
                        {
                            Bean.Idx = ++Idx_;
                        }
                        loading.IsActive = false;
                        loadingPart.Visibility = Visibility.Hidden;
                        this.CheckBox_All.IsChecked = false;
                        CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    }));
                });
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 装置への登録が失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"装置への登録が失敗しました。{ex.Message}", "エラー",
                            MessageBoxButton.OK, MessageBoxImage.Error);
                loading.IsActive = false;
                loadingPart.Visibility = Visibility.Hidden;
            }
        }

        private void Btn_Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            string msg = "アプリを終了しますか?";
            IEnumerable<FaceAuthDataBean> UnsavedFaceDatas = this.ViewModel.Recordings.Where(item => { return (item.IsDeleted || item.IsUpdated); });
            if (UnsavedFaceDatas.Count() > 0)
            {
                msg = "変更が保存されていません。\r\n" + msg;
            }
            MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                MessageBoxButton.YesNo, MessageBoxImage.Information);
            if (messageBoxResult.Equals(MessageBoxResult.Yes))
            {
                WriteLog.Log($"[登録者一覧画面] 登録者一覧画面を閉じました。");
                base.OnClosing(e);
            }
            else
            {
                e.Cancel = true;
                base.OnClosing(e);
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            System.Environment.Exit(0);
            base.OnClosed(e);
        }

        private void Btn_CSV_Click(object sender, RoutedEventArgs e)
        {
            Microsoft.Win32.SaveFileDialog Dlg = new Microsoft.Win32.SaveFileDialog
            {
                FileName = "Tool_backup",
                DefaultExt = ".csv",
                Filter = "CSV documents (.csv)|*.csv"
            };
            Nullable<bool> result = Dlg.ShowDialog();
            if (result == true)
            {
                bool CallByBackup = true;
                bool res = ToCSV(Dlg.FileName, CallByBackup);
                if (res == true)
                {
                    System.Windows.MessageBox.Show("バックアップが成功しました。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    System.Windows.MessageBox.Show("バックアップが失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        public bool ToCSV(string FilePath, bool CallByBackup=false)
        {
            try
            {
                // modify by yuan 2021/01/28 　　#223により、仕様変更
                List<List<string>> csvInfo = new List<List<string>>();

                if (this.IsReadFromAtlas && !CallByBackup)
                {
                    if (this.IsFaceTransmitMode == 0 || this.IsFaceTransmitMode == 3)
                    {
                        csvInfo = Read_CSV_info();
                    }
                }

                if (File.Exists(FilePath))
                {
                    
                    File.Delete(FilePath);
                }

                if (!Directory.Exists(Configure.FaceDataPath))
                {
                    Directory.CreateDirectory(Configure.FaceDataPath);
                }

                // modify by yuan 2021/01/28 　　#223により、仕様変更
                if (this.IsReadFromAtlas && !CallByBackup)
                {
                    if (this.IsFaceTransmitMode == 1 || this.IsFaceTransmitMode == 2)
                    {
                        bool csvResult = Init_CSV_8000();

                        if (csvResult)
                        {
                            return true;
                        }

                        return false;
                    }

                    if (this.IsFaceTransmitMode == 0 || this.IsFaceTransmitMode == 3)
                    {
                        bool csvResult = Init_CSV_by_CsvInfo(csvInfo);

                        if (csvResult)
                        {
                            return true;
                        }

                        return false;
                    }
                }
                

                using (FileStream _stream = new FileStream(FilePath, FileMode.Create, FileAccess.ReadWrite))
                {
                    StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);

                    foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                    {
                        string sline;
                        if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                        {
                            ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                        }
                        if (this.IsFaceTransmitMode == 3)
                        {
                            // Replace CR/LF
                            string oldTrafficPattern = beanTable.TrafficPattern;
                            string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWrite);

                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + newTrafficPattern + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        else if (this.IsFaceTransmitMode == 2)
                        {
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + beanTable.FloorNum + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        else
                        {
                            // this.IsFaceTransmitMode == 0 || this.IsFaceTransmitMode == 1
                            sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                            + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                            + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + ",";
                            for (int i = 0; i < beanTable.UserIds.Length; i++)
                            {
                                sline = sline + "," + beanTable.UserIds[i];
                            }
                        }
                        _writer.WriteLine(sline);
                    }
                    _writer.Close();
                    return true;
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] CSVファイルへの出力が失敗しました。{ex.Message}");
                return false;
            }
        }

        // modify by yuan 2021/01/28 　　#223により、仕様変更
        public bool Init_CSV_8000()
        {
            String csvPath = Configure.ToolCsvPath + "\\tool_csv.csv";

            using (FileStream _stream = new FileStream(csvPath, FileMode.Create, FileAccess.ReadWrite))
            {
                StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);

                if (this.IsFaceTransmitMode == 1)
                {
                    for (int id = 1; id < 8001; id++)
                    {
                        string sline;
                        string card_id = "CARDID" + id.ToString().PadLeft(10, '0');
                        bool isNeedWrite = false;

                        foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                        {
                            if (card_id.Equals(beanTable.FaceId))
                            {
                                if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                                {
                                    ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                                }

                                sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + ",";
                                for (int i = 0; i < beanTable.UserIds.Length; i++)
                                {
                                    sline = sline + "," + beanTable.UserIds[i];
                                }
                                isNeedWrite = true;
                                _writer.WriteLine(sline);
                                break;
                            }
                        }

                        if (!isNeedWrite)
                        {
                            sline = "," + card_id + "," + "," + "," + "," + "," + "0" + "," + "," + "," + "," + "," + "無" + "," + "," + ",";
                            for (int user_id = 0; user_id < 64; user_id++)
                            {
                                sline = sline + ",";
                            }
                            _writer.WriteLine(sline);
                        }
                    }
                }

                if (this.IsFaceTransmitMode == 2)
                {
                    for (int id = 1; id < 8001; id++)
                    {
                        string sline;
                        string card_id = "CARDID" + id.ToString().PadLeft(10, '0');
                        bool isNeedWrite = false;

                        foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                        {
                            if (card_id.Equals(beanTable.FaceId))
                            {
                                if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                                {
                                    ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                                }

                                sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + beanTable.FloorNum + "," + ",";
                                for (int i = 0; i < beanTable.UserIds.Length; i++)
                                {
                                    sline = sline + "," + beanTable.UserIds[i];
                                }
                                isNeedWrite = true;
                                _writer.WriteLine(sline);
                                break;
                            }
                        }

                        if (!isNeedWrite)
                        {
                            sline = "," + card_id + "," + "," + "," + "," + "," + "0" + "," + "," + "," + "," + "," + "無" + "," + "1" + "," + ",";
                            for (int user_id = 0; user_id < 64; user_id++)
                            {
                                sline = sline + ",";
                            }
                            _writer.WriteLine(sline);
                        }
                    }
                }
                
                _writer.Close();
                return true;
            }
        }

        // modify by yuan 2021/02/08 　　#223により、仕様変更
        public bool Init_CSV_by_CsvInfo(List<List<string>> csvInfo)
        {
            String csvPath = Configure.ToolCsvPath + "\\tool_csv.csv";

            List<List<string>> cardInfos = csvInfo;

            using (FileStream _stream = new FileStream(csvPath, FileMode.Create, FileAccess.ReadWrite))
            {
                StreamWriter _writer = new StreamWriter(_stream, System.Text.Encoding.UTF8);

                if (this.IsFaceTransmitMode == 0 || this.IsFaceTransmitMode == 3)
                {
                    string sline = "";

                    foreach (FaceAuthDataBean beanTable in this.ViewModel.Recordings)
                    {
                        bool IsWrited = false;
                        foreach (List<string> cardInfo in cardInfos)
                        {
                            string[] Values = cardInfo.ToArray();

                            // values[1] == FaceId
                            // tool_csvに存在する
                            if (Values[1].Equals(beanTable.FaceId))
                            {
                                // values[3] == StaffName
                                if (Values[3].Equals(beanTable.StaffName))
                                {
                                    if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                                    {
                                        ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                                    }

                                    if (this.IsFaceTransmitMode == 3)
                                    {
                                        // Replace CR/LF
                                        string oldTrafficPattern = beanTable.TrafficPattern;
                                        string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWrite);

                                        sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                        + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                        + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + ","
                                        // Atlasの顔IDとtool_csv.csvの顔IDが一致かつ
                                        // Atlasの氏名 とtool_csv.csvの氏名が一致の場合
                                        // ⇒通行パターンは変えない、tool_csv.csv画像Atlas画像に差し変える
                                        + Values[13] + ",";

                                        for (int i = 0; i < beanTable.UserIds.Length; i++)
                                        {
                                            sline = sline + "," + beanTable.UserIds[i];
                                        }
                                    }
                                    else
                                    {
                                        // this.IsFaceTransmitMode == 0
                                        sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                        + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                        + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + ",";
                                        for (int i = 0; i < beanTable.UserIds.Length; i++)
                                        {
                                            sline = sline + "," + beanTable.UserIds[i];
                                        }
                                    }

                                    _writer.WriteLine(sline);

                                    cardInfos.Remove(cardInfo);
                                    IsWrited = true;
                                    break;
                                }
                                else
                                {
                                    // Atlasの顔IDとtool_csv.csvの顔IDが一致かつ
                                    // Atlasの氏名 とtool_csv.csvの氏名が一致しないの場合
                                    // ⇒通行パターン削除、tool_csv.csv画像Atlas画像に差し変える

                                    // values[13] == TrafficPattern
                                    // TrafficPattern削除
                                    Values[13] = "";

                                    if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                                    {
                                        ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                                    }

                                    if (this.IsFaceTransmitMode == 3)
                                    {
                                        // Replace CR/LF
                                        string oldTrafficPattern = beanTable.TrafficPattern;
                                        string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWrite);

                                        sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                        + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                        + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + Values[13] + ",";
                                        for (int i = 0; i < beanTable.UserIds.Length; i++)
                                        {
                                            sline = sline + "," + beanTable.UserIds[i];
                                        }
                                    }
                                    else
                                    {
                                        // this.IsFaceTransmitMode == 0
                                        sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                        + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                        + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + ",";
                                        for (int i = 0; i < beanTable.UserIds.Length; i++)
                                        {
                                            sline = sline + "," + beanTable.UserIds[i];
                                        }
                                    }

                                    _writer.WriteLine(sline);

                                    cardInfos.Remove(cardInfo);
                                    IsWrited = true;
                                    break;
                                }
                            }
                        }

                        // tool_csvに存在しない
                        if (!IsWrited)
                        {
                            if (!"".Equals(beanTable.StaffImgPath) && !File.Exists(beanTable.StaffImgPath) && beanTable.Staff_Image != null)
                            {
                                ImageHelper.EncryptFile((BitmapImage)beanTable.Staff_Image, beanTable.StaffImgPath);
                            }

                            if (this.IsFaceTransmitMode == 3)
                            {
                                // Replace CR/LF
                                string oldTrafficPattern = beanTable.TrafficPattern;
                                string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWrite);

                                sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + newTrafficPattern + ",";
                                for (int i = 0; i < beanTable.UserIds.Length; i++)
                                {
                                    sline = sline + "," + beanTable.UserIds[i];
                                }
                            }
                            else
                            {
                                // this.IsFaceTransmitMode == 0
                                sline = beanTable.TicketId + "," + beanTable.FaceId + "," + beanTable.ManageId + "," + beanTable.StaffName + "," + beanTable.StaffNameKN + ","
                                + beanTable.FigureId + "," + beanTable.FigureStatus + "," + beanTable.Thresholds + "," + beanTable.StartDate + "," + beanTable.ValidDate + ","
                                + beanTable.StaffImgPath + "," + beanTable.LoginStatus + "," + "," + ",";
                                for (int i = 0; i < beanTable.UserIds.Length; i++)
                                {
                                    sline = sline + "," + beanTable.UserIds[i];
                                }
                            }
                            _writer.WriteLine(sline);
                        }
                    }

                    foreach (List<string> cardInfo in cardInfos)
                    {
                        string[] Values = cardInfo.ToArray();

                        // values[10] == StaffImgPath
                        Values[10] = "";
                        // values[13] == TrafficPattern
                        Values[13] = "";

                        // Values[1] == FaceId    Values[3] == StaffName
                        sline = "," + Values[1] + "," + "," + Values[3] + "," + "," + "," + "0" + "," + "," + "," + "," + "," + "無" + "," + "," + ",";
                        for (int user_id = 0; user_id < 64; user_id++)
                        {
                            sline = sline + ",";
                        }
                        _writer.WriteLine(sline);
                    }
                }
                _writer.Close();
                return true;
            }
        }

        // modify by yuan 2021/01/28 　　#223により、仕様変更
        public List<List<string>> Read_CSV_info()
        {
            try
            {
                String csvPath = Configure.ToolCsvPath + "\\tool_csv.csv";
                List<List<string>> csvLines;
                List<List<string>> csvInfo = new List<List<string>>();

                if (!File.Exists(csvPath))
                {
                    return csvInfo;
                }

                CsvFile Csv = new CsvFile(csvPath);
                csvLines = Csv.Read(0, "UTF-8");
                int maxColumn = 79;

                foreach (List<string> line in csvLines)
                {
                    string[] Values = line.ToArray();

                    if (Values.Length < maxColumn)
                    {
                        continue;
                    }
                    if (CheckBytes(Values[0], 32) || CheckBytes(Values[1], 32) || CheckBytes(Values[2], 16)
                        || CheckBytes(Values[3], 50) || CheckBytes(Values[4], 50) || CheckBytes(Values[5], 4)
                        || CheckBytes(Values[6], 1) || CheckBytes(Values[7], 4) || CheckBytes(Values[8], 10)
                        || CheckBytes(Values[9], 10))
                    {
                        continue;
                    }

                    csvInfo.Add(line);
                }

                return csvInfo;                
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] ファイルから顔データの読込は失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"ファイルから顔データの読込は失敗しました。{ex.Message}", "エラー", 
                    MessageBoxButton.OK, MessageBoxImage.Error);

                List<List<string>> csvInfo_null = new List<List<string>>();
                return csvInfo_null;
            }
        }

        private Boolean CheckBytes(string text, int max)
        {
            int ByteLength = System.Text.Encoding.Default.GetByteCount(text.Trim());
            if (ByteLength > max)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        private async Task<bool> UploadData(string AtlasIp, List<FaceAuthDataBean> FaceDatasToDelete, List<FaceAuthDataBean> FaceDatasToUpdate, int No)
        {
            var Api = new AtlasApi();
            var Token = await Api.GetToken(AtlasIp);
            if ("".Equals(Token))
            {
                return false;
            }

            bool IsDBNew = false;
            string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
            if ("".Equals(DBId))
            {
                DBId = await Api.NewDBByName(AtlasIp, Token, Configure.LibraryName, LibraryDesp);
                if ("".Equals(DBId))
                {
                    return false;
                }
                IsDBNew = true;
            }
            else if (this.IsRecoveryMode)
            {
                var UserList = await Api.GetUserList(AtlasIp, Token, DBId, No, this.AtlasViewModel.Recordings.Count()-1);
                foreach (var user in UserList)
                {
                    bool exists = false;
                    string userIdAtlas = ReturnUserId(user, No);
                    foreach (FaceAuthDataBean bean in this.ViewModel.Recordings)
                    {
                        if (userIdAtlas.Equals(ReturnUserId(bean, No)))
                        {
                            exists = true;
                            break;
                        }
                    }
                    if (!exists)
                    {
                        await Api.DelUserByUserID(AtlasIp, Token, DBId, userIdAtlas);
                    }
                }
            }

            Boolean Flag = true;
            foreach (FaceAuthDataBean bean in FaceDatasToDelete.Concat(FaceDatasToUpdate))
            {
                string UserId_Temp = ReturnUserId(bean, No);
                if (!"".Equals(UserId_Temp))
                {
                    if (IsDBNew)
                    {
                        this.UpdateUserId(bean, No, "");
                        continue;
                    }
                    Flag = await Api.DelUserByUserID(AtlasIp, Token, DBId, UserId_Temp);
                    if (!Flag)
                    {
                        WriteLog.Log($"[登録者一覧画面] 顔データ(顔ID:{bean.FaceId})の削除が失敗しました。");
                    }
                    // TODO: 强制赋值为空风险，但如果不赋值为空，该记录后面不可能再登录成功
                    this.UpdateUserId(bean, No, "");
                }
            }
            if (FaceDatasToUpdate.Count() == 0)
            {
                return true;
            }

            // 通行パターン対応
            if (this.IsFaceTransmitMode == 3)
            {
                List<FaceAuthDataBean> FaceDatasToUpdate_Traffic = new List<FaceAuthDataBean>();
                int numAtlas = No - 1;
                if (Configure.TrafficList[numAtlas] != "共有")
                {
                    foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                    {
                        string traffic = bean.TrafficPattern;

                        string oldTrafficPattern = bean.TrafficPattern;
                        string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\r\n", matchEvaluWriteComma);

                        string[] strarrTraffic = newTrafficPattern.Split(',');

                        int iExists = Array.IndexOf(strarrTraffic, Configure.TrafficList[numAtlas]);
                        if (iExists != -1)
                        {
                            // 該当登録者には、通行パターンがある、更新必要があります。
                            FaceDatasToUpdate_Traffic.Add(bean);
                        }
                    }

                    if (FaceDatasToUpdate_Traffic.Count() == 0)
                    {
                        return true;
                    }
                    else
                    {
                        FaceDatasToUpdate = FaceDatasToUpdate_Traffic;
                    }
                }
            }
            

            int loginAddCount = 50;
            int totalCount = FaceDatasToUpdate.Count();
            
            for (int i = 0; i <= totalCount / loginAddCount; i++)
            {
                IEnumerable<FaceAuthDataBean> FaceDatasTemp;
                if (i == totalCount / loginAddCount)
                {
                    if (totalCount > loginAddCount)
                    {
                        if(i * loginAddCount < totalCount)
                        {
                            FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, totalCount % loginAddCount);
                        }
                        else
                        {
                            continue;
                        }
                    }
                    else
                    {
                        FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, totalCount);
                    }
                }
                else
                {
                    FaceDatasTemp = FaceDatasToUpdate.GetRange(i * loginAddCount, loginAddCount);
                }

                string response = await Api.AddUserBatch(AtlasIp, Token, DBId, FaceDatasTemp);
                if ("".Equals(response))
                {
                    WriteLog.Log($"[登録者一覧画面] Atlas装置({AtlasIp})への顔データ登録は中断されました。");
                    return false;
                }
                
                var jsonArr = DynamicJson.Parse(response).results;
                foreach (FaceAuthDataBean bean in FaceDatasToUpdate)
                {
                    foreach (var json in jsonArr)
                    {
                        if (json.user != null && bean.FaceId.Equals(json.user.card_id))
                        {
                            this.UpdateUserId(bean, No, json.user.user_id);
                        }
                    }
                }
            }
            return true;
        }
        
        public void ReadFromCenterFile(string FilePath)
        {
            try
            {
                List<FaceAuthDataBean> TempList = new List<FaceAuthDataBean>();
                CsvFile Csv = new CsvFile(FilePath);
                List<List<string>> Lines = Csv.Read(4, "Shift_JIS");
                int Count = 0;
                int OriginCount = 0;
                bool ChangeToRecoveryMode = false;
                bool OverMaxFaceCount = false;

                if (!this.IsBackupMode && !this.IsRecoveryMode)
                {
                    int loginCount = this.ViewModel.Recordings.Where(item => { return "1".Equals(item.LoginStatusCode); }).Count();
                    if (loginCount >= 1)
                    {
                        ChangeToRecoveryMode = true;
                    }
                    this.ViewModel.Recordings.Clear();
                    GC.Collect();
                    GC.WaitForPendingFinalizers();
                }
                else
                {
                    OriginCount = this.ViewModel.Recordings.Count();
                    foreach (FaceAuthDataBean bean in this.ViewModel.Recordings)
                    {
                        bean.IsLossed = true;
                    }
                }

                foreach (List<string> line in Lines)
                {
                    string[] Values = line.ToArray();
                    if (Values.Length < 10)
                    {
                        continue;
                    }
                    if (ViewModel.CheckBytes(Values[0], 32) || ViewModel.CheckBytes(Values[1], 32) || ViewModel.CheckBytes(Values[2], 16)
                        || ViewModel.CheckBytes(Values[3], 50) || ViewModel.CheckBytes(Values[4], 50) || ViewModel.CheckBytes(Values[5], 4)
                        || ViewModel.CheckBytes(Values[6], 1) || ViewModel.CheckBytes(Values[7], 4) || ViewModel.CheckBytes(Values[8], 10)
                        || ViewModel.CheckBytes(Values[9], 10))
                    {
                        continue;
                    }
                    FaceAuthDataBean FaceItem = new FaceAuthDataBean()
                    {
                        TicketId = Values[0],
                        FaceId = Values[1],
                        ManageId = Values[2],
                        StaffName = Values[3],
                        StaffNameKN = Values[4],
                        FigureId = Values[5],
                        FigureStatus = Values[6],
                        Thresholds = Values[7],
                        StartDate = Values[8],
                        ValidDate = Values[9],
                        StaffImgPath = "",
                        StaffImgName = "",
                        Staff_Image = null,
                        UserIds = new string[64],
                        LoginStatus = "無",
                        LoginStatusCode = "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsInserted = false,
                        IsUpdated = false,
                        IsDeleted = false,
                        // add traffic pattern for BIVALE
                        TrafficPattern = ""
                    };

                    if (!IsBackupMode && !IsRecoveryMode)
                    {
                        Count++;
                        if (Count > Configure.MaxFaceCount)
                        {
                            OverMaxFaceCount = true;
                            break;
                        }
                        this.ViewModel.Recordings.Add(FaceItem);
                        continue;
                    }

                    FaceAuthDataBean OriginFaceItem = null;
                    foreach (FaceAuthDataBean bean in this.ViewModel.Recordings)
                    {
                        if (FaceItem.FaceId.Equals(bean.FaceId))
                        {
                            OriginFaceItem = bean;
                            break;
                        }
                    }
                    if (OriginFaceItem == null)
                    {
                        FaceItem.IsInserted = true;
                        FaceItem.IsLossed = false;
                        Count++;
                        if (Count + OriginCount > Configure.MaxFaceCount)
                        {
                            OverMaxFaceCount = true;
                            continue;
                        }
                        this.ViewModel.Recordings.Add(FaceItem);
                    }
                    else
                    {
                        OriginFaceItem.TicketId = FaceItem.TicketId;
                        OriginFaceItem.ManageId = FaceItem.ManageId;
                        OriginFaceItem.StaffNameKN = FaceItem.StaffNameKN;
                        OriginFaceItem.FigureId = FaceItem.FigureId;
                        OriginFaceItem.FigureStatus = FaceItem.FigureStatus;
                        OriginFaceItem.Thresholds = FaceItem.Thresholds;
                        OriginFaceItem.StartDate = FaceItem.StartDate;
                        OriginFaceItem.ValidDate = FaceItem.ValidDate;
                        OriginFaceItem.IsLossed = false;
                        if (!FaceItem.StaffName.Equals(OriginFaceItem.StaffName))
                        {
                            OriginFaceItem.StaffName = FaceItem.StaffName;
                            OriginFaceItem.IsUpdated = true;
                        }
                    }
                }

                if (OverMaxFaceCount)
                {
                    WriteLog.Log($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                    System.Windows.MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
 
                if (IsBackupMode || IsRecoveryMode)
                {
                    List<FaceAuthDataBean> FaceDatasLossed = this.ViewModel.Recordings.Where(item => { return item.IsLossed; }).ToList();
                    foreach (FaceAuthDataBean bean in FaceDatasLossed)
                    {
                        bean.StaffImgPath = "";
                        bean.StaffImgName = "";
                        bean.Staff_Image = null;
                        bean.IsDeleted = true;
                        bean.IsLossed = false;
                    }
                }

                if (ChangeToRecoveryMode)
                {
                    this.IsRecoveryMode = true;
                }
                CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] センターCSVファイルの読出に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show("センターCSVファイルの読出に失敗しました。" + ex.Message, "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        private string ReturnUserId(FaceAuthDataBean Bean, int Index)
        {
            string UserId;
            if (Index >= 1 && Index <= 64)
            {
                UserId = Bean.UserIds[Index - 1];
            }
            else
            {
                UserId = "";
                WriteLog.Log($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
            return UserId;
        }

        private void UpdateUserId(FaceAuthDataBean Bean, int Index, string UserId)
        {
            if (Index >= 1 && Index <= 64)
            {
                Bean.UserIds[Index - 1] = UserId;
            }
            else
            {
                WriteLog.Log($"[Atlas通信ログ] Atlas装置のインデックスが配列の境界外です。index:({Index})");
            }
        }

        private void Window_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (this.loading.IsActive)
            {
                e.Handled = true;
            }
        }

        private void Btn_ClearLoginStatus_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                int FaceCount = FaceDatas.Count();
                if (FaceCount == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                string msg = "登録者の登録状態をクリアしますか？";
                MessageBoxResult messageBoxResult = System.Windows.MessageBox.Show(msg, "確認",
                    MessageBoxButton.YesNo, MessageBoxImage.Information);
                if (messageBoxResult.Equals(MessageBoxResult.Yes))
                {
                    foreach (FaceAuthDataBean FaceData in FaceDatas)
                    {
                        FaceData.LoginStatus = "無";
                        FaceData.LoginStatusCode = "0";
                        FaceData.IsUpdated = true;
                    }
                    this.CheckBox_All.IsChecked = false;
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLog.Log($"[登録者一覧画面] 選択した登録者の登録状態({FaceCount}件)は正常にクリアされました。");
                    System.Windows.MessageBox.Show($"選択した登録者の登録状態({FaceCount}件)は正常にクリアされました", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 登録者登録状態のクリアに失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者登録状態のクリアに失敗しました。{ex.Message}", "情報",
                    MessageBoxButton.OK, MessageBoxImage.Information);
            }
        }

        private void Btn_Search_Click(object sender, RoutedEventArgs e)
        {
            Search SearchPage = new Search(this);
            SearchPage.Show();
            this.btn_search.IsEnabled = false;
        }

        private void Btn_AtlasSetting_Click(object sender, RoutedEventArgs e)
        {
            AtlasSetting AtlasSettingPage = new AtlasSetting();
            AtlasSettingPage.ShowDialog();
        }

        private void Btn_batchEdit_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                if (FaceDatas.Count() == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                EditFloorNum editFloorNum = new EditFloorNum(FaceDatas);
                editFloorNum.Owner = this;
                editFloorNum.ShowDialog();
                if (true == editFloorNum.HasChanged)
                {
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    //WriteLog.Log($"[登録者一覧画面] 登録者({FaceData.FaceId})の顔情報を編集しました。");
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 登録者の行き先階の情報の編集に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者の行き先階の情報の編集に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btn_edit_traffic_batch_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                IEnumerable<FaceAuthDataBean> FaceDatas = this.ViewModel.Recordings.Where(item => { return item.IsSelected; });
                if (FaceDatas.Count() == 0)
                {
                    System.Windows.MessageBox.Show("登録者データを選択してください。", "情報",
                        MessageBoxButton.OK, MessageBoxImage.Information);
                    return;
                }
                EditTraffic editTrafficPattern = new EditTraffic(FaceDatas);
                editTrafficPattern.Owner = this;
                editTrafficPattern.ShowDialog();
                if (true == editTrafficPattern.HasChanged)
                {
                    CollectionViewSource.GetDefaultView(this.DG1.ItemsSource).Refresh();
                    WriteLog.Log($"[登録者一覧画面] 登録者の通行パターン情報を一括編集しました。");
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 登録者の通行パターン情報の一括編集に失敗しました。{ex.Message}");
                System.Windows.MessageBox.Show($"登録者の通行パターン情報の一括編集に失敗しました。{ex.Message}", "エラー",
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }
}
