﻿using System;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Drawing;
using System.Windows;

namespace RegisterFaceAuthTool
{
    public class ImageHelper
    {
        public static string Key = "QXRsYXM1MDA=";
        public static byte[] sKey = new byte[8];
        public static byte[] sIV = new byte[8];

        static ImageHelper()
        {
            byte[] keyByteArray = Encoding.Default.GetBytes(Key);
            SHA1 ha = new SHA1Managed();
            byte[] hb = ha.ComputeHash(keyByteArray);

            for (int i = 0; i < 8; i++)
                sKey[i] = hb[i];
            for (int i = 8; i < 16; i++)
                sIV[i - 8] = hb[i];
        }

        public static bool EncryptFile(BitmapImage bitmapImage, string savePath)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bitmapImage));
                using (MemoryStream ims = new MemoryStream())
                {
                    encoder.Save(ims);
                    inputByteArray = ims.ToArray();
                }

                des.Key = sKey;
                des.IV = sIV;
                using (MemoryStream ms = new MemoryStream())
                {
                    using (CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(inputByteArray, 0, inputByteArray.Length);
                        cs.FlushFinalBlock();
                        using (FileStream fs = File.Create(savePath))
                        {
                            foreach (byte b in ms.ToArray())
                            {
                                fs.WriteByte(b);
                            }
                        }
                    }
                }
                return true;
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[イメージツール] 画像ファイル({savePath})の暗号化保存は失敗しました。{ex.Message}");
            }
            return false;
        }

        public static BitmapImage DecryptFile(string filePath)
        {
            try
            {
                DESCryptoServiceProvider des = new DESCryptoServiceProvider();
                byte[] inputByteArray;
                using (FileStream fs = File.OpenRead(filePath))
                {
                    inputByteArray = new byte[fs.Length];
                    fs.Read(inputByteArray, 0, (int)fs.Length);
                }

                des.Key = sKey;
                des.IV = sIV;
                using (WrappingStream wrapper = new WrappingStream(new MemoryStream()))
                {
                    using (CryptoStream cs = new CryptoStream(wrapper, des.CreateDecryptor(), CryptoStreamMode.Write))
                    {
                        cs.Write(inputByteArray, 0, inputByteArray.Length);
                        cs.FlushFinalBlock();
                        wrapper.Position = 0;
                        BitmapImage bitmapImage = new BitmapImage();
                        bitmapImage.BeginInit();
                        bitmapImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                        bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                        bitmapImage.UriSource = null;
                        bitmapImage.StreamSource = wrapper;
                        bitmapImage.EndInit();
                        bitmapImage.Freeze();
                        return bitmapImage;
                    }
                }
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[イメージツール] 暗号化した画像ファイル({filePath})の読み込みは失敗しました。{ex.Message}");
            }
            return null;
        }

        public static long GetImageSize(string file)
        {
            try
            {
                FileInfo info = new FileInfo(file);
                return info.Length;
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[イメージツール] 画像ファイル({file})のサイズ取得は失敗しました。{ex.Message}");
            }
            return 0;
        }

        public static BitmapImage GetBitmapImage(string file)
        {
            try
            {
                BitmapImage bmpImg = new BitmapImage();
                bmpImg.BeginInit();
                bmpImg.CacheOption = BitmapCacheOption.OnLoad;
                bmpImg.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
                bmpImg.UriSource = new Uri(file);
                bmpImg.EndInit();
                bmpImg.Freeze();
                return bmpImg;
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[イメージツール] 画像ファイル({file})の読み込みは失敗しました。{ex.Message}");
            }
            return null;
        }

        public static string BitmapToBase64(BitmapImage bi)
        {
            using (MemoryStream ms = new MemoryStream())
            {
                JpegBitmapEncoder encoder = new JpegBitmapEncoder();
                encoder.Frames.Add(BitmapFrame.Create(bi));
                encoder.Save(ms);
                byte[] bitmapdata = ms.ToArray();
                return Convert.ToBase64String(bitmapdata);
            }
        }

        public static BitmapSource GetBitmapImageExifOrientate(string file)
        {
            BitmapImage bmpImage = new BitmapImage();
            FileStream stream = File.OpenRead(file);
            bmpImage.BeginInit();
            bmpImage.CacheOption = BitmapCacheOption.OnLoad;
            bmpImage.CreateOptions = BitmapCreateOptions.PreservePixelFormat;
            bmpImage.StreamSource = stream;


            var metaData = (BitmapFrame.Create(stream).Metadata) as BitmapMetadata;

            stream.Position = 0;
            bmpImage.UriSource = new Uri(file);
            

            string query = "/app1/ifd/exif:{uint=274}";
            if (!metaData.ContainsQuery(query))
            {
                bmpImage.EndInit();
                bmpImage.Freeze();
                stream.Close();
                return bmpImage;
            }
            switch (Convert.ToUInt32(metaData.GetQuery(query)))
            {
                case 1:
                    break;
                case 3:
                    bmpImage.Rotation = Rotation.Rotate180;
                    break;
                case 6:
                    bmpImage.Rotation = Rotation.Rotate90;
                    break;
                case 8:
                    bmpImage.Rotation = Rotation.Rotate270;
                    break;
                case 2:
                    break;
                case 4:
                    break;
                case 5:
                    bmpImage.Rotation = Rotation.Rotate90;
                    break;
                case 7:
                    bmpImage.Rotation = Rotation.Rotate270;
                    break;
            }
            bmpImage.EndInit();
            bmpImage.Freeze();

            stream.Close();
            return bmpImage;
        }

        public static BitmapSource TransformBitmap(BitmapSource source, Transform transform)
        {
            var result = new TransformedBitmap();
            result.BeginInit();
            result.Source = source;
            result.Transform = transform;
            result.EndInit();
            return result;
        }
    }

}