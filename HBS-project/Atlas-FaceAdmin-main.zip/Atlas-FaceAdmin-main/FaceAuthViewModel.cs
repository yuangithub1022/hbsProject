﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace RegisterFaceAuthTool
{
    public class FaceAuthDataBean
    {
        public int Idx { get; set; }
        public string[] UserIds { get; set; }
        public string TicketId { get; set; }
        public string FaceId { get; set; }
        public string ManageId { get; set; }
        public string StaffName { get; set; }
        public string StaffNameKN { get; set; }
        public string FigureId { get; set; }
        public string FigureStatus { get; set; }
        public string Thresholds { get; set; }
        public string StartDate { get; set; }
        public string ValidDate { get; set; }
        public string StaffImgPath { get; set; }
        public string StaffImgName { get; set; }
        public string FloorNum { get; set; }
        public string TrafficPattern { get; set; }
        public string LoginStatus { get; set; }
        public string LoginStatusCode { get; set; }
        public bool IsChecked { get; set; }
        public bool IsSelected { get; set; }
        public bool IsInserted { get; set; }
        public bool IsUpdated { get; set; }
        public bool IsDeleted { get; set; }
        public bool IsLossed { get; set; }
        public ImageSource Staff_Image { get; set; }
    }

    public class FaceAuthViewModel
    {
        private List<List<string>> Lines;
        private static readonly string FilePath = Configure.ToolCsvPath + @"\tool_csv.csv";
        private readonly string Path_ = "";
        MatchEvaluator matchEvaluRead = delegate (Match m)
        {
            return "\r\n";
        };

        public ObservableCollection<FaceAuthDataBean> Recordings { get; set; } = new ObservableCollection<FaceAuthDataBean>();
        
        public FaceAuthViewModel()
        {
            this.Path_ = FilePath;
        }

        public FaceAuthViewModel(string Path_)
        {
            this.Path_ = Path_;
        }

        public void ReadViewDelay(int IsFaceTransmitMode)
        {
            ReadCsvFormal(IsFaceTransmitMode);
        }

        public void DoEvents()
        {
            DispatcherFrame frame = new DispatcherFrame();
            Dispatcher.CurrentDispatcher.BeginInvoke(DispatcherPriority.Background,
                new DispatcherOperationCallback(ExitFrames), frame);
            Dispatcher.PushFrame(frame);
        }

        public object ExitFrames(object f)
        {
            ((DispatcherFrame)f).Continue = false;
            return null;
        }

        public void ReadCsvFormal(int IsFaceTransmitMode)
        {
            try
            {
                if (!File.Exists(this.Path_))
                {
                    return;
                }
                CsvFile Csv = new CsvFile(this.Path_);
                this.Lines = Csv.Read(0, "UTF-8");
                int Count = 0;
                int maxColumn = 79;

                
                foreach (List<string> line in Lines)
                {
                    string[] Values = line.ToArray();
                    
                    if (Values.Length < maxColumn)
                    {
                        continue;
                    }
                    if (CheckBytes(Values[0], 32) || CheckBytes(Values[1], 32) || CheckBytes(Values[2], 16)
                        || CheckBytes(Values[3], 50) || CheckBytes(Values[4], 50) || CheckBytes(Values[5], 4)
                        || CheckBytes(Values[6], 1) || CheckBytes(Values[7], 4) || CheckBytes(Values[8], 10)
                        || CheckBytes(Values[9], 10))
                    {
                        continue;
                    }
                    FaceAuthDataBean FaceItem = new FaceAuthDataBean
                    {
                        TicketId = Values[0],
                        FaceId = Values[1],
                        ManageId = Values[2],
                        StaffName = Values[3],
                        StaffNameKN = Values[4],
                        FigureId = Values[5],
                        FigureStatus = Values[6],
                        Thresholds = Values[7],
                        StartDate = Values[8],
                        ValidDate = Values[9],
                        StaffImgPath = "",
                        StaffImgName = "",
                        Staff_Image = null,
                        UserIds = new string[64],
                        LoginStatus = "有".Equals(Values[11]) ? "有" : "無",
                        LoginStatusCode = "有".Equals(Values[11]) ? "1" : "0",
                        IsChecked = false,
                        IsSelected = false,
                        IsInserted = false,
                        IsUpdated = false,
                        IsDeleted = false
                    };
                    for (int i = 0; i < FaceItem.UserIds.Length; i++)
                    {
                        // userid_1 is start from Valuse[15]
                        int valNum = i + 15;
                        FaceItem.UserIds[i] = Values[valNum];
                    }
                    if (Values[10] != null && !"".Equals(Values[10]))
                    {
                        BitmapImage image = ImageHelper.DecryptFile(Values[10]);
                        if (image != null)
                        {
                            FaceItem.StaffImgName = Values[1] + @".jpg";
                            FaceItem.StaffImgPath = Path.Combine(Configure.FaceDataPath, FaceItem.StaffImgName);
                            FaceItem.Staff_Image = image;
                        }
                    }

                    if (IsFaceTransmitMode == 2)
                    {
                        if(Values[12] != null && !"".Equals(Values[12]))
                        {
                            FaceItem.FloorNum = Values[12];
                        }
                        else
                        {
                            FaceItem.FloorNum = "";
                        }
                    }

                    if (IsFaceTransmitMode == 3)
                    {
                        if (Values[13] != null && !"".Equals(Values[13]))
                        {
                            // Replace CR/LF
                            string oldTrafficPattern = Values[13];
                            string newTrafficPattern = Regex.Replace(oldTrafficPattern, @"\\r\\n", matchEvaluRead);

                            FaceItem.TrafficPattern = newTrafficPattern;
                        }
                        else
                        {
                            FaceItem.TrafficPattern = "";
                        }
                    }

                    Count++;
                    if (Count > Configure.MaxFaceCount)
                    {
                        WriteLog.Log($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                        MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    }
                    this.Recordings.Add(FaceItem);
                    DoEvents();
                }
                
                this.Recordings = new ObservableCollection<FaceAuthDataBean>(this.Recordings.OrderBy(item => item.FaceId));
                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.Recordings)
                {
                    Bean.Idx = ++Idx_;
                }

                GC.Collect();
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] ファイルから顔データの読込は失敗しました。{ex.Message}");
                MessageBox.Show($"ファイルから顔データの読込は失敗しました。{ex.Message}", "エラー", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
        
        public async Task<bool> ReadFromAtlas(string AtlasIp, int AtlasKey, int AtlasCount) 
        {
            try
            {
                this.Recordings.Clear();
                GC.Collect();
                GC.WaitForPendingFinalizers();

                AtlasApi Api = new AtlasApi();
                string Token = await Api.GetToken(AtlasIp);
                if ("".Equals(Token))
                {
                    MessageBox.Show($"装置への認証は失敗しました。", "エラー",
                        MessageBoxButton.OK, MessageBoxImage.Error);
                    return false;
                }
                string DBId = await Api.GetDBIdByName(AtlasIp, Token, Configure.LibraryName);
                var UserList = await Api.GetUserList(AtlasIp, Token, DBId, AtlasKey, AtlasCount);
                
                int Count = 0;
                foreach (var user in UserList)
                {
                    var ImageId = user.StaffImgName;
                    BitmapImage image = await Api.DownloadImage(AtlasIp, Token, ImageId, user.FaceId);
                    if (image != null)
                    {
                        user.StaffImgName = user.FaceId + @".jpg";
                        user.StaffImgPath = Path.Combine(Configure.FaceDataPath, user.StaffImgName);
                        user.Staff_Image = image;
                    }

                    Count++;
                    if (Count > Configure.MaxFaceCount)
                    {
                        WriteLog.Log($"[登録者一覧画面] 顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。");
                        MessageBox.Show($"顔データ件数が上限{Configure.MaxFaceCount}を超えています。超えた分は無視されます。", "情報",
                            MessageBoxButton.OK, MessageBoxImage.Information);
                        break;
                    }
                    
                    this.Recordings.Add(user);
                }
                
                this.Recordings = new ObservableCollection<FaceAuthDataBean>(this.Recordings.OrderBy(item => item.FaceId));
                
                int Idx_ = 0;
                foreach (FaceAuthDataBean Bean in this.Recordings)
                {
                    Bean.Idx = ++Idx_;
                }

                GC.Collect();
                return true;
            }
            catch (Exception ex)
            {
                WriteLog.Log($"[登録者一覧画面] 装置から顔データの読込が失敗しました。{ex.Message}");
                MessageBox.Show($"装置から顔データの読込が失敗しました。{ex.Message}", "エラー", 
                    MessageBoxButton.OK, MessageBoxImage.Error);
            }
            return false;
        }

        public Boolean CheckBytes(string text, int max)
        {
            int ByteLength = System.Text.Encoding.Default.GetByteCount(text.Trim());
            if (ByteLength > max)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }

    public class AtlasServerDataBean
    {
        public string Server_Name { get; set; }
        public string Server_Ip { get; set; }
    }

    public class AtlasServerViewModel
    {
        public ObservableCollection<AtlasServerDataBean> Recordings { get; } = new ObservableCollection<AtlasServerDataBean>();
        public AtlasServerDataBean InitSelectedItem { get; }
        public AtlasServerViewModel()
        {
            this.Recordings.Add(new AtlasServerDataBean()
            {
                Server_Name = "All",
                Server_Ip = ""
            });
            for (int i = 0; i < Configure.AtlasList.Length; i++)
            {
                string Item = Configure.AtlasList[i];
                if (Item != "")
                {
                    Recordings.Add(new AtlasServerDataBean()
                    {
                        Server_Name = $"{i+1}",
                        Server_Ip = Item
                    });
                }
            }
            
            this.InitSelectedItem = this.Recordings.First();
        }
    }

    public class ReadSrcDataBean
    {
        public int Key { get; set; }
        public string Value { get; set; }
    }

    public class ReadSrcViewModel
    {
        public ObservableCollection<ReadSrcDataBean> Recordings { get; } = new ObservableCollection<ReadSrcDataBean>();

        public ReadSrcDataBean InitSelectedItem { get; }

        public ReadSrcViewModel(int IsFaceTransmitMode = 0)
        {
            if (IsFaceTransmitMode == 0 || IsFaceTransmitMode == 3)
            {
                this.Recordings.Add(new ReadSrcDataBean()
                {
                    Key = 1,
                    Value = "ファイル"
                });
            }
            this.Recordings.Add(new ReadSrcDataBean()
            {
                Key = 2,
                Value = "装置(Atlas)"
            });
            this.InitSelectedItem = this.Recordings.First();
        }
    }
}
