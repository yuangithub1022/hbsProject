import instance from './index';

export default {
  signIn(params) {
    return instance.post('/components/operation-maintenance/v1/users/sign_in', params);
  },
  signOut(params) {
    params.token = instance.defaults.headers.common['Authorization'];
    return instance.post('/components/operation-maintenance/v1/users/sign_out', params);
  },
  listCaptureResults(params) {
    //return instance.get('/engine/feature-process/v1/capture_results',params);
    return instance.get('/engine/feature-process/v1/capture_results?'+params);
  },
  async getLatestCaptureResult(task_id) {
    let result = null;
    let offset = 0;
    let param = 'page_request.offset='+offset+'&page_request.limit=100';
    let res = await this.listCaptureResults(param);
    if (!res.data || !res.data.results) {
      return result;
    }
    
    if (res.data.results.length < 100) {
      for (let i = res.data.results.length-1; i >= 0; i--) {
        if (res.data.results[i].task_id === task_id) {
          result = res.data.results[i];
          return result;
        }
      }
      return result;
    }

    offset = res.data.page_request.total - 100;
    param = 'page_request.offset='+offset+'&page_request.limit=100';
    for (;;) {
      res = await this.listCaptureResults(param);

      for (let i = res.data.results.length-1; i >= 0; i--) {
        if (res.data.results[i].task_id === task_id) {
          result = res.data.results[i];
          return result;
        }
      }
      offset -= 100;
      if (offset <= 0) {
        break;
      }
    }
    return result;
  },
  async listAllCaptureResults(params) {
    let result = [];
    let offset = 0;
    for (;;) {
      params = params + '&page_request.offset='+offset+'&page_request.limit=100'
      let res = await this.listCaptureResults(encodeURI(encodeURI(params)));
      if (!res.data || !res.data.results) {
        break;
      }
      for (let i = 0; i < res.data.results.length; i++) {
        let panoramaData;
        try {
          panoramaData = await this.downloadObject(res.data.results[i].panorama.url);
        } catch (err) {
          panoramaData = '';
        }
        let imageData;
        try {
          imageData = await this.downloadObject(res.data.results[i].capture_result.face.portrait.url);
        } catch (err) {
          imageData = '';
        }
        res.data.results[i].panorama.data = panoramaData;
        res.data.results[i].capture_result.face.portrait.data = imageData;
        result.push(res.data.results[i]);
      }
      if (res.data.results.length < 100) {
        break;
      }
      offset += 100;
    }
    return result;
  },
  taskNewAcs(params) {
    return instance.post('/engine/access-control/v1/tasks', params);
  },
  taskStatusAcs(id)  {
    return instance.get(`/engine/access-control/v1/tasks/${id}`);
  },
  taskListAcs(params) {
    return instance.get('/engine/access-control/v1/tasks', {params: params});
  },
  taskUpdateAcs(params)  {
    return instance.put(`/engine/access-control/v1/tasks/${params.task_id}`, params);
  },
  taskDeleteAcs(id)  {
    return instance.delete(`/engine/access-control/v1/tasks/${id}`);
  },
  taskNewMps(params) {
    return instance.post('/engine/media-process/v1/tasks', params);
  },
  taskStatusMps(id)  {
    return instance.get(`/engine/media-process/v1/tasks/${id}`);
  },
  taskListMps(params) {
    return instance.get('/engine/media-process/v1/tasks', {params: params});
  },
  taskUpdateMps(params)  {
    return instance.put(`/engine/media-process/v1/tasks/${params.task_id}`, params);
  },
  taskDeleteMps(id)  {
    return instance.delete(`/engine/media-process/v1/tasks/${id}`);
  },
  taskUpdateConfig(params)  {
    return instance.put(`/engine/access-control/v1/configs/${params.device_id}`, params);
  },
  taskDeleteConfig(id)  {
    return instance.delete(`/engine/access-control/v1/configs/${id}`);
  },
  dBNew(params)  {
    return instance.post('/engine/alert-feature/v1/databases', params);
  },
  dBGet(id)  {
    return instance.get(`/engine/alert-feature/v1/databases/${id}`);
  },
  dBList(params)  {
    return instance.get('/engine/alert-feature/v1/databases', params);
  },
  dBUpdate(params)  {
    return instance.put(`/engine/alert-feature/v1/databases/${params.id}`, params);
  },
  dBDelete(id)  {
    return instance.delete(`/engine/alert-feature/v1/databases/${id}`);
  },
  userBatchAdd(params)  {
    return instance.post(`/engine/alert-feature/v1/databases/${params.db_id}/users`, params);
  },
  userGet(db_id, user_id)  {
    return instance.get(`/engine/alert-feature/v1/databases/${db_id}/users/${user_id}`);
  },
  userList(db_id, params)  {
    return instance.get(`/engine/alert-feature/v1/databases/${db_id}/users?`+ params);
  },
  async userListAll(db_id) {
    let result = [];
    let offset = 0;
    for (;;) {
      let params = 'page_request.offset='+offset+'&page_request.limit=100';
      let res = await this.userList(db_id, params);
      if (!res.data || !res.data.users) {
        break;
      }
      for (let i = 0; i < res.data.users.length; i++) {
        let imageData;
        try {
          imageData = await this.downloadObject( res.data.users[i].image.url);
        } catch (err) {
          imageData = '';
        }
        res.data.users[i].image.data = imageData;
        result.push(res.data.users[i]);
      }
      if (res.data.users.length < 100) {
        break;
      }
      offset += 100;
    }
    return result;
  },
  userUpdate(params)  {
    return instance.put(`/engine/alert-feature/v1/databases/${params.db_id}/users/${params.user_id}`, params);
  },
  userDelete(db_id, user_id) {
    return instance.delete(`/engine/alert-feature/v1/databases/${db_id}/users/${user_id}`);
  },
  downloadObject(fid) {
    return instance.get(`/components/osg-default/v1/objects/${fid}`, {responseType: 'arraybuffer'})
      .then(res => {
        let mimeType = res.headers['content-type'].toLowerCase();
        let imgBase64 = new Buffer(res.data, 'binary').toString('base64');
        return 'data:' + mimeType + ';base64,' + imgBase64;
      });
  },
  getFileUrl(fid) {
    let token = instance.defaults.headers.common['Authorization'];
    return `${instance.defaults.baseURL}/components/osg-default/v1/objects/${fid}?token=${token}`;
  },
  getHttpServer() {
    return instance.get('/engine/feature-process/v1/http_server');
  },
  setHttpServer(params) {
    return instance.post('/engine/feature-process/v1/http_server', params);
  },
  deleteAllRecords() {
    return instance.delete('/engine/feature-process/v1/records');
  },
  acsGetVersion() {
    return instance.get('/engine/access-control/v1/version');
  },
  fpsGetVersion() {
    return instance.get('/engine/feature-process/v1/version');
  },
  mpsGetVersion() {
    return instance.get('/engine/media-process/v1/version');
  },
  omsGetVersion() {
    return instance.get('/components/operation-maintenance/v1/version');
  },
  afdGetVersion() {
    return instance.get('/engine/alert-feature/v1/version');
  },
  afdImageSearchInMultiDatabases(params){
    return instance.post('/engine/alert-feature/v1/databases/image_search', params);
  },
  omsGetSystemInfo() {
    return instance.get('/components/operation-maintenance/v1/system_info');
  },
  omsGetSystemConfig() {
    return instance.get('/components/operation-maintenance/v1/system_config');
  },
  omsUpdateSystemConfig(param){
    return instance.post('/components/operation-maintenance/v1/system_config',param);
  },
  omsSetHTTPServer(param) {
    return instance.post('/components/operation-maintenance/v1/http_server', param);
  },
  omsGetHTTPServer() {
    return instance.get('/components/operation-maintenance/v1/http_server');
  }
}
