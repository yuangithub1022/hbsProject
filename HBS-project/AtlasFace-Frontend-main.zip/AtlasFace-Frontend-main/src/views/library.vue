<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.modal-form {
  margin-top: 15px;
}
.file-upload {
  background-color: #ffffff;
  width: 100%;
  height: 250px;
  margin: 0 auto;
}
.file-upload-input {
  position: absolute;
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%; 
  outline: none;
  opacity: 0;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  cursor: pointer;
  z-index: 999;
}
.image-upload-wrap {
  height: 100%;
  position: relative;
  margin-top: 20px;
  vertical-align: middle;
  border: 4px dashed #3c8dbc;
}
.image-dropping {
  background-color: #3c8dbc;
  border: 4px dashed #ffffff;
}
.drag-text {
  margin-top: 80px;
  text-align: center;
  color: #3c8dbc;
  font-size: 50px;
}
.portrait {
  max-height: 100%;
  max-width: 100%;
  width: auto;
  height: auto;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
}
.compare {
  text-align: center;
  margin-top: 40px;
}
.searchBtnStyle{
  width: 100%;
  margin-top: 10px;
}
.imgPosition{
  position: absolute;
}
</style>

<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.library") }}</h4>
            </div>
            <div class="box-body">
              <table id="library" class="table table-bordered table-striped" width="100%">
                <thead>
                  <tr>
                    <th>{{ $t("library.id") }}</th>
                    <th>{{ $t("library.name") }}</th>
                    <th>{{ $t("library.total") }}</th>
                    <th>{{ $t("library.type") }}</th>
                    <th>{{ $t("library.time") }}</th>
                    <th>{{ $t("library.description") }}</th>
                    <th>{{ $t("common.action") }}</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>

          <pageModal :show.sync="showSearchModal" :footer="false" :modalclass="'modal-lg'">
            <div slot="header">
              {{ $t("common.select") }}
            </div>
            <div slot="body" class="detail-body">
              <div class="col-xs-5">
                <div class="file-upload">
                    <div class="image-upload-wrap"
                      :class="[{'image-dropping': isDrag}]"
                      @dragover.prevent="isDrag=true;"
                      @dragleave.prevent="isDrag=false;">
                      <input class="file-upload-input" type='file' @change="importImage" accept="image/jpeg"/>
                      <div class="drag-text" v-if="!uploadImage">
                      <i aria-hidden="true" class="fa fa-plus"></i>
                      </div>
                    <img class="portrait imgPosition" :src="uploadImage" v-if="uploadImage">
                    </div>
                </div>
                <button type="button" class="btn btn-primary searchBtnStyle" @click="searchInMultiDB">{{ $t("common.select") }}</button>
              </div>
              <div class="col-xs-2 compare">
                <hr>
                <strong> {{ $t("alarm.score") }}: </strong><br><br>
                <span class="badge bg-red" v-if="showResultObject">{{ showResultObject.score *100}}%</span>
                <hr>
              </div>
              <div class="col-xs-5" v-if="showResultObject">
                <div class="portrait">
                  <img height="150px" width="150px" v-auth-image="showResultObject.user.image.url">
                  <h6>{{ $t("alarm.master") }}</h6>
                </div>
                <div class="table-responsive">
                  <table class="table">
                    <tbody>
                      <tr>
                        <th> {{ $t("user.name") }}: </th>
                        <td> {{ showResultObject.user.name}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("menu.library") }}: </th>
                        <td> {{ showResultObject.id | transferName}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.gender") }}: </th>
                        <td> {{ showResultObject.user.gender}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.age") }}: </th>
                        <td> {{ showResultObject.user.age}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.cardId") }}: </th>
                        <td> {{ showResultObject.user.card_id}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.address") }}: </th>
                        <td> {{ showResultObject.user.address}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.create_time") }}: </th>
                        <td> {{ showResultObject.user.create_time }} </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="col-xs-5" v-else>
                <h5><b>{{errMsg}}</b></h5>
              </div>
            </div>
          </pageModal>

          <pageModal :show.sync="showModal" :footer="true">
            <div slot="header">
              <span v-if="showObject.id">{{ $t("common.edit") }} (ID: {{ showObject.name }})</span>
              <span v-if="!showObject.id">{{ $t("common.create") }} </span>
            </div>
            <div slot="body">
              <form class="form-horizontal">
                <div class="modal-form">
                  <div class="form-group">
                    <label class="col-xs-2 control-label">
                      {{ $t("library.name") }}
                    </label>
                    <div class="col-xs-10">
                      <input type="text" class="form-control" v-model="showObject.name" placeholder="Name" required="required">
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-2 control-label">
                      {{ $t("library.type") }}
                    </label>
                    <div class="col-xs-10">
                      <select class="form-control" v-model="showObject.type">
                        <option value="UNKNOWN">UNKNOWN</option>
                        <option value="WHITE">WHITE</option>
                        <option value="BLACK">BLACK</option>
                      </select>
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-2 control-label">
                      {{ $t("library.description") }}
                    </label>
                    <div class="col-xs-10">
                      <textarea class="form-control" rows="3" v-model="showObject.description" placeholder="Description"></textarea>
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div slot="footer">
              <button class="btn btn-default pull-left" @click="showModal=false;">{{ $t("common.cancel") }}</button>
              <button class="btn btn-primary pull-right" @click="updateLibrary">{{ $t("common.ok") }}</button>
            </div>
          </pageModal>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>
<script>
import * as moment from 'moment';
import api from '../api/api'; 

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      diff: this.$root.diffTime,
      showModal: false,
      showSearchModal:false,
      showObject: {},
      showResultObject: null,
      uploadImage:'',
      dataTable: null,
      isDrag: false,
      errMsg: ''
    };
  },
  filters:{
    transferName(value){
      for(var i = 0;i < $('#library').DataTable().data().length; i++){
        if(value === $('#library').DataTable().data()[i][0]){
          return $('#library').DataTable().data()[i][1]
        }
      }
    }
  },
  methods: {
    searchInMultiDB(){
      let vm = this;
      let dbList = [];
      if($('#library').DataTable().data().length <= 0){
        vm.$toastr.e(vm.$i18n.t('message.common_empty_database'));
        return;
      }
      if(!vm.uploadImage){
        vm.$toastr.e(vm.$i18n.t('message.common_empty_image'));
        return;
      }
      for(var i = 0;i < $('#library').DataTable().data().length; i++){
        dbList.push($('#library').DataTable().data()[i][0]);
      }
      let param = {
        id: dbList,
        min_score: 0.8,
        image: {
          format:'IMAGE_UNKNOWN',
          data: vm.uploadImage.split(',')[1],
          url:''
        }
      }
      vm.$emit('loading', true);  
      api.afdImageSearchInMultiDatabases(param).then(res => {
        vm.$emit('loading', false);
        vm.showResultObject = res.data;
        vm.showResultObject.user.create_time = moment(vm.showResultObject.user.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss');
      }).catch(err => {
        vm.$emit('loading', false);
        vm.showResultObject = null;
        vm.errMsg = vm.$i18n.t('message.common_empty_result') + ': ' +  err.response.data.message;
        //vm.$toastr.e(vm.$i18n.t('message.common_empty_result') + '<br>' + err.response.data.message);
      });
    },
    importImage(e) {
      let vm = this;
      const files = e.target.files || e.dataTransfer.files;
      const reader = new FileReader();
      reader.onload = e => {
        vm.uploadImage = e.target.result;
      };
      reader.readAsDataURL(files[0]);
    },
    updateLibrary(){
      let vm = this;
      if (!vm.showObject.name) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }
      if (vm.showObject.id) {
        api.dBUpdate(vm.showObject).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.library_update_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.library_update_failure') + '<br>' + err.response.data.message);
        });
      } else {
        api.dBNew(vm.showObject).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.library_create_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.library_create_failure') + '<br>' + err.response.data.message);
        });
      }
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
  },
  mounted: function() {
    let vm = this;
    vm.dataTable = $('#library').DataTable({
      paging: true,
      pageLength: 10,
      lengthChange: false,
      searching: true,
      ordering: true,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: false,
      order: [[ 3, "asc" ]],
      dom: 'Bfrtip',
      buttons: [
        {
          text: vm.$i18n.t('common.create'),
          className: 'btn btn-primary',
          init: function(api, node) {
            $(node).removeClass('dt-button');
          },
          action: function() {
            vm.showObject = {
              type:'UNKNOWN'
            };
            vm.showModal = true;
          }
        },
        {
          text: vm.$i18n.t('common.select'),
          className: 'btn btn-primary marginLeft',
          init: function(api, node) {
            $(node).removeClass('dt-button');
          },
          action: function() {
            vm.showSearchModal = true;
          }
        }
      ],
      columnDefs: [
        {
          orderable: false,
          targets: [3, 4, -1]
        },
        {
          targets: [0],
          visible: false,
          searchable: false
        },
        {
          targets: -1,
          data: null,
          defaultContent: '<a class="btn btn-info btn-xs manage" style="margin-right:10px"><i class="fa fa-gears"></i>&nbsp;' 
                    + vm.$i18n.t('common.manage') + '</a>'
                    + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                    + vm.$i18n.t('common.edit') + '</a>'
                    + '<a class="btn btn-info btn-xs delete"><i class="fa fa-remove"></i>&nbsp;' 
                    + vm.$i18n.t('common.delete') + '</a>'
        }
      ],
      ajax: function (data, callback) {
        api.dBList({}).then(res => {
          let result = res.data;
          let records = {draw: 1, data: []};
          result.databases.forEach(element => {
              records.data.push([element.id, element.name, element.size, element.type, moment(element.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'), element.description]);
          });
          callback(records);
        }).catch(() => {
          callback({draw: 1, data: []});
        });
      }
    });
    vm.dataTable.on('click', '.manage', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.$router.push({path: `/library/${rowData[0]}/user`});
    });
    vm.dataTable.on('click', '.edit', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.showObject = {
        id: rowData[0],
        name: rowData[1],
        type: rowData[3],
        description: rowData[5]
      };
      vm.showModal = true;
    });
    vm.dataTable.on('click', '.delete', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      if (confirm("Confirm Delete?")) {
        api.dBDelete(rowData[0]).then(() => {
          vm.$toastr.s(vm.$i18n.t('message.library_delete_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.library_delete_failure') + '<br>' + err.response.data.message);
        });
      }
    });

    $('.marginLeft').css('margin-left','10px');
  }
};
</script>
