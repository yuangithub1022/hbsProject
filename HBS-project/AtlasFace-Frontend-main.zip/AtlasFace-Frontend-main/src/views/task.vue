<style scoped>
.box-body {
  min-height: 30vh;
}
.modal-form {
  margin-top: 15px;
}
.desc {
  margin-top: 20px;
}
.noBottom{
  margin-bottom: 0px;
}
.setStyle{
  font-size: 11px;
}
</style>
<template>
  <div class="wrapper">
    <pageHeader></pageHeader>
    <pageAside></pageAside>
    <div class="content-wrapper">
      <section class="content">
        <div class="box box-default">
          <div class="box-header">
            <h4>{{ $t("task.mps") }}</h4>
          </div>
          <div class="box-body">
            <table id="mps-tasks" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.url") }}</th>
                  <th>{{ $t("task.score") }}</th>
                  <th>{{ $t("task.library") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th>{{ $t("task.roi") }}</th>
                  <th>{{ $t("task.tmode") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
        <div class="box box-default">
          <div class="box-header">
            <h4>{{ $t("task.acs") }}</h4>
          </div>
          <div class="box-body">
            <table id="acs-tasks" class="table table-bordered table-striped" width="100%">
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.device") }}</th>
                  <th>{{ $t("task.score") }}</th>
                  <th>{{ $t("task.library") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody>
              </tbody>
            </table>
          </div>
        </div>
        <pageModal :show.sync="showModal" :footer="editable">
          <div slot="header">
            <span v-if="showObject.task_id && editable">{{ $t("common.edit") }} ({{ showObject.extra_info.task_name }})</span>
            <span v-if="showObject.task_id && !editable">{{ $t("common.detail") }} ({{ showObject.extra_info.task_name }}) </span>
            <span v-if="!showObject.task_id && editable">{{ $t("common.create") }} </span>
          </div>
          <div slot="body">
            <form class="form-horizontal" v-if="showObject.task">
              <div class="modal-form">
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.name") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.extra_info.task_name" placeholder="Device Name" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 control-label">
                    {{ $t("task.stype") }}
                  </label>
                  <div class="col-sm-9">
                    <select v-model="showObject.source.type" class="form-control" :disabled="!editable">
                      <option value="FC_SENSEPASS" v-if="showObject.source.type==='FC_SENSEPASS'">TABLET CAMERA</option>
                      <option value="VN_RTSP" v-if="showObject.source.type==='VN_RTSP'">RTSP</option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='VN_RTSP'">
                  <label class="col-sm-3 control-label">
                    {{ $t("task.tmode") }}
                  </label>
                  <div class="col-sm-9">
                    <select v-model="showObject.task.parameter.face.track_mode" class="form-control" :disabled="!editable">
                      <option value="VIDEO_TRACK_MODE_ENTER">{{ $t("task.mode_enter") }}</option>
                      <option value="VIDEO_TRACK_MODE_OPTIMAL">{{ $t("task.mode_optimal") }}</option>
                      <option value="VIDEO_TRACK_MODE_PERIODIC">{{ $t("task.mode_periodic") }}</option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='FC_SENSEPASS'">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.device") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.source.parameter.sensepass.device_sn" placeholder="Device SN" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group" v-if="showObject.source.type==='VN_RTSP'">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.url") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.source.parameter.rtsp.url" placeholder="RTSP URL" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group noBottom" v-if="showObject.source.type==='VN_RTSP'">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.substream") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.extra_info.substream" placeholder="Substream" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group noBottom" v-if="showObject.source.type==='VN_RTSP'">
                    <label class="col-sm-3 control-label"></label>
                    <div class="col-sm-9">
                      <span class="setStyle">{{ $t("task.noteRtsp") }}</span>
                    </div>
                </div>
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.score") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="number" min="0.6" max="1" step="0.01" class="form-control" v-model="showObject.task.parameter.face.min_score" placeholder="Min Score" :disabled="!editable">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.library") }}
                  </label>
                  <div class="col-xs-9">
                    <select v-model="showObject.task.parameter.face.id_array" v-select2 :disabled="!editable" class="form-control select2" multiple="multiple" data-placeholder="Select Libraries" style="width: 100%;">
                      <option v-for="item of libraries" :key="item.id" :value="item.id">{{ item.name }}</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 control-label">
                    {{ $t("task.otype") }}
                  </label>
                  <div class="col-sm-9">
                    <select v-model="showObject.extra_info.output_type" class="form-control" :disabled="!editable">
                      <option value="NONE">NONE</option>
                      <option value="RS-485">RS-485</option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.extra_info.output_type!=='NONE'">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.ovalue") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-model="showObject.extra_info.output_value" placeholder="Output Value" :disabled="!editable">
                    <span style="font-size:12px;">例:#011001,#011000,2000,#011101,#011100,2000</span>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.task_id && !editable">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.status") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" v-if="showObject.status" :value="showObject.status.status" disabled>
                  </div>
                </div>
                <div class="form-group" v-if="showObject.task_id && !editable">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.created") }}
                  </label>
                  <div class="col-xs-9">
                    <input type="text" class="form-control" :value="showObject.create_time" disabled>
                  </div>
                </div>
              </div>
            </form>
          </div>
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showModal=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="updateTask">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>

        <pageModal :show.sync="showRoiDialog" :footer="true">
          <div slot="header">
            <span v-if="showObject.extra_info">{{ $t("common.roi") }} ({{ showObject.extra_info.task_name }}) </span>
          </div>
          <div slot="body">
            <v-stage ref="stage" :config="roiStageConfig">
              <v-layer ref="layer">
                <v-image :config="roiImageConfig"/>
                <v-rect ref="rectangle" :config="roiRectConfig" @transform="handleRectChange" />
                <v-transformer ref="transformer" :config="roiTransformerConfig" />
              </v-layer>
            </v-stage>
            <div class="desc">
              <p class="text-muted">
                {{ $t("message.task_roi_description") }}
              </p>
              <p class="text-muted">
                {{ $t("message.task_roi_currentvalue") }} 
                <span v-if="showObject.task && showObject.task.parameter.face.roi">
                  {{ showObject.task.parameter.face.roi.vertices }}
                </span>
              </p>
            </div>
          </div>
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showRoiDialog=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="updateTask">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>

        <pageModal :show.sync="showSetDialog" :footer="true">
          <div slot="header">
            <span>{{ $t("common.set") }} </span>
          </div>
          <div slot="body">
            <div class="col-sm-12">
                  <form class="form-horizontal">
                    <div class="modal-form">
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("task.base") }}
                        </label>
                        <div class="col-sm-9">
                          <textarea v-model="baseStr" rows="10" placeholder="Base config" class="col-sm-12"></textarea>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("task.extra") }}
                        </label>
                        <div class="col-sm-9">
                          <textarea v-model="extraStr" rows="10" placeholder="Extra config" class="col-sm-12"></textarea>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
          </div>
          <div slot="footer">
            <button class="btn btn-default pull-left" @click="showSetDialog=false;">{{ $t("common.cancel") }}</button>
            <button class="btn btn-primary pull-right" @click="updateSetting">{{ $t("common.ok") }}</button>
          </div>
        </pageModal>
      </section>
    </div>
    <!-- <pageFooter></pageFooter> -->
  </div>
</template>
<script>
import * as moment from 'moment';
import api from '../api/api'; 
import axios from 'axios';

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      diff: this.$root.diffTime,
      libraries: [],
      showModal: false,
      showObject: {},
      showRoiDialog: false,
      showSetDialog: false,
      roiStageConfig: {width: 560, height: 315},
      roiImageConfig: {x: 0, y: 0, image: null},
      roiRectConfig: null,
      roiTransformerConfig: null,
      roiScaleRatio: 1,
      editable: false,
      dataTableAcs: null,
      dataTableMps: null,

      baseStr:'{"mode":5,"open_door_type":0,"liveness":true,"liveness_threshold":0.98,"verify_threshold":0.83,"face_update_threshold":9.9,"admin_pwd":"123","device_run_type":1,'+
        '"language_type":2,"yaw":30,"pitch":30,"roll":30,"recognition_distance":1.0,"hack_no_pass_count_threshold":10,"stranger_count_threshold":5,"network_relay_address":"",' +
        '"use_mode":3,"ntp_server_address":"","logo":true,"welcome_tip":"","verify_success_tip":"","verify_fault_tip":"","use_show_avatar":true,"show_user_name":true,'+
        '"auto_reboot":true,"reboot_time":"06:00:00","wait_time":5}',
      extraStr:'{}',

      bodyObj:{}
    };
  },
  methods: {
    updateTask() {
      let vm = this;

      if (!vm.showObject.extra_info.task_name || !vm.showObject.source.type || vm.showObject.task.parameter.face.id_array.length < 1
          || vm.showObject.task.parameter.face.min_score < 0 || vm.showObject.task.parameter.face.min_score > 1
          || (vm.showObject.source.type === 'FC_SENSEPASS' && !vm.showObject.source.parameter.sensepass.device_sn)
          || (vm.showObject.source.type === 'VN_RTSP' && !vm.showObject.source.parameter.rtsp.url)) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }
      
      if(vm.showObject.source.type === 'VN_RTSP' && vm.showObject.extra_info.substream && vm.showObject.extra_info.substream.substr(0, 4) !== 'rtsp'){
        vm.$toastr.i(vm.$i18n.t('message.task_formatStream_error'));
        return;
      }

      // MIN_SCORE will be used by uploadCaptureResult
      vm.showObject.extra_info.min_score = String(vm.showObject.task.parameter.face.min_score);

      if (vm.showObject.task_id) {
        if (vm.showObject.source.type === 'FC_SENSEPASS') {
          api.taskUpdateAcs(vm.showObject).then(() => {
            vm.showModal = false;
            vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
          });
        } else {
          api.taskUpdateMps(vm.showObject).then(() => {
            vm.showModal = false;
            vm.showRoiDialog = false;
            vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
            vm.dataTableMps.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
          });
        }
      } else {
        if (vm.showObject.source.type === 'FC_SENSEPASS' ) {
          api.taskNewAcs(vm.showObject).then(() => {
            vm.showModal = false;
            vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
          });
        } else {
          api.taskNewMps(vm.showObject).then(() => {
            vm.showModal = false;
            vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
            vm.dataTableMps.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
          });
        }
      }
    },
    updateSetting(){
      let vm = this;
      if (!vm.baseStr) {
        vm.$toastr.i(vm.$i18n.t('message.task_baseInput_error'));
        return;
      }

      if (!vm.extraStr) {
        vm.$toastr.i(vm.$i18n.t('message.task_extraInput_error'));
        return;
      }

      try{
        vm.bodyObj.base = JSON.parse(vm.baseStr);
        vm.bodyObj.extra = JSON.parse(vm.extraStr);
      }catch(e){
        vm.$toastr.i(vm.$i18n.t('message.task_formatInput_error'));
        return;
      }

      api.taskUpdateConfig(vm.bodyObj).then(() => {
        vm.showSetDialog = false;
        vm.$toastr.s(vm.$i18n.t('message.task_updateSet_success'));
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.task_updateSet_failure') + '<br>' + err.response.data.message);
      });

    },
    handleRectChange() {
      let vm = this;
      const rectNode = vm.$refs.rectangle.getStage();
      const imageWidth = Math.round(vm.roiImageConfig.width/vm.roiScaleRatio);
      const imageHeight = Math.round(vm.roiImageConfig.height/vm.roiScaleRatio);

      let realLx = Math.floor(Math.floor(rectNode.x())/vm.roiScaleRatio);
      if (realLx <= 4) {
        realLx = 0;
      }
      let realLy = Math.floor(Math.floor(rectNode.y())/vm.roiScaleRatio);
      if (realLy <= 4) {
        realLy = 0;
      }
      let realRx = Math.ceil(Math.ceil((rectNode.x() + rectNode.width()*rectNode.scaleX()))/vm.roiScaleRatio);
      if (realRx >= imageWidth - 4) {
        realRx = imageWidth;
      }
      let realRy = Math.ceil(Math.ceil((rectNode.y() + rectNode.height()*rectNode.scaleY()))/vm.roiScaleRatio);
      if (realRy >= imageHeight - 4) {
        realRy = imageHeight;
      }
      
      vm.showObject.task.parameter.face.roi = {
        vertices: [{x: realLx, y: realLy}, {x: realRx, y: realRy}]
      }
    },
    renderLibraries(id_array) {
      let ret = '';
      id_array.forEach(obj => {
        this.libraries.forEach(element => {
          if(obj === element.id){
            ret += '<span class="badge bg-light-blue">' + element.name + '</span>';
          }
        }) 
      });
      return ret;
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
  },
  mounted: function() {
    let vm = this;
    api.dBList({}).then(res => {
      if (res.data.databases) {
        vm.libraries = res.data.databases;
      }
    }).catch(() => {
      vm.libraries = [];
    }).finally(() => {
      // ACS DEVICES
      vm.dataTableAcs = $('#acs-tasks').DataTable({
        paging: true,
        pageLength: 10,
        lengthChange: false,
        searching: false,
        ordering: false,
        responsive: true,
        info: true,
        autoWidth: true,
        serverSide: true,
        order: [],
        dom: 'Bfrtip',
        buttons: [
          {
            text: vm.$i18n.t('common.create'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {
              vm.showObject = {
                source: {type: 'FC_SENSEPASS', parameter: {sensepass: {device_sn: ''}}},
                task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: 0.8, id_array: []}}},
                extra_info: {task_name: '', output_type: 'NONE', output_value: '', min_score: ''}
              };
              vm.editable = true;
              vm.showModal = true;
            }
          }
        ],
        columnDefs: [
          {
            orderable: false,
            targets: [1, 5, -1]
          },
          {
            targets: [0],
            visible: false,
            searchable: false
          },
          {
            targets: 1,
            render: function(url, type, row) {
              return row[1].task_name;
            }
          },
          {
            targets: 5,
            render: function(url, type, row) {
              return vm.renderLibraries(row[5]);
            }
          },
          {
            targets: -1,
            data: null,
            render: function() {
              return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;' 
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;' 
                      + vm.$i18n.t('common.delete') + '</a>'
                      // + '<a class="btn btn-info btn-xs set" style="margin-right:10px"><i class="fa fa-cogs"></i>&nbsp;' 
                      // + vm.$i18n.t('common.set') + '</a>'
                      // + '<a class="btn btn-info btn-xs set_delete" style="margin-right:10px"><i class="fa fa-cogs"></i>&nbsp;' 
                      // + vm.$i18n.t('common.set_delete') + '</a>'
                      ;
            },
          }
        ],
        ajax: function (data, callback) {
          api.taskListAcs({'page_request.offset': data.start, 'page_request.limit': data.length})
            .then(res => {
              let result = res.data;
              let records = {draw: new Date().getTime(), data: []};
              if (result.page_response.total >= 0) {
                records.recordsTotal = result.page_response.total;
                records.recordsFiltered = result.page_response.total;
                result.tasks.forEach(element => {
                  records.data.push([
                    element.task_id,
                    element.extra_info,
                    element.source.type,
                    element.source.parameter.sensepass.device_sn,
                    element.task.parameter.face.min_score,
                    element.task.parameter.face.id_array,
                    moment(element.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                    element.status.status]);
                });
              }
              callback(records);
            }).catch(() => {
              callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
            });
        }
      });
      vm.dataTableAcs.on('click', '.detail', async function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        let res = await api.taskStatusAcs(rowData[0]);
        if (res.data && res.data.status.status) {
          rowData[7] = res.data.status.status;
          vm.dataTableAcs.draw();
        }
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {sensepass: {device_sn: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: rowData[4], id_array: rowData[5]}}},
          extra_info: rowData[1],
          create_time: rowData[6],
          status: {status: rowData[7]}
        };
        vm.editable = false;
        vm.showModal = true;
      });
      vm.dataTableAcs.on('click', '.edit', function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {sensepass: {device_sn: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: rowData[4], id_array: rowData[5]}}},
          extra_info: rowData[1],
        };
        vm.editable = true;
        vm.showModal = true;
      });
      vm.dataTableAcs.on('click', '.delete', function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        if (confirm("Confirm Delete?")) {
          api.taskDeleteAcs(rowData[0]).then(() => {
            vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err.response.data.message);
          });
        }
      });

      vm.dataTableAcs.on('click', '.set', function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        vm.bodyObj.device_id = rowData[0]
        vm.showSetDialog = true;
      });
      vm.dataTableAcs.on('click', '.set_delete', function() {
        let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
        if (confirm("Confirm Delete?")) {
          api.taskDeleteConfig(rowData[0]).then(() => {
            vm.$toastr.s(vm.$i18n.t('message.task_deleteSet_success'));
            vm.dataTableAcs.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_deleteSet_failure') + '<br>' + err.response.data.message);
          });
        }
      });
      
      // MPS DEVICES
      vm.dataTableMps = $('#mps-tasks').DataTable({
        paging: true,
        pageLength: 10,
        lengthChange: false,
        searching: false,
        ordering: false,
        responsive: true,
        info: true,
        autoWidth: true,
        serverSide: true,
        order: [],
        dom: 'Bfrtip',
        buttons: [
          {
            text: vm.$i18n.t('common.create'),
            className: 'btn btn-primary',
            init: function(api, node) {
              $(node).removeClass('dt-button');
            },
            action: function() {
              vm.showObject = {
                source: {type: 'VN_RTSP', parameter: {rtsp: {url: ''}}},
                task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: 'VIDEO_TRACK_MODE_ENTER', min_score: 0.8, id_array: []}}},
                extra_info: {task_name: '', output_type: 'NONE', output_value: '', min_score: 0},
              };
              vm.editable = true;
              vm.showModal = true;
            }
          }
        ],
        columnDefs: [
          {
            orderable: false,
            targets: [1, 5, -1]
          },
          {
            targets: [0, 3, 8, 9],
            visible: false,
            searchable: false
          },
          {
            targets: 1,
            render: function(url, type, row) {
              return row[1].task_name;
            }
          },
          {
            targets: 5,
            render: function(url, type, row) {
              return vm.renderLibraries(row[5]);
            }
          },
          {
            targets: -1,
            data: null,
            render: function() {
              return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;' 
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;' 
                      + vm.$i18n.t('common.delete') + '</a>'
                      + '<a class="btn btn-info btn-xs roi"><i class="fa fa-gears"></i>&nbsp;' 
                      + vm.$i18n.t('common.roi') + '</a>';
            },
          }
        ],
        ajax: function (data, callback) {
          api.taskListMps({'page_request.offset': data.start, 'page_request.limit': data.length})
            .then(res => {
              let result = res.data;
              let records = {draw: new Date().getTime(), data: []};
              if (result.page_response.total >= 0) {
                records.recordsTotal = result.page_response.total;
                records.recordsFiltered = result.page_response.total;
                result.tasks.forEach(element => {
                  records.data.push([
                    element.task_id,
                    element.extra_info,
                    element.source.type,
                    element.source.parameter.rtsp.url,
                    element.task.parameter.face.min_score,
                    element.task.parameter.face.id_array,
                    moment(element.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                    element.status.status,
                    element.task.parameter.face.roi,
                    element.task.parameter.face.track_mode]);
                });
              }
              callback(records);
            }).catch(() => {
              callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
            });
        }
      });
      vm.dataTableMps.on('click', '.detail', async function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        let res = await api.taskStatusMps(rowData[0]);
        if (res.data && res.data.status.status) {
          rowData[7] = res.data.status.status;
          vm.dataTableMps.draw();
        }
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
          extra_info: rowData[1],
          create_time: rowData[6],
          status: {status: rowData[7]}
        };
        vm.editable = false;
        vm.showModal = true;
      });
      vm.dataTableMps.on('click', '.edit', function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
          extra_info: rowData[1]
        };
        vm.editable = true;
        vm.showModal = true;
      });
      vm.dataTableMps.on('click', '.delete', function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        if (confirm("Confirm Delete?")) {
          api.taskDeleteMps(rowData[0]).then(() => {
            vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
            vm.dataTableMps.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err.response.data.message);
          });
        }
      });
      vm.dataTableMps.on('click', '.roi', async function() {
        let rowData = vm.dataTableMps.row($(this).parents('tr')).data();
        vm.showObject = {
          task_id: rowData[0],
          source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
          task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
          extra_info: rowData[1]
        };
        vm.$emit('loading', true);
        let capture = await axios.post('/atlas/backend/getCapture', vm.showObject)
        vm.$emit('loading', false);
        if (capture === null) {
          vm.$toastr.s(vm.$i18n.t('message.capture_no_result'));
          return;
        }   
        const image = new window.Image();
        const fixWidth = 560;
        const minRectSize = 50;
        image.src = capture.data.data
        image.onload = () => {
          vm.roiScaleRatio = fixWidth / image.width;
          vm.roiImageConfig.image = image;
          vm.roiImageConfig.width = fixWidth;
          vm.roiImageConfig.height = image.height * vm.roiScaleRatio;
          vm.roiStageConfig.width = fixWidth;
          vm.roiStageConfig.height = image.height * vm.roiScaleRatio;
          vm.roiRectConfig = {
            fill: 'green',
            opacity: 0.4,
            stroke: 'black',
            name: 'rect',
            draggable: false
          }

          if (rowData[8] && rowData[8].vertices && rowData[8].vertices.length >= 2) {
            let vertices = rowData[8].vertices;
            vm.roiRectConfig.x = vertices[0].x * vm.roiScaleRatio;
            vm.roiRectConfig.y = vertices[0].y * vm.roiScaleRatio;
            vm.roiRectConfig.width = (vertices[1].x - vertices[0].x) * vm.roiScaleRatio;
            vm.roiRectConfig.height = (vertices[1].y - vertices[0].y) * vm.roiScaleRatio;
          } else {
            vm.roiRectConfig.x = 0;
            vm.roiRectConfig.y = 0;
            vm.roiRectConfig.width = fixWidth;
            vm.roiRectConfig.height = image.height * vm.roiScaleRatio;
          }
          
          const transformerNode = vm.$refs.transformer.getStage();
          const rectNode = vm.$refs.rectangle.getStage();
          transformerNode.attachTo(rectNode);
          vm.roiTransformerConfig = {
            rotateEnabled: false,
            boundBoxFunc: function(oldBoundBox, newBoundBox) {
              if (newBoundBox.x < 0) {
                newBoundBox.x = 0;
              }
              if (newBoundBox.y < 0) {
                newBoundBox.y = 0;
              }
              if (newBoundBox.x > vm.roiStageConfig.width - minRectSize) {
                newBoundBox.x = vm.roiStageConfig.width - minRectSize;
              }
              if (newBoundBox.y > vm.roiStageConfig.height - minRectSize) {
                newBoundBox.y = vm.roiStageConfig.height - minRectSize;
              }
              if (newBoundBox.width < minRectSize) {
                newBoundBox.width = minRectSize;
              }
              if (newBoundBox.height < minRectSize) {
                newBoundBox.height = minRectSize;
              }
              if (newBoundBox.x + newBoundBox.width > vm.roiStageConfig.width) {
                newBoundBox.width = vm.roiStageConfig.width - newBoundBox.x;
              }
              if (newBoundBox.y + newBoundBox.height > vm.roiStageConfig.height) {
                newBoundBox.height = vm.roiStageConfig.height - newBoundBox.y;
              }

              return newBoundBox;
            }
          }
        };
        vm.$emit('loading', false);
        vm.showRoiDialog = true;
      });
    });
  }
};
</script>
