<style scoped>
.box {
  margin-bottom: 0px;
}
.box-body {
  height: calc(100vh - 143px);
}
.live-results {
  margin: 15px 0;
  height: calc(100vh - 220px);
}
.live-header {
  font-size: small;
  color: white;
  position: absolute;
  z-index: 800;
  left: 10px;
  top: 13px;
}
.live-container {
  height: 100%;
  background-color: aliceblue;
}
.live-item {
  background-color: aqua;
  position: relative;
}
.capture-results {
  margin: 15px 0;
  height: calc(100vh - 220px);
  background-color: aliceblue;
  overflow-y: scroll;
}
.info-box-icon {
  line-height: 0px;
  width: 125px;
}
.info-box-content {
  margin-left: 125px;
  height: 125px;
  background-color: lightyellow;
}
.face {
  height: 125px;
  width: 125px;
  border-radius: 0px;
}
.live-monitor {
  width: 100%;
  height: 100%;
  background-color: black;
  margin: 0 auto;
  display: flex;
  align-items: center;
}
.panorama {
  max-width: 100%;
  max-height: 100%;
  width: auto;
  height: auto;
  margin: auto;
  display: block;
}
.detail-content {
  margin: auto;
  width: 300px;
}
.portrait {
  text-align: center;
  color: gray;
  margin: 20px;
}
.compare {
  text-align: center;
  margin-top: 40px;
}
.detail-body {
  font-size: x-small;
}
.detail-body tr th {
  width: 90px;
  padding: 3px;
}
.detail-body tr td {
  padding: 3px;
  text-align: center;
}
.selectButton{
  margin-left: 10px;
}
.info-box-content{
  position: relative;
}
.loginButton{
  position:absolute;
  right: 0;
  bottom: 0;
}
.file-upload {
  background-color: #ffffff;
  width: 100%;
  height: 250px;
  margin: 0 auto;
}
.file-upload-content {
  height: 100%;
  vertical-align: middle;
}
.file-upload-input {
  position: absolute;
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%; 
  outline: none;
  opacity: 0;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  cursor: pointer;
  z-index: 999;
}
.image-upload-wrap {
  height: 100%;
  position: relative;
  margin-top: 20px;
  vertical-align: middle;
  border: 4px dashed #3c8dbc;
}
.image-dropping {
  background-color: #3c8dbc;
  border: 4px dashed #ffffff;
}
.drag-text {
  margin-top: 80px;
  text-align: center;
  color: #3c8dbc;
  font-size: 50px;
}
.portraitNew {
  max-height: 100%;
  max-width: 100%;
  width: auto;
  height: auto;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
}
.iconStyle{
  position: absolute;
  right: 10px;
  bottom: 10px;
  cursor: pointer;
}
.bgColor{
  color: rgb(204, 177, 177);
  cursor: default;
}
</style>
<template>
  <div class="wrapper">
    <pageHeader></pageHeader>
    <pageAside></pageAside>
    <div class="content-wrapper">
      <section class="content">
        <div class="row">
          <div class="col-xs-8">
            <div class="box box-default">
              <div class="box-header">
                <h4>{{ $t("menu.video") }}</h4>
              </div>
              <div class="box-body">
                <div class="form-group">
                  <div class="row">
                    <div class="col-xs-8">
                      <select v-model="targetLiveTasks" @change="changeLiveTasks" v-select2="tastLiveSelectOption" multiple="multiple" class="form-control select2" data-placeholder="Select Devices" style="width: 100%;">
                        <option v-for="item of tasks" :key="item.task_id" :value="item">{{ item.extra_info.task_name }}</option>
                      </select>
                    </div>
                    <bootstrap-toggle v-model="popup" :options="{ on: 'Alarm Popup ON', off: 'Alarm Popup OFF', width: 150 }" :disabled="false" />
                  </div>
                  <div class="live-results">
                    <div class="live-container">
                      <div class="live-item" v-if="targetLiveTasks.length!==3" v-for="(item, index) in targetLiveTasks" :key="item.task_id" :style="calcLiveStyle(item, index)" >
                        <span class="live-header"> {{ item.viewer.text }} </span>
                        <div class="live-monitor" v-if="item.viewer.panorama"><img class="panorama" v-auth-image="item.viewer.panorama"></div>
                        <video-player class="live-monitor" :url="item.viewer.videoOptions.url" v-if="item.viewer.videoOptions"/>
                      </div>
                      <div v-if="targetLiveTasks.length===3" style="height:100%;width:100%">
                        <div style="height:100%;width:50%;float:left;">
                          <div class="live-item" v-for="(item, index) in targetLiveTasks.slice(0, 2)" :key="item.task_id" :style="calcLiveStyle(item, index)" >
                            <span class="live-header"> {{ item.viewer.text }} </span>
                            <div class="live-monitor" v-if="item.viewer.panorama"><img class="panorama" v-auth-image="item.viewer.panorama"></div>
                            <video-player class="live-monitor" :url="item.viewer.videoOptions.url" v-if="item.viewer.videoOptions"/>
                          </div>
                        </div>
                        <div style="height:100%;width:50%;float:right;">
                          <div class="live-item" :style="calcLiveStyle(targetLiveTasks[2], 3)" >
                            <span class="live-header"> {{ targetLiveTasks[2].viewer.text }} </span>
                            <div class="live-monitor" v-if="targetLiveTasks[2].viewer.panorama"><img class="panorama" v-auth-image="targetLiveTasks[2].viewer.panorama"></div>
                            <video-player class="live-monitor" :url="targetLiveTasks[2].viewer.videoOptions.url" v-if="targetLiveTasks[2].viewer.videoOptions"/>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div class="col-xs-4">
            <div class="box box-default">
              <div class="box-header">
                <div class="row">
                  <div class="col-xs-4">
                    <h4>{{ $t("video.capture") }}</h4>
                  </div>
                  <div class="col-xs-8" style="padding-top:6px; text-align:right;">
                    <input type="checkbox" v-model="authFlag" name="authFlag" title="show identified"/>  {{ $t("video.checkCapture") }}
                  </div>
                </div>
              </div>
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-6">
                    <select v-model="targetCaptureTasks" v-select2="tastCaptureSelectOption" multiple="multiple" class="form-control select2 selectCaptures" data-placeholder="Select Devices" style="width: 100%;">
                      <option v-for="item of tasks" :key="item.task_id" :value="item.task_id">{{ item.extra_info.task_name }}</option>
                    </select>
                  </div>
                  <button class="btn btn-primary" title="Clear All" @click="clearCaptures"><i class="fa fa-eraser"></i></button>
                  <button class="btn btn-primary selectButton" title="Select All" @click="selectCaptures"><i class="fa fa-check"></i></button>
                  <button class="btn btn-primary selectButton" title="Reverse" @click="reverseCaptures"><i class="fa fa-sort"></i></button>
                </div>
                <div class="capture-results">
                  <div class="info-box" v-for="item in filteredCaptures" :key="item.id">
                    <span class="info-box-icon bg-aqua"><img class="face" v-auth-image="item.portrait"></span>
                    <div class="info-box-content">
                      <span class="info-box-text">{{ item.task_name }}</span>
                      <span class="info-box-text">{{ item.user.name }}</span>
                      <span class="info-box-text" v-if="item.user.gender==='-'">Gender: {{ item.attributes.gender }} (Age: {{ item.attributes.age }})</span>
                      <span class="info-box-text" v-if="item.user.gender!=='-'">Gender: {{ item.user.gender }} (Age: {{ item.user.age }})</span>
                      <span class="info-box-text">{{ item.attributes.respirator }}、 {{ item.attributes.expression }}</span>
                      <span class="info-box-text">{{ $t("capture.temperature") }}: {{item.temperature}}</span>
                      <span class="info-box-text">{{ item.capture_time }}</span>
                      <i class="fa fa-user-o iconStyle" @click="openLogin(item)" v-if="item.library_name ==='' && item.quality >= 0.3 "></i>
                      <i class="fa fa-user-o iconStyle bgColor" v-if="item.library_name ==='' && item.quality < 0.3 "></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <pageModal :show.sync="showModal" :footer="false" :modalclass="'modal-lg'">
          <div slot="header">
            {{ $t("video.popup") }}
          </div>
          <div slot="body" class="detail-body">
            <div class="col-xs-5">
              <div class="portrait">
                <img height="150px" width="150px" v-auth-image="showObject.portrait">
                <h6>{{ $t("alarm.capture") }}</h6>
              </div>
              <div class="table-responsive" v-if="showObject.user">
                <table class="table">
                  <tbody>
                    <tr>
                      <th> {{ $t("alarm.task") }}: </th>
                      <td> {{ showObject.task_name}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.object") }}: </th>
                      <td> {{ showObject.user.name}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.v_age") }}: </th>
                      <td> {{ showObject.attributes.age}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.v_gender") }}: </th>
                      <td> {{ showObject.attributes.gender}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.respirator") }}: </th>
                      <td> {{ showObject.attributes.respirator}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.expression") }}: </th>
                      <td> {{ showObject.attributes.expression}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.temperature") }}: </th>
                      <td> {{ showObject.temperature}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.card_info") }}: </th>
                      <td> - </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.time") }}: </th>
                      <td> {{ showObject.capture_time}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.receive_time") }}: </th>
                      <td> {{ showObject.capture_time}}</td>
                    </tr>
                    <tr>
                      <th> {{ $t("alarm.upload_time") }}: </th>
                      <td> {{ showObject.capture_time}}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
            <div class="col-xs-2 compare">
              <hr>
              <strong> {{ $t("alarm.score") }}: </strong><br><br>
              <span class="badge bg-red">{{ showObject.score }}%</span>
              <hr>
            </div>
            <div class="col-xs-5" v-if="showObject.user">
              <div class="portrait">
                <img height="150px" width="150px" v-auth-image="showObject.user.url">
                <h6>{{ $t("alarm.master") }}</h6>
              </div>
              <div class="table-responsive">
                <table class="table">
                  <tbody>
                    <tr>
                      <th> {{ $t("user.name") }}: </th>
                      <td> {{ showObject.user.name}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("menu.library") }}: </th>
                      <td> {{ showObject.library_name}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("user.gender") }}: </th>
                      <td> {{ showObject.user.gender}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("user.age") }}: </th>
                      <td> {{ showObject.user.age}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("user.cardId") }}: </th>
                      <td> {{ showObject.user.card_id}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("user.address") }}: </th>
                      <td> {{ showObject.user.address}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("user.create_time") }}: </th>
                      <td> {{ showObject.user.year}} </td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </pageModal>
        <pageModal :show.sync="showLoginModal" :footer="true">
            <div slot="header">
              <span>{{ $t("video.registerUser") }} </span>
            </div>
            <div slot="body">
              <div class="row" v-if="showObject">
                <div class="col-sm-4">
                  <div class="file-upload">
                    <div class="image-upload-wrap" :class="[{'image-dropping': isDrag}]" @dragover.prevent="isDrag=true;" @dragleave.prevent="isDrag=false;">
                      <img class="portraitNew" v-auth-image="showObjectNew.image.url">
                    </div>
                  </div>
                </div>
                <div class="col-sm-8">
                  <form class="form-horizontal">
                    <div class="modal-form">
                      <div class="form-group">
                        <label class="col-sm-4 control-label">
                          {{ $t("user.library") }}
                        </label>
                        <div class="col-sm-8">
                          <select v-model="libraryId" class="form-control" placeholder="Library">
                            <option v-for="item in librariesArr" :key="item.id" :value="item.id">{{ item.name }}</option>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">
                          {{ $t("user.name") }}
                        </label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" v-model="showObjectNew.name" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">
                          {{ $t("user.gender") }}
                        </label>
                        <div class="col-sm-8">
                          <select v-model="showObjectNew.gender" class="form-control" placeholder="Gender">
                            <option value="MALE">MALE</option>
                            <option value="FEMALE">FEMALE</option>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">
                          {{ $t("user.age") }}
                        </label>
                        <div class="col-sm-8">
                          <input type="number" class="form-control" v-model="showObjectNew.age" placeholder="Age">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">
                          {{ $t("user.cardId") }}
                        </label>
                        <div class="col-sm-8">
                          <input type="text" class="form-control" v-model="showObjectNew.card_id" placeholder="ID">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-4 control-label">
                          {{ $t("user.address") }}
                        </label>
                        <div class="col-sm-8">
                          <textarea class="form-control" rows="2" v-model="showObjectNew.address" placeholder="Department"></textarea>
                        </div>
                      </div>
                      <div class="form-group" v-show="false">
                        <label class="col-xs-4 control-label">
                          {{ $t("user.create_time") }}
                        </label>
                        <div class="col-xs-8">
                          <input type="text" class="form-control" :value="showObjectNew.capture_time" disabled>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div slot="footer">
              <button class="btn btn-default pull-left" @click="showLoginModal=false;">{{ $t("common.cancel") }}</button>
              <button class="btn btn-primary pull-right" @click="createUser">{{ $t("common.ok") }}</button>
            </div>
          </pageModal>
      </section>
    </div>
    <!-- <pageFooter></pageFooter> -->
  </div>
</template>
<script>
import * as moment from 'moment';
import io from 'socket.io-client';
import BootstrapToggle from 'vue-bootstrap-toggle';
import api from '../api/api';
import * as util from '../assets/js/util';

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
    VideoPlayer: () => import("../components/video.vue"),
    BootstrapToggle
  },
  data() {
    return {
      user: this.$root.userData,
      tasks: [],
      libraries: [],
      filteredCaptures: [],
      targetCaptureTasks: [],
      targetLiveTasks: [],
      popup: true,
      showModal: false,
      showObject: {},
      socket: null,
      latestSensepassAlarmTime: 0,
      tastLiveSelectOption: {
        allowClear: true,
        maximumSelectionLength: 4,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
      tastCaptureSelectOption: {
        allowClear: true,
        maximumSelectionLength: 20,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
      isDrag: false,
      showLoginModal:false,
      showObjectNew: {
        image:{
          data:{}
        }
      },
      librariesArr:[],
      libraryId:'',
      reverseFlag:true,
      authFlag: true
    };
  },
  methods: {
    openLogin(item){
      let vm = this;
      vm.showLoginModal = true;
      vm.libraryId = '';
      vm.showObjectNew.name  = '';
      vm.showObjectNew.card_id  = '';
      vm.showObjectNew.depart  = '';
      vm.showObjectNew.address  = '';

      vm.showObjectNew.gender  = '';
      vm.showObjectNew.age  = '';
      vm.showObjectNew.image.url  = item.portrait;
      vm.showObjectNew.capture_time  = item.capture_time;

      api.downloadObject(item.portrait).then(function(res) {
        vm.showObjectNew.image.data = res;
      }).catch((function() {
        vm.$toastr.e(vm.$i18n.t('message.library_selectImg_failure'));
      }));

      api.dBList({}).then(res => {
        vm.librariesArr = res.data.databases;
      }).catch(() => {
        vm.$toastr.e(vm.$i18n.t('message.library_select_failure'));
      });
    },
    createUser(){
      let vm = this;
      if (!vm.showObjectNew.name || !vm.showObjectNew.image || !vm.showObjectNew.gender || vm.showObjectNew.age < 0 || !vm.libraryId) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      vm.showObjectNew.name  = vm.showObjectNew.name.trim();
      vm.showObjectNew.card_id  = vm.showObjectNew.card_id.trim();
      vm.showObjectNew.address  = vm.showObjectNew.address.trim();
      vm.showObjectNew.age  = Number(vm.showObjectNew.age);
      let userData = JSON.parse(JSON.stringify(vm.showObjectNew));
      userData.image.data = userData.image.data.substring(userData.image.data.indexOf(",") + 1);
      api.userBatchAdd({db_id: vm.libraryId, users: [userData]}).then(() => {
        vm.showLoginModal = false;
        vm.$toastr.s(vm.$i18n.t('message.user_create_success'));
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.user_create_failure') + '<br>' + err.response.data.message);
      });

    },
    calcLiveStyle(item, index) {
      if (this.targetLiveTasks) {
        let num = this.targetLiveTasks.length;
        let cssResult = {position: "float", border: "1px solid blue", display: "inline"};
        if (num === 1) {
          cssResult.height = "100%";
          cssResult.width = "100%";
          cssResult.float = "left";
        }
        if (num === 2) {
          cssResult.height = "100%";
          cssResult.width = "50%";
          cssResult.float = index === 1 ? "right" : "left";
        }
        if (num === 3) {
          cssResult.height = index <= 1 ? "50%" : "100%";
          cssResult.width = "100%";
          cssResult.float = index <= 1 ? "left" : "right";
        }
        if (num >= 4) {
          cssResult.height = "50%";
          cssResult.width = "50%";
          cssResult.float = index % 2 === 0 ? "left" : "right";
        }
        return cssResult;
      }
    },
    clearCaptures() {
      this.filteredCaptures = [];
      this.targetCaptureTasks = [];
      $(".selectCaptures").val([]);
      $(".selectCaptures").trigger("change");
    },
    reverseCaptures() {
      let vm  = this;
      vm.reverseFlag = !vm.reverseFlag;
      if(vm.reverseFlag){
        vm.filteredCaptures.sort(function (a, b) {
          if (moment(a.capture_time).diff(moment(b.capture_time), 'seconds') > 0) {
            return -1;
          } else {
            return 1;
          }
        });
      }else{
        vm.filteredCaptures.sort(function (a, b) {
          if (moment(a.capture_time).diff(moment(b.capture_time), 'seconds') < 0) {
            return -1;
          } else {
            return 1;
          }
        });
      } 
    },
    selectCaptures() {
      let vm = this;
      var aArray = new Array();
      var count = 0
      $(".selectCaptures option").each(function(){
        if(count < 20){
          aArray.push($(this).val());
        } 
        count += 1; 
      })
      $(".selectCaptures").val(aArray);
      vm.targetCaptureTasks = aArray;
      $(".selectCaptures").trigger("change");
    },
    changeLiveTasks() {
      let vm = this;
      for (let element of vm.targetLiveTasks) {
        if (!element.viewer) {
          element.viewer = {text: element.extra_info.task_name};
          if (element.source.type === 'FC_SENSEPASS') {
            element.viewer.panorama = '';
          } else {
            if(element.extra_info.substream)
            {
              // let splitSubstream = element.extra_info.substream.split(',');
              // if(splitSubstream.length === 2){
              //   element.source.parameter.rtsp.url = element.source.parameter.rtsp.url.replace(new RegExp(splitSubstream[0].trim(), 'gi') , splitSubstream[1].trim());
              // }
              element.source.parameter.rtsp.url = element.extra_info.substream;
            }else{
              //element.source.parameter.rtsp.url = element.source.parameter.rtsp.url.replace(/subtype=0/i, 'subtype=1').replace(/channels\/101/i, 'channels/102').replace(/inst=1/i, 'inst=2').replace(/Media1/i,"Media2");
              element.source.parameter.rtsp.url = element.source.parameter.rtsp.url;
            }
            // FOR TEST
            // element.source.parameter.rtsp.url = 'rtsp://admin:Huawei1234@172.30.10.91:554/cam/realmonitor?channel=1&subtype=1';
            // element.source.parameter.rtsp.url = 'rtsp://admin:Huawei1234@124.219.161.88:18554/cam/realmonitor?channel=1&subtype=1';
            element.viewer.videoOptions = {
              url: element.source.parameter.rtsp.url
            };
          }
        }
      }
      setTimeout(() => {
        util.resizeWindow();
      }, 100);
    },
    connectWebsocket() {
      let vm = this;
      vm.socket = io('/message', {path: '/atlas/backend/socket.io'});
      vm.socket.on('notify', (message) => {
        if (message.data) {
          vm.receiveMessage(message.data);
        }
      });
    },
    receiveMessage(data) {
      let vm = this;
      let task_id = data.task_id;
      if (task_id === undefined) {
        return;
      }
      let diff = vm.$root.diffTime;
      let capture_time = moment(data.capture_time).add(diff, 'seconds');
      let received_time = moment(data.received_time).add(diff, 'seconds');
      //let upload_result_time = moment(data.upload_result_time).add(diff, 'seconds');
      let temperature =  data.extra_info.zk_temp != undefined ? data.extra_info.zk_temp : '-';
      let panorama = data.panorama.url;
      let portrait = data.capture_result.face.portrait.url;
      let gender = data.capture_result.face.attributes && data.capture_result.face.attributes.gender ? data.capture_result.face.attributes.gender : '-';
      let age = data.capture_result.face.attributes && data.capture_result.face.attributes.age ? data.capture_result.face.attributes.age : '-';
      let expression = data.capture_result.face.attributes && data.capture_result.face.attributes.expression ? data.capture_result.face.attributes.expression : '-';
      let respirator = data.capture_result.face.attributes && data.capture_result.face.attributes.respirator === 'color_type_none' ? 'マスクなし' : 'マスクあり';
      let quality = data.capture_result.face.quality;
      let user_name = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.name : '-';
      let user_gender = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.gender : '-';
      let user_age = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.age : '-';
      let user_create_time = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.create_time : '-';
      let user_url = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.image.url : '-';
      let user_address = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.address : '-';
      let user_card_id = data.capture_result.face.most_similar_user ? data.capture_result.face.most_similar_user.card_id : '-';
      let user_score = data.capture_result.face.score ? Math.round(Number(data.capture_result.face.score)*10000)/100 : 0;

      let libraryName = data.capture_result.face.db_id;
      let curLibrary = vm.libraries.filter(ele => { if (ele.id === data.capture_result.face.db_id) return true; });
      if (curLibrary.length > 0) {
        libraryName = curLibrary[0].name;
      }

      let isSensepass = false;
      if (vm.targetLiveTasks.length > 0) {
        vm.targetLiveTasks.forEach(element => {
          if (element.task_id === task_id) {
            if (panorama && element.source.type === 'FC_SENSEPASS') {
              isSensepass = true;
              if (new Date().getTime() - vm.latestSensepassAlarmTime > 2000) {
                element.viewer.panorama = panorama;
              }
            }
          }
        });
      }

      if (isSensepass) {
        if (!data.capture_result.face.most_similar_user
            && new Date().getTime() - vm.latestSensepassAlarmTime <= 2000) {
          return;
        }
        capture_time = capture_time.add(-9, 'hours');
        received_time = received_time.add(-9, 'hours');
        //upload_result_time = upload_result_time.add(-9, 'hours');
      }
      
      if (vm.targetCaptureTasks.length > 0) {
        capture_time = capture_time.format('YYYY-MM-DD HH:mm:ss');
        received_time = received_time.format('YYYY-MM-DD HH:mm:ss');
        //upload_result_time = upload_result_time.format('YYYY-MM-DD HH:mm:ss');
        vm.targetCaptureTasks.forEach(element => {
          if (element === task_id) {
            let user_year = '-';
            if (user_create_time && user_create_time !== '-') {
              user_year = moment(user_create_time).add(diff, 'seconds').format('YYYY-MM-DD HH:mm:ss');
            }
            let dataObj; 
            for(var perItem in vm.tasks){
              if(vm.tasks[perItem].task_id === task_id){
                dataObj = vm.tasks[perItem];
              }
            }
            let item = {
              id: new Date().getTime(),
              task_id: task_id,
              task_name: dataObj.extra_info.task_name,
              library_name: libraryName,
              capture_time: capture_time,
              received_time: received_time,
              //upload_result_time: upload_result_time,
              temperature:temperature,
              portrait: portrait,
              score: user_score,
              attributes: {gender: gender, age: age, expression:expression, respirator: respirator},
              user: {name: user_name, gender: user_gender, age: user_age, url: user_url, address: user_address, card_id: user_card_id, year: user_year},
              quality:quality
            };
            if(vm.authFlag){
              if(data.capture_result.face.most_similar_user){
                if(vm.reverseFlag){
                  vm.filteredCaptures.unshift(item);
                }else{
                  vm.filteredCaptures.push(item);
                }
              }
            }else{
              if(vm.reverseFlag){
                vm.filteredCaptures.unshift(item);
              }else{
                vm.filteredCaptures.push(item);
              }
            }
            
            if (vm.popup && !vm.showModal && data.capture_result.face.most_similar_user) {
              let min_score = dataObj.task.parameter.face.min_score;
              if (user_score >= min_score) {
                if (isSensepass) {
                  vm.latestSensepassAlarmTime = new Date().getTime();
                }
                vm.showObject = item;
                vm.showModal = true;
                setTimeout(() => {
                  vm.showModal = false;
                }, 3 * 1000);
              }
            }
          }
        });
      }
    },
    disconnectWebsocket() {
      if (this.socket) {
        this.socket.disconnect();
      }
    }
  },
  created: function() {
    let vm = this;
    if (!vm.user) {
      vm.$router.push({ path: "/login" });
    }

    // Get All Libraries
    api.dBList().then(res => {
      vm.libraries = res.data.databases;
    }).catch(() => {
      vm.libraries = [];
    });
  },
  mounted: async function() {
    let vm = this;
    // init websocket client
    vm.connectWebsocket();

    // Get All tasks (status===OK)
    await api.taskListAcs({'page_request.offset': 0, 'page_request.limit': 100}).then(res =>{
      if (res.data.tasks) {
        let running = res.data.tasks.filter(element => {
          if (element.status.status === 'OK') return true;
        });
        if (running.length > 0) {
          vm.tasks = vm.tasks.concat(running);
        }
      }
    });
    await api.taskListMps({'page_request.offset': 0, 'page_request.limit': 100}).then(res =>{
      if (res.data.tasks) {
        let running = res.data.tasks.filter(element => {
          if (element.status.status === 'OK') return true;
        });
        if (running.length > 0) {
          vm.tasks = vm.tasks.concat(running);
        }
       }
    });
  },
  beforeDestroy: function () {
    this.disconnectWebsocket();
  },
};
</script>
