<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.ctl-button {
  margin-left: 10px;
}
.checkall {
  border: none;
  background: transparent;
  font-size: 16px;
}
.portrait {
  text-align: center;
  margin: 20px;
}
.detail-content {
  margin: auto;
  width: 450px;
}
.table th{
  min-width: 100px;
}
.buttonRight{
  margin-right: 10px;
}
</style>
<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.capture") }}</h4>
            </div>
            <div class="box-body">
              <div class="form-group">
                <div class="row">
                  <div class="col-xs-3">
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-clock-o"></i>
                      </div>
                      <input type="text" class="form-control pull-right" id="timerange">
                    </div>
                  </div>
                  <div class="col-xs-2">
                    <select v-model="targetTasks" @change="changeTasks" v-select2="tastSelectOption" multiple="multiple" class="form-control select2" data-placeholder="Select Devices" style="width: 100%;">
                      <option v-for="item of tasks" :key="item.task_id" :value="item">{{ item.extra_info.task_name }}</option>
                    </select>
                  </div>
                  <div class="col-xs-2">
                    <select v-model="targetOrders" class="form-control select2" style="width: 100%;">
                      <option v-for="item of orders" :key="item.key" :value="item.key">{{ item.value }}</option>
                    </select>
                  </div>
                  <div class="col-xs-2">
                    <select v-model="targetGenders" class="form-control select2" style="width: 100%;">
                      <option v-for="item of genders" :key="item.key" :value="item.key">{{ item.value }}</option>
                    </select>
                  </div>
                  <div class="col-xs-3">
                    <button class="btn btn-primary ctl-button buttonRight" @click="search" title="Search"><i class="fa fa-search"></i></button>
                    <bootstrap-toggle v-model="popup" :options="{ on: '画像あり', off: '画像なし', width: 90 }" :disabled="false"/>
                    <button class="btn btn-primary ctl-button" @click="exportData(true)" v-if="user.admin">{{ $t("common.export") }}</button>
                    <button class="btn btn-primary ctl-button" @click="exportData(false)" v-if="user.admin">{{ $t("common.exportAll") }}</button>
                  </div>
                </div>
              </div>

              <table id="captures" class="table table-bordered table-striped" width="100%">
                <thead>
                <tr>
                  <th class="text-center">
                    <button class="checkall" @click="checkAll">
                      <i class="fa fa-square-o" v-if="selected===0"></i>
                      <i class="fa fa-minus-square-o" v-if="selected===1"></i>
                      <i class="fa fa-check-square-o" v-if="selected===2"></i>
                    </button>
                  </th>
                  <th>{{ $t("capture.time") }}</th>
                  <th>{{ $t("capture.taskId") }}</th>
                  <th>{{ $t("capture.task") }}</th>
                  <th>{{ $t("capture.image") }}</th>
                  <th>{{ $t("capture.object") }}</th>
                  <th>{{ $t("capture.v_age") }}</th>
                  <th>{{ $t("capture.v_gender") }}</th>
                  <th>{{ $t("capture.respirator") }}</th>
                  <th>{{ $t("capture.expression") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          <pageModal :show.sync="showModal" :footer="false">
            <div slot="header">
              {{ $t("common.detail") }}
            </div>
            <div slot="body">
              <div class="portrait">
                <img height="200px" width="200px" v-auth-image="showObject[4]">
              </div>
              <div class="table-responsive detail-content">
                <table class="table">
                  <tbody>
                    <tr>
                      <th> {{ $t("capture.task") }}: </th>
                      <td> {{ showObject[3]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.object") }}: </th>
                      <td> {{ showObject[5]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.v_age") }}: </th>
                      <td> {{ showObject[6]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.v_gender") }}: </th>
                      <td> {{ showObject[7]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.respirator") }}: </th>
                      <td> {{ showObject[8]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.expression") }}: </th>
                      <td> {{ showObject[9]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.temperature") }}: </th>
                      <td> {{ showObject[12]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.card_info") }}: </th>
                      <td> - </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.time") }}: </th>
                      <td> {{ showObject[1]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.receive_time") }}: </th>
                      <td> {{ showObject[10]}} </td>
                    </tr>
                    <tr>
                      <th> {{ $t("capture.upload_time") }}: </th>
                      <td> {{ showObject[11]}}</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </pageModal>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>
<script>
import jsZip from 'jszip';
import FileSaver from 'file-saver';
import * as moment from 'moment';
import api from '../api/api';
import BootstrapToggle from 'vue-bootstrap-toggle';

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
    BootstrapToggle
  },
  data() {
    return {
      user: this.$root.userData,
      diff: this.$root.diffTime,
      loading: this.$root.loading,
      selected: 0,
      tasks: [],
      targetTasks: [],
      targetOrders:'DESC',
      targetGenders:'',
      libraries: [],
      dataTable: null,
      timePicker: null,
      showModal: false,
      showObject: [],
      tastSelectOption: {
        allowClear: true,
        maximumSelectionLength: 4,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
      popup:false,
      orders:[{key:'ASC',value:'検知時間昇順'},{key:'DESC',value:'検知時間降順'}],
      genders:[{key:'',value:'選んでください'},{key:'SECRET',value:'SECRET'},{key:'MALE',value:'MALE'},{key:'FEMALE',value:'FEMALE'}],
      searchTasks:[],
    };
  },
  methods: {
    checkAll() {
      let all = this.dataTable.rows({search: 'applied'}).count();
      let selectedRows = this.dataTable.rows({search: 'applied', selected: true}).count();

      if (selectedRows < all) {
        this.dataTable.rows().deselect();
        this.dataTable.rows({search: 'applied'}).select();
        this.selected = 2;
      } else {
        this.dataTable.rows().deselect();
        this.selected = 0;
      }
    },
    search() {
      this.dataTable.ajax.reload();
    },
    changeTasks() {
      let vm = this;
      //let searchRegex = '';
      vm.searchTasks = [];
      if (vm.targetTasks.length > 0) {
        // searchRegex += '(';
        // vm.targetTasks.forEach((element, index) => {
        //   searchRegex += element.task_id;
        //   if (index < (vm.targetTasks.length - 1)) {
        //     searchRegex += '|';
        //   }
        // })
        // searchRegex += ')';
        vm.targetTasks.forEach(element => {
          vm.searchTasks.push(element.task_id);
        })
      }
      // this.dataTable.rows().deselect();
      // vm.dataTable.columns(2).search(searchRegex, true, false).draw();
      
    },
    view(rowData) {
      this.showObject = rowData;
      this.showModal = true;
    },
    listData(res){
      let vm = this;
      let result = res.data;
      let records = {draw: 1, data: []};
      if (result.page_request.total >= 0) {
        records.recordsTotal = result.page_request.total;
        records.recordsFiltered = result.page_request.total;
        for (let i = 0; i < result.results.length; i++) {
          let element = result.results[i];
          let curTask = vm.tasks.filter(ele => { if (ele.task_id === element.task_id) return true; });
          records.data.push([
            '', 
            moment(element.capture_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'), 
            element.task_id,
            curTask.length > 0 ? curTask[0].extra_info.task_name : element.task_id, 
            element.capture_result.face.portrait.url,
            element.capture_result.face.most_similar_user ? element.capture_result.face.most_similar_user.name : '-',
            element.capture_result.face.attributes.age ? element.capture_result.face.attributes.age : '-',
            element.capture_result.face.attributes.gender ? element.capture_result.face.attributes.gender : '-',
            element.capture_result.face.attributes.respirator === 'color_type_none' ? 'マスクなし':'マスクあり',
            element.capture_result.face.attributes.expression ? element.capture_result.face.attributes.expression : '-',
            moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
            moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'), 
            element.extra_info.zk_temp != undefined ? element.extra_info.zk_temp : '-'
          ]);
        }
      }
      return records;
    },
    async exportData(selected) {
      let vm  = this;
      let selectedRows;
      this.$emit('loading', true);
      if (selected) {
        selectedRows = this.dataTable.rows({search: 'applied', selected: selected});
        vm.baseExport(selectedRows.data(),selected);
      } else {
        let param = 'time_range.start='+new Date(vm.timePicker.data('daterangepicker').startDate.toDate() - vm.diff * 1000).toISOString()
                    +'&time_range.end='+new Date(vm.timePicker.data('daterangepicker').endDate.toDate() - vm.diff * 1000).toISOString()

        for(var i=0;i<vm.searchTasks.length;i++){
          param += '&task_id='+vm.searchTasks[i];
        }

        param = param + '&order='+vm.targetOrders
        if(vm.targetGenders != ''){
          param = param + '&gender='+vm.targetGenders;
        }

        api.listCaptureResults(encodeURI(encodeURI(param))).then(res => {
          selectedRows = vm.listData(res);
          vm.baseExport(selectedRows.data,selected);
        }).catch(() => {
          this.$toastr.e('message.common_zipFile_result');
        });
      }
    },
    async baseExport(selectedRows,selected) {
      if (selectedRows.length === 0) {
        this.$toastr.i(this.$i18n.t(selected ? 'message.common_no_selected' : 'message.common_empty_result'));
        this.$emit('loading', false);
      } else {
        let rows = [];
        this.$emit('loading', true);
        let zipFile = new jsZip();
        let imgFolder;
        if(this.popup){
          imgFolder = zipFile.folder("images");
        }

        rows.push([
          this.$i18n.t('common.index'),
          this.$i18n.t('capture.time'),
          this.$i18n.t('capture.taskId'),
          this.$i18n.t('capture.task'),
          this.$i18n.t('capture.object'),
          this.$i18n.t('capture.v_age'),
          this.$i18n.t('capture.v_gender'),
          this.$i18n.t('capture.image'),
          this.$i18n.t('capture.respirator'),
          this.$i18n.t('capture.expression')
        ]);
        let items = selectedRows
        for (let index = 0; index < items.length; index++) {
          let item = items[index];
          let imgData;
          
          let imgName = index + '_' + item[5] + '.jpg';
          if(this.popup){
            try {
            imgData = await api.downloadObject(item[4].substring(item[4].lastIndexOf('/') + 1));
            } catch {
              imgData = item[4];
            }
            imgData = imgData.substring(imgData.indexOf(",") + 1);
              imgFolder.file(imgName, imgData, {base64: true});
          }
          rows.push([index, item[1], item[2], item[3], item[5], item[6], item[7], imgName, item[8], item[9]]);
        }
        let csvContent = '\ufeff' + rows.map(e => e.join(',')).join('\n');
        zipFile.file('records.csv', csvContent);
        zipFile.generateAsync({type:"blob"}).then(content => {
          FileSaver.saveAs(content, 'CaptureRecords_' + moment(new Date(), 'YYYYMMDDHHmmss') + '.zip');
        }).finally(() => {
          this.$emit('loading', false);
        });
      }
    }
  },
  created: function() {
    let vm = this;
    if (!vm.user) {
      vm.$router.push({ path: "/login" });
    }
    vm.$emit('loading', true);
  },
  mounted: async function() {
    let vm = this;

    vm.timePicker = $('#timerange').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      startDate: moment().subtract(1, 'hours'),
      endDate: moment(),
      locale: { format: 'MM/DD HH:mm:ss' }
    });

    // Get All tasks and libraries
    let res, acsTasks, mpsTasks;
    try {
      res = await api.taskListAcs({'page_request.offset': 0, 'page_request.limit': 100});
      acsTasks = res.data.tasks;
    } catch (err) {
      acsTasks = [];
    }

    try {
      res = await api.taskListMps({'page_request.offset': 0, 'page_request.limit': 100});
      mpsTasks = res.data.tasks;
    } catch (err) {
      mpsTasks = [];
    }
    vm.tasks = mpsTasks.concat(acsTasks);
    
    try {
      res = await api.dBList();
      vm.libraries = res.data.databases;
    } catch (err) {
      vm.libraries = [];
    }

    vm.dataTable = $('#captures').DataTable({
      paging: true,
      pageLength: 100,
      lengthChange: false,
      searching: true,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [],
      sDom: 'ltipr', 
      columnDefs: [
        {
          orderable: false,
          targets: [0, 4, -1]
        },
        {
          targets: 0,
          className: 'select-checkbox'
        },
        {
          targets: 4,
          render: function() {            
            return `<img height="20px" width="20px"/>`;
          }
        },
        {
          targets: -1,
          render: function() {
            return '<a class="btn btn-info btn-xs detail"> <i class="fa fa-eye"></i>&nbsp;' + vm.$i18n.t('common.detail') + '</a>';
          }
        },
        {
          targets: [2],
          visible: false
        }
      ],
      select: {
        style: 'multi',
        selector: 'td:not(:last-child)'
      },
      initComplete: function() {
        if (vm.targetTasks.length > 0) {
          vm.changeTasks();
        }
      },
      fnRowCallback: function(nRow, aData) {
        api.downloadObject(aData[4]).then(res => {
          $('td:eq(3)', nRow).html(`<img height="20px" width="20px" src="${res}"/>`);
        });
      },
      ajax: function (data, callback) {
        vm.$emit('loading', true);
        let param = 'time_range.start='+new Date(vm.timePicker.data('daterangepicker').startDate.toDate() - vm.diff * 1000).toISOString()
                    +'&time_range.end='+new Date(vm.timePicker.data('daterangepicker').endDate.toDate() - vm.diff * 1000).toISOString()
                    +'&page_request.offset='+data.start+'&page_request.limit='+data.length;

        for(var i=0;i<vm.searchTasks.length;i++){
          param += '&task_id='+vm.searchTasks[i];
        }

        param = param + '&order='+vm.targetOrders
        if(vm.targetGenders != ''){
          param = param + '&gender='+vm.targetGenders;
        }

        api.listCaptureResults(encodeURI(encodeURI(param))).then(res => {
          let result = res.data;
          let records = {draw: data.draw, data: []};
          if (result.page_request.total >= 0) {
            records.recordsTotal = result.page_request.total;
            records.recordsFiltered = result.page_request.total;
            for (let i = 0; i < result.results.length; i++) {
              let element = result.results[i];
              let curTask = vm.tasks.filter(ele => { if (ele.task_id === element.task_id) return true; });
              records.data.push([
                '', 
                moment(element.capture_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'), 
                element.task_id,
                curTask.length > 0 ? curTask[0].extra_info.task_name : element.task_id, 
                element.capture_result.face.portrait.url,
                element.capture_result.face.most_similar_user ? element.capture_result.face.most_similar_user.name : '-',
                element.capture_result.face.attributes.age ? element.capture_result.face.attributes.age : '-',
                element.capture_result.face.attributes.gender ? element.capture_result.face.attributes.gender : '-',
                element.capture_result.face.attributes.respirator === 'color_type_none' ? 'マスクなし':'マスクあり',
                element.capture_result.face.attributes.expression ? element.capture_result.face.attributes.expression : '-',
                moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'), 
                element.extra_info.zk_temp != undefined ? element.extra_info.zk_temp : '-'
              ]);
            }
          }
          callback(records);
        }).catch(() => {
          callback({draw: 1, data: []});
        }).finally(() => {
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTable.on('select deselect draw', function() {
      let all = vm.dataTable.rows({search: 'applied'}).count();
      let selectedRows = vm.dataTable.rows({search: 'applied', selected: true}).count();
      if (selectedRows === 0) {
        vm.selected = 0;
      } else if (selectedRows < all) {
        vm.selected = 1;
      } else {
        vm.selected = 2;
      }
    });
    vm.dataTable.on('click', '.detail', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.view(rowData);
    });
  }
};
</script>
