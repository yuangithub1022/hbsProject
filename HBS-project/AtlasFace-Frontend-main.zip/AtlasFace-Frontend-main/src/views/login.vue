<style>
.login-box-body {
  border-radius: 1em;
  margin-top: 200px;
}
</style>
<template>
  <div class="login-box">
    <div class="login-box-body">
      <h4 class="text-center font-weight-bold">Sign In</h4>
      
      <div class="alert alert-danger" role="alert" v-show="errMsg">
        {{errMsg}}
      </div>

      <form @submit.prevent="login">
        <div class="form-group has-feedback">
          <input type="text" class="form-control" placeholder="User Name" v-model="user" required="">
          <span class="glyphicon glyphicon-user form-control-feedback"></span>
        </div>
        <div class="form-group has-feedback">
          <input type="password" class="form-control" placeholder="Password" v-model="password" required="">
          <span class="glyphicon glyphicon-lock form-control-feedback"></span>
        </div>
        <div class="row">
          <div class="col-xs-4">
            <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
          </div>
        </div>
      </form>
    </div>
  </div>
</template>

<script>
import * as util from '../assets/js/util';
import api from '../api/api';

export default {
  data() {
    return {
      user: '',
      password: '',
      isLoading: false,
      errMsg: '',
      publicPath: process.env.BASE_URL
    };
  },
  computed: {
    btnText() {
      if (this.isLoading) {
        return this.$i18n.t("login.verifying");
      }
      return this.$i18n.t("login.signin");
    }
  },
  methods: {
    login() {
      var vm = this;

      let loginParams = {
        user: vm.user==='member' ? 'admin' : vm.user,
        password: vm.password
      };

      vm.isLoading = true;
      vm.$emit('loading', true);
      api.signIn(loginParams).then(res => {
        let result = res.data;
        if(result.token){
          let admin = vm.user==='admin' ? true : false;
          let role = vm.user==='admin' ? 'Administrator' : 'User';
          util.session('user', {name: vm.user, token: result.token, admin: admin, role: role});
          vm.$emit('login', vm.$router.currentRoute.query.from);
        }else{
          vm.errMsg = vm.$i18n.t('message.login_failure');
        }
      }).catch(() => {
        vm.errMsg = vm.$i18n.t('message.login_failure');
      }).finally(() => {
        vm.isLoading = false;
        vm.$emit('loading', false);
      });
    }
  },
  mounted() {
    $('body').addClass('login-page');
    $('body').css({"background-image": `url("${this.publicPath}bg.jpg")`, "background-size": "cover"});
  },
  destroyed: function () {
    $('body').removeClass('login-page');
    $('body').css({"background-image": "", "background-size": ""});
 },
};
</script>
