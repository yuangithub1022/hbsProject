<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.ctl-button {
  margin-left: 10px;
}
.checkall {
  border: none;
  background: transparent;
  font-size: 16px;
}
.portrait {
  text-align: center;
  color: gray;
  margin: 20px;
}
.compare {
  text-align: center;
  margin-top: 40px;
}
.detail-body {
  font-size: x-small;
}
.detail-body tr th {
  width: 90px;
  padding: 3px;
}
.detail-body tr td {
  padding: 3px;
  text-align: center;
}
.buttonRight{
  margin-right: 10px;
}
.btn{
  padding: 6px 9px!important;
}
</style>
<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.alarm") }}</h4>
            </div>
            <div class="box-body">
              <div class="form-group">
                <div class="row">
                  <div class="col-xs-3">
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-clock-o"></i>
                      </div>
                      <input type="text" class="form-control pull-right" id="timerange">
                    </div>
                  </div>
                  <div class="col-xs-2">
                    <select v-model="targetTasks" @change="changeTasks" v-select2="tastSelectOption" multiple="multiple" class="form-control select2" data-placeholder="Select Devices" style="width: 100%;">
                      <option v-for="item of tasks" :key="item.task_id" :value="item">{{ item.extra_info.task_name }}</option>
                    </select>
                  </div>
                  <!-- <div class="col-xs-2">
                    <select v-model="targetLibraries" @change="changeLibraries" v-select2="tastSelectOption" multiple="multiple" class="form-control select2" data-placeholder="Select Libraries" style="width: 100%;">
                      <option v-for="item of libraries" :key="item.id" :value="item">{{ item.name }}</option>
                    </select>
                  </div> -->
                  <div class="col-xs-2">
                    <select v-model="targetOrders" class="form-control select2" style="width: 100%;">
                      <option v-for="item of orders" :key="item.key" :value="item.key">{{ item.value }}</option>
                    </select>
                  </div>
                  <div class="col-xs-3">
                    <input type="text" class="form-control" v-model="targetSearchs" placeholder="Input Keyword：検知対象/Card id/年齢/部署">
                  </div>
                  <div class="col-xs-2">
                    <select v-model="targetGenders" class="form-control select2" style="width: 100%;">
                      <option v-for="item of genders" :key="item.key" :value="item.key">{{ item.value }}</option>
                    </select>
                  </div>
                </div>
                <div class="row" style="margin-top:10px;">
                  <div class="col-xs-3">
                    <input type="text" class="form-control" v-model="targetUsers" placeholder="Input User Id:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx">
                  </div>
                  <button class="btn btn-primary ctl-button buttonRight" @click="search" title="Search"><i class="fa fa-search"></i></button>
                  <bootstrap-toggle v-model="popup" :options="{ on: '画像あり', off: '画像なし', width: 90 }" :disabled="false"/>
                  <button class="btn btn-primary ctl-button" @click="exportData(true)" v-if="user.admin">{{ $t("common.export") }}</button>
                  <button class="btn btn-primary ctl-button" @click="exportData(false)" v-if="user.admin">{{ $t("common.exportAll") }}</button>
                </div>
              </div>

              <table id="alarm" class="table table-bordered table-striped" width="100%">
                <thead>
                <tr>
                  <th class="text-center">
                    <button class="checkall" @click="checkAll">
                      <i class="fa fa-square-o" v-if="selected===0"></i>
                      <i class="fa fa-minus-square-o" v-if="selected===1"></i>
                      <i class="fa fa-check-square-o" v-if="selected===2"></i>
                    </button>
                  </th>
                  <th>{{ $t("alarm.time") }}</th>
                  <th>{{ $t("alarm.taskId") }}</th>
                  <th>{{ $t("alarm.task") }}</th>
                  <th>{{ $t("alarm.libraryId") }}</th>
                  <th>{{ $t("alarm.library") }}</th>
                  <th>{{ $t("alarm.object") }}</th>
                  <th>{{ $t("alarm.image") }}</th>
                  <th>{{ $t("alarm.card_id") }}</th>
                  <th>{{ $t("alarm.age") }}</th>
                  <th>{{ $t("alarm.gender") }}</th>
                  <th>{{ $t("alarm.department") }}</th>
                  <th>{{ $t("alarm.score") }}</th>
                  <th>{{ $t("alarm.user") }}</th>
                  <th>{{ $t("alarm.attributes") }}</th>
                  <th>{{ $t("alarm.respirator") }}</th>
                  <th>{{ $t("alarm.expression") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>

          <pageModal :show.sync="showModal" :footer="false" :modalclass="'modal-lg'">
            <div slot="header">
              {{ $t("common.detail") }}
            </div>
            <div slot="body" class="detail-body">
              <div class="col-xs-5">
                <div class="portrait">
                  <img height="150px" width="150px" v-auth-image="showObject[4]">
                  <h6>{{ $t("alarm.capture") }}</h6>
                </div>
                <div class="table-responsive" v-if="showObject[11]">
                  <table class="table">
                    <tbody>
                      <tr>
                        <th> {{ $t("alarm.task") }}: </th>
                        <td> {{ showObject[3]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.object") }}: </th>
                        <td> {{ showObject[2]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.v_age") }}: </th>
                        <td> {{ showObject[14].age}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.v_gender") }}: </th>
                        <td> {{ showObject[14].gender}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.respirator") }}: </th>
                        <td> {{ showObject[15]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.expression") }}: </th>
                        <td> {{ showObject[16]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.temperature") }}: </th>
                        <td> {{ showObject[19]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.card_info") }}: </th>
                        <td> - </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.time") }}: </th>
                        <td> {{ showObject[1]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.receive_time") }}: </th>
                        <td> {{ showObject[17]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.upload_time") }}: </th>
                        <td> {{ showObject[18]}}</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div class="col-xs-2 compare">
                <hr>
                <strong> {{ $t("alarm.score") }}: </strong><br><br>
                <span class="badge bg-red">{{ showObject[12] }}%</span>
                <hr>
              </div>
              <div class="col-xs-5" v-if="showObject[13]">
                <div class="portrait">
                  <img height="150px" width="150px" v-auth-image="showObject[13].image.url">
                  <h6>{{ $t("alarm.master") }}</h6>
                </div>
                <div class="table-responsive">
                  <table class="table">
                    <tbody>
                      <tr>
                        <th> {{ $t("user.name") }}: </th>
                        <td> {{ showObject[13].name}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("menu.library") }}: </th>
                        <td> {{ showObject[5]}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.gender") }}: </th>
                        <td> {{ showObject[13].gender}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.age") }}: </th>
                        <td> {{ showObject[13].age}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.cardId") }}: </th>
                        <td> {{ showObject[13].card_id}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.address") }}: </th>
                        <td> {{ showObject[13].address}} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.create_time") }}: </th>
                        <td> {{ showObject[13].create_time }} </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </pageModal>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>

<script>
import jsZip from 'jszip';
import FileSaver from 'file-saver';
import * as moment from 'moment';
import api from '../api/api';
import BootstrapToggle from 'vue-bootstrap-toggle';

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
    BootstrapToggle
  },
  data() {
    return {
      user: this.$root.userData,
      diff: this.$root.diffTime,
      selected: 0,
      tasks: [],
      targetTasks: [],
      targetOrders:'DESC',
      targetUsers:'',
      targetSearchs:'',
      targetGenders:'',
      libraries: [],
      //targetLibraries: [],
      dataTable: null,
      timePicker: null,
      showModal: false,
      showObject: [],
      tastSelectOption: {
        allowClear: true,
        maximumSelectionLength: 4,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
      popup:false,
      orders:[{key:'ASC',value:'検知時間昇順'},{key:'DESC',value:'検知時間降順'}],
      genders:[{key:'',value:'選んでください'},{key:'SECRET',value:'SECRET'},{key:'MALE',value:'MALE'},{key:'FEMALE',value:'FEMALE'}],
      searchTasks:[]
    };
  },
  methods: {
    checkAll() {
      let all = this.dataTable.rows({search: 'applied'}).count();
      let selectedRows = this.dataTable.rows({search: 'applied', selected: true}).count();

      if (selectedRows < all) {
        this.dataTable.rows().deselect();
        this.dataTable.rows({search: 'applied'}).select();
        this.selected = 2;
      } else {
        this.dataTable.rows().deselect();
        this.selected = 0;
      }
    },
    search() {
      this.dataTable.ajax.reload();
    },
    changeTasks() {
      let vm = this;
      vm.searchTasks = [];
      if (vm.targetTasks.length > 0) {
        vm.targetTasks.forEach(element => {
          vm.searchTasks.push(element.task_id);
        })
      }
    },
    // changeLibraries() {
    //   let vm = this;
    //   // let searchTaskRegex = '';
    //   // if (vm.targetTasks.length > 0) {
    //   //   searchTaskRegex += '(';
    //   //   vm.targetTasks.forEach((element, index) => {
    //   //     searchTaskRegex += element.task_id;
    //   //     if (index < (vm.targetTasks.length - 1)) {
    //   //       searchTaskRegex += '|';
    //   //     }
    //   //   })
    //   //   searchTaskRegex += ')';
    //   // }
    //   let searchLibraryRegex = '';
    //   if (vm.targetLibraries.length > 0) {
    //     searchLibraryRegex += '(';
    //     vm.targetLibraries.forEach((element, index) => {
    //       searchLibraryRegex += element.id;
    //       if (index < (vm.targetLibraries.length - 1)) {
    //         searchLibraryRegex += '|';
    //       }
    //     })
    //     searchLibraryRegex += ')';
    //   }
    //   this.dataTable.rows().deselect();
    //   vm.dataTable
    //     //.columns(5).search(searchTaskRegex, true, false)
    //     .columns(7).search(searchLibraryRegex, true, false)
    //     .draw();
    // },
    view(rowData) {
      this.showObject = rowData;
      this.showModal = true;
    },
    listData(res){
      let vm = this;
      let result = res.data;
          let records = {draw: 1, data: []};
          
          if (result.page_request.total >= 0) {
            records.recordsTotal = result.page_request.total;
            records.recordsFiltered = result.page_request.total;

            for (let i = 0; i < result.results.length; i++) {
              let element = result.results[i];
              
              if (!element.capture_result.face.most_similar_user) {
                continue;
              }
              
              let curTask = vm.tasks.filter(ele => { if (ele.task_id === element.task_id) return true; });
              if (curTask.length === 0 || element.capture_result.face.score < curTask[0].task.parameter.face.min_score) {
                continue;
              }

              let libraryName = element.capture_result.face.db_id;
              let curLibrary = vm.libraries.filter(ele => { if (ele.id === element.capture_result.face.db_id) return true; });
              if (curLibrary.length > 0) {
                libraryName = curLibrary[0].name;
              }

              element.capture_result.face.most_similar_user.create_time = moment(element.capture_result.face.most_similar_user.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss');
              records.data.push([
                '', 
                moment(element.capture_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                element.task_id,
                curTask[0].extra_info.task_name,
                element.capture_result.face.db_id,
                libraryName,
                element.capture_result.face.most_similar_user.name,
                element.capture_result.face.portrait.url,
                element.capture_result.face.most_similar_user.card_id,
                element.capture_result.face.most_similar_user.age,
                element.capture_result.face.most_similar_user.gender,
                element.capture_result.face.most_similar_user.address,
                Math.round(Number(element.capture_result.face.score)*10000)/100,
                element.capture_result.face.most_similar_user,
                Object.keys(element.capture_result.face.attributes).length > 0 ? element.capture_result.face.attributes : {'age': '-', 'gender': '-'},
                element.capture_result.face.attributes.respirator === 'color_type_none' ? 'マスクなし':'マスクあり',
                element.capture_result.face.attributes.expression ? element.capture_result.face.attributes.expression : '-',
                moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                element.extra_info.zk_temp != undefined ? element.extra_info.zk_temp : '-',
              ]);
            }
          }
        return records;
    },
    async exportData(selected) {
      let vm  = this;
      let selectedRows;
      this.$emit('loading', true);
      if (selected) {
        selectedRows = this.dataTable.rows({search: 'applied', selected: selected});
        vm.baseExport(selectedRows.data(),selected);
      } else {
        let param = 'time_range.start='+new Date(vm.timePicker.data('daterangepicker').startDate.toDate() - vm.diff * 1000).toISOString()
                    +'&time_range.end='+new Date(vm.timePicker.data('daterangepicker').endDate.toDate() - vm.diff * 1000).toISOString()
        for(var i=0;i<vm.searchTasks.length;i++){
          param += '&task_id='+vm.searchTasks[i];
        }

        param = param + '&order='+vm.targetOrders+ '&user_id='+vm.targetUsers+ '&search='+vm.targetSearchs
        if(vm.targetGenders != ''){
          param = param + '&gender='+vm.targetGenders;
        }

        api.listCaptureResults(encodeURI(encodeURI(param))).then(res => {
          selectedRows = vm.listData(res);
          vm.baseExport(selectedRows.data,selected);
        }).catch(() => {
          this.$toastr.e('message.common_zipFile_result');
        });
      }
    },
    async baseExport(selectedRows,selected) {
      if (selectedRows.length === 0) {
        this.$toastr.i(this.$i18n.t(selected ? 'message.common_no_selected' : 'message.common_empty_result'));
        this.$emit('loading', false);
      } else {
        let rows = [];
        this.$emit('loading', true);
        let zipFile = new jsZip();
        let imgFolder;
        if(this.popup){
          imgFolder = zipFile.folder("images");
        }
        rows.push([
          this.$i18n.t("common.index"),
          this.$i18n.t("alarm.time"),
          this.$i18n.t("alarm.task"),
          this.$i18n.t("alarm.library"),
          this.$i18n.t("alarm.object"),
          this.$i18n.t("alarm.image"),
          this.$i18n.t("alarm.card_id"),
          this.$i18n.t("alarm.age"),
          this.$i18n.t("alarm.gender"),
          this.$i18n.t("user.address"),
          this.$i18n.t('capture.respirator'),
          this.$i18n.t('capture.expression'),
          this.$i18n.t("alarm.libraryId"),
          this.$i18n.t("alarm.userId")
        ]);
        let items = selectedRows
        for (let index = 0; index < items.length; index++) {
          let item = items[index];
          let imgData;
          let imgName = index + '_' + item[6] + '.jpg';
          if(this.popup){
            try {
              imgData = await api.downloadObject(item[7].substring(item[7].lastIndexOf('/') + 1));
            } catch {
              imgData = item[7];
            }
            imgData = imgData.substring(imgData.indexOf(",") + 1);
            imgFolder.file(imgName, imgData, {base64: true});
          }
          rows.push([index, item[1], item[3], item[5], item[6], imgName, item[8], item[9], item[10],item[11], item[15], item[16], item[4], item[13].user_id]);
        }
        let csvContent = '\ufeff' + rows.map(e => e.join(',')).join('\n');
        zipFile.file('records.csv', csvContent);
        zipFile.generateAsync({type:"blob"}).then(content => {
          FileSaver.saveAs(content, 'AlarmRecords_' + moment(new Date(), 'YYYYMMDDHHmmss') + '.zip');
        }).finally(() => {
          this.$emit('loading', false);
        });
      }
    }
  },
  created: function() {
    let vm = this;
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    vm.$emit('loading', true);
  },
  mounted: async function() {
    let vm = this;

    vm.timePicker = $('#timerange').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      startDate: moment().subtract(1, 'hours'),
      endDate: moment(),
      locale: { format: 'MM/DD HH:mm:ss' }
    });

    // Get All tasks and libraries
    let res, acsTasks, mpsTasks;
    try {
      res = await api.taskListAcs({'page_request.offset': 0, 'page_request.limit': 100});
      acsTasks = res.data.tasks;
    } catch (err) {
      acsTasks = [];
    }

    try {
      res = await api.taskListMps({'page_request.offset': 0, 'page_request.limit': 100});
      mpsTasks = res.data.tasks;
    } catch (err) {
      mpsTasks = [];
    }
    vm.tasks = mpsTasks.concat(acsTasks);

    try {
      res = await api.dBList();
      vm.libraries = res.data.databases;
    } catch (err) {
      vm.libraries = [];
    }

    vm.dataTable = $('#alarm').DataTable({
      paging: true,
      pageLength: 100,
      lengthChange: false,
      searching: true,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [[1, 'desc']],
      sDom: 'ltipr', 
      columnDefs: [
        {
          orderable: false,
          targets: [0, 3, -1,-2,-3]
        },
        {
          targets: 0,
          className: 'select-checkbox'
        },
        {
          targets: 4,
          data: "img",
          render: function() {
            return `<img height="20px" width="20px"/>`;
          }
        },
        {
          targets: -1,
          data: null,
          render: function() {
            return '<a class="btn btn-info btn-xs detail"> <i class="fa fa-eye"></i>&nbsp;' + vm.$i18n.t('common.detail') + '</a>';
          },
        },
        {
          targets: [-4, -5, -6, -14, -16],
          visible: false
        }
      ],
      select: {
        style: 'multi',
        selector: 'td:not(:last-child)'
      },
      initComplete: function() {
        // if (vm.targetTasks.length > 0 || vm.targetLibraries.length > 0) {
        //   vm.changeTasksOrLibraries();
        // }
      },
      fnRowCallback: function(nRow, aData) {
        api.downloadObject(aData[7]).then(res => {
          $('td:eq(5)', nRow).html(`<img height="20px" width="20px" src="${res}"/>`);
        });
      },
      ajax: function (data, callback) {
        vm.$emit('loading', true);
        let param = 'time_range.start='+new Date(vm.timePicker.data('daterangepicker').startDate.toDate() - vm.diff * 1000).toISOString()
                    +'&time_range.end='+new Date(vm.timePicker.data('daterangepicker').endDate.toDate() - vm.diff * 1000).toISOString()
                    +'&page_request.offset='+data.start+'&page_request.limit='+data.length;
        for(var i=0;i<vm.searchTasks.length;i++){
          param += '&task_id='+vm.searchTasks[i];
        }

        param = param + '&order='+vm.targetOrders+ '&user_id='+vm.targetUsers+ '&search='+vm.targetSearchs
        if(vm.targetGenders != ''){
          param = param + '&gender='+vm.targetGenders;
        }

        api.listCaptureResults(encodeURI(encodeURI(param))).then(res => {
          let result = res.data;
          let records = {draw: data.draw, data: []};
          
          if (result.page_request.total >= 0) {
            records.recordsTotal = result.page_request.total;
            records.recordsFiltered = result.page_request.total;

            for (let i = 0; i < result.results.length; i++) {
              let element = result.results[i];
              
              if (!element.capture_result.face.most_similar_user) {
                continue;
              }
              
              let curTask = vm.tasks.filter(ele => { if (ele.task_id === element.task_id) return true; });
              if (curTask.length === 0 || element.capture_result.face.score < curTask[0].task.parameter.face.min_score) {
                continue;
              }

              let libraryName = element.capture_result.face.db_id;
              let curLibrary = vm.libraries.filter(ele => { if (ele.id === element.capture_result.face.db_id) return true; });
              if (curLibrary.length > 0) {
                libraryName = curLibrary[0].name;
              }

              element.capture_result.face.most_similar_user.create_time = moment(element.capture_result.face.most_similar_user.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss');
              records.data.push([
                '', 
                moment(element.capture_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                element.task_id,
                curTask[0].extra_info.task_name,
                element.capture_result.face.db_id,
                libraryName,
                element.capture_result.face.most_similar_user.name,
                element.capture_result.face.portrait.url,
                element.capture_result.face.most_similar_user.card_id,
                element.capture_result.face.most_similar_user.age,
                element.capture_result.face.most_similar_user.gender,
                element.capture_result.face.most_similar_user.address,
                Math.round(Number(element.capture_result.face.score)*10000)/100,
                element.capture_result.face.most_similar_user,
                Object.keys(element.capture_result.face.attributes).length > 0 ? element.capture_result.face.attributes : {'age': '-', 'gender': '-'},
                element.capture_result.face.attributes.respirator === 'color_type_none' ? 'マスクなし':'マスクあり',
                element.capture_result.face.attributes.expression ? element.capture_result.face.attributes.expression : '-',
                moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                moment(element.received_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                element.extra_info.zk_temp != undefined ? element.extra_info.zk_temp : '-',
              ]);
            }
          }
          callback(records);
        }).catch(() => {
          callback({draw: 1, data: []});
        }).finally(() => {
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTable.on('select deselect draw', function() {
      let all = vm.dataTable.rows({search: 'applied'}).count();
      let selectedRows = vm.dataTable.rows({search: 'applied', selected: true}).count();
      if (selectedRows === 0) {
        vm.selected = 0;
      } else if (selectedRows < all) {
        vm.selected = 1;
      } else {
        vm.selected = 2;
      }
    });
    vm.dataTable.on('click', '.detail', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.view(rowData);
    });
  }
};
</script>
