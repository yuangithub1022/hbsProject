<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.setting {
  vertical-align: middle;
  margin-bottom: 15px;
}
.http-title {
  margin-top: 5px;
}
.info-text {
  color: gray;
  font-size: smaller;
}
#library {
  margin-bottom: 15px;
}
</style>
<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.system") }}({{titleVersion}})</h4>
            </div>
            <div class="box-body">
              <table id="library" class="table table-bordered" width="100%">
                <thead>
                  <tr>
                    <th width="100px">{{ $t("common.no") }}</th>
                    <th width="300px">{{ $t("system.serviceName") }}</th>
                    <th>{{ $t("system.serviceVersion") }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>AccessControlService</td>
                    <td><span class="info-text">{{ acsVersion }}</span></td>
                  </tr>
                  <tr>
                    <td>2</td>
                    <td>FeatureProcessService</td>
                    <td><span class="info-text">{{ fpsVersion }}</span></td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>OperationMaintenanceService</td>
                    <td><span class="info-text">{{ omsVersion }}</span></td>
                  </tr>
                  <tr>
                    <td>4</td>
                    <td>StaticFeatureDatabaseService</td>
                    <td><span class="info-text">{{ afdVersion }}</span></td>
                  </tr>
                  <tr>
                    <td>5</td>
                    <td>MediaProcessService</td>
                    <td><span class="info-text">{{ mpsVersion }}</span></td>
                  </tr>
                </tbody>
              </table>
              
              <div class="row">
                <div class="setting col-xs-6">
                  <div class="row">
                    <div class="col-xs-12" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.http") }} <span class="info-text">(Captures and Alarms will be posted to Http Server.)</span></label>
                      <button class="btn btn-primary pull-right" v-if="!editable" @click="editable=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="editable" @click="updateHttpServer">{{ $t("common.update") }}</button>
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" rows="1" placeholder="" :disabled="!editable" v-model="httpServer"></textarea>
                    <span class="info-text">Sample: http://172.31.254.100:5000/atlas/backend/upload </span>
                  </div>
                </div>

                <div class="setting col-xs-6">
                  <div class="row">
                    <div class="col-xs-12" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.db") }}</label>
                      <button class="btn btn-primary pull-right" v-if="!editableDb" @click="editableDb=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="editableDb" @click="updateDbServer">{{ $t("common.update") }}</button>
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" rows="1" placeholder="" :disabled="!editableDb" v-model="dbServer"></textarea>
                    <span class="info-text">Sample: http://172.31.254.100:5000/dbserver </span>
                  </div>
                </div>
              </div>

              <div class="row">
                <div class="setting col-xs-6">
                  <div class="row">
                    <div class="col-xs-12" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.error") }} </label>
                      <button class="btn btn-primary pull-right" v-if="!errorEditable" @click="errorEditable=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="errorEditable" @click="updateTaskError">{{ $t("common.update") }}</button>
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" rows="1" placeholder="" :disabled="!errorEditable" v-model="taskError"></textarea>
                    <span class="info-text">Sample: http://172.31.254.100:5000/atlas/backend/uploadError </span>
                  </div>
                </div>

                <div class="setting col-xs-6">
                  <div class="row">
                    <div class="col-xs-12" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.errorDb") }}</label>
                      <button class="btn btn-primary pull-right" v-if="!errorEditableDB" @click="errorEditableDB=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="errorEditableDB" @click="updateErrorDBServer">{{ $t("common.update") }}</button>
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" rows="1" placeholder="" :disabled="!errorEditableDB" v-model="errorDBServer"></textarea>
                    <span class="info-text">Sample: http://172.31.254.100:5000/errordbserver </span>
                  </div>
                </div>
              </div>
              <div class="row" style="padding:15px;">
                <textarea class="form-control" rows="5" placeholder="" v-model="errorMessage"></textarea>
              </div>
              <div class="row" style="padding:15px;">
                <button class="btn btn-danger pull-left" @click="clearErrorMsg">{{ $t("common.clearErrorMsg") }}</button><br/>
              </div>
              <div class="row">
                <div class="col-xs-4">
                  <button class="btn btn-danger pull-left" @click="clear">{{ $t("common.clear") }}</button>
                </div>
                <div class="col-xs-8">
                  <input type='file' ref='file' @change="loadTextFromFile" accept=".json" style="display:none" />
                  <button class="btn btn-primary pull-left" style="margin-right:10px"  @click="configImport">{{ $t("common.configImport") }}</button>
                  <button class="btn btn-primary pull-left" @click="configExport">{{ $t("common.configExport") }}</button>
                </div>
              </div> 
            </div>
          </div>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>
<script>
import axios from 'axios';
import api from '../api/api'; 

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      acsVersion: '',
      fpsVersion: '',
      omsVersion: '',
      afdVersion: '',
      mpsVersion: '',
      httpServer: '',
      editable: false,
      dbServer: '',
      editableDb: false,
      titleVersion:'',
      taskError:'',
      errorDBServer:'',
      errorEditable:false,
      errorEditableDB: false,
      errorMessage:''
    };
  },
  methods: {
    loadTextFromFile(e){
      let vm = this;
      try{
        if(e.target.files[0]!==null){
          let reader = new FileReader()
          reader.readAsText(e.target.files[0], 'UTF-8')
          reader.onload = function (e) {
            let fileContent = e.target.result
            let configInfo = JSON.parse(fileContent);
            api.omsGetSystemConfig(configInfo).then(() => {
              vm.$toastr.s(vm.$i18n.t('message.config_update_success'));
            }).catch(err => {
              vm.$toastr.e(vm.$i18n.t('message.config_update_failure') + '<br>' + err.response.data.message);
            });
          }
        }else{
          vm.$toastr.e(vm.$i18n.t('message.no_select_file'));
        }
      }catch(e){
        vm.$toastr.e(vm.$i18n.t('message.read_file_failure'));
      }
    },
    download (data) {
      if (!data) {
          return
      }
      let url = window.URL.createObjectURL(new Blob([data]))
      let link = document.createElement('a')
      link.style.display = 'none'
      link.href = url
      link.setAttribute('download', `System_Config_Info.json`)
      document.body.appendChild(link)
      link.click()
    },
    configImport(){
      let vm = this;
      vm.$refs.file.dispatchEvent(new MouseEvent('click'))
    },
    configExport(){
      let vm = this;
      api.omsGetSystemConfig().then(res => {
        if (res.data) {
          this.download(JSON.stringify(res.data))
        }
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.config_export_failure') + '<br>' + err.response.data.message);
      });
    },
    updateErrorDBServer(){
      let vm = this;
      axios.post('/atlas/backend/errordbserver', {server: vm.errorDBServer}).then(res => {
        if (res.data.code === 0) {
          vm.errorEditableDB = false;
          vm.$toastr.s(vm.$i18n.t('message.errordbserver_update_success'));
        } else {
          vm.$toastr.e(vm.$i18n.t('message.errordbserver_update_failure'));
        }
      }).catch(() => {
        vm.$toastr.e(vm.$i18n.t('message.errordbserver_update_failure'));
      });
    },
    updateTaskError(){
      let vm = this;
      if (!vm.taskError) {
        vm.$toastr.e(vm.$i18n.t('message.task_errorServer_empty'));
        return;
      }
      let param = {
        url:vm.taskError.trim()
      }
      api.omsSetHTTPServer(param).then(() => {
        vm.errorEditable = false;
        vm.$toastr.s(vm.$i18n.t('message.task_errorServer_success'));
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.task_errorServer_failure') + '<br>' + err.response.data.message);
      });
    },
    updateHttpServer() {
      let vm = this;
      let newServer = vm.httpServer.trim();
      if (!newServer) {
        vm.$toastr.e(vm.$i18n.t('message.http_update_empty'));
        return;
      }
      api.setHttpServer({url: newServer}).then(() => {
        vm.editable = false;
        vm.httpServer = newServer;
        vm.$toastr.s(vm.$i18n.t('message.http_update_success'));
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.http_update_failure') + '<br>' + err.response.data.message);
      });
    },
    updateDbServer() {
      let vm = this;
      let newServer = vm.dbServer.trim();
      
      axios.post('/atlas/backend/dbserver', {server: newServer}).then(res => {
        if (res.data.code === 0) {
          vm.editableDb = false;
          vm.dbServer = newServer;
          vm.$toastr.s(vm.$i18n.t('message.dbserver_update_success'));
        } else {
          vm.$toastr.e(vm.$i18n.t('message.dbserver_update_failure'));
        }
      }).catch(() => {
        vm.$toastr.e(vm.$i18n.t('message.dbserver_update_failure'));
      });
    },
    clearErrorMsg(){
      let vm = this;
      axios.get('/atlas/backend/clearerrormessage').then(res => {
        if (res.data.code === 0) {
          vm.$toastr.s(vm.$i18n.t('message.errormessage_clear_success'));
          vm.errorMessage = '';
        } 
      }).catch(() => {
        vm.$toastr.e(vm.$i18n.t('errormessage_clear_failure'));
      });
    },
    clear() {
      let vm = this;
      if (confirm("Confirm Delete All Records?")) {
        api.deleteAllRecords().then(() => {
          vm.$toastr.s(vm.$i18n.t('message.delete_all_success'));
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.delete_all_failure') + '<br>' + err.response.data.message);
        });
      }
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    // Get version info and http server url
    let vm = this;
    api.acsGetVersion().then(res => {
      if (res.data) {
        vm.acsVersion = res.data.version;
      }
    }).catch(err => {
      vm.acsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.fpsGetVersion().then(res => {
      if (res.data) {
        vm.fpsVersion = res.data.version;
      }
    }).catch(err => {
      vm.fpsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.omsGetVersion().then(res => {
      if (res.data) {
        vm.omsVersion = res.data.version;
      }
    }).catch(err => {
      vm.omsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.afdGetVersion().then(res => {
      if (res.data) {
        vm.afdVersion = res.data.version;
      }
    }).catch(err => {
      vm.afdVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.mpsGetVersion().then(res => {
      if (res.data) {
        vm.mpsVersion = res.data.version;
      }
    }).catch(err => {
      vm.mpsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.getHttpServer().then(res => {
      if (res.data) {
        vm.httpServer = res.data.url;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.omsGetSystemInfo().then(res => {
      if (res.data) {
        vm.titleVersion = res.data.version;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.omsGetHTTPServer().then(res => {
      if (res.data) {
        vm.taskError = res.data.url;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.task_errorServer_failure') + '<br>' + err.response.data.message);
    });
    axios.get('/atlas/backend/dbserver').then(res => {
      if (res.data.server) {
        vm.dbServer = res.data.server;
      } else {
        vm.dbServer = '';
      }
    });
    axios.get('/atlas/backend/errordbserver').then(res => {
      if (res.data.server) {
        vm.errorDBServer = res.data.server;
      } else {
        vm.errorDBServer = '';
      }
    });
    axios.get('/atlas/backend/geterrormessage').then(res => {
      if (res.data.errorMsg) {
        vm.errorMessage = res.data.errorMsg;
      } else {
        vm.errorMessage = '';
      }
    });
  }
};
</script>
