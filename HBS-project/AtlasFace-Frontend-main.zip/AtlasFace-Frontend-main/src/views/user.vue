<style scoped>
.box-body {
  min-height: calc(100vh - 163px);
}
.breadcrumb {
  background: transparent;
  margin-top: 0;
  margin-bottom: 0;
  font-size: 12px;
  padding: 7px 5px;
  position: absolute;
  top: 15px;
  right: 10px;
  border-radius: 2px;
}
.ctl-button {
  margin-right: 10px;
}
.checkall {
  border: none;
  background: transparent;
  font-size: 16px;
}
.portrait {
  text-align: center;
  margin: 20px;
}
.modal-form {
  margin-top: 15px;
}
body {
  font-family: sans-serif;
  background-color: #eeeeee;
}
.file-upload {
  background-color: #ffffff;
  width: 100%;
  height: 250px;
  margin: 0 auto;
}
.file-upload-content {
  height: 100%;
  vertical-align: middle;
}
.file-upload-input {
  position: absolute;
  margin: 0;
  padding: 0;
  width: 100%;
  height: 100%; 
  outline: none;
  opacity: 0;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  cursor: pointer;
  z-index: 999;
}
.image-upload-wrap {
  height: 100%;
  position: relative;
  margin-top: 20px;
  vertical-align: middle;
  border: 4px dashed #3c8dbc;
}
.image-dropping {
  background-color: #3c8dbc;
  border: 4px dashed #ffffff;
}
.drag-text {
  margin-top: 80px;
  text-align: center;
  color: #3c8dbc;
  font-size: 50px;
}
.portrait {
  max-height: 100%;
  max-width: 100%;
  width: auto;
  height: auto;
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  margin: auto;
}
.wizard-info {
  color: gray;
  margin-bottom: 10px;
}
.noPadding{
  padding: 0;
}
</style>

<template>
  <div>
    <div class="wrapper">
      <pageHeader></pageHeader>
      <pageAside></pageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.user") }} <span v-if="library">({{ library.name }})</span></h4>
              <ol class="breadcrumb">
                <li><router-link :to="{path: '/library'}">{{ $t("menu.library") }}</router-link></li>
                <li class="active">{{ $t("menu.user") }}</li>
              </ol>
            </div>
            <div class="box-body">
              <div class="form-group">
                <div class="row">
                  <div class="col-xs-12">
                    <div class="row">
                      <div class="col-xs-4">
                        <div class="input-group">
                          <div class="input-group-addon">
                            <i class="fa fa-clock-o"></i>
                          </div>
                          <input type="text" class="form-control pull-right" id="timerange">
                        </div>
                      </div>
                      <div class="col-xs-3">
                        <input type="text" class="form-control" v-model="targetSearchs" placeholder="Input Keyword：名前/Card id/年齢/部署">
                      </div>
                      <div class="col-xs-4">
                        <select v-model="targetGenders" class="form-control select2" style="width: 100%;">
                          <option v-for="item of genders" :key="item.key" :value="item.key">{{ item.value }}</option>
                        </select>
                      </div>
                    </div>
                    <div class="row" style="margin-top:10px;">
                      <div class="col-xs-4">
                        <select v-model="targetOrderKeys" class="form-control select2" style="width: 100%;">
                          <option v-for="item of orderKeys" :key="item.key" :value="item.key">{{ item.value }}</option>
                        </select>
                      </div>
                      <div class="col-xs-3">
                        <select v-model="targetOrders" class="form-control select2" style="width: 100%;">
                          <option v-for="item of orders" :key="item.key" :value="item.key">{{ item.value }}</option>
                        </select>
                      </div>
                      <div class="col-xs-5">
                        <button class="btn btn-primary ctl-button" @click="selectResult"><i class="fa fa-search"></i></button>
                        <button class="btn btn-primary ctl-button" @click="exportSelected" v-if="user.admin">{{ $t("common.export") }}</button>
                        <button class="btn btn-primary ctl-button" @click="exportAll" v-if="user.admin">{{ $t("common.exportAll") }}</button>
                        <button class="btn btn-primary ctl-button" @click="addUser">{{ $t("common.create") }}</button>
                        <input type="file" ref="file" multiple="multiple" accept="image/jpeg" @change="openImportWizard" style="display: none">
                        <button class="btn btn-primary ctl-button" @click="$refs.file.click()">{{ $t("user.batchImport") }}</button>
                        <button class="btn btn-primary ctl-button" @click="batchDelete">{{ $t("user.batchDelete") }}</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <table id="users" class="table table-bordered table-striped" width="100%">
                <thead>
                  <tr>
                    <th class="text-center">
                      <button class="checkall" @click="checkAll">
                        <i class="fa fa-square-o" v-if="selected===0"></i>
                        <i class="fa fa-minus-square-o" v-if="selected===1"></i>
                        <i class="fa fa-check-square-o" v-if="selected===2"></i>
                      </button>
                    </th>
                    <th>{{ $t("user.id") }}</th>
                    <th>{{ $t("user.image") }}</th>
                    <th>{{ $t("user.name") }}</th>
                    <th>{{ $t("user.gender") }}</th>
                    <th>{{ $t("user.age") }}</th>
                    <th>{{ $t("user.cardId") }}</th>
                    <th>{{ $t("user.address") }}</th>
                    <th>{{ $t("user.create_time") }}</th>
                    <th>{{ $t("common.action") }}</th>
                  </tr>
                </thead>
                <tbody>
                </tbody>
              </table>
            </div>
          </div>
          <pageModal :show.sync="showModal" :footer="editable">
            <div slot="header">
              <span v-if="showObject.user_id && editable">{{ $t("common.edit") }} ({{ showObject.name }})</span>
              <span v-if="showObject.user_id && !editable">{{ $t("common.detail") }} ({{ showObject.name }})</span>
              <span v-if="!showObject.user_id">{{ $t("common.create") }} </span>
            </div>
            <div slot="body">
              <div class="row" v-if="showObject">
                <div class="col-sm-4">
                  <div class="file-upload">
                    <div class="image-upload-wrap"
                      :class="[{'image-dropping': isDrag && editable}]"
                      @dragover.prevent="isDrag=true;"
                      @dragleave.prevent="isDrag=false;">
                      <input class="file-upload-input" type='file' @change="importImage" accept="image/jpeg" :disabled="showObject.user_id"/>
                      <div class="drag-text" v-if="!showObject.image">
                        <i aria-hidden="true" class="fa fa-plus"></i>
                      </div>
                      <img class="portrait" v-auth-image="showObject.image.url" v-if="showObject.image&&showObject.image.url">
                      <img class="portrait" :src="showObject.image.data" v-if="showObject.image&&showObject.image.data">
                    </div>
                  </div>
                </div>
                <div class="col-sm-8">
                  <form class="form-horizontal">
                    <div class="modal-form">
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("user.name") }}
                        </label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" v-model="showObject.name" placeholder="Name" :disabled="!editable">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("user.gender") }}
                        </label>
                        <div class="col-sm-9">
                          <select v-model="showObject.gender" class="form-control" :disabled="!editable">
                            <option value="MALE">MALE</option>
                            <option value="FEMALE">FEMALE</option>
                          </select>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("user.age") }}
                        </label>
                        <div class="col-sm-9">
                          <input type="number" class="form-control" v-model="showObject.age" placeholder="Age" :disabled="!editable">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("user.cardId") }}
                        </label>
                        <div class="col-sm-9">
                          <input type="text" class="form-control" v-model="showObject.card_id" placeholder="ID" :disabled="!editable">
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="col-sm-3 control-label">
                          {{ $t("user.address") }}
                        </label>
                        <div class="col-sm-9">
                          <textarea class="form-control" rows="2" v-model="showObject.address" placeholder="Department" :disabled="!editable"></textarea>
                        </div>
                      </div>
                      <div class="form-group" v-if="showObject.user_id && !editable">
                        <label class="col-xs-3 control-label">
                          {{ $t("user.create_time") }}
                        </label>
                        <div class="col-xs-9">
                          <input type="text" class="form-control" :value="showObject.create_time" disabled>
                        </div>
                      </div>
                    </div>
                  </form>
                </div>
              </div>
            </div>
            <div slot="footer" v-if="editable">
              <button class="btn btn-default pull-left" @click="showModal=false;">{{ $t("common.cancel") }}</button>
              <button class="btn btn-primary pull-right" @click="updateUser">{{ $t("common.ok") }}</button>
            </div>
          </pageModal>
          <pageModal :show.sync="showWizard" :footer="true" :modalclass="'modal-lg'">
            <div slot="header">
              <span>{{ $t("user.wizard") }}</span>
            </div>
            <div slot="body">
              <div class="wizard-info">New users will be imported. Total: {{ userImportList.length }}</div>
              <table id="import" class="table table-bordered table-striped" width="100%">
                <thead>
                  <tr>
                    <th style="width: 90px">{{ $t("user.image") }}</th>
                    <th style="width: 120px">{{ $t("user.name") }}</th>
                    <th style="width: 100px">{{ $t("user.gender") }}</th>
                    <th style="width: 80px">{{ $t("user.age") }}</th>
                    <th style="width: 100px">{{ $t("user.cardId") }}</th>
                    <th>{{ $t("user.address") }}</th>
                    <th style="width: 50px">{{ $t("common.action") }}</th>
                  </tr>
                </thead>
                <tbody>
                  <tr v-for="item in userImportList" :key="item.no">
                    <td><img height="34px" :src="item.image.data"></td>
                    <td><input type="text" class="form-control" v-model="item.name"></td>
                    <td>
                      <select v-model="item.gender" class="form-control">
                        <option value="MALE">MALE</option>
                        <option value="FEMALE">FEMALE</option>
                      </select>
                    </td>
                    <td><input type="number" class="form-control" v-model="item.age"></td>
                    <td><input type="text" class="form-control" v-model="item.card_id"></td>
                    <td><input type="text" class="form-control" v-model="item.address"></td>
                    <td>
                      <button type="button" class="close" @click="removeRow(item)">
                        <span style="font-size: 34px">&times;</span>
                      </button>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
            <div slot="footer">
              <button class="btn btn-default pull-left" @click="showWizard=false;">{{ $t("common.cancel") }}</button>
              <button class="btn btn-primary pull-right" @click="batchImport" :disabled="userImportList.length<1">{{ $t("common.ok") }}</button>
            </div>
          </pageModal>
        </section>
      </div>
      <!-- <pageFooter></pageFooter> -->
    </div>
  </div>
</template>
<script>
import Vue from 'vue';
import jsZip from 'jszip';
import FileSaver from 'file-saver';
import * as moment from 'moment';
import api from '../api/api'; 

export default {
  components: {
    pageHeader: () => import("../components/header.vue"),
    pageAside: () => import("../components/aside.vue"),
    pageFooter: () => import("../components/footer.vue"),
    pageModal: () => import("../components/modal.vue"),
  },
  data() {
    return {
      user: this.$root.userData,
      diff: this.$root.diffTime,
      library: null,
      libraryId: this.$route.params.id,
      showModal: false,
      showObject: {gender: 'MALE'},
      editable: false,
      selected: 0,
      isDrag: false,
      showWizard: false,
      userImportList: [],
      dataTable: null,
      timePicker: null,
      orders:[{key:'ASC',value:'昇順'},{key:'DESC',value:'降順'}],
      genders:[{key:'',value:'選んでください'},{key:'SECRET',value:'SECRET'},{key:'MALE',value:'MALE'},{key:'FEMALE',value:'FEMALE'}],
      orderKeys:[{key:'NAME',value:'名前'},{key:'AGE',value:'年齢'},{key:'CARD_ID',value:'カード番号'}],
      targetOrders:'DESC',
      targetSearchs:'',
      targetGenders:'',
      targetOrderKeys:'NAME',
    };
  },
  methods: {
    checkAll() {
      let all = this.dataTable.rows().count();
      let selectedRows = this.dataTable.rows({ selected: true }).count();

      if (selectedRows < all) {
        this.dataTable.rows().deselect();
        this.dataTable.rows().select();
        this.selected = 2;
      } else {
        this.dataTable.rows().deselect();
        this.selected = 0;
      }
    },
    selectResult(){
      let vm = this;
      vm.dataTable.ajax.reload();
    },
    async exportSelected() {
      let selectedRows = this.dataTable.rows({selected: true});
      if (selectedRows.count() === 0) {
        this.$toastr.i(this.$i18n.t('message.common_no_selected'));
      } else {
        let rows = [];
        let zipFile = new jsZip();
        let imgFolder = zipFile.folder("images");
        rows.push([
          this.$i18n.t('common.index'),
          this.$i18n.t('user.id'),
          this.$i18n.t('user.name'),
          this.$i18n.t('user.gender'),
          this.$i18n.t('user.age'),
          this.$i18n.t('user.cardId'),
          this.$i18n.t('user.address'),
          this.$i18n.t('user.image')
        ]);
        let items = selectedRows.data();
        for (let index = 0; index < items.length; index++) {
          let item = items[index];
          let imgData;
          try {
            imgData = await api.downloadObject(item[2].substring(item[2].lastIndexOf('/') + 1));
          } catch {
            imgData = item[2];
          }
          imgData = imgData.substring(imgData.indexOf(",") + 1);
          let imgName = `${item[3]}_${item[4]}_${item[5]}_${item[6]}_${item[7]}.jpg`;
          imgFolder.file(imgName, imgData, {base64: true});
          rows.push([index, item[1], item[3], item[4], item[5], item[6], item[7], imgName]);
        }
        let csvContent = '\ufeff' + rows.map(e => e.join(',')).join('\n');
        zipFile.file('users.csv', csvContent);
        zipFile.generateAsync({type:"blob"}).then(content => {
          FileSaver.saveAs(content, 'Users_' + this.library.name  + '_' + moment(new Date(), 'YYYYMMDDHHmmss') + '.zip');
        });
      }
    },
    async exportAll() {
      let vm = this;
      vm.$emit('loading', true);
      let result = await api.userListAll(vm.libraryId);
      vm.$emit('loading', false);
      if (result.length === 0) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_result'));
      } else {
        let rows = [];
        vm.$emit('loading', true);
        let zipFile = new jsZip();
        let imgFolder = zipFile.folder("images");
        rows.push([this.$i18n.t('common.index'),
          this.$i18n.t('user.id'),
          this.$i18n.t('user.name'),
          this.$i18n.t('user.gender'),
          this.$i18n.t('user.age'),
          this.$i18n.t('user.cardId'),
          this.$i18n.t('user.address'),
          this.$i18n.t('user.image')]
        );
        for (let index = 0; index < result.length; index++) {
          let element = result[index];
          let imgData;
          try {
            imgData = await api.downloadObject(element.image.url);
          } catch {
            imgData = element.image.url;
          }
          imgData = imgData.substring(imgData.indexOf(",") + 1);
          let imgName = `${element.name}_${element.gender}_${element.age}_${element.card_id}_${element.address}.jpg`;
          imgFolder.file(imgName, imgData, {base64: true});
          rows.push([index, element.user_id, element.name, element.gender, element.age, element.card_id, element.address, imgName]);
        }
        let csvContent = '\ufeff' + rows.map(e => e.join(',')).join('\n');
        zipFile.file('records.csv', csvContent);
        zipFile.generateAsync({type:"blob"}).then(content => {
          FileSaver.saveAs(content, 'Users' + '_' + vm.library.name + '_' + moment(new Date(), 'YYYYMMDDHHmmSS') + '.zip');
        }).finally(() => {
          vm.$emit('loading', false);
        });
      }
    },
    addUser() {
      this.showObject = {
        gender: 'MALE'
      };
      this.editable = true;
      this.showModal = true;
    },
    updateUser() {
      let vm = this;
      if (!vm.showObject.name || !vm.showObject.image || !vm.showObject.gender || vm.showObject.age < 0) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }
      
      if(vm.showObject.card_id === undefined){
        vm.showObject.card_id = '';
      }

      if(vm.showObject.address === undefined){
        vm.showObject.address = '';
      }

      

      vm.showObject.name  = vm.showObject.name.trim();
      vm.showObject.card_id  = vm.showObject.card_id.trim();
      vm.showObject.address  = vm.showObject.address.trim();

      if (vm.showObject.user_id) {
        let userData = JSON.parse(JSON.stringify(vm.showObject));
        delete userData.image;
        api.userUpdate({db_id: vm.libraryId, user_id: vm.showObject.user_id, user: userData}).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.user_update_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.user_update_failure') + '<br>' + err.response.data.message);
        });
      } else {
        let userData = JSON.parse(JSON.stringify(vm.showObject));
        userData.image.data = userData.image.data.substring(userData.image.data.indexOf(",") + 1);
        api.userBatchAdd({db_id: vm.libraryId, users: [userData]}).then(res => {
          vm.showModal = false;
          let arr = res.data.results;
          let flag = false;
          for(let i=0;i<arr.length;i++){
            if(arr[i].user === null){
              flag = true;
              break;
            }
          }
          if(!flag){
            vm.$toastr.s(vm.$i18n.t('message.user_create_success'));
          }else{
            vm.$toastr.e(vm.$i18n.t('message.user_createUser_failure'));
          }
            vm.dataTable.ajax.reload();
          }).catch(err => {
            vm.$toastr.e(vm.$i18n.t('message.user_create_failure') + '<br>' + err.response.data.message);
          });
      }
    },
    checkDrag(event, key, status) {
      if (status && event.dataTransfer.types == "text/plain") {
        return false;
      }
      this.isDrag = status ? key : null;
    },
    importImage(e) {
      let vm = this;
      const files = e.target.files || e.dataTransfer.files;
      const reader = new FileReader();
      reader.onload = e => {
        Vue.set(vm.showObject, 'image', {data: e.target.result});
      };
      reader.readAsDataURL(files[0]);
    },
    openImportWizard(e) {
      let vm = this;
      const files = e.target.files || e.dataTransfer.files;
      vm.userImportList = [];
      
      for (let i = 0; i < files.length; i++) {
        let file = files[i];
        const reader = new FileReader();
        reader.fileName = file.name.substring(0, file.name.lastIndexOf('.'));
        reader.onload = e => {
          let fileName = e.target.fileName;
          let fields = fileName.split('_');
          let name = fields.length > 0 ? fields[0].trim() : '';
          let gender = fields.length > 1 ? fields[1].trim().toUpperCase() : 'MALE';
          gender = ['MALE', 'FEMALE'].includes(gender) ? gender : 'MALE';
          let age = fields.length > 2 ? Number(fields[2].trim()) : 0;
          age = isNaN(age) ? 0 : age;
          let card_id = fields.length > 3 ? fields[3].trim() : '';
          let address = fields.length > 4 ? fields[4].trim() : '';
          let no = vm.userImportList.length + 1;
          vm.userImportList.push({
            no: no,
            name: name,
            gender: gender,
            age: age,
            card_id: card_id,
            address: address,
            image: {data: e.target.result}
          });
        };
        reader.readAsDataURL(file);
      }
      this.showWizard = true;
    },
    removeRow(item) {
      let index = this.userImportList.indexOf(item);
      if (index >= 0) {
        this.userImportList.splice(index, 1);
      }
    },
    batchImport() {
      let vm = this;
      if (vm.userImportList.length === 0) {
        vm.$toastr.i(vm.$i18n.t('message.common_no_selected'));
        return;
      }
      if (vm.userImportList.length > 60) {
        vm.$toastr.i(vm.$i18n.t('message.user_import_limit'));
        return;
      }
      let invalidData = vm.userImportList.filter(element => {
        if (!element.name || !element.image || !element.gender || vm.showObject.age < 0) {
          return true;
        }
      });
      if (invalidData.length > 0) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }

      vm.$emit('loading', true);
      let users = JSON.parse(JSON.stringify(vm.userImportList));
      users.forEach(element => {
        element.image.data = element.image.data.substring(element.image.data.indexOf(",") + 1);
      });
      
      api.userBatchAdd({db_id: vm.libraryId, users: users}).then(res => {
        vm.showWizard = false;
        let arr = res.data.results;
        let flag = false;
        for(let i=0;i<arr.length;i++){
          if(arr[i].user === null){
            flag = true;
            break;
          }
        }
        if(!flag){
          vm.$toastr.s(vm.$i18n.t('message.user_create_success'));
        }else{
          vm.$toastr.e(vm.$i18n.t('message.user_createUser_failure'));
        }
        vm.dataTable.ajax.reload();
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.user_create_failure') + '<br>' + err.response.data.message);
      }).finally(() => {
        vm.$emit('loading', false);
      });
    },
    async batchDelete() {
      let vm = this;
      let selectedRows = vm.dataTable.rows({selected: true});
      if (selectedRows.count() === 0) {
        vm.$toastr.i(vm.$i18n.t('message.common_no_selected'));
      } else {
        vm.$emit('loading', true);
        if (confirm("Confirm Delete?")) {
          let count = 0;
          let items = selectedRows.data();
          for (let i = 0; i < items.length; i++) {
            try {
              await api.userDelete(vm.libraryId, items[i][1]);
              count += 1;
            } catch (err) {
              vm.$toastr.e(vm.$i18n.t('message.user_delete_failure') + '<br>' + items[i][3] + ':' + err.response.data.message);
            }
          }
          if (count > 0) {
            vm.$toastr.s(vm.$i18n.t('message.user_delete_success') + '<br>Deleted ' + count + ' items.');
            vm.dataTable.ajax.reload();
          }
        }
        vm.$emit('loading', false);
      }
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    // Get Current DB
    let vm = this;
    api.dBGet(vm.libraryId).then(res => {
      if (res.data) {
        vm.library = res.data;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.library_get_failure') + '<br>' + err.response.data.message);
    });
  },
  mounted: function() {
    let vm = this;

    vm.timePicker = $('#timerange').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      startDate: moment().subtract(1, 'months'),
      endDate: moment(),
      locale: { format: 'MM/DD HH:mm:ss' }
    });

    
    vm.dataTable = $('#users').DataTable({
      paging: true,
      pageLength: 100,
      lengthChange: false,
      searching: false,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [],
      columnDefs: [
        {
          orderable: false,
          targets: [0, 2, 6, -1]
        },
        {
          targets: 0,
          className: 'select-checkbox'
        },
        {
          targets: [1],
          visible: false
        },
        {
          targets: 2,
          data: "img",
          render: function() {
            return `<img height="20px" width="20px"/>`;
          }
        },
        {
          targets: -1,
          data: null,
          render: function() {
            return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;' 
                    + vm.$i18n.t('common.detail') + '</a>'
                    + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                    + vm.$i18n.t('common.edit') + '</a>'
                    + '<a class="btn btn-info btn-xs delete"><i class="fa fa-remove"></i>&nbsp;' 
                    + vm.$i18n.t('common.delete') + '</a>';
          },
        }
      ],
      select: {
        style: 'multi',
        selector: 'td:not(:last-child)'
      },
      fnRowCallback: function(nRow, aData) {
        api.downloadObject(aData[2]).then(res => {
          $('td:eq(1)', nRow).html(`<img height="20px" width="20px" src="${res}"/>`);
        });
      },
      ajax: function (data, callback) {
        vm.$emit('loading', true);
        let param = 'time_range.start='+new Date(vm.timePicker.data('daterangepicker').startDate.toDate() - vm.diff * 1000).toISOString()
                    +'&time_range.end='+new Date(vm.timePicker.data('daterangepicker').endDate.toDate() - vm.diff * 1000).toISOString()
                    +'&page_request.offset='+data.start+'&page_request.limit='+data.length
                    +'&sort_key='+vm.targetOrderKeys
                    +'&order='+vm.targetOrders
                    +'&search='+vm.targetSearchs
        if(vm.targetGenders != ''){
          param = param + '&gender='+vm.targetGenders;
        }
        api.userList(vm.libraryId, 
        encodeURI(encodeURI(param)))
          .then(res => {
            let result = res.data;
            let records = {draw: new Date().getTime(), data: []};
            if (result.page_response.total >= 0) {
              records.recordsTotal = result.page_response.total;
              records.recordsFiltered = result.page_response.total;
              for (let i = 0; i < result.users.length; i++) {
                records.data.push([
                  '',
                  result.users[i].user_id, 
                  result.users[i].image.url,
                  result.users[i].name, 
                  result.users[i].gender, 
                  result.users[i].age, 
                  result.users[i].card_id, 
                  result.users[i].address,
                  moment(result.users[i].create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss')
                ]);
              }
            }
            callback(records);
          }).catch(() => {
            callback({draw: 1, data: []});
          }).finally(() => {
            vm.$emit('loading', false);
          });
      }
    });
    vm.dataTable.on('select deselect draw', function() {
      let all = vm.dataTable.rows().count();
      let selectedRows = vm.dataTable.rows({selected: true}).count();
      if (selectedRows === 0) {
        vm.selected = 0;
      } else if (selectedRows < all) {
        vm.selected = 1;
      } else {
        vm.selected = 2;
      }
    });
    vm.dataTable.on('click', '.detail', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.showObject = {
        user_id: rowData[1],
        image: {url: rowData[2]},
        name: rowData[3],
        gender: rowData[4],
        age: rowData[5],
        card_id: rowData[6],
        address: rowData[7],
        create_time: rowData[8]
      };
      vm.editable = false;
      vm.showModal = true;
    });
    vm.dataTable.on('click', '.edit', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.showObject = {
        user_id: rowData[1],
        image: {url: rowData[2]},
        name: rowData[3],
        gender: rowData[4],
        age: rowData[5],
        card_id: rowData[6],
        address: rowData[7]
      };
      vm.editable = true;
      vm.showModal = true;
    });
    vm.dataTable.on('click', '.delete', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      if (confirm("Confirm Delete?")) {
        api.userDelete(vm.libraryId, rowData[1]).then(() => {
          vm.$toastr.s(vm.$i18n.t('message.user_delete_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.user_delete_failure') + '<br>' + err.response.data.message);
        });
      }
    });
  }
};
</script>
