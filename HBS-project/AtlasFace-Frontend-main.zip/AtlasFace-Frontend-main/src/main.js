import Vue from 'vue';
import VueI18n from 'vue-i18n';
import VueKonva from 'vue-konva';
import Toastr from 'vue-toastr';

import App from './App.vue';
import router from './router';
import api from './api/api';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'font-awesome/css/font-awesome.css';
import 'admin-lte/dist/css/AdminLTE.min.css';
import 'admin-lte/dist/css/skins/_all-skins.min.css';
import 'admin-lte/dist/js/adminlte.min.js';

import 'bootstrap-daterangepicker/daterangepicker.css';
import 'bootstrap-daterangepicker/daterangepicker.js';

import 'select2/dist/css/select2.min.css';
import 'select2/dist/js/select2.full.min.js';

import 'datatables.net/js/jquery.dataTables.min.js';
import 'datatables.net-bs/js/dataTables.bootstrap.min.js';
import 'datatables.net-bs/css/dataTables.bootstrap.min.css';
import 'datatables.net-select-dt/js/select.dataTables.min.js';
import 'datatables.net-select-dt/css/select.dataTables.min.css';
import 'datatables.net-responsive-dt/js/responsive.dataTables.min.js';
import 'datatables.net-responsive-dt/css/responsive.dataTables.min.css';
import 'datatables.net-buttons-dt/js/buttons.dataTables.min.js';
import 'datatables.net-buttons-dt/css/buttons.dataTables.min.css';

import 'video.js/dist/video-js.css';

/*
* toastr initialize
*/
Vue.use(Toastr, {
  defaultTimeout: 3000,
  defaultProgressBar: false,
  defaultProgressBarValue: 0,
  defaultType: "error",
  defaultPosition: "toast-top-right",
  defaultCloseOnHover: false,
  defaultClickClose: true,
  defaultStyle: { "margin-top": "50px" },
  defaultClassNames: ["animated", "zoomInUp"]
});

/*
* i18n initialize
*/
Vue.use(VueI18n);
const i18n = new VueI18n({
  locale: 'ja',
  messages: {
    'ja': require('./assets/i18n/ja'),
    'en': require('./assets/i18n/en')
  }
});

/*
* konvajs initialize
*/
Vue.use(VueKonva);

function setImgSrc(el, binding) {
  if (binding.oldValue === undefined || binding.value !== binding.oldValue) {
    let fid = binding.value;
    api.downloadObject(fid).then(function(res) {
      el.src = res;
    }).catch((function() {
      el.src = fid;
    }));
  }
}

Vue.directive('auth-image', {
  bind: function(el, binding) {
    setImgSrc(el, binding);
  },
  componentUpdated: function(el, binding) {
    setImgSrc(el, binding);
  }
});

Vue.directive('select2', {
  inserted: function(el, binding) {
    let options = binding.value;
    $(el).select2(options).on('select2:select', function() {
      el.dispatchEvent(new Event('change'));
    });
    $(el).select2(options).on('select2:unselect', function() {
      el.dispatchEvent(new Event('change'));
    });
  },
});

/*
* new vue instance
*/
new Vue({
  el: '#app',
  i18n,
  router,
  render: h => h(App)
});

