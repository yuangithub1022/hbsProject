<style>
</style>

<template>
  <div id="app" @mousemove="moveEvent" @click="moveEvent">
    <router-view @login="loginDirect" @loading="switchLoading"></router-view>
    <vue-element-loading :active="loading" spinner="bar-fade-scale" color="#FF6700" size="64" is-full-screen/>
  </div>
</template>

<script>
import axios from 'axios';
import VueElementLoading from 'vue-element-loading';
import * as util from './assets/js/util';
import AllRoutesData from './router/fullpath';
import instance from './api/index';
import api from './api/api'; 

export default {
  data() {
    return {
      menuData: null,
      userData: null,
      diffTime: 0,
      loading: true,
      timer: null,
      refresher: null
    }
  },
  components: {
    VueElementLoading
  },
  methods: {
    switchLoading: function(loading) {
      this.loading = loading;
    },
    extendRoutes: function(isAdmin) {
      let originPath = util.deepcopy(AllRoutesData);
      if (!isAdmin) {
        originPath = originPath.filter(function(item) {
          if (!item.meta.admin) {
            return true;
          }
          return false;
        });
      }
      
      this.$router.addRoutes(originPath.concat([{
        path: '*',
        redirect: '/404'
      }]));

      return originPath;
    },
    generateMenus: function(routes) {
      let vm = this;
      let menus = routes.filter(function(item) {
        if (item.meta.menu) {
          return true;
        }
        return false;
      });
      vm.$root.menuData = menus;
    },
    loginDirect: function(newPath) {
      // Step 1 Check whether the user has access
      let localUser = util.session('user');
      if (!localUser || !localUser.token) {
        return this.$router.push({path: '/login', query: {from: this.$router.currentRoute.path}});
      }
      this.$root.userData = localUser;

      // Step 2 Set Authorization
      instance.defaults.headers.common['Authorization'] = localUser.token;

      // Step 3 Adding routing privileges to users
      let routes = this.extendRoutes(localUser.admin);

      // Step 4 Build Menu data
      this.generateMenus(routes);
      
      // Step 5 move to next page
      this.$router.replace({path: newPath || '/'});

      // Step 6 auto logout (only Admin user)
      if (localUser.admin) {
        this.initTimer();
      }

      // Step 7 init token refresher
      this.initRefresher();
    },
    moveEvent: function() {
      let path = ['/login'];
      if (!path.includes(this.$route.path) && this.$root.userData && this.$root.userData.admin) {
        if (this.timer) {
          clearTimeout(this.timer);
        }
        this.initTimer();
      }
    },
    initTimer: function() {
      this.timer = setTimeout(() => {
        //Clear local user information
        util.session('user', '');
        // reload app
        location.reload();
      }, 3 * 60 * 1000);
    },
    initRefresher: function() {
      this.refresher = setInterval(() => {
        api.omsGetVersion();
      }, 3 * 60 * 1000);
    },
  },
  created: function() {
    this.loginDirect(this.$route.path);
    this.$root.diffTime = 0;
    axios.get('/atlas/backend/time').then(res => {
      if (res.data.time) {
        this.$root.diffTime = Math.floor((new Date() - new Date(res.data.time)) / 1000);
      }
    });
  },
  mounted: function() {
    this.loading = false;
  }
}
</script>
