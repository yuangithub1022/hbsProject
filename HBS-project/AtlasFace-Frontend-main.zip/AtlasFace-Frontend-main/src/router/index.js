import Vue from 'vue';
import Router from 'vue-router';
Vue.use(Router);

// Base Route
let baseRoute = [{
  path: '/login',
  name: 'Login',
  component: (resolve) => require(['../views/login.vue'], resolve)
}, {
  path: '/401',
  name: 'NoAccess',
  component: (resolve) => require(['../views/common/401.vue'], resolve)
}, {
  path: '/404',
  name: 'PageNotFound',
  component: (resolve) => require(['../views/common/404.vue'], resolve)
}];

let router = new Router({
  routes: baseRoute
});

export default router;
