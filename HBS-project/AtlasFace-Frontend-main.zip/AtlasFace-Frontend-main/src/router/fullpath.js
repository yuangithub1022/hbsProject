// Menu Route
export default [{
  path: '/',
  alias: '/live',
  name: 'LiveStream',
  meta: {
    name: 'menu.video',
    icon: 'fa fa-video-camera',
    menu: true
  },
  component: (resolve) => require(['../views/live.vue'], resolve)
},{
  path: '/capture',
  name: 'CaptureRecord',
  meta: {
    name: 'menu.capture',
    icon: 'fa fa-picture-o',
    menu: true
  },
  component: (resolve) => require(['../views/capture.vue'], resolve)
},{
  path: '/alarm',
  name: 'AlarmRecord',
  meta: {
    name: 'menu.alarm',
    icon: 'fa fa-bell',
    menu: true
  },
  component: (resolve) => require(['../views/alarm.vue'], resolve)
},{
  path: '/library',
  name: 'LibraryManagement',
  meta: {
    name: 'menu.library',
    icon: 'fa fa-database',
    menu: true
  },
  component: (resolve) => require(['../views/library.vue'], resolve)
},{
  path: '/library/:id/user',
  name: 'UserManagement',
  meta: {
    
  },
  component: (resolve) => require(['../views/user.vue'], resolve)
},{
  path: '/device',
  name: 'TaskManagement',
  meta: {
    name: 'menu.task',
    icon: 'fa fa-tasks',
    menu: true,
    admin: true
  },
  component: (resolve) => require(['../views/task.vue'], resolve)
},{
  path: '/system',
  name: 'System',
  meta: {
    name: 'menu.system',
    icon: 'fa fa-cog',
    menu: true,
    admin: true
  },
  component: (resolve) => require(['../views/system.vue'], resolve)
}];