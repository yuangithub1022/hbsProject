<style>
.canvas {
  padding: 0;
  margin: auto;
  display: block;
  max-width: 100%;
  max-height: 100%;
}
</style>
<template>
  <div ref="player">
    <canvas ref="canvas" class="canvas"></canvas>
  </div>
</template>
<script>
import axios from 'axios';
import JSMpeg from '../assets/js/jsmpeg.min.js';

export default {
  name: "VideoPlayer",
  props: {
    url: ''
  },
  data() {
    return {
      player: null
    }
  },
  methods: {
    initPlayer(live_name) {
      let vm = this;
      let loc = window.location;
      let ws_url = `${loc.protocol.replace('http', 'ws')}//${loc.hostname}:${loc.port}/atlas/streaming/${live_name}`
      vm.player = new JSMpeg.Player(ws_url, {
        canvas: vm.$refs.canvas
      });
    },
    handleResize() {
      let playerAspect = this.$refs.player.clientHeight / this.$refs.player.clientWidth;
      if (playerAspect >= 0.5625) {
        this.$refs.canvas.style.height = `${this.$refs.player.clientWidth * 0.5625}px`;
        this.$refs.canvas.style.width = '100%';
      } else {
        this.$refs.canvas.style.height = '100%';
        this.$refs.canvas.style.width = `${this.$refs.player.clientHeight / 0.5625}px`;
      }
    }
  },
  mounted() {
    let vm = this;
    vm.handleResize();
    window.addEventListener('resize', vm.handleResize);
    axios.post('/atlas/backend/apply', {url: vm.url}).then(res => {
      vm.initPlayer(res.data.data);
    });
  },
  beforeDestroy() {
    window.removeEventListener('resize', this.handleResize);
    if (this.player) {
      this.player.destroy();
    }
  }
}
</script>
