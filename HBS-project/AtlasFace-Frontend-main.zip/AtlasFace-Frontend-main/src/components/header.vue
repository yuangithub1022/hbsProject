<style scoped>
.language-menu {
  width: 80px !important;
}
.user-header {
  height: 150px !important;
}
</style>

<template>
  <header class="main-header">
    <!-- Logo -->
    <router-link to="/" class="logo">
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>500</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Atlas</b>500</span>
    </router-link>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
          <li class="dropdown notifications-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <i class="fa fa-language"></i> {{ locale.name }}
            </a>
            <ul class="dropdown-menu language-menu">
              <li>
                <ul class="menu">
                  <li v-for="item in langs" :key="item.lang">
                    <a href="javascript:void(0);" @click="changeLang(item)">
                      <img :src="item.icon" height="16"> <span class="align-middle"> {{ item.name }} </span>
                    </a>
                  </li>
                </ul>
              </li>
            </ul>
          </li>
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown">
              <img src="../assets/images/face.png" class="user-image" alt="User Image">
              <span class="hidden-xs">{{ user.name }}</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img src="../assets/images/face.png" class="img-circle" alt="User Image">
                <p>
                  {{ user.name }} - {{ user.role }}
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <router-link :to="{path: '/system'}" class="btn btn-default btn-flat">System</router-link>
                </div>
                <div class="pull-right">
                  <a href="javascript:void(0);" @click="logout" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
</template>

<script>
import api from '../api/api';
import * as util from '../assets/js/util';

export default {
  data() {
    let vm = this;
    let langs = [
      {
        lang: 'ja',
        name: '日本語',
        icon: require('../assets/images/ja.jpg')
      },
      {
        lang: 'en',
        name: 'English',
        icon: require('../assets/images/en.jpg')
      }
    ];

    let locale = langs.filter(function(item){
      if (item.lang === vm.$i18n.locale) return true;
    });

    return {
      user: vm.$root.userData,
      langs: langs,
      locale: locale[0]
    };
  },
  methods: {
    changeLang(item) {
      let locale = this.$i18n.locale;
      if (locale !== item.lang) {
        this.$i18n.locale = item.lang;
        this.locale = item;
      }
    },
    logout: function() {
      if (confirm("Confirm Logout?")) {
        api.signOut({user: this.user.name}).finally(() => {
          //Clear local user information
          util.session('user', '');
          // reload app
          location.reload();
        });
      }
    }
  }
};
</script>
