const webpack = require('webpack');

module.exports = { 
  outputDir: 'dist',
  devServer: {
    proxy: {
      '^/atlas/api': {
        //target: 'https://172.30.1.190:38443',
        //target: 'https://124.219.161.88:28443',
        target: 'https://124.219.161.88:58443',
        changeOrigin: true,
        pathRewrite: {
          '^/atlas/api': '',
        }
      },
      '^/atlas/backend': {
        //target: 'https://124.219.161.88:12443',
        target: 'http://172.30.1.116:5000',
        changeOrigin: true,
        ws: true
      },
      '^/atlas/streaming': {
        //target: 'https://124.219.161.88:38181',
        target: 'http://172.30.1.116:5001',
        changeOrigin: true,
        ws: true
      }
    }
  },
  configureWebpack: {
    plugins: [
      new webpack.ProvidePlugin({
        $: 'jquery',
        jquery: 'jquery',
        'window.jQuery': 'jquery',
        jQuery: 'jquery'
      })
    ]
  },
  publicPath: '/atlas/frontend/'
}