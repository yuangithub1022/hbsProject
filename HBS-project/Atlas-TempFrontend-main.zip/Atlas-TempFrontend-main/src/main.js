import Vue from 'vue';
import VueI18n from 'vue-i18n';
import VueKonva from 'vue-konva';
import Toastr from 'vue-toastr';

import App from './App.vue';
import router from './router';
import api from './api/api';

import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min.js';
import 'font-awesome/css/font-awesome.css';
import 'admin-lte/dist/css/AdminLTE.min.css';
import 'admin-lte/dist/css/skins/_all-skins.min.css';
import 'admin-lte/dist/js/adminlte.min.js';

import 'bootstrap-daterangepicker/daterangepicker.css';
import 'bootstrap-daterangepicker/daterangepicker.js';

import 'select2/dist/css/select2.min.css';
import 'select2/dist/js/select2.full.min.js';

import 'datatables.net/js/jquery.dataTables.min.js';
import 'datatables.net-bs/js/dataTables.bootstrap.min.js';
import 'datatables.net-bs/css/dataTables.bootstrap.min.css';
import 'datatables.net-select-dt/js/select.dataTables.min.js';
import 'datatables.net-select-dt/css/select.dataTables.min.css';
import 'datatables.net-responsive-dt/js/responsive.dataTables.min.js';
import 'datatables.net-responsive-dt/css/responsive.dataTables.min.css';
import 'datatables.net-buttons-dt/js/buttons.dataTables.min.js';
import 'datatables.net-buttons-dt/css/buttons.dataTables.min.css';

import { library } from '@fortawesome/fontawesome-svg-core';
import { fas } from '@fortawesome/free-solid-svg-icons';
import { FontAwesomeIcon, FontAwesomeLayers } from '@fortawesome/vue-fontawesome';

import globalVariable from './assets/js/globalVariable';

library.add(fas);
Vue.component('font-awesome-icon', FontAwesomeIcon);
Vue.component('font-awesome-layers', FontAwesomeLayers);


Vue.prototype.GLOBAL = globalVariable;
/*
* toastr initialize
*/
Vue.use(Toastr, {
  defaultTimeout: 3000,
  defaultProgressBar: false,
  defaultProgressBarValue: 0,
  defaultType: "error",
  defaultPosition: "toast-top-right",
  defaultCloseOnHover: false,
  defaultClickClose: true,
  defaultStyle: { "margin-top": "50px" },
  defaultClassNames: ["animated", "zoomInUp"]
});

/*
* i18n initialize
*/
Vue.use(VueI18n);
const i18n = new VueI18n({
  locale: 'ja',
  messages: {
    'ja': require('./assets/i18n/ja')
  }
});

/*
* konvajs initialize
*/
Vue.use(VueKonva);

function setImgSrc(el, binding) {
  if (binding.oldValue === undefined || binding.value !== binding.oldValue) {
    let fid = binding.value;
    api.downloadObject(fid).then(function(res) {
      el.src = res;
    }).catch((function() {
      el.src = fid;
    }));
  }
}

Vue.directive('auth-image', {
  bind: function(el, binding) {
    setImgSrc(el, binding);
  },
  componentUpdated: function(el, binding) {
    setImgSrc(el, binding);
  }
});

Vue.directive('select2', {
  inserted: function(el, binding) {
    let options = binding.value;

    $(el).select2(options).on('select2:select', function(evt) {
      el.dispatchEvent(new Event('change'));
      const element = evt.params.data.element;
      const $element = $(element);
      $element.detach();
      const selected = $(el).find("option:selected").length;
      if(selected<1) {
        $(el).prepend($element);
      }else{
        $(el).find("option:eq("+ (selected-1) +")").after($element);
      }
      $(el).trigger("change");
    });

    $(el).select2(options).on('select2:unselect', function(evt) {
      el.dispatchEvent(new Event('change'));
      const element = evt.params.data.element;
      const $element = $(element);
      $element.detach();
      $(el).append($element);
    });
  },
});

/*
* new vue instance
*/
new Vue({
  i18n,
  router,
  render: h => h(App)
}).$mount('#app');

