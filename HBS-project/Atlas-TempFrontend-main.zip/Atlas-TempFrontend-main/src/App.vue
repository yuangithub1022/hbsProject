<template>
  <div id="app">
    <router-view
      @login="loginDirect"
      @loading="switchLoading"
    />
    <VueElementLoading
      :active="loading"
      spinner="bar-fade-scale"
      color="#FF6700"
      size="64"
      is-full-screen
    />
  </div>
</template>

<script>
import VueElementLoading from 'vue-element-loading';
import * as util from './assets/js/util';
import AllRoutesData from './router/fullpath';
import instance from './api/index';
import instance_backend from './api/index_backend';
import api from './api/api';

export default {
  components: {
    VueElementLoading
  },
  data() {
    return {
      menuData: null,
      userData: null,
      loading: true,
      timer: null,
      refresher: null,
      license: 0
    }
  },
  created() {
    this.loginDirect(this.$route.path);
  },
  mounted() {
    this.loading = false;
  },
  methods: {
    switchLoading(loading) {
      this.loading = loading;
    },
    extendRoutes(menuLic) {
      // let newPaths = util.deepcopy(AllRoutesData);
      let newPaths;
      // filter accessible routes by license (-1: NA, 0: base, 1: standard, 2: advanced)
      if (menuLic !== this.GLOBAL.base) {
        newPaths = AllRoutesData.filter(function(item) {
          return item.meta.role.indexOf("advanced") > -1;
        });
      } else {
        newPaths = AllRoutesData.filter(function(item) {
          return item.meta.role.indexOf("base") > -1;
        });
      }

      this.$router.addRoutes([...newPaths, {path: '*', redirect: '/404'}]);
      // this.$router.addRoutes([{path: '*', redirect: '/404'}]);
      return newPaths;
    },
    generateMenus(routes) {
      const vm = this;
      vm.$root.menuData = routes.filter(function(item) {
        return item.meta.menu;
      });
    },
    loginDirect(newPath) {
      // Step 1 Check whether the user has access
      const localUser = util.session('user');
      if (!localUser || !localUser.token) {
        if (this.$route.path !== '/login') {
          this.$router.push('/login');
        }
        return;
      }
      this.$root.userData = localUser;

      // Step 2 Set Authorization
      instance.defaults.headers.common['Authorization'] = localUser.token;
      instance_backend.defaults.headers.common['Authorization'] = localUser.token;

      // Step 3 Adding routing privileges to users
      const routes = this.extendRoutes(localUser.license);

      // Step 4 Build Menu data
      this.generateMenus(routes);

      //Step 5 move to next page
      if (!newPath) {
        this.$router.push('/');
      }

      if (newPath !== this.$route.path) {
        this.$router.push(newPath);
      }
      if(this.$root.userData.license !== this.GLOBAL.base) {
        this.initRefresher();
      }
    },
    initRefresher() {
      // refresh every 3 minutes
      this.refresher = setInterval(() => {
        api.omsGetVersion().then(() => { })
      }, 3 * 60 * 1000);
    },
  }

}
</script>

<style>
</style>
