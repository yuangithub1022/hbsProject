// Menu Route
//advanced => license 2
//standard => license 1
//base => license 0
import LiveCapture from '../views/LiveCapture';
import AlarmList from '../views/AlarmList';
import LibraryList from '../views/LibraryList';
import UserManage from '../views/UserManage';
import TaskList from '../views/TaskList';
import SystemInfo from '../views/SystemInfo';


export default [{
  path: '/',
  alias: '/live',
  name: 'LiveStream',
  meta: {
    name: 'menu.video',
    icon: 'fa fa-video-camera',
    menu: true,
    role: ["advanced","base"]
  },
  component: LiveCapture
},{
  path: '/alarm',
  name: 'AlarmRecord',
  meta: {
    name: 'menu.capture',
    icon: 'fa fa-picture-o',
    menu: true,
    role: ["advanced","base"]
  },
  component: AlarmList
},{
  path: '/library',
  name: 'LibraryManagement',
  meta: {
    name: 'menu.library',
    icon: 'fa fa-database',
    menu: true,
    role:["advanced"]
  },
  component: LibraryList
},{
  path: '/library/:id/user',
  name: 'UserManagement',
  meta: {
    role: ["advanced","base"]
  },
  component: UserManage
},{
  path: '/device',
  name: 'TaskManagement',
  meta: {
    name: 'menu.task',
    icon: 'fa fa-tasks',
    menu: true,
    role: ["advanced","base"]
  },
  component: TaskList
},{
  path: '/system',
  name: 'System',
  meta: {
    name: 'menu.system',
    icon: 'fa fa-cog',
    menu: true,
    role:["advanced"]
  },
  component: SystemInfo
}];