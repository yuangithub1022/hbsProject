import Vue from 'vue';
import Router from 'vue-router';

import LoginPage from '../views/LoginPage';
import Error401 from '../views/common/Error401';
import Error404 from '../views/common/Error404';

Vue.use(Router);

// Base Route
const baseRoute = [{
  path: '/login',
  name: 'Login',
  component: LoginPage
}, {
  path: '/401',
  name: 'NoAccess',
  component: Error401
}, {
  path: '/404',
  name: 'PageNotFound',
  component: Error404
}];

const router = new Router({
  routes: baseRoute
});

export default router;
