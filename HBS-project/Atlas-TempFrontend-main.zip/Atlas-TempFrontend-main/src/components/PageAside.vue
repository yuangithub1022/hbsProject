<template>
  <aside class="main-sidebar">
    <section class="sidebar">
      <div class="user-panel">
        <div class="pull-left image">
          <img
            src="../assets/images/face.png"
            class="img-circle"
            alt="User Image"
          >
        </div>
        <div class="pull-left info">
          <p> {{ user.name }} </p>
          <a href="#"><i class="fa fa-circle text-success" /> {{ $t("aside.status") }} </a>
        </div>
      </div>
      <ul
        class="sidebar-menu"
        data-widget="tree"
      >
        <li class="header">
          MAIN NAVIGATION
        </li>
        <li
          v-for="menu in menus"
          :key="menu.name"
          :class="{active: menu.path==='/' ? $route.path===menu.path:$route.path.indexOf(menu.path) > -1}"
        >
          <router-link :to="{name: menu.name}">
            <i :class="menu.meta.icon" /> <span v-t="menu.meta.name" />
          </router-link>
        </li>
      </ul>
    </section>
  </aside>
</template>

<script>
export default {
  name: 'PageAside',
  data() {
    return {
      user: this.$root.userData,
      menus: this.$root.menuData,
    };
  },
  mounted: () => {
  },
  methods: {

  }
};
</script>

<style scoped>
  .main-sidebar {
    z-index: 1999 !important;
  }
</style>
