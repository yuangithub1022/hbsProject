<template>
  <div
    v-if="show"
    class="modal fade in"
    tabindex="-1"
    role="dialog"
    aria-labelledby="myModalLabel"
    style="display: block;"
  >
    <div
      class="modal-dialog modal-centered"
      :class="modalclass"
      role="document"
    >
      <div class="modal-content">
        <div class="modal-header">
          <button
            type="button"
            class="close"
            data-dismiss="modal"
            aria-label="Close"
            aria-hidden=" true"
            @click="$emit('update:show', false)"
          >
            <span>&times;</span>
          </button>
          <h4
            id="myModalLabel"
            class="modal-title"
          >
            <slot name="header">
              default header
            </slot>
          </h4>
        </div>
        <div class="modal-body">
          <slot name="body">
            default body
          </slot>
        </div>
        <div
          v-if="footer"
          class="modal-footer"
        >
          <slot name="footer">
            default footer
          </slot>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'PageModal',
  props: {
    show: Boolean,
    footer: Boolean,
    modalclass: String,
  },
}
</script>

<style>
  .modal-header {
    text-align: center;
  }
  .modal-body {
    max-height: calc(100vh - 180px);
    overflow-y: auto;
  }
  .modal-centered {
    border-radius: 5px;
    position: relative;
    top: 45%;
    transform: translate(0, -50%) !important;
    -ms-transform: translate(0, -50%) !important; /* IE 9 */
    -webkit-transform: translate(0, -50%) !important; /* Safari and Chrome */
  }
</style>