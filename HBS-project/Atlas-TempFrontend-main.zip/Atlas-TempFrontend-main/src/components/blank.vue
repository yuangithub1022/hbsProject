<template>
  <div>
  </div>
</template>

<script>
export default {
  data() {
    return {

    };
  },
  methods: {

  },
  mounted: () => {
  }
};
</script>

<style scoped>

</style>
