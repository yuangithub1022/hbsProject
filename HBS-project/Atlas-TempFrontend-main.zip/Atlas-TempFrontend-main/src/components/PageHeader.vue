<template>
  <header class="main-header">
    <!-- Logo -->
    <router-link
      to="/"
      class="logo"
    >
      <!-- mini logo for sidebar mini 50x50 pixels -->
      <span class="logo-mini"><b>A</b>500</span>
      <!-- logo for regular state and mobile devices -->
      <span class="logo-lg"><b>Atlas</b>500</span>
    </router-link>
    <!-- Header Navbar: style can be found in header.less -->
    <nav class="navbar navbar-static-top">
      <!-- Sidebar toggle button-->
      <a
        href="#"
        class="sidebar-toggle"
        data-toggle="push-menu"
        role="button"
      >
        <span class="sr-only">Toggle navigation</span>
        <span class="icon-bar" />
        <span class="icon-bar" />
        <span class="icon-bar" />
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
<!--          <li class="dropdown notifications-menu">-->
<!--            <a-->
<!--              href="#"-->
<!--              class="dropdown-toggle"-->
<!--              data-toggle="dropdown"-->
<!--            >-->
<!--              <i class="fa fa-language" /> {{ locale.name }}-->
<!--            </a>-->
<!--          </li>-->
          <!-- User Account: style can be found in dropdown.less -->
          <li class="dropdown user user-menu">
            <a
              href="#"
              class="dropdown-toggle"
              data-toggle="dropdown"
            >
              <img
                src="../assets/images/face.png"
                class="user-image"
                alt="User Image"
              >
              <span class="hidden-xs">{{ user.name }}</span>
            </a>
            <ul class="dropdown-menu">
              <!-- User image -->
              <li class="user-header">
                <img
                  src="../assets/images/face.png"
                  class="img-circle"
                  alt="User Image"
                >
                <p>
                  {{ user.name }} - {{ user.role }}
                </p>
              </li>
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <router-link
                    :to="{path: '/system'}"
                    class="btn btn-default btn-flat"
                  >
                    System
                  </router-link>
                </div>
                <div class="pull-right">
                  <a
                    href="javascript:void(0);"
                    class="btn btn-default btn-flat"
                    @click="logout"
                  >Sign out</a>
                </div>
              </li>
            </ul>
          </li>
        </ul>
      </div>
    </nav>
  </header>
</template>

<script>
import backend from '../api/backend';
import * as util from '../assets/js/util';
import icon from '../assets/images/ja.jpg'

export default {
  name: 'PageHeader',
  data() {
    let vm = this;
    let langs = [
      {
        lang: 'ja',
        name: '日本語',
        icon: icon
      }
    ];

    return {
      user: vm.$root.userData,
      langs: langs,
      locale: langs[0]
    };
  },
  methods: {
    logout() {
      let vm = this;
      if (confirm('Are you sure to logout?')) {
        backend.signOut({user: this.user.name,token: this.user.token}).then(res => {
          if(res.data.code === 0) {
            util.session('user', '');
            location.reload();
          }else{
            vm.$toastr.e(res.data.msg);
          }
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.signOut_failure') + '<br>' + err);
        }).finally(() => {
        });
      }
    }
  }
};
</script>

<style scoped>
  .language-menu {
    width: 80px !important;
  }
  .user-header {
    height: 150px !important;
  }
</style>
