import axios from 'axios';
import * as util from '../assets/js/util.js';

const instance = axios.create({
  baseURL: '/api',
  withCredentials: true,
  headers: {'Cache-Control': 'no-cache'},
  timeout: 10000
});

instance.defaults.headers.post['Content-Type'] = 'application/json';

instance.interceptors.request.use(function (config) {
  if (typeof config.params === 'undefined') {
    config.params = {};
  }
  if (typeof config.params === 'object') {
    if (typeof URLSearchParams === 'function' && config.params instanceof URLSearchParams) {
      config.params.append('_', Date.now());
    } else {
      config.params._ = Date.now();
    }
  }

  return config;
});

instance.interceptors.response.use(function(response) {
  return response;
}, util.catchError);

export default instance;