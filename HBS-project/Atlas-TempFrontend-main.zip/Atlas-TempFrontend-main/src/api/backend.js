import instance from './index_backend';

export default {
  signIn(params) {
    return instance.post('/user/login', params);
  },
  signOut(params) {
    return instance.post('/user/logout', params);
  },
  
  // todo
  // acs device list/new/get/delete/update/taskUpdateConfig/taskDeleteConfig -> devices table
  // capture/alarm page list/delete -> records table
  // socket.io live page -> data
  // login/logout -> return token -> header auth token

  taskNew(params) {
    return instance.post('/device/new', params);
  },
  taskList() {
    return instance.get('/devices');
  },
  taskUpdate(params)  {
    return instance.put(`/device/update/${params.task_id}`, params);
  },
  taskDelete(id)  {
    return instance.delete(`/device/delete/${id}`);
  },
  resetDevice(params) {
    return instance.post(`/device/restart`, params);
  },
  resetDeviceTime(params) {
    return instance.post(`/device/set_time`, params);
  },
  handleDeleteRecords(params) {
    return instance.post(`/device/delete_records`, params);
  },
  listCaptureResults(params) {
    return instance.post(`/records`, params);
  },
  deleteAllRecords() {
    return instance.delete('/records/delete');
  },
  getDBServer() {
    return instance.get(`/setting/db_server`);
  },
  updateDBServer(param) {
    return instance.post(`/setting/db_server`,param);
  },
  getTaskConfig(taskId) {
    return instance.get(`/device/config/${taskId}`);
  },
  updateTaskConfig(taskId,param) {
    return instance.post(`/device/config/${taskId}`,param);
  },
  getLatestCaptureResult(taskId) {
    return instance.get(`/device/video_capture/${taskId}`);
  }
}