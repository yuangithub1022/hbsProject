
//sessionStorage
export const session = function(key, value) {
  if (value === void(0)) {
    var lsVal = sessionStorage.getItem(key);
    if(lsVal && lsVal.indexOf('autostringify-') === 0 ) {
      return JSON.parse(lsVal.split('autostringify-')[1]);
    }else{
      return lsVal;
    }
  } else {
    if (typeof(value)==="object" || Array.isArray(value)) {
      value = 'autostringify-' + JSON.stringify(value);
    }
    return sessionStorage.setItem(key, value);
  }
};

//Object deepcopy
export const deepcopy = function(source) {
  if (!source) {
    return source;
  }
  let sourceCopy = source instanceof Array ? [] : {};
  for (let item in source) {
    sourceCopy[item] = typeof source[item] === 'object' ? deepcopy(source[item]) : source[item];
  }
  return sourceCopy;
};

//Resize window
export const resizeWindow = function() {
  if (typeof(Event) === 'function') {
    // modern browsers
    window.dispatchEvent(new Event('resize'));
  } else {
    // for IE and other old browsers
    let evt = window.document.createEvent('UIEvents'); 
    evt.initUIEvent('resize', true, false, window, 0); 
    window.dispatchEvent(evt);
  }
}

//Ajax error catch
export const catchError = function(err) {
  if (err.response) {
    switch (err.response.status) {
    case 408:
    case 504:
    case 403:
    case 412:
    case 501:
    case 500:
    case 409:
    case 401:
      session('user','');
      window.location.reload();
      break;
    }
  }
  return Promise.reject(err);
};