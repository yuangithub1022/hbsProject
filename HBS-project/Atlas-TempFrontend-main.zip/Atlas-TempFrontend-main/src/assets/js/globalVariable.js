const base = 0
const standard = 1
const advanced = 2
//base = 0
//  (Task Menu: only create face task with temperature measurement function, but can not select library)
//  (System Menu: do not set HTTP server and DB server and do not show video stream information)
//standard = 1
//  (Task Menu: only create face task with temperature measurement function and must select library and do not select 'no' for temperature measurement function)
//  (System Menu: do set HTTP server and DB server and do not show video stream information)
//advanced = 2
//  (no rule above)

export default {
  base,
  standard,
  advanced
}