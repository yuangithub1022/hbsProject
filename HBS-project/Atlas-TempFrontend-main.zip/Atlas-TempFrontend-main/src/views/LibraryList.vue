<template>
  <div>
    <div class="wrapper">
      <PageHeader />
      <PageAside />
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.library") }}</h4>
            </div>
            <div class="box-body">
              <table
                id="library"
                class="table table-bordered table-striped"
                width="100%"
              >
                <thead>
                  <tr>
                    <th>{{ $t("library.id") }}</th>
                    <th>{{ $t("library.name") }}</th>
                    <th>{{ $t("library.total") }}</th>
                    <th>{{ $t("library.time") }}</th>
                    <th>{{ $t("library.description") }}</th>
                    <th>{{ $t("common.action") }}</th>
                  </tr>
                </thead>
                <tbody />
              </table>
            </div>
          </div>
          <PageModal
            :show.sync="showModal"
            :footer="true"
          >
            <div slot="header">
              <span v-if="showObject.id">{{ $t("common.edit") }} (ID: {{ showObject.name }})</span>
              <span v-if="!showObject.id">{{ $t("common.create") }} </span>
            </div>
            <div slot="body">
              <form class="form-horizontal">
                <div class="modal-form">
                  <div class="form-group">
                    <label class="col-xs-2 control-label">
                      {{ $t("library.name") }}
                    </label>
                    <div class="col-xs-10">
                      <input
                        v-model="showObject.name"
                        type="text"
                        class="form-control"
                        placeholder="Name"
                        required="required"
                      >
                    </div>
                  </div>
                  <div class="form-group">
                    <label class="col-xs-2 control-label">
                      {{ $t("library.description") }}
                    </label>
                    <div class="col-xs-10">
                      <textarea
                        v-model="showObject.description"
                        class="form-control"
                        rows="3"
                        placeholder="Description"
                      />
                    </div>
                  </div>
                </div>
              </form>
            </div>
            <div slot="footer">
              <button
                class="btn btn-default pull-left"
                @click="showModal=false"
              >
                {{ $t("common.cancel") }}
              </button>
              <button
                class="btn btn-primary pull-right"
                @click="updateLibrary"
              >
                {{ $t("common.ok") }}
              </button>
            </div>
          </PageModal>
        </section>
      </div>
    </div>
  </div>
</template>

<script>
import * as moment from 'moment';
import api from '../api/api';

import PageHeader from '../components/PageHeader';
import PageAside from '../components/PageAside';
import PageModal from '../components/PageModal';

export default {
  name: 'LibraryList',
  components: {
    PageHeader,
    PageAside,
    PageModal
  },
  data() {
    return {
      user: this.$root.userData,
      diff: this.$root.diffTime,
      showModal: false,
      showObject: {},
      dataTable: null
    };
  },
  created() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
  },
  mounted() {
    const vm = this;
    vm.dataTable = $('#library').DataTable({
      paging: true,
      pageLength: 10,
      lengthChange: false,
      searching: true,
      ordering: true,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: false,
      order: [[ 3, "asc" ]],
      dom: 'Bfrtip',
      buttons: [
        {
          text: vm.$i18n.t('common.create'),
          className: 'btn btn-primary',
          init: function(api, node) {
            $(node).removeClass('dt-button');
          },
          action: function() {
            vm.showObject = {};
            vm.showModal = true;
          }
        }
      ],
      columnDefs: [
        {
          orderable: false,
          targets: [4, -1]
        },
        {
          targets: [0],
          visible: false,
          searchable: false
        },
        {
          targets: -1,
          data: null,
          defaultContent: '<a class="btn btn-info btn-xs manage" style="margin-right:10px"><i class="fa fa-gears"></i>&nbsp;' 
                    + vm.$i18n.t('common.manage') + '</a>'
                    + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;' 
                    + vm.$i18n.t('common.edit') + '</a>'
                    + '<a class="btn btn-info btn-xs delete"><i class="fa fa-remove"></i>&nbsp;' 
                    + vm.$i18n.t('common.delete') + '</a>'
        }
      ],
      ajax(data, callback) {
        api.dBList({}).then(res => {
          let result = res.data;
          let records = {draw: 1, data: []};
          result.databases.forEach(element => {
            records.data.push([element.id, element.name, element.size, moment(element.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'), element.description]);
          });
          callback(records);
        }).catch(() => {
          callback({draw: 1, data: []});
        });
      }
    });
    vm.dataTable.on('click', '.manage', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.$router.push({path: `/library/${rowData[0]}/user`});
    });
    vm.dataTable.on('click', '.edit', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.showObject = {
        id: rowData[0],
        name: rowData[1],
        description: rowData[4]
      };
      vm.showModal = true;
    });
    vm.dataTable.on('click', '.delete', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      if (confirm("Confirm Delete?")) {
        api.dBDelete(rowData[0]).then(() => {
          vm.$toastr.s(vm.$i18n.t('message.library_delete_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.library_delete_failure') + '<br>' + err.response.data.message);
        });
      }
    });
  },
  methods: {
    updateLibrary() {
      const vm = this;
      if (!vm.showObject.name) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }
      if (vm.showObject.id) {
        api.dBUpdate(vm.showObject).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.library_update_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.library_update_failure') + '<br>' + err.response.data.message);
        });
      } else {
        api.dBNew(vm.showObject).then(() => {
          vm.showModal = false;
          vm.$toastr.s(vm.$i18n.t('message.library_create_success'));
          vm.dataTable.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.library_create_failure') + '<br>' + err.response.data.message);
        });
      }
    }
  }
};
</script>

<style scoped>
  .box-body {
    min-height: calc(100vh - 163px);
  }
  .modal-form {
    margin-top: 15px;
  }
</style>