<template>
  <div>
    <div class="wrapper">
      <PageHeader />
      <PageAside />
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.alarm") }}</h4>
            </div>
            <div class="box-body">
              <div class="form-group">
                <div class="row">
                  <div
                    class="col-xs-3"
                    style="width:23%"
                  >
                    <div class="input-group">
                      <div class="input-group-addon">
                        <i class="fa fa-clock-o" />
                      </div>
                      <input
                        id="timerange"
                        type="text"
                        class="form-control pull-right"
                      >
                    </div>
                  </div>
                  <div
                    class="col-xs-2"
                    style="width:15%"
                  >
                    <select
                      v-model="targetTasks"
                      v-select2="taskSelectOption"
                      multiple="multiple"
                      class="form-control select2"
                      data-placeholder="Select Devices"
                      style="width: 100%;"
                    >
                      <option
                        v-for="item of tasks"
                        :key="item.task_id"
                        :value="item"
                      >
                        {{ item.extra_info.task_name }}
                      </option>
                    </select>
                  </div>
                  <div
                    class="col-xs-2"
                    style="width:15%"
                  >
                    <select
                      v-model="targetLibraries"
                      v-select2="taskSelectOption"
                      multiple="multiple"
                      class="form-control select2"
                      data-placeholder="Select Libraries"
                      style="width: 100%;"
                    >
                      <option
                        v-for="item of libraries"
                        :key="item.id"
                        :value="item"
                      >
                        {{ item.name }}
                      </option>
                    </select>
                  </div>
                  <div
                    class="col-xs-1"
                    style="width:12%"
                  >
                    <select
                      v-model="identifyState"
                      class="form-control selectStyle"
                      data-placeholder="Select IdentifyState"
                      style="width: 100%;"
                    >
                      <option
                        v-for="item of identifyTypeList"
                        :key="item.id"
                        :value="item.id"
                      >
                        {{ item.name }}
                      </option>
                    </select>
                  </div>
                  <div
                    class="col-xs-1"
                    style="width:12%"
                  >
                    <select
                      v-model="temperatureState"
                      class="form-control selectStyle"
                      data-placeholder="Select TemperatureState"
                      style="width: 100%;"
                    >
                      <option
                        v-for="item of temperatureTypeList"
                        :key="item.id"
                        :value="item.id"
                      >
                        {{ item.name }}
                      </option>
                    </select>
                  </div>
                  <div
                    class="col-xs-3"
                    style="width:23%"
                  >
                    <button
                      class="btn btn-primary ctl-button buttonRight"
                      title="Search"
                      @click="search"
                    >
                      <i class="fa fa-search" />
                    </button>
                    <button
                      class="btn btn-primary ctl-button"
                      @click="exportData(true)"
                    >
                      Export
                    </button>
                    <button
                      class="btn btn-primary ctl-button"
                      @click="exportData(false)"
                    >
                      ExportAll
                    </button>
                  </div>
                </div>
              </div>

              <table
                id="alarm"
                class="table table-bordered table-striped"
                width="100%"
              >
                <thead>
                  <tr>
                    <th class="text-center">
                      <button
                        class="checkall"
                        @click="checkAll"
                      >
                        <i
                          v-if="selected===0"
                          class="fa fa-square-o"
                        />
                        <i
                          v-if="selected===1"
                          class="fa fa-minus-square-o"
                        />
                        <i
                          v-if="selected===2"
                          class="fa fa-check-square-o"
                        />
                      </button>
                    </th>
                    <th>{{ $t("alarm.time") }}</th>
                    <th>{{ $t("alarm.object") }}</th>
                    <th>{{ $t("alarm.image") }}</th>
                    <th>{{ $t("alarm.age") }}</th>
                    <th>{{ $t("alarm.taskId") }}</th>
                    <th>{{ $t("alarm.task") }}</th>
                    <th>{{ $t("alarm.libraryId") }}</th>
                    <th>{{ $t("alarm.library") }}</th>
                    <th>{{ $t("alarm.score") }}</th>
                    <th>{{ $t("alarm.user") }}</th>
                    <th>{{ $t("alarm.attributes") }}</th>

                    <th>{{ $t("alarm.temperature") }}</th>
                    <th>{{ $t("alarm.temperatureState") }}</th>
                    <th>{{ $t("alarm.identifyState") }}</th>
                    <th>{{ $t("common.action") }}</th>
                  </tr>
                </thead>
                <tbody />
              </table>
            </div>
          </div>

          <PageModal
            :show.sync="showModal"
            :footer="false"
          >
            <div slot="header">
              {{ $t("common.detail") }}
            </div>
            <div
              slot="body"
              :class="{'detail-body':showObject[14] === 'T'}"
            >
              <div :class="{'col-xs-5':showObject[14] === 'T','col-xs-12':showObject[14] === 'F'}">
                <div class="portrait">
                  <img
                    height="150px"
                    width="150px"
                    :src="'data:image/png;base64,'+showObject[3]"
                  >
                  <h6>{{ $t("alarm.capture") }}</h6>
                </div>
                <div
                  v-if="showObject[11]"
                  class="table-responsive"
                >
                  <table class="table">
                    <tbody>
                      <tr>
                        <th> {{ $t("alarm.task") }}: </th>
                        <td> {{ showObject[6] }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.object") }}: </th>
                        <td> {{ showObject[2] | dealStr }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.v_age") }}: </th>
                        <td> {{ showObject[11].age | dealAge }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.v_gender") }}: </th>
                        <td> {{ showObject[11].gender }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.temperature") }}: </th>
                        <td> {{ showObject[12] | dealStr }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.temperatureState") }}: </th>
                        <td> {{ showObject[13] | dealStr }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("alarm.time") }}: </th>
                        <td> {{ showObject[1] }} </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
              <div
                v-if="showObject[14] === 'T'"
                class="col-xs-2 compare"
              >
                <hr>
                <strong> {{ $t("alarm.score") }}: </strong><br><br>
                <span class="badge bg-red">{{ showObject[9] }}%</span>
                <hr>
              </div>
              <div
                v-if="showObject[14] === 'T'"
                class="col-xs-5"
              >
                <div class="portrait">
                  <img
                    v-if="showObject[10].image.data !==null && showObject[10].image.data !==''"
                    height="150px"
                    width="150px"
                    :src="'data:image/png;base64,'+showObject[10].image.data"
                  >
                  <img
                    v-else
                    height="150px"
                    width="150px"
                  >
                  <h6>{{ $t("alarm.master") }}</h6>
                </div>
                <div class="table-responsive">
                  <table class="table">
                    <tbody>
                      <tr>
                        <th> {{ $t("user.name") }}: </th>
                        <td> {{ showObject[10].name }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("menu.library") }}: </th>
                        <td> {{ showObject[8] | dealStr }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.age") }}: </th>
                        <td> {{ showObject[10].age | dealAge }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.gender") }}: </th>
                        <td> {{ showObject[10].gender }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.cardId") }}: </th>
                        <td> {{ showObject[10].card_id | dealStr }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.address") }}: </th>
                        <td> {{ showObject[10].address | dealStr }} </td>
                      </tr>
                      <tr>
                        <th> {{ $t("user.create_time") }}: </th>
                        <td> {{ showObject[10].create_time | dealTime }} </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </PageModal>
        </section>
      </div>
    </div>
  </div>
</template>

<script>
import jsZip from 'jszip';
import FileSaver from 'file-saver';
import * as moment from 'moment';
import api from '../api/api';
import backend from '../api/backend';

import PageHeader from '../components/PageHeader';
import PageAside from '../components/PageAside';
import PageModal from '../components/PageModal';

export default {
  name: 'AlarmList',
  components: {
    PageHeader,
    PageAside,
    PageModal
  },
  filters:{
    dealStr(data) {
      if (data === null || data === '') {
        return '-';
      } else {
        return data;
      }
    },
    dealTime(data) {
      if (data === 'Invalid date' || data === null || data === '') {
        return '-'
      } else {
        return data;
      }
    },
    dealAge(data) {
      if (data === 0 || data === null || data === '') {
        return '-'
      } else {
        return data;
      }
    }
  },
  data() {
    return {
      user: this.$root.userData,
      selected: 0,
      tasks: [],
      targetTasks: [],
      libraries: [],
      targetLibraries: [],
      dataTable: null,
      timePicker: null,
      showModal: false,
      showObject: [],
      taskSelectOption: {
        allowClear: true,
        maximumSelectionLength: 4,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
      identifyState:'',
      temperatureState:'',
      identifyTypeList:[{id:'',name:'すべて'},{id:'T',name:'認証成功'},{id:'F',name:'認証失敗'}],
      temperatureTypeList:[{id:'',name:'すべて'},{id:'1',name:'体温正常'},{id:'2',name:'体温異常'}],
      taskArr:[],
      libArr:[]
    };
  },
  created() {
    const vm = this;
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    vm.$emit('loading', true);
  },
  mounted: async function() {
    const vm = this;

    vm.timePicker = $('#timerange').daterangepicker({
      timePicker: true,
      timePickerIncrement: 30,
      startDate: moment().subtract(1, 'hours'),
      endDate: moment(),
      locale: { format: 'MM/DD HH:mm:ss' }
    });

    // Get All tasks and libraries
    try {
      const res = await backend.taskList({'page_request.offset': 0, 'page_request.limit': 100});
      if(this.$root.userData.license === this.GLOBAL.base) {
        let running = res.data.tasks.filter(element => {
          if (element.source.type === 'FC_SENSEPASS') return true;
        });
        if (running.length > 0) {
          vm.tasks = vm.tasks.concat(running);
        }
      } else if(this.$root.userData.license === this.GLOBAL.standard) {
        let running = res.data.tasks.filter(element => {
          if (element.source.type !== 'VN_RTSP') return true;
        });
        if (running.length > 0) {
          vm.tasks = vm.tasks.concat(running);
        }
      } 
      else{
        vm.tasks = res.data.tasks;
      }
    } catch (err) {
      vm.tasks = [];
    }
    
    try {
      if(this.$root.userData.license !== this.GLOBAL.base) {
        const res = await api.dBList();
        vm.libraries = res.data.databases;
        if(this.$root.userData.license === this.GLOBAL.base) {
          vm.libraries = [];
        }
      }
    } catch (err) {
      vm.libraries = [];
    }

    vm.dataTable = $('#alarm').DataTable({
      paging: true,
      pageLength: 10,
      lengthChange: false,
      searching: true,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [],
      sDom: 'ltipr',
      columnDefs: [
        {
          orderable: false,
          targets: [0, 3, -1]
        },
        {
          targets: 0,
          className: 'select-checkbox'
        },
        {
          targets: 3,
          data: null,
          render: function(url, type, row) {
            if(row[3] !== '') {
              return `<img height="20px" width="20px" src="data:image/png;base64,`+row[3] +`" alt="X"/>`;
            }else{
              return ``;
            }
          }
        },
        {
          targets: -1,
          data: null,
          defaultContent: '<a class="btn btn-info btn-xs detail"> <i class="fa fa-eye"></i>&nbsp;' + vm.$i18n.t('common.detail') + '</a>'
        },
        {
          targets: -2,
          render: function(data) {
            if(data === 'T') {
              return '認証成功';
            }else{
              return '認証失敗';
            }
          },
        },
        {
          targets: [-5, -6, -7, -9, -11],
          visible: false
        }
      ],
      select: {
        style: 'multi',
        selector: 'td:not(:last-child)'
      },
      initComplete() {
        if (vm.targetTasks.length > 0 || vm.targetLibraries.length > 0) {
          vm.changeTasksOrLibraries();
        }
      },
      ajax(data, callback) {
        vm.$emit('loading', true);
        vm.getCondition();
        let params  = {
          'page_no':(data.start / data.length) + 1,
          'page_limit':data.length,
          'time_range.start': moment(vm.timePicker.data('daterangepicker').startDate.toDate()).format('YYYY-MM-DD HH:mm:ss'),
          'time_range.end': moment(vm.timePicker.data('daterangepicker').endDate.toDate()).format('YYYY-MM-DD HH:mm:ss'),
          'task_id':vm.taskArr.toString(),
          'lib_ids':vm.libArr.toString(),
          'user_identified_state':vm.identifyState,
          'temperature_state':vm.temperatureState
        }
        
        backend.listCaptureResults(params).then(res => {
          let records = vm.listData(res);
          // console.log(records)
          callback(records);
        }).catch(() => {
          callback({draw: 1, data: []});
        }).finally(() => {
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTable.on('select deselect draw', function() {
      let all = vm.dataTable.rows({search: 'applied'}).count();
      let selectedRows = vm.dataTable.rows({search: 'applied', selected: true}).count();
      if (selectedRows === 0) {
        vm.selected = 0;
      } else if (selectedRows < all) {
        vm.selected = 1;
      } else {
        vm.selected = 2;
      }
    });
    vm.dataTable.on('click', '.detail', function() {
      let rowData = vm.dataTable.row($(this).parents('tr')).data();
      vm.view(rowData);
    });
  },
  methods: {
    baseExport(selectedRows,selected) {
      if (selectedRows.length === 0) {
        this.$toastr.i(this.$i18n.t(selected ? 'message.common_no_selected' : 'message.common_empty_result'));
        this.$emit('loading', false);
      } else {
        let rows = [];
        this.$emit('loading', true);
        let zipFile = new jsZip();
        let imgFolder;
        imgFolder = zipFile.folder("images");
        rows.push([
          this.$i18n.t("common.index"),
          this.$i18n.t("alarm.time"),
          this.$i18n.t("alarm.task"),
          this.$i18n.t("alarm.score"),
          this.$i18n.t("alarm.object"),
          this.$i18n.t("alarm.library"),
          this.$i18n.t("user.gender"),
          this.$i18n.t("alarm.age"),
          this.$i18n.t("user.cardId"),
          this.$i18n.t("user.address"),
          this.$i18n.t("alarm.image"),
          this.$i18n.t("alarm.temperature"),
          this.$i18n.t("alarm.temperatureState"),
          this.$i18n.t("alarm.identifyState"),
        ]);
        let items = selectedRows;
        for (let index = 0; index < items.length; index++) {
          let item = items[index];
          let imgName = index + '_' + item[2] + '.jpg';
          imgFolder.file(imgName, item[3], {base64: true});
          rows.push([index+1, item[1], item[6], item[9], item[2], item[8], item[11].gender, item[4], item[10].card_id, item[10].address, imgName, item[12], item[13], item[14]==='T'?'認証成功':'認証失敗'
          ]);
        }
        let csvContent = '\ufeff' + rows.map(e => e.join(',')).join('\n');
        zipFile.file('records.csv', csvContent);
        zipFile.generateAsync({type:"blob"}).then(content => {
          FileSaver.saveAs(content, 'Records_' + moment(new Date(), 'YYYYMMDDHHmmss') + '.zip');
        }).finally(() => {
          this.$emit('loading', false);
        });
      }
    },
    getCondition() {
      let vm = this;
      vm.taskArr = [];
      vm.libArr = [];
      if (vm.targetTasks !== '' && vm.targetTasks.length > 0) {
        vm.targetTasks.forEach(function(item) {
          vm.taskArr.push(item.task_id);
        })
      } else {
        vm.taskArr = [];
      }
      if (vm.targetLibraries !== '' && vm.targetLibraries.length > 0) {
        vm.targetLibraries.forEach(function(item) {
          vm.libArr.push(item.id);
        })
      }else{
        vm.libArr = [];
      }
    },
    listData(res) {
      let vm = this;
      let result = res.data.data;
      let records = {draw: new Date().getTime(), data: []};
      if (result.page_request.total >= 0) {
        records.recordsTotal = result.page_request.total;
        records.recordsFiltered = result.page_request.total;
        
        for (let i = 0; i < result.results.length; i++) {
          let element = result.results[i];
          if (!element.capture_result.face.most_similar_user) {
            continue;
          }

          let curTask = vm.tasks.filter(ele => { if (ele.task_id === element.task_id) return true; });

          if (curTask.length === 0) {
            continue;
          }

          let libraryName = element.capture_result.face.db_id;
          let curLibrary = vm.libraries.filter(ele => { if (ele.id === element.capture_result.face.db_id) return true; });
          if (curLibrary.length > 0) {
            libraryName = curLibrary[0].name;
          }

          let tempStatus = '';
          if(element.temperature_state === '1') {
            tempStatus = '正常';
          }else if(element.temperature_state === '2') {
            tempStatus = '異常';
          }else{
            tempStatus = '';
          }

          
          element.capture_result.face.most_similar_user.create_time = moment(element.capture_result.face.most_similar_user.create_time).format('YYYY-MM-DD HH:mm:ss');
          // console.log('-------------------------------------')
          // console.log(moment(Number(element.capture_time)).format('YYYY-MM-DD HH:mm:ss'))
          // console.log(element.capture_result.face.most_similar_user.name)
          // console.log(element.capture_result.face.portrait.data)
          // console.log(element.capture_result.face.most_similar_user.age)
          // console.log(element.task_id)
          // console.log(curTask[0].extra_info.task_name)
          // console.log(element.capture_result.face.db_id)
          // console.log(libraryName)
          // console.log(Math.round(Number(element.capture_result.face.score)*10000)/100)
          // console.log(element.capture_result.face.most_similar_user)
          // console.log(Object.keys(element.capture_result.face.attributes).length > 0 ? element.capture_result.face.attributes : {'age': '-', 'gender': '-'})
          // console.log(element.temperature)
          // console.log(tempStatus)
          // console.log(element.user_identified_state)


          records.data.push([
            '',
            moment(Number(element.capture_time)).format('YYYY-MM-DD HH:mm:ss'),
            element.capture_result.face.most_similar_user.name,
            element.capture_result.face.portrait.data,
            element.capture_result.face.most_similar_user.age,
            element.task_id,
            curTask[0].extra_info.task_name,
            element.capture_result.face.db_id,
            libraryName,
            Math.round(Number(element.capture_result.face.score)*10000)/100,
            element.capture_result.face.most_similar_user,
            Object.keys(element.capture_result.face.attributes).length > 0 ? element.capture_result.face.attributes : {'age': '-', 'gender': '-'},
            element.temperature,
            tempStatus,
            element.user_identified_state,
          ]);
        }
      }
      return records;
    },
    checkAll() {
      let all = this.dataTable.rows({search: 'applied'}).count();
      let selectedRows = this.dataTable.rows({search: 'applied', selected: true}).count();

      if (selectedRows < all) {
        this.dataTable.rows().deselect();
        this.dataTable.rows({search: 'applied'}).select();
        this.selected = 2;
      } else {
        this.dataTable.rows().deselect();
        this.selected = 0;
      }
    },
    search() {
      this.dataTable.ajax.reload();
    },
    view(rowData) {
      this.showObject = rowData;
      this.showModal = true;
    },
    async exportData(selected) {
      let vm  = this;
      let selectedRows;
      this.$emit('loading', true);
      if (selected) {
        selectedRows = this.dataTable.rows({search: 'applied', selected: selected});
        vm.baseExport(selectedRows.data(),selected);
      } else {
        vm.getCondition();
        let param  = {
          'time_range.start': moment(vm.timePicker.data('daterangepicker').startDate.toDate()).format('YYYY-MM-DD HH:mm:ss'),
          'time_range.end': moment(vm.timePicker.data('daterangepicker').endDate.toDate()).format('YYYY-MM-DD HH:mm:ss'),
          'task_id':vm.taskArr.toString(),
          'lib_ids':vm.libArr.toString(),
          'user_identified_state':vm.identifyState,
          'temperature_state':vm.temperatureState
        }

        await backend.listCaptureResults(param).then(res => {
          selectedRows = vm.listData(res);
          vm.baseExport(selectedRows.data,selected);
        }).catch(() => {
          this.$toastr.e('message.common_zipFile_result');
        });
      }
    }
  }
};
</script>

<style scoped>
  .box-body {
    min-height: calc(100vh - 163px);
  }
  .ctl-button {
    margin-left: 10px;
  }
  .checkall {
    border: none;
    background: transparent;
    font-size: 16px;
  }
  .portrait {
    text-align: center;
    color: gray;
    margin: 20px;
  }
  .compare {
    text-align: center;
    margin-top: 40px;
  }
  .detail-body tr th {
    width: 120px;
    padding: 3px;
  }
  .detail-body tr td {
    padding: 3px;
    text-align: center;
  }
  .buttonRight{
    margin-right: 10px;
  }
  .selectStyle{
    border-radius:4px;
  }
</style>