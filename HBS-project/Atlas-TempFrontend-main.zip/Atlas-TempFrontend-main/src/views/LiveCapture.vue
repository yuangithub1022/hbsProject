<template>
  <div class="wrapper">
    <PageHeader />
    <PageAside />
    <div class="content-wrapper">
      <section class="content">
        <div class="row">
          <div class="col-xs-12">
            <div class="box box-default">
              <div class="box-header">
                <h4>{{ $t("video.capture") }}</h4>
              </div>
              <div class="box-body">
                <div class="row">
                  <div class="col-xs-11">
                    <select
                      v-model="targetCaptureTasks"
                      v-select2="taskCaptureSelectOption"
                      multiple="multiple"
                      class="form-control select2 selectCaptures"
                      data-placeholder="Select Devices"
                      style="width: 100%;"
                      @change="changeLiveTasks"
                    >
                      <option
                        v-for="item of tasks"
                        :key="item.task_id"
                        :value="item.task_id"
                        :data-type="item.source.type"
                      >
                        {{ item.extra_info.task_name }}
                      </option>
                    </select>
                  </div>
                  <button
                    class="btn btn-primary selectButton"
                    title="Select All"
                    @click="selectCaptures"
                  >
                    <i class="fa fa-check" />
                  </button>
                </div>
                <div class="row">
                  <div class="col-xs-12">
                    <div class="row live-results">
                      <div
                        v-for="item in filteredCaptures"
                        :key="item.id"
                        :class="calcLiveStyle().cssResult"
                      >
                        <div class="databox-taskname">
                          <p>{{ item.task_name }}</p>
                        </div>
                        <div class="row">
                          <font-awesome-icon
                            v-if="item.user_capture_image === ''"
                            icon="user"
                            class="normalTemperature"
                            :class="{'color': item.user_temperature_status}"
                            width="200px"
                            height="200px"
                          />
                          <img
                            v-else
                            :src="item.user_capture_image"
                            width="200px"
                            height="200px"
                          >
                        </div> 
                        <div
                          class="row"
                          style="text-align:center;"
                        >
                          <span
                            v-if="item.user_temperature_status === 'green'"
                            class="label label-success textStyle"
                          >&nbsp;</span>
                          <span
                            v-else-if="item.user_temperature_status === 'red'"
                            class="label label-danger textStyle"
                          >&nbsp;</span>
                          <span
                            v-else
                            class="label label-default textStyle"
                          >&nbsp;</span>
                        </div>
                        <div
                          class="row"
                          style="text-align:left;"
                        >
                          <div class="showMessage">
                            <span>ID：{{ item.user_card_id }}</span><br>
                            <span>Name：{{ item.user_name }}</span><br>
                            <span v-if="item.user_temperature !== ''">Temperature：<font :color="item.user_temperature_status"><b>{{ item.user_temperature }} °C</b></font></span><br v-if="item.user_temperature !== ''">
                            <span>Time：{{ item.user_capture_time }}</span>
                          </div>
                        </div> 
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  </div>
</template>

<script>
import io from 'socket.io-client';
import backend from '../api/backend';
import * as moment from 'moment';

import PageHeader from '../components/PageHeader';
import PageAside from '../components/PageAside';

export default {
  name: 'LiveCapture',
  components: {
    PageHeader,
    PageAside
  },
  filters:{
    identifiedCheck(value) {
      if (value === "T") {
        return "Success";
      }else if (value === "F") {
        return "Failure";
      } else {
        return 'Unknown';
      }
    }
  },
  data() {
    return {
      user: this.$root.userData,
      tasks: [],
      libraries: [],
      filteredCaptures: [],
      targetCaptureTasks: [],
      socket: null,
      taskCaptureSelectOption: {
        allowClear: true,
        maximumSelectionLength: 20,
        containerCss: {'height': '32px', 'overflow-y': 'auto'}
      },
      timerObj:{}
    };
  },
  created() {
    let vm = this;
    if (!vm.user) {
      vm.$router.push({ path: "/login" });
    }
  },
  mounted: async function() {
    let vm = this;
    // init websocket client
    vm.connectWebsocket();
    // Get All tasks (status===OK)
    await backend.taskList({'page_request.offset': 0, 'page_request.limit': 100}).then(res =>{
      if (res.data.tasks) {
        if(this.$root.userData.license === this.GLOBAL.base) {
          let running = res.data.tasks.filter(element => {
            if (element.source.type === 'FC_SENSEPASS' && element.status.status === 'OK') return true;
          });
          if (running.length > 0) {
            vm.tasks = vm.tasks.concat(running);
          }
        } else if(this.$root.userData.license === this.GLOBAL.standard) {
          let running = res.data.tasks.filter(element => {
            if (element.source.type !== 'VN_RTSP' && element.status.status === 'OK') return true;
          });
          if (running.length > 0) {
            vm.tasks = vm.tasks.concat(running);
          }
        } else {
          let running = res.data.tasks.filter(element => {
            if (element.status.status === 'OK') return true;
          });
          if (running.length > 0) {
            vm.tasks = vm.tasks.concat(running);
          }
        }
      } 
    });
  },
  beforeDestroy() {
    this.disconnectWebsocket();
  },
  methods: {
    selectCaptures() {
      const vm = this;
      const aArray = [];
      this.filteredCaptures = [];
      this.timerObj = {};
      $(".selectCaptures option").each(function() {
        aArray.push($(this).val());
        let _taskname = $(this).text();
        let _tasktype = $(this).attr('data-type');
        vm.initTaskBox($(this).val(), _taskname,_tasktype);
      })
      const captureSelector = $(".selectCaptures");
      captureSelector.val(aArray);
      vm.targetCaptureTasks = aArray;
      captureSelector.trigger("change");
    },    
    connectWebsocket() {
      let vm = this;
      vm.socket = io('/message', {path: '/backend/socket.io'});
      vm.socket.on('notify', (message) => {
        if (message.data) {
          vm.receiveMessage(message.data);
        }
      });
    },
    receiveMessage(data) {
      const vm = this;
      let devices_data;
      
      if (data.device_status) {
        devices_data = data.device_status;
      }
      if (devices_data === undefined) {
        return;
      }
      for (const value of Object.keys(devices_data)) {
        let device_data = devices_data[value];
        let _record = device_data.record;
        if (_record === undefined) {
          return;
        }        
        let _task_name = device_data.extra_info ? device_data.extra_info.task_name : '--';
        if (_task_name === undefined) {
          return;
        }
        let _user_identified_state = device_data.record.user_identified_state;
        let _user_card_id = device_data.record.user_card_id;
        let _user_name = device_data.record.user_name;

        let _temperature = device_data.record.temperature;
        let _temperature_status = device_data.record.temperature_state;
        
        let _Base64image = device_data.record.capture_image;
        let _capture_time = device_data.record.capture_time;
        let _task_id = device_data.record.task_id; 
        vm.filteredCaptures.forEach(element => {
          if (element.task_id ===  _task_id) {
            if (_user_identified_state !== undefined && _user_identified_state === 'T') {
              element.user_show = true;
              element.user_identified_state = _user_identified_state;
            }else if (_user_identified_state !== undefined && _user_identified_state === 'F') {
              element.user_show = false;
              element.user_identified_state = _user_identified_state;
            }
            if (_user_card_id !== undefined) {
              element.user_card_id = _user_card_id;
            }
            if (_user_name !== undefined) {
              element.user_name = _user_name;
            }
            if (_temperature !== undefined) {
              element.user_temperature = _temperature;
            }
            if (_temperature_status !== undefined && _temperature_status === '1') {
              element.user_temperature_status = "green";
            }else if (_temperature_status  !== undefined && _temperature_status === '2') {
              element.user_temperature_status = "red";
            }else{
              element.user_temperature_status = "gray";
            }
            if (_Base64image !== undefined && _Base64image !== '') {
              element.user_capture_image = "data:image/png;base64," + _Base64image ;
            }
            if (_capture_time !== undefined) {
              element.user_capture_time = moment(parseInt(_capture_time)).format('YYYY-MM-DD HH:mm:ss');
            }


            if(this.timerObj[_task_id].timer !== null) {
              clearTimeout(this.timerObj[_task_id].timer);
              this.timerObj[_task_id].timer = null;
            }

            this.timerObj[_task_id].timer = setTimeout(function() {
              element.user_identified_state = "";
              element.user_show = true;
              element.user_card_id = "--";
              element.user_name = "--";
              if(element.task_type !== 'FC_SENSEPASS') {
                element.user_temperature = "-";
              }else{
                element.user_temperature = "";
              }
              element.user_temperature_status = 'gray';
              element.user_capture_time = '--';
              element.user_capture_image = '';
            },5000);
                
          }
        })        
      }
    },
    disconnectWebsocket() {
      if (this.socket) {
        this.socket.disconnect();
      }
    },
    changeLiveTasks() {
      let vm = this;
      this.filteredCaptures = [];
      this.timerObj = {}
      $(".selectCaptures option:selected").each(function() {
        let _taskId = $(this).val();
        let _taskName = $(this).text();
        let _tasktype = $(this).attr('data-type');
        vm.initTaskBox(_taskId, _taskName,_tasktype);
      })
    },
    initTaskBox(taskId,taskName,taskType) {
      let vm = this;
      let item = {
        task_id: taskId,
        task_name: taskName,
        task_type:taskType,
        user_identified_state: "",
        user_show: true,
        user_card_id: "--",
        user_name: "--",
        
        user_temperature_status: 'black',
        user_capture_time: '--',
        user_capture_image: ''
      };
      if(taskType !== 'FC_SENSEPASS') {
        item.user_temperature = "-";
      } else{
        item.user_temperature = "";
      }
      vm.filteredCaptures.push(item);
      this.timerObj[taskId] = {timer:null };
    },
    calcLiveStyle() {
      if (this.filteredCaptures) {
        let num = this.filteredCaptures.length;
        let result = {}
        switch(num) {
        case 1:
          result.cssResult = 'col-xs-12';
          break;
        case 2:
          result.cssResult = 'col-xs-6';
          break;
        case 3:
          result.cssResult = 'col-xs-4';
          break;
        case 4:
        case 5:
        case 6:
        case 7:
        case 8:
          result.cssResult = 'col-xs-3';
          break;
        default:
          break;
        } 
        return result;
      }
    }
  },
};
</script>

<style scoped>
  .box {
    margin-bottom: 0;
  }
  .box-body {
    height: 100%;
  }
  .databox-img img{
    width: 100%;
    height: 100%;
  }
  .live-results {
    text-align: center;
    font-size: 1em;
  }
  .databox-taskname {
    margin-top:20px;
    font-size: 20px;
    text-align: center;
  }
  .selectButton{
    margin-left: 10px;
  }
  .normalTemperature{
    font-size: 200px;
  }
  .textStyle{
    display: block;
    width: 200px;
    margin: 10px auto;
  }
  .showMessage{
    width:200px;
    display: block;
    margin: 0 auto;
    padding-left: 10px;
  }
</style>
