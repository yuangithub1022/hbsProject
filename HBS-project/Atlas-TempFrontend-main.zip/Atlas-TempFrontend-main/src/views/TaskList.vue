<template>
  <div class="wrapper">
    <PageHeader />
    <PageAside />
    <div class="content-wrapper">
      <section class="content">
        <div class="box box-default" v-if="user.license === GLOBAL.advanced">
          <div class="box-header">
            <h4>{{ $t("task.mps") }}</h4>
          </div>
          <div class="box-body">
            <table
              id="mps-tasks"
              class="table table-bordered table-striped"
              width="100%"
            >
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.url") }}</th>
                  <th>{{ $t("task.score") }}</th>
                  <th>{{ $t("task.library") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th>{{ $t("task.roi") }}</th>
                  <th>{{ $t("task.tmode") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody />
            </table>
          </div>
        </div>
        <div class="box box-default">
          <div class="box-header">
            <h4>{{ $t("task.acs") }}</h4>
          </div>
          <div class="box-body">
            <table
              id="acs-tasks"
              class="table table-bordered table-striped"
              width="100%"
            >
              <thead>
                <tr>
                  <th>{{ $t("task.id") }}</th>
                  <th>{{ $t("task.name") }}</th>
                  <th>{{ $t("task.stype") }}</th>
                  <th>{{ $t("task.device") }}</th>
                  <th>{{ $t("task.score") }}</th>
                  <th>{{ $t("task.library") }}</th>
                  <th>{{ $t("task.created") }}</th>
                  <th>{{ $t("task.status") }}</th>
                  <th>{{ $t("common.action") }}</th>
                </tr>
              </thead>
              <tbody />
            </table>
          </div>
        </div>
        <PageModal
          :show.sync="showModal"
          :footer="editable"
        >
          <div slot="header">
            <span v-if="showObject.task_id && editable">{{ $t("common.edit") }} ({{ showObject.extra_info.task_name }})</span>
            <span v-if="showObject.task_id && !editable">{{ $t("common.detail") }} ({{ showObject.extra_info.task_name }}) </span>
            <span v-if="!showObject.task_id && editable">{{ $t("common.create") }} </span>
          </div>
          <div slot="body">
            <form
              v-if="showObject.task"
              class="form-horizontal"
            >
              <div class="modal-form">
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.name") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      v-model="showObject.extra_info.task_name"
                      type="text"
                      class="form-control"
                      placeholder="Device Name"
                      :disabled="!editable"
                    >
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='FC_SENSEPASS' && user.license !== GLOBAL.base"
                  class="form-group"
                >
                  <label class="col-sm-3 control-label">
                    {{ $t("task.sourceType") }}
                  </label>
                  <div class="col-sm-9">
                    <select
                      v-model="showObject.temperatureDevice"
                      class="form-control"
                      :disabled="!editable || !itemEditable"
                      @change="changeLibSelectTypeFromTempture"
                    >
                      <option value="1">
                        あり
                      </option>
                      <option value="2" v-if="user.license === GLOBAL.advanced">
                        なし
                      </option>
                    </select>
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='FC_SENSEPASS' && showObject.temperatureDevice ==='1'"
                  class="form-group"
                >
                  <label class="col-sm-3 control-label">
                    {{ $t("task.password") }}
                  </label>
                  <div class="col-sm-9">
                    <input
                      v-model="showObject.password"
                      type="password"
                      class="form-control"
                      placeholder="Device Password"
                      :disabled="!editable"
                    >
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='FC_SENSEPASS' && showObject.temperatureDevice ==='1'"
                  class="form-group"
                >
                  <label class="col-sm-3 control-label">
                    {{ $t("task.address") }}
                  </label>
                  <div class="col-sm-9">
                    <input
                      v-model="showObject.extra_info.address"
                      type="text"
                      class="form-control"
                      placeholder="Device Address and Port"
                      :disabled="!editable || !itemEditable"
                    >
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='FC_SENSEPASS' && showObject.temperatureDevice ==='1'"
                  class="form-group"
                >
                  <label class="col-sm-3 control-label">
                    {{ $t("task.maker") }}
                  </label>
                  <div class="col-sm-9">
                    <select
                      v-model="showObject.maker"
                      class="form-control"
                      :disabled="!editable || !itemEditable"
                    >
                      <option value="1">
                        maker-1
                      </option>
                      <option value="2">
                        iFly
                      </option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-3 control-label">
                    {{ $t("task.stype") }}
                  </label>
                  <div class="col-sm-9">
                    <select
                      v-model="showObject.source.type"
                      class="form-control"
                      :disabled="!editable"
                    >
                      <option
                        v-if="showObject.source.type==='FC_SENSEPASS'"
                        value="FC_SENSEPASS"
                      >
                        TABLET CAMERA
                      </option>
                      <option
                        v-if="showObject.source.type==='VN_RTSP'"
                        value="VN_RTSP"
                      >
                        RTSP CAMERA
                      </option>
                    </select>
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='VN_RTSP'"
                  class="form-group"
                >
                  <label class="col-sm-3 control-label">
                    {{ $t("task.tmode") }}
                  </label>
                  <div class="col-sm-9">
                    <select
                      v-model="showObject.task.parameter.face.track_mode"
                      class="form-control"
                      :disabled="!editable"
                    >
                      <option value="VIDEO_TRACK_MODE_ENTER">
                        {{ $t("task.mode_enter") }}
                      </option>
                      <option value="VIDEO_TRACK_MODE_OPTIMAL">
                        {{ $t("task.mode_optimal") }}
                      </option>
                      <option value="VIDEO_TRACK_MODE_PERIODIC">
                        {{ $t("task.mode_periodic") }}
                      </option>
                    </select>
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='FC_SENSEPASS'"
                  class="form-group"
                >
                  <label class="col-xs-3 control-label">
                    {{ $t("task.device") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      v-model="showObject.source.parameter.sensepass.device_sn"
                      type="text"
                      class="form-control"
                      placeholder="Device SN"
                      :disabled="!editable || !itemEditable"
                    >
                  </div>
                </div>
                <div
                  v-if="showObject.source.type==='VN_RTSP'"
                  class="form-group"
                >
                  <label class="col-xs-3 control-label">
                    {{ $t("task.url") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      v-model="showObject.source.parameter.rtsp.url"
                      type="text"
                      class="form-control"
                      placeholder="RTSP URL"
                      :disabled="!editable"
                    >
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.score") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      v-model="showObject.task.parameter.face.min_score"
                      type="number"
                      step="0.01"
                      class="form-control"
                      placeholder="Min Score"
                      :disabled="!editable"
                    >
                  </div>
                </div>
                <div class="form-group" v-if="user.license !== GLOBAL.base">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.libraryState") }}
                  </label>
                  <div class="col-xs-9">
                    <select
                      v-model="showObject.libraryState"
                      class="form-control"
                      data-placeholder="Select libraryState"
                      style="width: 100%;"
                      :disabled="!editable"
                      @change="changeLibSelectType"
                    >
                      <option value="Y">
                        有効
                      </option>
                      <option
                        v-if="showObject.source.type==='FC_SENSEPASS' && showObject.temperatureDevice === '1'"
                        value="N"
                      >
                        無効
                      </option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="user.license !== GLOBAL.base">
                  <label class="col-xs-3 control-label">
                    {{ $t("task.library") }}
                  </label>
                  <div class="col-xs-9">
                    <select
                      id="id_array"
                      v-model="showObject.task.parameter.face.id_array"
                      v-select2
                      :disabled="!editable || selectLibType"
                      class="form-control select2 select2Option"
                      multiple="multiple"
                      data-placeholder="Select Libraries"
                      style="width: 100%;"
                    >
                      <option
                        v-for="item of libraries"
                        :key="item.id"
                        :value="item.id"
                      >
                        {{ item.name }}
                      </option>
                    </select>
                  </div>
                </div>
                <div class="form-group" v-if="user.license !== GLOBAL.base">
                  <label class="col-sm-3 control-label">
                    {{ $t("task.otype") }}
                  </label>
                  <div class="col-sm-9">
                    <select
                      v-model="showObject.extra_info.output_type"
                      class="form-control"
                      :disabled="!editable || selectLibType"
                    >
                      <option value="NONE">
                        NONE
                      </option>
                      <option value="RS-485">
                        RS-485
                      </option>
                      <option value="RS-232">
                        RS-232
                      </option>
                    </select>
                  </div>
                </div>
                <div
                  v-if="user.license !== GLOBAL.base && showObject.extra_info.output_type!=='NONE'"
                  class="form-group"
                >
                  <label class="col-xs-3 control-label">
                    {{ $t("task.ovalue") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      v-model="showObject.extra_info.output_value"
                      type="text"
                      class="form-control"
                      placeholder="Output Value"
                      :disabled="!editable || selectLibType"
                    >
                  </div>
                </div>
                <div
                  v-if="showObject.task_id && !editable"
                  class="form-group"
                >
                  <label class="col-xs-3 control-label">
                    {{ $t("task.status") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      v-if="showObject.status"
                      type="text"
                      class="form-control"
                      :value="showObject.status.status"
                      disabled
                    >
                  </div>
                </div>
                <div
                  v-if="showObject.task_id && !editable"
                  class="form-group"
                >
                  <label class="col-xs-3 control-label">
                    {{ $t("task.created") }}
                  </label>
                  <div class="col-xs-9">
                    <input
                      type="text"
                      class="form-control"
                      :value="showObject.create_time"
                      disabled
                    >
                  </div>
                </div>
              </div>
            </form>
          </div>
          <div slot="footer">
            <button
              class="btn btn-default pull-left"
              @click="showModal=false"
            >
              {{ $t("common.cancel") }}
            </button>
            <button
              class="btn btn-primary pull-right"
              @click="updateTask"
            >
              {{ $t("common.ok") }}
            </button>
          </div>
        </PageModal>

        <PageModal
          :show.sync="showSetDialog"
          :footer="true"
        >
          <div slot="header">
            <span>{{ $t("common.set") }} </span>
          </div>
          <div slot="body">
            <div class="col-sm-12">
              <form class="form-horizontal">
                <div class="modal-form">
                  <div class="form-group">
                    <label class="col-sm-3 control-label">
                      {{ $t("task.base") }}
                    </label>
                    <div class="col-sm-9">
                      <textarea
                        v-model="baseStr"
                        rows="10"
                        placeholder="Device config"
                        class="col-sm-12"
                      />
                    </div>
                  </div>
                </div>
              </form>
            </div>
          </div>
          <div slot="footer">
            <button
              class="btn btn-default pull-left"
              @click="showSetDialog=false"
            >
              {{ $t("common.cancel") }}
            </button>
            <button
              class="btn btn-primary pull-right"
              @click="updateSetting"
            >
              {{ $t("common.ok") }}
            </button>
          </div>
        </PageModal>

        <PageModal
          :show.sync="showRoiDialog"
          :footer="true"
        >
          <div slot="header">
            <span v-if="showObject.extra_info">{{ $t("common.roi") }} ({{ showObject.extra_info.task_name }}) </span>
          </div>
          <div slot="body">
            <v-stage
              ref="stage"
              :config="roiStageConfig"
            >
              <v-layer ref="layer">
                <v-image :config="roiImageConfig" />
                <v-rect
                  ref="rectangle"
                  :config="roiRectConfig"
                  @transform="handleRectChange"
                />
                <v-transformer
                  ref="transformer"
                  :config="roiTransformerConfig"
                />
              </v-layer>
            </v-stage>
            <div class="desc">
              <p class="text-muted">
                {{ $t("message.task_roi_description") }}
              </p>
              <p class="text-muted">
                {{ $t("message.task_roi_currentvalue") }}
                <span v-if="showObject.task && showObject.task.parameter.face.roi">
                  {{ showObject.task.parameter.face.roi.vertices }}
                </span>
              </p>
            </div>
          </div>
          <div slot="footer">
            <button
              class="btn btn-default pull-left"
              @click="showRoiDialog=false"
            >
              {{ $t("common.cancel") }}
            </button>
            <button
              class="btn btn-primary pull-right"
              @click="updateTask"
            >
              {{ $t("common.ok") }}
            </button>
          </div>
        </PageModal>
      </section>
    </div>
  </div>
</template>

<script>
import * as moment from 'moment';
import api from '../api/api';
import backend from '../api/backend';

import PageHeader from '../components/PageHeader';
import PageAside from '../components/PageAside';
import PageModal from '../components/PageModal';

export default {
  name: 'TaskList',
  components: {
    PageHeader,
    PageAside,
    PageModal
  },
  data() {
    return {
      user: this.$root.userData,
      libraries: [],
      showModal: false,
      showObject: {},
      showSetDialog: false,
      editable: false,
      itemEditable: false,
      dataTableAcs: null,
      bodyObj:{},
      refresher:null,
      selectLibType:false,
      baseStr:'{}',
      showRoiDialog: false,
      roiStageConfig: {width: 560, height: 315},
      roiImageConfig: {x: 0, y: 0, image: null},
      roiRectConfig: null,
      roiTransformerConfig: null,
      roiScaleRatio: 1,
    };
  },
  created() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
  },
  async mounted() {
    const vm = this;

    if (this.GLOBAL.base!== this.$root.userData.license) {
      try {
        const res = await api.dBList({});
        vm.libraries = res.data.databases;
      } catch(err) {
        vm.libraries = [];
      }
    }

    // ACS DEVICES

    vm.dataTableAcs = $('#acs-tasks').DataTable({
      paging: true,
      pageLength: 10,
      lengthChange: false,
      searching: false,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [],
      dom: 'Bfrtip',
      buttons: [
        {
          text: vm.$i18n.t('common.create'),
          className: 'btn btn-primary',
          init(api, node) {
            $(node).removeClass('dt-button');
          },
          action() {
            if(vm.dataTableAcs.data().length >= 8) {
              vm.$toastr.e(vm.$i18n.t('message.task_morethan_failure'));
              return;
            }
            vm.showObject = {
              source: {type: 'FC_SENSEPASS', parameter: {sensepass: {device_sn: ''}}},
              task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: 0.8, id_array: []}}},
              extra_info: {task_name: '', output_type: 'NONE', output_value: '', min_score: ''},
              libraryState:'Y',
              maker: '1',
              temperatureDevice: '1'
            };

            vm.selectLibType = vm.showObject.libraryState === 'N';
            vm.editable = true;
            vm.itemEditable  = true;
            vm.showModal = true;
          }
        }
      ],
      columnDefs: [
        {
          orderable: false,
          targets: [1, 5, -1]
        },
        {
          targets: [0],
          visible: false,
          searchable: false
        },
        {
          targets: 1,
          render(url, type, row) {
            return row[1].task_name;
          }
        },
        {
          targets: 2,
          render(url, type, row) {
            if(row[2] === 'VN_RTSP') {
              return 'RTSP CAMERA';
            }else{
              return 'TABLET CAMERA';
            }
          }
        },
        {
          targets: 5,
          render(url, type, row) {
            return vm.renderLibraries(row[5]);
          }
        },
        {
          targets: -1,
          render(url, type, row) {
            if(row[10]) {
              return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;'
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;'
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                      + vm.$i18n.t('common.delete') + '</a>'
                      + '<a class="btn btn-info btn-xs deleteRecord" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                      + vm.$i18n.t('common.deleteRecord') + '</a>'
                      + '<a class="btn btn-info btn-xs reset" style="margin-right:10px"><i class="fa fa-power-off"></i>&nbsp;'
                      + vm.$i18n.t('common.reset') + '</a>'
                      + '<a class="btn btn-info btn-xs resetTime" style="margin-right:10px"><i class="fa fa-power-off"></i>&nbsp;'
                      + vm.$i18n.t('common.resetTime') + '</a>'
                      + '<a class="btn btn-info btn-xs set" style="margin-right:10px"><i class="fa fa-gears"></i>&nbsp;'
                      + vm.$i18n.t('common.set') + '</a>';
            } else {
              return '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;'
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;'
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                      + vm.$i18n.t('common.delete') + '</a>'
                      + '<a class="btn btn-info btn-xs deleteRecord" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                      + vm.$i18n.t('common.deleteRecord') + '</a>';
            }
          }
        }
      ],
      ajax(data, callback) {
        backend.taskList({'page_request.offset': data.start, 'page_request.limit': data.length})
          .then(res => {
            const result = res.data;
            const records = {draw: new Date().getTime(), data: []};
            if (result.tasks.length >= 0) {
              let faceDeviceCount = 0;
              if(vm.$root.userData.license === vm.GLOBAL.base) {
                result.tasks.forEach(element => {
                  if(element.source.type === 'FC_SENSEPASS') {
                    faceDeviceCount++;
                    records.data.push([
                      element.task_id,
                      element.extra_info,
                      element.source.type,
                      element.source.parameter.sensepass.device_sn,
                      element.task.parameter.face.min_score,
                      element.task.parameter.face.id_array === '' ? []: element.task.parameter.face.id_array,
                      moment(element.create_time).format('YYYY-MM-DD HH:mm:ss'),
                      element.status.status,
                      element.password,
                      element.maker,
                      element.measure_temp,
                    ]);
                  }
                });
              }else {
                result.tasks.forEach(element => {
                  if(element.source.type !== 'VN_RTSP') {
                    faceDeviceCount++;
                    records.data.push([
                      element.task_id,
                      element.extra_info,
                      element.source.type,
                      element.source.parameter.sensepass.device_sn,
                      element.task.parameter.face.min_score,
                      element.task.parameter.face.id_array === '' ? []: element.task.parameter.face.id_array,
                      moment(element.create_time).format('YYYY-MM-DD HH:mm:ss'),
                      element.status.status,
                      element.password,
                      element.maker,
                      element.measure_temp,
                    ]);
                  }
                });
              }
              records.recordsTotal = faceDeviceCount;
              records.recordsFiltered = faceDeviceCount;
            }
            callback(records);
          }).catch(() => {
            callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
          });
      }
    });
    vm.dataTableAcs.on('click', '.detail', async function() {
      const rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
      vm.showObject = {
        task_id: rowData[0],
        source: {type: rowData[2] !== 'VN_RTSP'?'FC_SENSEPASS':'VN_RTSP', parameter: {sensepass: {device_sn: rowData[3]}}},
        task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: rowData[4], id_array: rowData[5]}}},
        extra_info: rowData[1],
        create_time: rowData[6],
        status: {status: rowData[7]},
        libraryState:rowData[5].length > 0 ? 'Y':'N',
        password: rowData[8],
        maker: rowData[9],
        temperatureDevice: (vm.$root.userData.license === vm.GLOBAL.base || rowData[10])? '1':'2'
      };
      vm.editable = false;
      vm.showModal = true;
    });
    vm.dataTableAcs.on('click', '.edit', function() {
      const rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
      vm.showObject = {
        task_id: rowData[0],
        source: {type: rowData[2] !== 'VN_RTSP'?'FC_SENSEPASS':'VN_RTSP', parameter: {sensepass: {device_sn: rowData[3]}}},
        task: {type: 'TASK_TYPE_FACE', parameter: {face: {min_score: rowData[4], id_array: rowData[5]}}},
        extra_info: rowData[1],
        libraryState:rowData[5].length > 0? 'Y':'N',
        password: rowData[8],
        maker: rowData[9],
        temperatureDevice: (vm.$root.userData.license === vm.GLOBAL.base || rowData[10])? '1':'2'
      };
      vm.selectLibType = vm.showObject.libraryState === 'N';
      vm.editable = true;
      vm.itemEditable = false;
      vm.showModal = true;
    });
    vm.dataTableAcs.on('click', '.delete', function() {
      let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();

      if (confirm("Are you sure to delete this task?")) {
        vm.$emit('loading', true);
        backend.taskDelete(rowData[0]).then(res => {
          if(res.data.code !== 0) {
            vm.$toastr.e(res.data.msg);
          }else{
            vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
            vm.dataTableAcs.ajax.reload();
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err);
          vm.$emit('loading', false);
        });
      }
    });

    vm.dataTableAcs.on('click', '.reset', function() {
      const rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
      const params  = {
        'dev_id': rowData[0]
      };

      if (confirm("Are you sure to restart the device?")) {
        vm.$emit('loading', true);
        backend.resetDevice(params).then(res => {
          if (res.data.code === 0 ) {
            vm.$toastr.s(vm.$i18n.t("message.task_resetDevice_success"));
          } else if (res.data.code === 1 ) {
            vm.$toastr.i(res.data.msg);
          } else {
            vm.$toastr.e(res.data.msg);
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t("message.task_resetDevice_failure")+ '<br>' + err);
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTableAcs.on('click', '.deleteRecord', function() {
      const rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
      const params = {
        'dev_id': rowData[0]
      };
      if (confirm("Are you sure to delete all records?")) {
        vm.$emit('loading', true);
        backend.handleDeleteRecords(params).then(res => {
          if (res.data.code === 0 ) {
            vm.$toastr.s(vm.$i18n.t("message.task_deleteRecord_success"));
          } else {
            vm.$toastr.e(res.data.msg);
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t("message.task_deleteRecord_failure")+ '<br>' + err);
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTableAcs.on('click', '.resetTime', function() {
      let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
      let param  = {
        'dev_id': rowData[0]
      };
      if (confirm("Are you sure to reset device time?")) {
        vm.$emit('loading', true);
        backend.resetDeviceTime(param).then(res => {
          if(res.data.code === 0) {
            vm.$toastr.s(vm.$i18n.t("message.task_resetTime_success"));
          }else{
            vm.$toastr.e(res.data.msg);
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t("message.task_resetTime_failure")+ '<br>' + err);
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTableAcs.on('click', '.set', function() {
      let rowData = vm.dataTableAcs.row($(this).parents('tr')).data();
      vm.bodyObj.device_id = rowData[0]
      vm.showSetDialog = true;

      backend.getTaskConfig(vm.bodyObj.device_id).then(res => {
        if(res.data.code === 0) {
          vm.baseStr = JSON.stringify(res.data.data.data, undefined, 4);
        }else{
          vm.$toastr.e(res.data.msg);
        }
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.task_getConfig_failure') + '<br>' + err);
      });
    });


    // MPS DEVICES
    vm.dataTableMps = $('#mps-tasks').DataTable({
      paging: true,
      pageLength: 10,
      lengthChange: false,
      searching: false,
      ordering: false,
      responsive: true,
      info: true,
      autoWidth: true,
      serverSide: true,
      order: [],
      dom: 'Bfrtip',
      buttons: [
        {
          text: vm.$i18n.t('common.create'),
          className: 'btn btn-primary',
          init(api, node) {
            $(node).removeClass('dt-button');
          },
          action() {
            vm.showObject = {
              source: {type: 'VN_RTSP', parameter: {rtsp: {url: ''}}},
              task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: 'VIDEO_TRACK_MODE_ENTER', min_score: 0.8, id_array: []}}},
              extra_info: {task_name: '', output_type: 'NONE', output_value: '', min_score: 0},
              libraryState:'Y',
              //maker: '1'
            };

            vm.selectLibType = vm.showObject.libraryState === 'N';
            vm.editable = true;
            vm.itemEditable = true;
            vm.showModal = true;
          }
        }
      ],
      columnDefs: [
        {
          orderable: false,
          targets: [1, 5, -1]
        },
        {
          targets: [0, 3, 8, 9],
          visible: false,
          searchable: false
        },
        {
          targets: 1,
          render(url, type, row) {
            return row[1].task_name;
          }
        },
        {
          targets: 2,
          render(url, type, row) {
            if(row[2] === 'VN_RTSP') {
              return 'RTSP CAMERA';
            }else{
              return 'TABLET CAMERA';
            }
          }
        },
        {
          targets: 5,
          render(url, type, row) {
            return vm.renderLibraries(row[5]);
          }
        },
        {
          targets: -1,
          data: null,
          defaultContent: '<a class="btn btn-info btn-xs detail" style="margin-right:10px"><i class="fa fa-eye"></i>&nbsp;'
                      + vm.$i18n.t('common.detail') + '</a>'
                      + '<a class="btn btn-info btn-xs edit" style="margin-right:10px"><i class="fa fa-pencil"></i>&nbsp;'
                      + vm.$i18n.t('common.edit') + '</a>'
                      + '<a class="btn btn-info btn-xs delete" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                      + vm.$i18n.t('common.delete') + '</a>'
                      + '<a class="btn btn-info btn-xs deleteRecord" style="margin-right:10px"><i class="fa fa-remove"></i>&nbsp;'
                      + vm.$i18n.t('common.deleteRecord') + '</a>'
                      + '<a class="btn btn-info btn-xs roi"><i class="fa fa-gears"></i>&nbsp;'
                      + vm.$i18n.t('common.roi') + '</a>'
        }
      ],
      ajax(data, callback) {
        backend.taskList({'page_request.offset': data.start, 'page_request.limit': data.length})
          .then(res => {
            const result = res.data;
            const records = {draw: new Date().getTime(), data: []};
            if (result.tasks.length >= 0) {
              let videoDeviceCount = 0;
              result.tasks.forEach(element => {
                if(element.source.type === 'VN_RTSP') {
                  videoDeviceCount++;
                  records.data.push([
                    element.task_id,
                    element.extra_info,
                    element.source.type,
                    element.source.parameter.rtsp.url,
                    element.task.parameter.face.min_score,
                    element.task.parameter.face.id_array === ''? [] : element.task.parameter.face.id_array,
                    moment(element.create_time).add(vm.diff, 'seconds').format('YYYY-MM-DD HH:mm:ss'),
                    element.status.status,
                    element.task.parameter.face.roi,
                    element.task.parameter.face.track_mode]);
                }
              });
              records.recordsTotal = videoDeviceCount;
              records.recordsFiltered = videoDeviceCount;
            }
            callback(records);
          }).catch(() => {
            callback({draw: 1, recordsTotal: 0, recordsFiltered:0, data: []});
          });
      }
    });
    vm.dataTableMps.on('click', '.detail', async function() {
      const rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      vm.showObject = {
        task_id: rowData[0],
        source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
        task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
        extra_info: rowData[1],
        libraryState:rowData[5].length > 0 ? 'Y':'N',
        create_time: rowData[6],
        status: {status: rowData[7]}
      };
      vm.editable = false;
      vm.showModal = true;
    });
    vm.dataTableMps.on('click', '.edit', function() {
      const rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      vm.showObject = {
        task_id: rowData[0],
        source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
        task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
        extra_info: rowData[1],
        libraryState:rowData[5].length > 0? 'Y':'N',
      };
      vm.selectLibType = vm.showObject.libraryState === 'N';
      vm.editable = true;
      vm.showModal = true;
    });
    vm.dataTableMps.on('click', '.delete', function() {
      const rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      if (confirm("Are you sure to delete this task?")) {
        vm.$emit('loading', true);
        backend.taskDelete(rowData[0]).then(() => {
          vm.$toastr.s(vm.$i18n.t('message.task_delete_success'));
          vm.$emit('loading', false);
          vm.dataTableMps.ajax.reload();
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.task_delete_failure') + '<br>' + err.response.data.message);
          vm.$emit('loading', false);
        });
      }
    });
    vm.dataTableMps.on('click', '.deleteRecord', function() {
      const rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      const params  = {
        'dev_id': rowData[0]
      };
      if (confirm("Are you sure to delete all records?")) {
        vm.$emit('loading', true);
        backend.handleDeleteRecords(params).then(res => {
          if (res.data.code === 0 ) {
            vm.$toastr.s(vm.$i18n.t("message.task_deleteRecord_success"));
          } else {
            vm.$toastr.e(res.data.msg);
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t("message.task_deleteRecord_failure")+ '<br>' + err);
          vm.$emit('loading', false);
        });
      }
    });

    vm.dataTableMps.on('click', '.roi', async function() {
      const rowData = vm.dataTableMps.row($(this).parents('tr')).data();
      vm.showObject = {
        task_id: rowData[0],
        source: {type: rowData[2], parameter: {rtsp: {url: rowData[3]}}},
        task: {type: 'TASK_TYPE_FACE', parameter: {face: {track_mode: rowData[9], min_score: rowData[4], id_array: rowData[5], roi: rowData[8]}}},
        extra_info: rowData[1]
      };
      vm.$emit('loading', true);
      const capture = await backend.getLatestCaptureResult(rowData[0]);

      if (capture.data.code !== 0) {
        vm.$toastr.i(vm.$i18n.t('message.capture_no_result'));
        vm.$emit('loading', false);
        return;
      }
      const image = new window.Image();
      const fixWidth = 560;
      const minRectSize = 50;
      image.src = 'data:image/jpg;base64,'+ capture.data.data;

      image.onload = () => {
        vm.roiScaleRatio = fixWidth / image.width;
        vm.roiImageConfig.image = image;
        vm.roiImageConfig.width = fixWidth;
        vm.roiImageConfig.height = image.height * vm.roiScaleRatio;
        vm.roiStageConfig.width = fixWidth;
        vm.roiStageConfig.height = image.height * vm.roiScaleRatio;
        vm.roiRectConfig = {
          fill: 'green',
          opacity: 0.4,
          stroke: 'black',
          name: 'rect',
          draggable: false
        }

        if (rowData[8] && rowData[8].vertices && rowData[8].vertices.length >= 2) {
          let vertices = rowData[8].vertices;
          vm.roiRectConfig.x = vertices[0].x * vm.roiScaleRatio;
          vm.roiRectConfig.y = vertices[0].y * vm.roiScaleRatio;
          vm.roiRectConfig.width = (vertices[1].x - vertices[0].x) * vm.roiScaleRatio;
          vm.roiRectConfig.height = (vertices[1].y - vertices[0].y) * vm.roiScaleRatio;
        } else {
          vm.roiRectConfig.x = 0;
          vm.roiRectConfig.y = 0;
          vm.roiRectConfig.width = fixWidth;
          vm.roiRectConfig.height = image.height * vm.roiScaleRatio;
        }

        const transformerNode = vm.$refs.transformer.getStage();
        const rectNode = vm.$refs.rectangle.getStage();
        transformerNode.attachTo(rectNode);
        vm.roiTransformerConfig = {
          rotateEnabled: false,
          boundBoxFunc(oldBoundBox, newBoundBox) {
            if (newBoundBox.x < 0) {
              newBoundBox.x = 0;
            }
            if (newBoundBox.y < 0) {
              newBoundBox.y = 0;
            }
            if (newBoundBox.x > vm.roiStageConfig.width - minRectSize) {
              newBoundBox.x = vm.roiStageConfig.width - minRectSize;
            }
            if (newBoundBox.y > vm.roiStageConfig.height - minRectSize) {
              newBoundBox.y = vm.roiStageConfig.height - minRectSize;
            }
            if (newBoundBox.width < minRectSize) {
              newBoundBox.width = minRectSize;
            }
            if (newBoundBox.height < minRectSize) {
              newBoundBox.height = minRectSize;
            }
            if (newBoundBox.x + newBoundBox.width > vm.roiStageConfig.width) {
              newBoundBox.width = vm.roiStageConfig.width - newBoundBox.x;
            }
            if (newBoundBox.y + newBoundBox.height > vm.roiStageConfig.height) {
              newBoundBox.height = vm.roiStageConfig.height - newBoundBox.y;
            }

            return newBoundBox;
          }
        }
      };
      vm.$emit('loading', false);
      vm.showRoiDialog = true;
    });
    this.updateTaskAtatus();

  },
  methods: {
    updateSetting() {
      const vm = this;
      if (!vm.baseStr) {
        vm.$toastr.i(vm.$i18n.t('message.task_baseInput_error'));
        return;
      }

      try {
        vm.bodyObj.base = JSON.parse(vm.baseStr);
      } catch(e) {
        vm.$toastr.i(vm.$i18n.t('message.task_formatInput_error'));
        return;
      }
      vm.$emit('loading', true);
      backend.updateTaskConfig(vm.bodyObj.device_id, vm.baseStr).then(res => {
        if(res.data.code === 0) {
          vm.$toastr.s(vm.$i18n.t('message.task_updateConfig_success'));
          vm.showSetDialog = false;
        }else{
          vm.$toastr.e(res.data.msg);
        }
        vm.$emit('loading', false);
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.task_updateConfig_failure') + '<br>' + err);
        vm.$emit('loading', false);
      });
    },
    changeLibSelectType() {
      const vm = this;
      if(vm.showObject.libraryState === 'N') {
        vm.selectLibType = true;
        vm.showObject.task.parameter.face.id_array = [];
        vm.showObject.extra_info.output_type = 'NONE';
        vm.showObject.extra_info.output_value = '';
        $('.select2Option').val('');
        $(".select2Option").trigger("change");
      }else{
        vm.selectLibType = false;
      }
    },
    changeLibSelectTypeFromTempture() {
      const vm = this;
      if(vm.showObject.temperatureDevice === '2') {
        vm.showObject.libraryState  = 'Y'
        vm.selectLibType = false;
      }
    },
    updateTaskAtatus() {
      const vm = this;

      vm.refresher = setInterval(() => {
        vm.dataTableAcs.ajax.reload();
        vm.dataTableMps.ajax.reload();
      }, 5000);

    },
    updateTask() {
      const vm = this;
      if(vm.$root.userData.license === vm.GLOBAL.base) {
        vm.showObject.extra_info.output_type = 'NONE';
        vm.showObject.extra_info.output_value = '';
      }

      if (!vm.showObject.extra_info.task_name || !vm.showObject.source.type || (vm.user.license !== vm.GLOBAL.base && vm.showObject.libraryState === 'Y' && vm.showObject.task.parameter.face.id_array.length < 1)
          || vm.showObject.task.parameter.face.min_score < 0 || vm.showObject.task.parameter.face.min_score > 1
          || (vm.showObject.source.type === 'FC_SENSEPASS' && !vm.showObject.source.parameter.sensepass.device_sn)
          || (vm.showObject.source.type === 'FC_SENSEPASS' && vm.showObject.temperatureDevice ==='1' && !vm.showObject.extra_info.address)
          || (vm.showObject.source.type === 'FC_SENSEPASS' && vm.showObject.temperatureDevice ==='1' && !vm.showObject.password)
          || (vm.showObject.source.type === 'VN_RTSP' && !vm.showObject.source.parameter.rtsp.url)
          || (vm.user.license !== vm.GLOBAL.base && vm.showObject.extra_info.output_type !== 'NONE' && vm.showObject.extra_info.output_value ==='')) {
        vm.$toastr.i(vm.$i18n.t('message.common_empty_input'));
        return;
      }
      // if(/\s/.test(vm.showObject.extra_info.substream) || /[\\"']/g.test(vm.showObject.extra_info.substream)){
      //   vm.$toastr.i(vm.$i18n.t('message.task_formatStream_error'));
      //   return;
      // }

      // MIN_SCORE will be used by uploadCaptureResult
      vm.showObject.extra_info.min_score = String(vm.showObject.task.parameter.face.min_score);

      if (vm.showObject.source.type === 'FC_SENSEPASS') {
        if (vm.showObject.temperatureDevice ==='1') {
          vm.showObject.source.parameter.sensepass.device_sn = vm.showObject.source.parameter.sensepass.device_sn.trim();
          vm.showObject.extra_info.address = vm.showObject.extra_info.address.trim();

          vm.showObject.measure_temp = true;
        } else if (vm.showObject.temperatureDevice ==='2') {
          vm.showObject.measure_temp = false;
        } else {
          vm.showObject.measure_temp = '';
        }
      }
      vm.$emit('loading', true);

      if (vm.showObject.task_id) {
        backend.taskUpdate(vm.showObject).then(res => {
          if (res.data.code === 0) {
            vm.showModal = false;
            vm.showRoiDialog = false;
            vm.$toastr.s(vm.$i18n.t('message.task_update_success'));
            vm.dataTableAcs.ajax.reload();
            vm.dataTableMps.ajax.reload();
          } else if (res.data.code === 1) {
            vm.showModal = false;
            vm.showRoiDialog = false;
            vm.$toastr.s(res.data.msg);
            vm.dataTableAcs.ajax.reload();
            vm.dataTableMps.ajax.reload();
          } else {
            vm.$toastr.e(res.data.msg);
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$emit('loading', false);
          vm.$toastr.e(vm.$i18n.t('message.task_update_failure') + '<br>' + err.response.data.message);
        });
      } else {
        backend.taskNew(vm.showObject).then(res => {
          if (res.data.code !== 0) {
            vm.$toastr.e(res.data.msg);
          } else {
            vm.showModal = false;
            vm.showRoiDialog = false;
            vm.$toastr.s(vm.$i18n.t('message.task_create_success'));
            if (vm.showObject.source.type === 'FC_SENSEPASS' ) {
              vm.dataTableAcs.ajax.reload();
            } else {
              vm.dataTableMps.ajax.reload();
            }
          }
          vm.$emit('loading', false);
        }).catch(err => {
          vm.$emit('loading', false);
          vm.$toastr.e(vm.$i18n.t('message.task_create_failure') + '<br>' + err.response.data.message);
        });
      }
    },
    handleRectChange() {
      const vm = this;
      const rectNode = vm.$refs.rectangle.getStage();
      const imageWidth = Math.round(vm.roiImageConfig.width / vm.roiScaleRatio);
      const imageHeight = Math.round(vm.roiImageConfig.height / vm.roiScaleRatio);

      let realLx = Math.floor(Math.floor(rectNode.x())/vm.roiScaleRatio);
      if (realLx <= 4) {
        realLx = 0;
      }
      let realLy = Math.floor(Math.floor(rectNode.y())/vm.roiScaleRatio);
      if (realLy <= 4) {
        realLy = 0;
      }
      let realRx = Math.ceil(Math.ceil((rectNode.x() + rectNode.width()*rectNode.scaleX()))/vm.roiScaleRatio);
      if (realRx >= imageWidth - 4) {
        realRx = imageWidth;
      }
      let realRy = Math.ceil(Math.ceil((rectNode.y() + rectNode.height()*rectNode.scaleY()))/vm.roiScaleRatio);
      if (realRy >= imageHeight - 4) {
        realRy = imageHeight;
      }

      vm.showObject.task.parameter.face.roi = {
        vertices: [{x: realLx, y: realLy}, {x: realRx, y: realRy}]
      }
    },
    renderLibraries(id_array) {
      let ret = '';
      id_array.forEach(obj => {
        this.libraries.forEach(element => {
          if(obj === element.id) {
            ret += '<span class="badge bg-light-blue">' + element.name + '</span>';
          }
        })
      });
      return ret;
    }
  }
};
</script>

<style scoped>
  .box-body {
    min-height: 30vh;
  }
  .modal-form {
    margin-top: 15px;
  }
  .desc {
    margin-top: 20px;
  }
</style>
