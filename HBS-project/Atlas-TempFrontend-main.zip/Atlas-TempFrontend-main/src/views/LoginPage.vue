<template>
  <div class="login-box">
<!--    <h1 class="text-center" style="color: #3c8dbc; font-weight: bolder">Neusoft</h1>-->
<!--    <h4 class="text-center font-weight-bold">-->
<!--      サインインしてください-->
<!--    </h4>-->
    <div class="login-box-body">
      <div
        v-show="errMsg"
        class="alert alert-danger"
        role="alert"
      >
        {{ errMsg }}
      </div>

      <div class="text-center" style="font-size: 100px;">
        <font-awesome-icon class="text-center" icon="user-circle" />
      </div>

      <form @submit.prevent="login">
        <div class="form-group has-feedback">
          <input
            v-model="user"
            type="text"
            class="form-control"
            placeholder="User Name"
            required=""
          >
          <span class="glyphicon glyphicon-user form-control-feedback" />
        </div>
        <div class="form-group has-feedback">
          <input
            v-model="password"
            type="password"
            class="form-control"
            placeholder="Password"
            required=""
          >
          <span class="glyphicon glyphicon-lock form-control-feedback" />
        </div>

        <button
          type="submit"
          class="btn btn-primary btn-block btn-flat"
        >
          Sign In
        </button>
      </form>
    </div>
  </div>
</template>

<script>
import * as util from '../assets/js/util';
import backend from '../api/backend';

export default {
  name: 'LoginPage',
  data() {
    return {
      user: '',
      password: '',
      errMsg: '',
      publicPath: process.env.BASE_URL
    };
  },
  mounted() {
    const bodySelector = $('body');
    bodySelector.addClass('login-page');
    bodySelector.css({"background-image": `url("${this.publicPath}bg.jpg")`, "background-size": "cover"});
  },
  destroyed() {
    const bodySelector = $('body');
    bodySelector.removeClass('login-page');
    bodySelector.css({"background-image": "", "background-size": ""});
  },
  methods: {
    async login() {
      const vm = this;

      const loginParams = {
        user: vm.user,
        password: vm.password
      };

      vm.$emit('loading', true);

      try {
        const res = await backend.signIn(loginParams);
        const result = res.data;
        if (result.code === 0) {
          if (result.data.license_status !== -1) {
            const admin = vm.user === 'admin';
            const role = vm.user === 'admin' ? 'Administrator' : 'User';
            util.session('user', {name: vm.user, token: result.data.token, admin: admin, role: role, license:result.data.license_status});
            vm.$emit('login', '/');
          } else {
            vm.errMsg = vm.$i18n.t('message.license_failure');
          }
        } else if (result.code === -1) {
          if (result.data != null && result.data.license_status != null) {
            vm.errMsg = result.msg;
          }
        } else {
          vm.errMsg = vm.$i18n.t('message.login_failure');
        }
      } catch(e) {
        vm.errMsg = vm.$i18n.t('message.login_failure');
      }

      vm.$emit('loading', false);

    }
  },
};
</script>

<style scoped>
.login-box-body {
  border-radius: 1em;
  background-color: rgba(241, 236, 236, 0.8);
}
.login-box {
  margin-top: 200px;
}
</style>
