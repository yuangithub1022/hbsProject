<template>
  <div class="error-page">
    <h2
      class="headline text-yellow"
      style="font-size:60px;"
    >
      404
    </h2>
    <div class="error-content">
      <h3><i class="fa fa-warning text-yellow" /> Oops! Page not found.</h3>
      <p>
        We could not find the page you were looking for.
        Meanwhile, you may <router-link to="/">
          return to home
        </router-link>.
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Error404'
}
</script>