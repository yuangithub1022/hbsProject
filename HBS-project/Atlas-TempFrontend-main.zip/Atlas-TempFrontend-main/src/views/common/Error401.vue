<template>
  <div class="error-page">
    <h2
      class="headline text-yellow"
      style="font-size:60px;"
    >
      401
    </h2>
    <div class="error-content">
      <h3><i class="fa fa-warning text-yellow" /> Oops! Authorization required.</h3>
      <p>
        This server could not verify that you are authorized to access the page.
        Meanwhile, you may <router-link to="/">
          return to Home
        </router-link>.
      </p>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Error401'
}
</script>
