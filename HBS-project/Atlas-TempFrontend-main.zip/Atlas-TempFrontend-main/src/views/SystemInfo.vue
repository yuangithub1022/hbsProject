<template>
  <div>
    <div class="wrapper">
      <PageHeader></PageHeader>
      <PageAside></PageAside>
      <div class="content-wrapper">
        <section class="content">
          <div class="box box-default">
            <div class="box-header">
              <h4>{{ $t("menu.system") }}</h4>
            </div>
            <div class="box-body">
              <div class="col-xs-8">
                <table id="library" class="table table-bordered" width="80%">
                  <thead>
                    <tr>
                      <th width="100px">{{ $t("common.no") }}</th>
                      <th width="300px">{{ $t("system.serviceName") }}</th>
                      <th>{{ $t("system.serviceVersion") }}</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr>
                      <td>1</td>
                      <td>AccessControlService</td>
                      <td><span class="info-text">{{ acsVersion }}</span></td>
                    </tr>
                    <tr>
                      <td>2</td>
                      <td>FeatureProcessService</td>
                      <td><span class="info-text">{{ fpsVersion }}</span></td>
                    </tr>
                    <tr>
                      <td>3</td>
                      <td>OperationMaintenanceService</td>
                      <td><span class="info-text">{{ omsVersion }}</span></td>
                    </tr>
                    <tr>
                      <td>4</td>
                      <td>StaticFeatureDatabaseService</td>
                      <td><span class="info-text">{{ afdVersion }}</span></td>
                    </tr>
                    <tr v-if="user.license === GLOBAL.advanced">
                      <td>5</td>
                      <td>MediaProcessService</td>
                      <td><span class="info-text">{{ mpsVersion }}</span></td>
                  </tr>
                  </tbody>
                </table>
              </div>

              <div class="col-xs-12 noPadding">
                <div class="setting col-xs-8">
                  <div class="row">
                    <div class="col-xs-12" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.http") }} <span class="info-text">(Captures and Alarms will be posted to Http Server.)</span></label>
                      <button class="btn btn-primary pull-right" v-if="!editable" @click="editable=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="editable" @click="updateHttpServer">{{ $t("common.update") }}</button>
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" rows="1" placeholder="" :disabled="!editable" v-model="httpServer"></textarea>
                  </div>
                </div>
              </div>
              <div class="col-xs-12"><p class="gray">このようなアドレスを入力してください: http://{Atlas IP}:5020/backend/record/face_upload</p></div>
              <div class="col-xs-12 noPadding">
                <div class="setting col-xs-8">
                  <div class="row">
                    <div class="col-xs-12" style="margin-bottom: 5px;">
                      <label class="http-title">{{ $t("system.db") }}</label>
                      <button class="btn btn-primary pull-right" v-if="!editableDb" @click="editableDb=true">{{ $t("common.edit") }}</button>
                      <button class="btn btn-danger pull-right" v-if="editableDb" @click="updateDbServer">{{ $t("common.update") }}</button>
                    </div>
                  </div>
                  <div class="form-group">
                    <textarea class="form-control" rows="1" placeholder="" :disabled="!editableDb" v-model="dbServer"></textarea>
                  </div>
                </div>
              </div>
              <div class="col-xs-12"><p class="gray">Sample: http://192.168.0.1:8080/url1,http://192.168.0.1:8080/url2</p></div>
              <div class="col-xs-8"><button class="btn btn-danger pull-left" @click="clear">{{ $t("common.clear") }}</button></div>
            </div>
          </div>
        </section>
      </div>
    </div>
  </div>
</template>

<script>
import api from '../api/api';
import backend from '../api/backend';

import PageHeader from '../components/PageHeader';
import PageAside from '../components/PageAside';

export default {
  name: 'SystemInfo',
  components: {
    PageHeader,
    PageAside
  },
  data() {
    return {
      user: this.$root.userData,
      acsVersion: '',
      fpsVersion: '',
      omsVersion: '',
      afdVersion: '',
      mpsVersion: '',
      httpServer: '',
      editable: false,
      dbServer: '',
      editableDb: false
    };
  },
  methods: {
    updateHttpServer() {
      let vm = this;
      let newServer = vm.httpServer.trim();
      if (!newServer) {
        vm.$toastr.e(vm.$i18n.t('message.http_update_empty'));
        return;
      }
      api.setHttpServer({url: newServer}).then(() => {
        vm.editable = false;
        vm.httpServer = newServer;
        vm.$toastr.s(vm.$i18n.t('message.http_update_success'));
      }).catch(err => {
        vm.$toastr.e(vm.$i18n.t('message.http_update_failure') + '<br>' + err.response.data.message);
      });
    },

    updateDbServer() {
      let vm = this;
      let newServer = vm.dbServer.trim();

      backend.updateDBServer({"value" : newServer}).then(res => {
        if (res.data.code === 0) {
          vm.editableDb = false;
          vm.dbServer = newServer;
          vm.$toastr.s(vm.$i18n.t('message.dbserver_update_success'));
        } else {
          vm.$toastr.e(vm.$i18n.t('message.dbserver_update_failure'));
        }
      }).catch(() => {
        vm.$toastr.e(vm.$i18n.t('message.dbserver_update_failure'));
      });
    },
    clear() {
      let vm = this;
      if (confirm("Confirm Delete All Records?")) {
        backend.deleteAllRecords().then(() => {
          vm.$toastr.s(vm.$i18n.t('message.delete_all_success'));
        }).catch(err => {
          vm.$toastr.e(vm.$i18n.t('message.delete_all_failure') + '<br>' + err);
        });
      }
    }
  },
  created: function() {
    if (!this.user) {
      this.$router.push({ path: "/login" });
    }
    // Get version info and http server url
    let vm = this;
    api.acsGetVersion().then(res => {
      if (res.data) {
        vm.acsVersion = res.data.version;
      }
    }).catch(err => {
      vm.acsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err);
    });
    api.fpsGetVersion().then(res => {
      if (res.data) {
        vm.fpsVersion = res.data.version;
      }
    }).catch(err => {
      vm.fpsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err);
    });
    api.omsGetVersion().then(res => {
      if (res.data) {
        vm.omsVersion = res.data.version;
      }
    }).catch(err => {
      vm.omsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err);
    });
    api.afdGetVersion().then(res => {
      if (res.data) {
        vm.afdVersion = res.data.version;
      }
    }).catch(err => {
      vm.afdVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err);
    });
    api.mpsGetVersion().then(res => {
      if (res.data) {
        vm.mpsVersion = res.data.version;
      }
    }).catch(err => {
      vm.mpsVersion = 'UNKNOWN';
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err.response.data.message);
    });
    api.getHttpServer().then(res => {
      if (res.data) {
        vm.httpServer = res.data.url;
      }
    }).catch(err => {
      vm.$toastr.e(vm.$i18n.t('message.version_info_failure') + '<br>' + err);
    });

    backend.getDBServer().then(res => {
      if (res.data.code === 0) {
        vm.dbServer = res.data.data.value;
      } else {
        vm.dbServer = '';
      }
    });
  }
};
</script>

<style scoped>
  .box-body {
    min-height: calc(100vh - 163px);
  }
  .setting {
    vertical-align: middle;
    margin-bottom: 0px;
  }
  .http-title {
    margin-top: 5px;
  }
  .info-text {
    color: gray;
    font-size: smaller;
  }
  #library {
    margin-bottom: 15px;
  }
  .gray{
    color: gray;
  }
  .noPadding{
    padding:0;
  }
</style>
