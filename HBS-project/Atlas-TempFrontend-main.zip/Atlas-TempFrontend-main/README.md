# Meter-Frontend

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run serve

# build for production with minification
npm run build

```

# Information
Local URL: http://localhost:8080/atlas/TempFrontend/
Websocket Backend: http://cloud.neusoft.co.jp/atlas/backend/
API Backend: Coming soon
