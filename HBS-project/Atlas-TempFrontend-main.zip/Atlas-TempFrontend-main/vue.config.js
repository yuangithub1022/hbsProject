const webpack = require('webpack');

module.exports = {
  outputDir: 'dist',
  devServer: {
    proxy: {
      '^/api': {
        // target: 'http://cloud.neusoft.co.jp/atlas/api',
        target: 'https://124.219.161.88:28443',
        changeOrigin: true,
        pathRewrite: {
          '^/api': '',
        }
      },
      '^/backend': {
        //target: 'http://cloud.neusoft.co.jp/backend',
        //target: 'http://127.0.0.1:5021/backend',
        target: 'http://124.219.161.88:5020/backend',
        changeOrigin: true,
        pathRewrite: {
          '^/backend': '',
        }
      }
    }
  },
  configureWebpack: {
    plugins: [
      new webpack.ProvidePlugin({
        $: 'jquery',
        jquery: 'jquery',
        'window.jQuery': 'jquery',
        jQuery: 'jquery'
      })
    ]
  },
  publicPath: '/frontend/'
}