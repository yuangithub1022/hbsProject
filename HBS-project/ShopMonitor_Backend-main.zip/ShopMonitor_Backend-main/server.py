import json
from time import sleep
import os
import platform
from datetime import datetime, date, timedelta
import numpy as np
from functools import reduce
from flask import Flask, abort, request, render_template, copy_current_request_context
from flask_socketio import SocketIO, emit, disconnect
from requests.packages.urllib3.exceptions import InsecureRequestWarning
from waitress import serve
import requests

from coordinate_lib import coordinate_lib
from models.cache import Cache
from models.cacheQueue import CacheQueue
from models.crowd_data_parser import CrowdDataParserFactory
from models.database import Database
from models.logger import logger
from models.config_data_parser import ConfigParser
from models.area import Area
from models.retention import Retention
from models.heatmap import Heatmap
from models.visitor import Visitor

requests.packages.urllib3.disable_warnings(InsecureRequestWarning)

app = Flask(__name__)

# parser config on Config Parser
ConfigParser(app)

# create socket io object
crowd_socket = SocketIO(app, async_mode="threading")

thread_socket_position_map = None
thread_socket_position_map_status = False

thread_socket_visitor_sum = None
thread_socket_visitor_sum_status = False

thread_socket_visitor_chart = None
thread_socket_visitor_chart_status = False

thread_socket_retention = None
thread_socket_retention_status = False

thread_socket_heat_info = False
thread_socket_heat_info_status = False

thread_socket_heat_map = False
thread_socket_heat_map_status = False


@app.route('/')
def index():
    # for web socket
    return render_template('index.html', async_mode=crowd_socket.async_mode)


@app.route('/capture', methods=['POST'])
def deal_capture():
    # read json data
    try:
        post_data = request.data.decode('utf-8')
        post_data = json.loads(post_data)
    except Exception as e:
        logger.error(f'Received invalid json data, {e}')
        return '{"result": "error"}'

    # check if post data is crowd data
    if 'task_type' not in post_data or post_data['task_type'] != 'TASK_TYPE_CROWD':
        logger.warning('task_type is not TASK_TYPE_CROWD')
        return '{"result": "error"}'

    # get crowd data
    try:
        crowd_data = post_data['capture_result']['crowd']
    except Exception as e:
        logger.error(f'Invalid capture result, {e}')
        return '{"result": "error"}'

    # check crowd type
    if 'type' not in crowd_data:
        logger.warning('No crowd type in post data')
        return '{"result": "error"}'

    crowd_type = crowd_data['type']

    if crowd_type == 'CROWD_TYPE_UNKNOWN':
        return '{"result": "error"}'

    supported_crowd_types = ['CROWD_TYPE_HEADCOUNT', 'CROWD_TYPE_SEGMENTATION']

    if crowd_type not in supported_crowd_types:
        logger.info(f'Received crowd task type is not supported : {crowd_type}')
        return '{"result": "error"}'

    # get extra_info
    if 'extra_info' not in post_data:
        logger.warning('extra_info not found in post data')
        return '{"result": "error"}'

    # get extra info and task name from crowd data
    extra_info = post_data['extra_info']
    task_name = extra_info['task_name']

    # if remote clear the panorama and portrait
    try:
        panorama_data = post_data['panorama']['data']
        if panorama_data:
            post_data['panorama']['data'] = None

        if crowd_type == 'CROWD_TYPE_HEADCOUNT':
            persons_data = post_data['capture_result']['crowd']['subclass']['headcount']['persons']
            if persons_data:
                for person_data in persons_data:
                    if person_data['portrait']['data']:
                        person_data['portrait']['data'] = None
    except Exception as e:
        logger.error(f'Error to clear the panorama and portrait capture result, {e}')
        return '{"result": "error"}'

    '''
    ++++ for sqlite database is locked error +++
    
    try:
        if task_name in app.config['HEADCOUNT_TASK_NAME'] or task_name in app.config['SEGMENTATION_TASK_NAME']:
            capture_database = Database(database_path=app.config['DATABASE_PATH'],
                                        database_name=app.config['DATABASE_NAME'],
                                        table_name_capture=app.config['TABLE_NAME_CAPTURE_DATA'],
                                        table_name_socket=app.config['TABLE_NAME_SOCKET_DATA'],
                                        table_name_segmentation=app.config['TABLE_NAME_SEGMENTATION_DATA'],
                                        app=app)
            capture_database.add_capture_result(post_data, task_name)

            # capture_time = post_data["capture_time"]
            # upload_result_time = post_data["upload_result_time"]
            # received_time = post_data["received_time"]
            #
        # capture_database.add_capture_time_result(post_data, task_name, crowd_type, capture_time, upload_result_time,
        #                                          received_time)

        # if __debug__:
        #     capture_database.select_from_table_desc_10(table_name=app.config['TABLE_NAME_CAPTURE_DATA'])
        else:
            logger.error(f'Receive task not specified on config file, task_name={task_name}')
            return '{"result": "error"}'
    except Exception as e:
        logger.error(f'Insert result to database error, {e}')
        return '{"result": "error"}'
    '''

    try:
        # parse crowd data
        crowd_data_parser = CrowdDataParserFactory.create_parser(crowd_type)
        is_success = False

        if crowd_type == 'CROWD_TYPE_HEADCOUNT' and task_name in app.config['HEADCOUNT_TASK_NAME']:
            is_success, count, rect_list, track_list = crowd_data_parser.parse(post_data)
            if is_success:
                position2d_list = []
                if count > 0 and rect_list:
                    # get the coordinate when the count > 0
                    person_p = np.asarray(rect_list)
                    position2d_list = get_position2d_list_by_name(person_p, task_name)

                if app.config['CACHE_QUEUE'] == 1:
                    is_success = cache.headcount_task_add_queue(task_name, count, position2d_list, track_list)
                else:
                    is_success = cache.headcount_task_add(task_name, count, position2d_list, track_list)

                if is_success:
                    logger.info(f'Received headcount crowd data from: "{task_name}".  count is : {count}')

        if crowd_type == 'CROWD_TYPE_SEGMENTATION' and task_name in app.config['SEGMENTATION_TASK_NAME']:
            is_success, forward, reverse = crowd_data_parser.parse(post_data)
            if is_success:
                try:
                    # if not capture_database:
                    capture_database = Database(database_path=app.config['DATABASE_PATH'],
                                                database_name=app.config['DATABASE_NAME'],
                                                table_name_capture=app.config['TABLE_NAME_CAPTURE_DATA'],
                                                table_name_socket=app.config['TABLE_NAME_SOCKET_DATA'],
                                                table_name_segmentation=app.config['TABLE_NAME_SEGMENTATION_DATA'],
                                                app=app)
                except Exception as e:
                    logger.error(f'Insert capture result to database error, {e}')
                    return '{"result": "error"}'

                capture_database.add_segmentation_result(forward, reverse, task_name)

                logger.info(f'Received segmentation data from: "{task_name}". forward:{forward}. reverse:{reverse}')

    except Exception as e:
        logger.error(f'Invalid parser capture result, {e}')
        return '{"result": "error"}'

    if not is_success:
        return '{"result": "error"}'

    return '{"result": "success"}'


@crowd_socket.on('connect')
def socket_connect():
    logger.info('[Frontend] Connected with WebSocket')

    emit('crowd_response', {'data': 'Connected', 'status': 0})


@crowd_socket.event
def disconnect_request():
    @copy_current_request_context
    def can_disconnect():
        disconnect()

    emit('crowd_response', {'data': 'Disconnected!', 'status': 0}, callback=can_disconnect)


@crowd_socket.on('disconnect')
def socket_disconnect():
    logger.info('[Frontend] Disconnected with WebSocket')


@crowd_socket.event
def start_send(message):
    try:
        # check request type and data
        if 'request' not in message and 'data' not in message:
            message = 'Received socket format error.'
            emit('crowd_response', {'status': -1, 'msg': message, 'type': 'startsend', 'data': ''})
            return

        request_type = message['request']
        request_data = message['data']

        if request_type == 'startsend':
            # check data type and interval
            if 'type' not in request_data:
                message = 'Received socket data type error.'
                emit('crowd_response', {'status': -1, 'msg': message, 'type': 'startsend', 'data': ''})
                return

            data_type = request_data['type']
            data_interval = request_data['interval'] if 'interval' in request_data else 1

            if not data_interval:
                data_interval = 1
            else:
                data_interval = int(data_interval)

            if data_type == 'all':
                # send position_map data start
                global thread_socket_position_map
                global thread_socket_position_map_status

                if not thread_socket_position_map or not thread_socket_position_map.is_alive():
                    thread_socket_position_map_status = True
                    thread_socket_position_map = crowd_socket.start_background_task(send_position_map,
                                                                                    data_interval)

                # send visitor_sum data start
                # global thread_socket_visitor_sum
                # global thread_socket_visitor_sum_status
                #
                # if not thread_socket_visitor_sum or not thread_socket_visitor_sum.is_alive():
                #     thread_socket_visitor_sum_status = True
                #     thread_socket_visitor_sum = crowd_socket.start_background_task(send_visitor_sum)

                # send visitor_chart data start
                global thread_socket_visitor_chart
                global thread_socket_visitor_chart_status

                if not thread_socket_visitor_chart or not thread_socket_visitor_chart.is_alive():
                    thread_socket_visitor_chart_status = True
                    thread_socket_visitor_chart = crowd_socket.start_background_task(send_visitor_chart)

                # send retention data start
                global thread_socket_retention
                global thread_socket_retention_status

                if not thread_socket_retention or not thread_socket_retention.is_alive():
                    thread_socket_retention_status = True
                    thread_socket_retention = crowd_socket.start_background_task(send_retention)

                # send heat info data start
                global thread_socket_heat_info
                global thread_socket_heat_info_status

                if not thread_socket_heat_info or not thread_socket_heat_info.is_alive():
                    thread_socket_heat_info_status = True
                    thread_socket_heat_info = crowd_socket.start_background_task(send_heat_info)

                # send heat map data start
                global thread_socket_heat_map
                global thread_socket_heat_map_status

                if not thread_socket_heat_map or not thread_socket_heat_map.is_alive():
                    thread_socket_heat_map_status = True
                    thread_socket_heat_map = crowd_socket.start_background_task(send_heat_map)

                emit('crowd_response', {'status': 0, 'msg': '', 'type': 'startsend', 'data': ''})
            else:
                message = 'Received socket data type is not all.'
                emit('crowd_response', {'status': -1, 'msg': message, 'type': 'startsend', 'data': ''})
                return

        else:
            message = 'Received socket request type is not startsend.'
            emit('crowd_response', {'status': -1, 'msg': message, 'type': 'startsend', 'data': ''})
            return

    except Exception as e:
        logger.error(f'Error to parse socket data, {e}')
        message = 'Error to parse socket data'
        emit('crowd_response', {'status': -1, 'msg': message, 'type': 'startsend', 'data': ''})


@crowd_socket.event
def stop_send(message):
    try:
        # check request type and data
        if 'request' not in message and 'data' not in message:
            message = 'Received socket format error.'
            emit('crowd_response', {'status': -1, 'msg': message, 'type': 'stopsend', 'data': ''})
            return

        request_type = message['request']
        request_data = message['data']

        if request_type == 'stopsend':
            # check data type and interval
            if 'type' not in request_data:
                message = 'Received socket data type error.'
                emit('crowd_response', {'status': -1, 'msg': message, 'type': 'stopsend', 'data': ''})
                return

            data_type = request_data['type']

            if data_type == 'all':
                # send position_map data start
                global thread_socket_position_map
                global thread_socket_position_map_status
                if thread_socket_position_map and thread_socket_position_map.is_alive():
                    thread_socket_position_map_status = False

                # send visitor_sum data start
                # global thread_socket_visitor_sum
                # global thread_socket_visitor_sum_status
                # if thread_socket_visitor_sum and thread_socket_visitor_sum.is_alive():
                #     thread_socket_visitor_sum_status = False

                # send visitor_chart data start
                global thread_socket_visitor_chart
                global thread_socket_visitor_chart_status
                if thread_socket_visitor_chart and thread_socket_visitor_chart.is_alive():
                    thread_socket_visitor_chart_status = False

                # send retention data start
                global thread_socket_retention
                global thread_socket_retention_status
                if thread_socket_retention and thread_socket_retention.is_alive():
                    thread_socket_retention_status = False

                # send heat info data start
                global thread_socket_heat_info
                global thread_socket_heat_info_status
                if thread_socket_heat_info and thread_socket_heat_info.is_alive():
                    thread_socket_heat_info_status = False

                # send heat map data start
                global thread_socket_heat_map
                global thread_socket_heat_map_status
                if thread_socket_heat_map and thread_socket_heat_map.is_alive():
                    thread_socket_heat_map_status = False

                emit('crowd_response', {'status': 0, 'msg': '', 'type': 'stopsend', 'data': ''})
            else:
                message = 'Received socket data type is not all.'
                emit('crowd_response', {'status': -1, 'msg': message, 'type': 'stopsend', 'data': ''})
                return

        else:
            message = 'Received socket request type is not stopsend.'
            emit('crowd_response', {'status': -1, 'msg': message, 'type': 'stoptsend', 'data': ''})
            return

    except Exception as e:
        logger.error(f'Error to parse socket data, {e}')
        message = 'Error to parse socket data'
        emit('crowd_response', {'status': -1, 'msg': message, 'type': 'stopsend', 'data': ''})


@crowd_socket.event
def request_data(message):
    try:
        # check request type and data
        if 'request' not in message:
            message = 'Received socket format error.'
            emit('crowd_response', {'status': -1, 'msg': message, 'type': 'requestdata', 'data': ''})
            return

        request_type = message['request']

        if request_type == 'requestdata':
            # send position_map data
            count = 0
            headcount_info = cache.headcount_task_get()

            headcount_debug_info = cache.headcount_task_debug_get()

            if headcount_info:
                count = len(headcount_info)

            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'position_map',
                                                 'data': {'map_width': app.config['MAP_WIDTH'],
                                                          'map_height': app.config['MAP_HEIGHT'],
                                                          'count_now': count,
                                                          'positions_list': headcount_info,
                                                          'debug_info': headcount_debug_info}})

            # send visitor sum data
            send_visitor_sum(0)

            # send visitor_chart data
            send_visitor_chart(0)

            # send retention data
            send_retention(0)

            # send heat info data
            send_heat_info(0)

            # send heat map data
            send_heat_map(0)

            emit('crowd_response', {'status': 0, 'msg': '', 'type': 'requestdata', 'data': ''})
        else:
            message = 'Received socket request type is not requestdata.'
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': message, 'type': 'requestdata', 'data': ''})
            return

    except Exception as e:
        logger.error(f'Error to parse socket data, {e}')
        message = 'Error to parse socket data'
        emit('crowd_response', {'status': -1, 'msg': message, 'type': 'requestdata', 'data': ''})


def send_position_map(interval=1):
    """send server generated events to clients."""
    while True:
        if not thread_socket_position_map_status:
            break

        try:
            if cache.update_ok:
                count = 0
                headcount_info = cache.headcount_task_get()

                headcount_debug_info = cache.headcount_task_debug_get()

                if headcount_info:
                    count = len(headcount_info)

                crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'position_map',
                                                     'data': {'map_width': app.config['MAP_WIDTH'],
                                                              'map_height': app.config['MAP_HEIGHT'],
                                                              'count_now': count,
                                                              'positions_list': headcount_info,
                                                              'debug_info': headcount_debug_info}})

                logger.info('[Frontend] Send position_map data with WebSocket')
                cache.update_ok = False

        except Exception as e:
            logger.error(f'Error to parse headcount data, {e}')
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'position_map', 'data': ''})

        crowd_socket.sleep(0.01)


def send_visitor_sum(interval=10 * 60):
    """send server generated events to clients."""

    count_sum_today = 0
    count_sum_yesterday, count_sum_before = visitor.get_visitor_sum_info()

    while True:
        if not thread_socket_visitor_sum_status and interval != 0:
            break

        try:
            # count_sum_today = 0
            # segmentation_info = capture_database.select_from_table_all_today(
            #     table_name=app.config['TABLE_NAME_SEGMENTATION_DATA'])
            #
            # if segmentation_info:
            #     for task_info in segmentation_info:
            #         count_sum_today += task_info[1]

            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'visitor_sum',
                                                 'data': {'visitor_today': str(count_sum_today),
                                                          'visitor_yesterday': str(count_sum_yesterday),
                                                          'visitor_before': str(count_sum_before)}})

            logger.info('[Frontend] Send visitor_sum data with WebSocket')

            if interval == 0:
                break

            for i in range(interval):
                if not thread_socket_visitor_sum_status and interval != 0:
                    break

                crowd_socket.sleep(1)
        except Exception as e:
            logger.error(f'Error to parse visitor_sum data, {e}')
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'visitor_sum', 'data': ''})


def send_visitor_chart(interval=10):
    """send server generated events to clients."""
    try:
        capture_database = Database(database_path=app.config['DATABASE_PATH'],
                                    database_name=app.config['DATABASE_NAME'],
                                    table_name_capture=app.config['TABLE_NAME_CAPTURE_DATA'],
                                    table_name_socket=app.config['TABLE_NAME_SOCKET_DATA'],
                                    table_name_segmentation=app.config['TABLE_NAME_SEGMENTATION_DATA'])
    except Exception as e:
        logger.error(f'Error to connect database to get visitor_sum data, {e}')
        crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'visitor_sum', 'data': ''})
        return

    today = date.today()
    yesterday = today - timedelta(days=1)
    before = today - timedelta(days=2)

    today_10 = str(today) + ' 10:00'
    today_18 = str(today) + ' 18:00'
    yesterday_10 = str(yesterday) + ' 10:00'
    yesterday_18 = str(yesterday) + ' 18:00'
    before_10 = str(before) + ' 10:00'
    before_18 = str(before) + ' 18:00'

    data_yesterday, data_before = visitor.get_visitor_chart_info()

    while True:
        if not thread_socket_visitor_chart_status and interval != 0:
            break

        try:
            # send visitor_chart_today data
            data_today = capture_database.select_from_table_all_today_hour(
                table_name=app.config['TABLE_NAME_SEGMENTATION_DATA'])

            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'visitor_chart_today',
                                                 'data': {'start': today_10, 'stop': today_18,
                                                          'interval': interval, 'data': data_today}})

            # send visitor chart yesterday data
            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'visitor_chart_yesterday',
                                                 'data': {'start': yesterday_10, 'stop': yesterday_18,
                                                          'interval': interval, 'data': data_yesterday}})

            # send visitor chart before data
            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'visitor_chart_before',
                                                 'data': {'start': before_10, 'stop': before_18,
                                                          'interval': interval, 'data': data_before}})

            logger.info('[Frontend] Send visitor_chart data with WebSocket')

            if interval == 0:
                break

            for i in range(interval):
                if not thread_socket_visitor_chart_status and interval != 0:
                    break

                crowd_socket.sleep(1)
        except Exception as e:
            logger.error(f'Error to parse visitor_chart data, {e}')
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'visitor_chart', 'data': ''})


def send_retention(interval=10 * 60):
    """send server generated events to clients."""
    while True:
        if not thread_socket_retention_status and interval != 0:
            break

        try:
            retention_yesterday = retention.retention_time_yesterday
            retention_before = retention.retention_time_before
            count_sum_today = retention.get_retention_today()

            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'stay_average',
                                                 'data': {'stay_today': str(count_sum_today),
                                                          'stay_yesterday': str(retention_yesterday),
                                                          'stay_before': str(retention_before)}})

            logger.info('[Frontend] Send stay_average data with WebSocket')

            if interval == 0:
                break

            for i in range(interval):
                if not thread_socket_retention_status and interval != 0:
                    break

                crowd_socket.sleep(1)
        except Exception as e:
            logger.error(f'Error to parse stay_average data, {e}')
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'stay_average', 'data': ''})


def send_heat_info(interval=10 * 60):
    """send server generated events to clients."""
    while True:
        if not thread_socket_heat_info_status and interval != 0:
            break

        try:
            area_show_info = heatmap.heat_area_show_info_get()
            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'heat_area',
                                                 'data': area_show_info})

            heatmap.update_heat_area()
            area_rank_today, area_rank_yesterday, area_rank_before = heatmap.heat_ranking_info_get()
            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'heat_ranking',
                                                 'data': {'ranking_today': area_rank_today,
                                                          'ranking_yesterday': area_rank_yesterday,
                                                          'ranking_before': area_rank_before}})

            logger.info('[Frontend] Send heat_area and heat_ranking data with WebSocket')

            if interval == 0:
                break

            for i in range(interval):
                if not thread_socket_heat_info_status and interval != 0:
                    break

                crowd_socket.sleep(1)
        except Exception as e:
            logger.error(f'Error to parse heat_area and heat_ranking data, {e}')
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'heat_area', 'data': ''})


def send_heat_map(interval=5):
    """send server generated events to clients."""
    while True:
        if not thread_socket_heat_map_status and interval != 0:
            break

        try:
            heatmap_base64 = heatmap.get_heatmap_base64()
            crowd_socket.emit('crowd_response', {'status': 0, 'msg': '', 'type': 'heat_map',
                                                 'data': {'format': "jpg",
                                                          'type': "base64",
                                                          'image': str(heatmap_base64)}})

            logger.info('[Frontend] Send heat_map data with WebSocket')

            if interval == 0:
                break

            for i in range(interval):
                if not thread_socket_heat_map_status and interval != 0:
                    break

                crowd_socket.sleep(1)
        except Exception as e:
            logger.error(f'Error to parse heat_map data, {e}')
            crowd_socket.emit('crowd_response', {'status': -1, 'msg': e, 'type': 'heat_map', 'data': ''})


def get_position2d_list_by_name(person_p, task_name):
    position2d_list = []

    if task_name == "175-A1":
        for person in person_p:
            position = transfer.foot_coordinate_a1(y1=person[0][1], y2=person[1][1], x1=person[0][0], x2=person[1][0])
            position2d_list.append(transfer.coordinate_2D_a1(position[0], position[1]))
    elif task_name == "175-A2":
        for person in person_p:
            position = transfer.foot_coordinate_a2(y1=person[0][1], y2=person[1][1], x1=person[0][0], x2=person[1][0])
            position2d_list.append(transfer.coordinate_2D_a2(position[0], position[1]))
    elif task_name == "175-B1":
        for person in person_p:
            position = transfer.foot_coordinate_b1(y1=person[0][1], y2=person[1][1], x1=person[0][0], x2=person[1][0])
            position2d_list.append(transfer.coordinate_2D_b1(position[0], position[1]))
    elif task_name == "175-B2":
        for person in person_p:
            position = transfer.foot_coordinate_b2(y1=person[0][1], y2=person[1][1], x1=person[0][0], x2=person[1][0])
            position2d_list.append(transfer.coordinate_2D_b2(position[0], position[1]))
    elif task_name == "175-C":
        for person in person_p:
            position = transfer.foot_coordinate_c(y1=person[0][1], y2=person[1][1], x1=person[0][0], x2=person[1][0])
            position2d_list.append(transfer.coordinate_2D_c(position[0], position[1]))
    elif task_name == "175-D":
        for person in person_p:
            position = transfer.foot_coordinate_d(y1=person[0][1], y2=person[1][1], x1=person[0][0], x2=person[1][0])
            position2d_list.append(transfer.coordinate_2D_d(position[0], position[1]))

    return position2d_list


if __name__ == "__main__":
    # make database
    capture_database = Database(database_path=app.config['DATABASE_PATH'],
                                database_name=app.config['DATABASE_NAME'],
                                table_name_capture=app.config['TABLE_NAME_CAPTURE_DATA'],
                                table_name_socket=app.config['TABLE_NAME_SOCKET_DATA'],
                                table_name_segmentation=app.config['TABLE_NAME_SEGMENTATION_DATA'],
                                app=app)
    capture_database.create_tables()

    # make heatmap info
    heatmap = Heatmap(app=app)

    # make cache
    if app.config['CACHE_QUEUE'] == 1:
        cache = CacheQueue(app=app, heatmap=heatmap)
    else:
        cache = Cache(headcount_task_name=app.config['HEADCOUNT_TASK_NAME'],
                      segmentation_task_name=app.config['SEGMENTATION_TASK_NAME'],
                      interval=app.config['INTERVAL'],
                      app=app, heatmap=heatmap)

    # make retention info
    retention = Retention(app=app)

    # make visitor info
    visitor = Visitor(app=app)

    # make transfer from coordinate_lib
    transfer = coordinate_lib()

    # start server
    serve(app, host='0.0.0.0', port=4442, threads=50)
