import logging


class Logger:
    instance = None

    def __init__(self):
        if not Logger.instance:
            fmt = "%(asctime)s %(levelname)s %(name)s : %(message)s"
            logging.basicConfig(format=fmt)
            Logger.instance = logging.getLogger('Atlas-SmartStore')
            Logger.instance.setLevel(logging.DEBUG)


Logger()
logger = Logger.instance
