from models.database import Database
from models.logger import logger


class Visitor:
    def __init__(self, app=None):
        self._app = app
        self.visitor_sum_yesterday = 0
        self.visitor_sum_before = 0
        self.visitor_chart_yesterday = []
        self.visitor_chart_before = []

        self.capture_database = None

        self.cal_visitor_sum()
        self.cal_visitor_chart()

    def cal_visitor_sum(self):
        try:
            connect_error = False
            self.capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                             database_name=self._app.config['DATABASE_NAME'],
                                             table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                             table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                             table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        try:
            if not connect_error:
                # get yesterday visitor sum
                segmentation_info = self.capture_database.select_from_table_all_yesterday(
                    table_name=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])

                if segmentation_info:
                    for task_info in segmentation_info:
                        self.visitor_sum_yesterday += task_info[1]

                # get before visitor sum
                segmentation_info = self.capture_database.select_from_table_all_before(
                    table_name=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])

                if segmentation_info:
                    for task_info in segmentation_info:
                        self.visitor_sum_before += task_info[1]

        except Exception as err:
            self.visitor_sum_yesterday = 0
            self.visitor_sum_before = 0
            logger.error('Connect to db for get visitor sum info error.', err)

    def cal_visitor_chart(self):
        try:
            # get visitor_chart_yesterday data
            self.visitor_chart_yesterday = self.capture_database.select_from_table_all_yesterday_hour(
                table_name=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])

            # get visitor_chart_yesterday data
            self.visitor_chart_before = self.capture_database.select_from_table_all_before_hour(
                table_name=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])

        except Exception as err:
            self.visitor_chart_yesterday = []
            self.visitor_chart_before = []
            logger.error('Connect to db for get visitor sum info error.', err)

    def get_visitor_sum_info(self):
        return self.visitor_sum_yesterday, self.visitor_sum_before

    def get_visitor_chart_info(self):
        return self.visitor_chart_yesterday, self.visitor_chart_before
