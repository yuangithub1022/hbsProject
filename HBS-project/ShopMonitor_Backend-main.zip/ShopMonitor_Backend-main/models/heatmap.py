import sys

import numpy as np

from coordinate_lib import coordinate_lib
from models.database import Database
from models.logger import logger


class Heatmap:
    def __init__(self, app=None):
        self._app = app
        self._transfer = coordinate_lib()

        self.heat_info = {}
        self.area_show_info = []
        self._rate = self._app.config["HEATMAP_RATE"]
        self._area_info = self._app.config['AREA_INFO']
        self._area_show_info = self._app.config['AREA_SHOW_INFO']

        self._map_height = self.rounding(int(self._app.config['MAP_HEIGHT'])) + 1
        self._map_width = self.rounding(int(self._app.config['MAP_WIDTH'])) + 1

        self._heat_np = np.zeros((self._map_height, self._map_width))
        self._heat_np_yesterday = np.zeros((self._map_height, self._map_width))
        self._heat_np_before = np.zeros((self._map_height, self._map_width))

        self.heat_info_today = ""
        self.area_rank_today = ""
        self.heat_info_yesterday = ""
        self.area_rank_yesterday = ""
        self.heat_info_before = ""
        self.area_rank_before = ""

        # np.set_printoptions(threshold=sys.maxsize)
        # logger.info(f'{self._heat_np}')

        self.init_heat_np()
        self.init_heat_info()
        self.init_area_show_info()

        # self.get_heatmap_base64()

    def init_heat_np(self):
        # make heat np for today and yesterday and before
        try:
            capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                        database_name=self._app.config['DATABASE_NAME'],
                                        table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                        table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                        table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])

            # update heat np for today
            headcount_info_today = capture_database.select_from_table_today_for_heat()
            today_positions_list = []
            for headcount_info_list in headcount_info_today:
                for headcount_info in headcount_info_list:
                    if int(headcount_info["x"]) >= 0 and int(headcount_info["y"]) >= 0:
                        position_x = self.rounding(int(headcount_info["x"]))
                        position_y = self.rounding(int(headcount_info["y"]))

                        if position_x < self._map_width and position_y < self._map_height:
                            today_positions_list.append((position_x, position_y))

            if today_positions_list:
                self._heat_np = self._transfer.heat_array_update(self._heat_np, today_positions_list)

            # update heat np for yesterday
            headcount_info_yesterday = capture_database.select_from_table_yesterday_for_heat()
            yesterday_positions_list = []
            for headcount_info_list in headcount_info_yesterday:
                for headcount_info in headcount_info_list:
                    if int(headcount_info["x"]) >= 0 and int(headcount_info["y"]) >= 0:
                        position_x = self.rounding(int(headcount_info["x"]))
                        position_y = self.rounding(int(headcount_info["y"]))

                        if position_x < self._map_width and position_y < self._map_height:
                            yesterday_positions_list.append((position_x, position_y))

            if yesterday_positions_list:
                self._heat_np_yesterday = self._transfer.heat_array_update(self._heat_np_yesterday,
                                                                           yesterday_positions_list)

            # update heat np for before
            headcount_info_before = capture_database.select_from_table_before_for_heat()
            before_positions_list = []
            for headcount_info_list in headcount_info_before:
                for headcount_info in headcount_info_list:
                    if int(headcount_info["x"]) >= 0 and int(headcount_info["y"]) >= 0:
                        position_x = self.rounding(int(headcount_info["x"]))
                        position_y = self.rounding(int(headcount_info["y"]))

                        if position_x < self._map_width and position_y < self._map_height:
                            before_positions_list.append((position_x, position_y))

            if before_positions_list:
                self._heat_np_before = self._transfer.heat_array_update(self._heat_np_before, before_positions_list)
        except Exception as err:
            logger.error('Init heat np error.', err)

    def init_heat_info(self):
        # make heat info and area rank for today and yesterday and before
        try:
            heat_info_today = {}
            area_rank_today = []

            heat_info_yesterday = {}
            area_rank_yesterday = []

            heat_info_before = {}
            area_rank_before = []

            for key, value in self._area_info.items():
                area_name = key
                post_list = value

                for post in post_list:
                    post[0] = self.rounding(post[0])
                    post[1] = self.rounding(post[1])

                heat_sum_today = self.check_heat_value(self._heat_np, post_list)
                heat_sum_yesterday = self.check_heat_value(self._heat_np_yesterday, post_list)
                heat_sum_before = self.check_heat_value(self._heat_np_before, post_list)

                heat_info_today[area_name] = heat_sum_today
                heat_info_yesterday[area_name] = heat_sum_yesterday
                heat_info_before[area_name] = heat_sum_before

            heat_info_sorted_today = sorted(heat_info_today.items(), key=lambda d: d[1], reverse=True)
            heat_info_sorted_yesterday = sorted(heat_info_yesterday.items(), key=lambda d: d[1], reverse=True)
            heat_info_sorted_before = sorted(heat_info_before.items(), key=lambda d: d[1], reverse=True)

            # heat_info_sorted_today = sorted(heat_info_today.items(), key=lambda d: d[1], reverse=True)
            for heat_info_sorted in heat_info_sorted_today:
                area_rank_today.append({heat_info_sorted[0]: heat_info_sorted[1]})

            # heat_info_sorted_yesterday = sorted(heat_info_yesterday.items(), key=lambda d: d[1], reverse=True)
            for heat_info_sorted in heat_info_sorted_yesterday:
                area_rank_yesterday.append({heat_info_sorted[0]: heat_info_sorted[1]})
            #
            # heat_info_sorted_before = sorted(heat_info_before.items(), key=lambda d: d[1], reverse=True)
            for heat_info_sorted in heat_info_sorted_before:
                area_rank_before.append({heat_info_sorted[0]: heat_info_sorted[1]})

            self.heat_info_today = area_rank_today
            # self.area_rank_today = area_rank_today

            self.heat_info_yesterday = area_rank_yesterday
            # self.area_rank_yesterday = area_rank_yesterday

            self.heat_info_before = area_rank_before
            # self.area_rank_before = area_rank_before

        except Exception as err:
            logger.error('Init heat info error.', err)

    def init_area_show_info(self):
        try:
            for area_name, post_list in self._area_show_info.items():
                self.area_show_info.append({"name": area_name, "area": post_list})
        except Exception as err:
            logger.error('Init show area info error.', err)

    def update_heat_np(self, headcount_info):
        try:
            positions_list = []
            if headcount_info:
                for key, value in headcount_info.items():
                    person_rect_list = value['personRect']
                    person_count = value['count']
                    if person_rect_list and person_count:
                        for i in range(person_count):
                            if person_rect_list[i]:
                                if person_rect_list[i][0] >= 0 and person_rect_list[i][1] >= 0:
                                    positions_list.append((self.rounding(person_rect_list[i][0]),
                                                           self.rounding(person_rect_list[i][1])))

                if positions_list:
                    self._heat_np = self._transfer.heat_array_update(self._heat_np, positions_list)
                logger.info('Update heat picture success.')
        except Exception as err:
            logger.error(f'Update heat picture error. {headcount_info}', err)

    def update_heat_np_queue(self, headcount_info):
        try:
            positions_list = []
            if headcount_info:
                for person in headcount_info:
                    if person["x"] >= 0 and person["y"] >= 0:
                        positions_list.append((self.rounding(person["x"]),
                                               self.rounding(person["y"])))

                if positions_list:
                    self._heat_np = self._transfer.heat_array_update(self._heat_np, positions_list)
                logger.info('Update heat picture success.')
        except Exception as err:
            logger.error(f'Update heat picture error. {headcount_info}', err)

    def update_heat_area(self):
        try:
            heat_info = {}
            area_rank = []
            for key, value in self._area_info.items():
                area_name = key
                post_list = value

                heat_sum = self.check_heat_value(self._heat_np, post_list)

                heat_info[area_name] = heat_sum

            heat_info_sorted_today = sorted(heat_info.items(), key=lambda d: d[1], reverse=True)

            # heat_info_sorted_today = sorted(heat_info.items(), key=lambda d: d[1], reverse=True)
            for heat_info_sorted in heat_info_sorted_today:
                area_rank.append({heat_info_sorted[0]: heat_info_sorted[1]})

            self.heat_info_today = area_rank
            # self.area_rank_today = area_rank
        except Exception as err:
            logger.error('Error to update heat area rank info.', err)

    def is_inside_polygon(self, pt, poly):
        c = False
        i = -1
        l = len(poly)
        j = l - 1
        while i < l - 1:
            i += 1
            if ((poly[i][0] <= pt[0] and pt[0] < poly[j][0]) or (poly[j][0] <= pt[0] and pt[0] < poly[i][0])):
                if (pt[1] < (poly[j][1] - poly[i][1]) * (pt[0] - poly[i][0]) / (poly[j][0] - poly[i][0]) + poly[i][1]):
                    c = not c
            j = i
        return c

    def check_heat_value(self, heat_np, area_poly):
        '''
        heat_np：图像大小的np数组，注意np数组中横坐标x与纵坐标y的参数顺序是[y][x]
        area_poly：区域的顶点，格式为[[x1, y1],[x2, y2]...]
        '''
        [rows, cols] = heat_np.shape
        heat_sum = 0

        for y in range(rows):
            for x in range(cols):
                if (self.is_inside_polygon([x, y], area_poly)):
                    heat_sum = heat_sum + heat_np[y, x]

        return heat_sum

    def get_heatmap_base64(self):
        try:
            return self._transfer.heat_picture(self._heat_np)
        except Exception as err:
            logger.error('Draw heat picture error.', err)

    def heat_ranking_info_get(self):
        return self.heat_info_today, self.heat_info_yesterday, self.heat_info_before

    def heat_area_show_info_get(self):
        return self.area_show_info

    def rounding(self, count):
        return int(count / self._rate + 0.5)
