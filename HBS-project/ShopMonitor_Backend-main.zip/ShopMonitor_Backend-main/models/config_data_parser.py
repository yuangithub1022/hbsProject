import json
import os
import platform

from models.logger import logger


def ConfigParser(app):
    # cache config info
    app.config['SEGMENTATION_TASK_COUNT'] = 2
    app.config['SEGMENTATION_TASK_NAME'] = []
    app.config['HEADCOUNT_TASK_COUNT'] = 6
    app.config['HEADCOUNT_TASK_NAME'] = []
    app.config['INTERVAL'] = 1

    # atlas config info
    # 'https://192.168.30.111:38443'
    app.config['ATLAS_API'] = 'https://124.219.161.88:11143'
    app.config['ATLAS_USERNAME'] = 'admin'
    app.config['ATLAS_PASSWORD'] = 'Atlas@2019'

    # db config info
    app.config['DATABASE_PATH'] = './crowd_db' if platform.system() == 'Windows' else '/var/crowd_db'
    app.config['DATABASE_NAME'] = 'crowd_shop_monitor.db'
    app.config['TABLE_NAME_CAPTURE_DATA'] = 'RAW_DATA'
    app.config['TABLE_NAME_SOCKET_DATA'] = 'REAL_TIME_HEADCOUNT'
    app.config['TABLE_NAME_SEGMENTATION_DATA'] = 'SEGMENTATION_DATA'

    # task info
    app.config['HEADCOUNT_TASK_INFO'] = {}
    app.config['SEGMENTATION_TASK_INFO'] = {}

    # for heat map and area
    app.config['MAP_WIDTH'] = 1298
    app.config['MAP_HEIGHT'] = 591
    app.config['AREA_INFO'] = {}
    app.config['AREA_SHOW_INFO'] = {}
    app.config['HEATMAP_RATE'] = 5

    # other
    app.config['CACHE_QUEUE'] = 0

    # Update config if config file exists
    base_dir = './config' if platform.system() == 'Windows' else '/var/crowd'
    config_file = f'{base_dir}/config.json'

    if os.path.isfile(config_file):
        with open(config_file) as f:
            try:
                config = json.load(f)
                if config:
                    app.config.update(config)
            except Exception as err:
                logger.warning('Read config file error', err)

    # check config settings
    try:
        app.config['INTERVAL'] = int(app.config['INTERVAL'])
        if app.config['INTERVAL'] < 1 or app.config['INTERVAL'] > 100:
            logger.warning('Invalid value of SEGMENTATION_TASK_COUNT, out of range [1 - 100].')
            app.config['INTERVAL'] = 1
    except Exception as err:
        app.config['INTERVAL'] = 1
        logger.warning('Invalid value of INTERVAL, Using default value 1', err)

    # get tasks name
    try:
        headcount_task_info = app.config['HEADCOUNT_TASK_INFO']
        headcount_task_name = []
        if isinstance(headcount_task_info, dict):
            for key, value in headcount_task_info.items():
                headcount_task_name.append(key)

            app.config['HEADCOUNT_TASK_NAME'] = headcount_task_name
            app.config['HEADCOUNT_TASK_COUNT'] = len(headcount_task_name)

        segmentation_task_info = app.config['SEGMENTATION_TASK_INFO']
        segmentation_task_name = []
        if isinstance(segmentation_task_info, dict):
            for key, value in segmentation_task_info.items():
                segmentation_task_name.append(key)

            app.config['SEGMENTATION_TASK_NAME'] = segmentation_task_name
            app.config['SEGMENTATION_TASK_COUNT'] = len(segmentation_task_name)
    except Exception as err:
        logger.warning('Invalid value of task info, cannot get task name', err)
