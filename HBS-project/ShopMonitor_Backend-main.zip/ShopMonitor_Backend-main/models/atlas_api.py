import requests
import json
import threading
import datetime
from time import sleep
import os
import ssl
import warnings

from models.logger import logger


class AtlasAPI:
    warnings.filterwarnings('ignore', message='Unverified HTTPS request')

    def __init__(self, atlas_address=None, atlas_user='admin', atlas_password='Atlas@2019', keep_alive=True):
        self._atlas_address = atlas_address
        self._username = atlas_user
        self._password = atlas_password
        self._keep_alive = keep_alive
        self._keep_alive_thread = None
        self._last_token_date = ''
        self._keep_token_interval = datetime.timedelta(minutes=1)
        self._token = self._get_token()

        self._keep_token_start()

    def get_token(self):
        return self._token

    def take_picture(self, fid=''):
        res = self._osg_download_object(str(fid))
        if res.status_code == 200:
            logger.info(f'Get picture success. fid:{str(fid)}')
            return res.content
        else:
            logger.warning(f'Take picture failed. fid:{str(fid)}')

        return None

    # def take_picture(self, fid):
    #     print("Get Picture " + str(fid))
    #     r = requests.get(self.address + osgDownloadObject + fid, \
    #                      headers={"Authorization": self.token}, \
    #                      verify=False)
    #     return r.content

    def _get_token(self):
        # make login call
        try:
            res = self._oms_sign_in()
        except Exception as e:
            logger.warning(f'Cannot make the login call, {e}.')
            return ''

        try:
            res_data = res.json()
        except Exception as e:
            logger.warning(f'Received invalid json data, {e}.')
            return ''

        if 'token' not in res_data or not res_data['token']:
            logger.warning('No valid token')
            return ''
        else:
            logger.info('Get token success')
            self._last_token_date = datetime.datetime.now()
            return res_data['token']

    def _keep_token_start(self):
        if self._keep_alive_thread and self._keep_alive_thread.is_alive():
            logger.info(f'Keep token thread is alive.')
            return

        if self._keep_alive:
            self._keep_alive_thread = threading.Thread(target=self._keep_token)
            self._keep_alive_thread.setDaemon(True)
            self._keep_alive_thread.start()

    def _keep_token(self):
        logger.info(f'Start keep token.')
        while True:
            if not self._token and not self._last_token_date:
                self._token = self._get_token()

            if self._token and self._last_token_date:
                time = datetime.datetime.now() - self._last_token_date
                if time > self._keep_token_interval:
                    res = self._oms_get_version()
                    if res.status_code == 200:
                        self._last_token_date = datetime.datetime.now()
                        logger.info(f'Keep token success.')
                    else:
                        logger.warning(f'Keep token failed.')
                        self._last_token_date = ''
                        self._token = ''

            sleep(1)

    def _oms_sign_in(self):
        url = f'{self._atlas_address}/components/operation-maintenance/v1/users/sign_in'
        data = {
            'user': self._username,
            'password': self._password
        }
        res = requests.post(url, verify=False, json=data, timeout=5)
        return res

    def _oms_get_version(self):
        url = f'{self._atlas_address}/components/operation-maintenance/v1/version'
        headers = {
            'Authorization': self._token
        }
        res = requests.get(url, verify=False, timeout=5, headers=headers)
        return res

    def _osg_download_object(self, fid=''):
        url = f'{self._atlas_address}/components/osg-default/v1/objects/{str(fid)}'
        headers = {
            'Authorization': self._token
        }
        res = requests.get(url, verify=False, timeout=5, headers=headers)
        return res

    def _mps_get_task_list(self):
        url = f'{self._atlas_address}/engine/media-process/v1/tasks?page_request.limit=100'
        headers = {
            'Authorization': self._token
        }
        res = requests.get(url, verify=False, timeout=5, headers=headers)
        return res
