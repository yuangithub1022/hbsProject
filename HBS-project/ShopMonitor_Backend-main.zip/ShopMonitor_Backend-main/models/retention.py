import threading
import time
from datetime import datetime, date, timedelta

from coordinate_lib import coordinate_lib
from models.database import Database
from models.logger import logger


class Retention:
    def __init__(self, app=None):
        self._app = app
        self.retention_time_today = ""
        self.retention_time_yesterday = ""
        self.retention_time_before = ""
        self.transfer = coordinate_lib()
        self.capture_database = None

        self.cal_retention_yesterday()
        self.cal_retention_before()

        self._loop_save_retention()

    def cal_retention_yesterday(self):
        try:
            connect_error = False
            self.capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                             database_name=self._app.config['DATABASE_NAME'],
                                             table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                             table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                             table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        try:
            if not connect_error:
                # get yesterday retention time
                headcount_sum_list, forward_sum_list, reverse_sum_list = self.capture_database.select_from_table_yesterday_for_retention()

                try:
                    retention_hour = 0
                    retention_min = 0
                    retention_sec = 0
                    if headcount_sum_list and forward_sum_list and reverse_sum_list:
                        retention_hour, retention_min, retention_sec = self.transfer.average_retention_time(
                            headcount_sum_list, forward_sum_list,
                            reverse_sum_list)
                except Exception as err:
                    logger.error('Get average_retention_time error.', err)

                retention_time = int(retention_hour) * 60 * 60 + int(retention_min) * 60 + int(retention_sec)

                self.retention_time_yesterday = str(retention_time)
        except Exception as err:
            logger.error('Connect to db for save retention time info error.', err)

    def cal_retention_before(self):
        try:
            connect_error = False
            if not self.capture_database:
                self.capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                                 database_name=self._app.config['DATABASE_NAME'],
                                                 table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                                 table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                                 table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        try:
            if not connect_error:
                # get yesterday retention time
                headcount_sum_list, forward_sum_list, reverse_sum_list = self.capture_database.select_from_table_before_for_retention()

                try:
                    retention_hour = 0
                    retention_min = 0
                    retention_sec = 0
                    if headcount_sum_list and forward_sum_list and reverse_sum_list:
                        retention_hour, retention_min, retention_sec = self.transfer.average_retention_time(
                            headcount_sum_list, forward_sum_list,
                            reverse_sum_list)
                except Exception as err:
                    logger.error('Get average_retention_time error.', err)

                retention_time = int(retention_hour) * 60 * 60 + int(retention_min) * 60 + int(retention_sec)

                self.retention_time_before = str(retention_time)
        except Exception as err:
            logger.error('Connect to db for save retention time info error.', err)

    def get_retention_today(self):
        try:
            capture_database_retention = Database(database_path=self._app.config['DATABASE_PATH'],
                                                  database_name=self._app.config['DATABASE_NAME'],
                                                  table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                                  table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                                  table_name_segmentation=self._app.config[
                                                      'TABLE_NAME_SEGMENTATION_DATA'])

            # get today retention time
            headcount_sum_list, forward_sum_list, reverse_sum_list = capture_database_retention.select_from_table_today_for_retention()

            try:
                retention_hour = 0
                retention_min = 0
                retention_sec = 0
                if headcount_sum_list and forward_sum_list and reverse_sum_list:
                    retention_hour, retention_min, retention_sec = self.transfer.average_retention_time(
                        headcount_sum_list, forward_sum_list,
                        reverse_sum_list)
            except Exception as err:
                logger.error('Get average_retention_time error.', err)

            retention_time = int(retention_hour) * 60 * 60 + int(retention_min) * 60 + int(retention_sec)

            return str(retention_time)
        except Exception as err:
            logger.error('Error to get retention time info.', err)
            return "0"

    def _loop_save_retention(self):
        self._thread = threading.Thread(target=self.loop_forever)
        self._thread.setDaemon(True)
        self._thread.start()

    def loop_forever(self):
        connect_error = False

        try:
            capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                        database_name=self._app.config['DATABASE_NAME'],
                                        table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                        table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                        table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        while True:
            try:
                if not connect_error:
                    # get today retention time
                    headcount_sum_list, forward_sum_list, reverse_sum_list = capture_database.select_from_table_today_for_retention()
                    try:
                        retention_hour = 0
                        retention_min = 0
                        retention_sec = 0
                        if headcount_sum_list and forward_sum_list and reverse_sum_list:
                            retention_hour, retention_min, retention_sec = self.transfer.average_retention_time(
                                headcount_sum_list, forward_sum_list,
                                reverse_sum_list)
                    except Exception as err:
                        logger.error('Get average_retention_time error.', err)

                    retention_time = int(retention_hour) * 3600 + int(retention_min) * 60 + int(retention_sec)
                    self.retention_time_today = str(retention_time)

                    # get yesterday retention time
                    if not self.retention_time_yesterday:
                        headcount_sum_list, forward_sum_list, reverse_sum_list = capture_database.select_from_table_yesterday_for_retention()

                        try:
                            retention_hour = 0
                            retention_min = 0
                            retention_sec = 0
                            if headcount_sum_list and forward_sum_list and reverse_sum_list:
                                retention_hour, retention_min, retention_sec = self.transfer.average_retention_time(
                                    headcount_sum_list, forward_sum_list,
                                    reverse_sum_list)
                        except Exception as err:
                            logger.error('Get average_retention_time error.', err)

                        retention_time = int(retention_time) * 60 * 60 + int(retention_min) * 60 + int(retention_sec)

                        self.retention_time_yesterday = str(retention_time)

                    today = date.today()
                    yesterday = today - timedelta(days=1)
                    retention_info = {str(today) + '_retention': self.retention_time_today,
                                      str(yesterday) + '_retention': self.retention_time_yesterday}

                    capture_database.add_retention_result(retention_info)
                else:
                    capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                                database_name=self._app.config['DATABASE_NAME'],
                                                table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                                table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                                table_name_segmentation=self._app.config[
                                                    'TABLE_NAME_SEGMENTATION_DATA'])
                    connect_error = False

            except Exception as err:
                connect_error = True
                logger.error('Connect to db for save retention time info error.', err)
                time.sleep(5)

            time.sleep(10 * 60)

    def area_info_add(self):
        pass

    def area_info_get(self):
        pass
