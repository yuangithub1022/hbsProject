import threading
import time
from datetime import datetime, timedelta
from threading import Lock
from functools import reduce

from models.logger import logger
from models.database import Database


class Area:
    def __init__(self, app=None):
        self._app = app

        self._loop_save_area()

    def _loop_save_area(self):
        self._thread = threading.Thread(target=self.loop_forever)
        self._thread.setDaemon(True)
        self._thread.start()

    def loop_forever(self):
        connect_error = False
        try:
            capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                        database_name=self._app.config['DATABASE_NAME'],
                                        table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                        table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                        table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        while True:
            try:
                if not connect_error:
                    area_info = [{"name": "area-A", "rect": [(10, 10), (10, 20), (20, 10), (20, 20)], "count": 30},
                                 {"name": "area-B", "rect": [(40, 40), (40, 50), (50, 40), (50, 50)], "count": 20},
                                 {"name": "area-C", "rect": [(10, 40), (40, 10), (10, 40), (10, 50)], "count": 10}]

                    area_rank = ("area-A", "area-B", "area-C")

                    capture_database.add_area_result(area_info, area_rank)
                else:
                    capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                                database_name=self._app.config['DATABASE_NAME'],
                                                table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                                table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                                table_name_segmentation=self._app.config[
                                                    'TABLE_NAME_SEGMENTATION_DATA'])
                    connect_error = False

            except Exception as err:
                connect_error = True
                logger.error('Connect to db for save headcount info error.', err)
                time.sleep(5)

            # capture_database.select_from_table_desc_10(table_name=self._app.config['TABLE_NAME_SOCKET_DATA'])
            time.sleep(10)

    def area_info_add(self):
        pass

    def area_info_get(self):
        pass
