from flask import current_app as app

from models.logger import logger


class CrowdDataParser:
    def parse(self, extra_info, crowd_data):
        pass


class IntrusionCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_INTRUSION'

    def parse(self, extra_info, crowd_data):
        pass


class RetentionCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_RETENTION'

    def parse(self, extra_info, crowd_data):
        pass


class DensityCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_DENSITY'

    def parse(self, extra_info, crowd_data):
        pass


class SegmentationCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_SEGMENTATION'

    def parse(self, post_data):
        try:
            crowd_data = post_data['capture_result']['crowd']
        except:
            logger.info('Not find extra can be found.')
            return False

        try:
            forward_count = int(crowd_data['subclass']['segmentation']['forward'])
            reverse_count = int(crowd_data['subclass']['segmentation']['reverse'])
        except Exception as e:
            logger.warning(f'Parser task type error. {e}')
            return False

        return True, forward_count, reverse_count


class HeadcountCrowdDataParser(CrowdDataParser):
    def __init__(self):
        self.crowd_type = 'CROWD_TYPE_HEADCOUNT'

    def parse(self, post_data):
        try:
            crowd_data = post_data['capture_result']['crowd']

            # get headcount
            crowd_task_headcount = crowd_data['subclass']['headcount']['count']

            # get rect and track
            person_list = post_data["capture_result"]["crowd"]["subclass"]["headcount"]["persons"]
            person_rect_list = []
            person_track_list = []

            if len(person_list) > 0:
                for person in person_list:
                    vertices = person["rectangle"]["vertices"]
                    person_rect_list.append([[vertices[0]["x"], vertices[0]["y"]], \
                                            [vertices[1]["x"], vertices[1]["y"]]])

                    track_id = person["track_id"]
                    person_track_list.append(track_id)

        except Exception as e:
            logger.warning(f'Parser task type error. {e}')
            return False

        return True, crowd_task_headcount, person_rect_list, person_track_list

    def offset_parse(self, task_num, position2d_list):
        try:
            if isinstance(task_num, int) and app.config['HEADCOUNT_TASK_COUNT'] >= task_num > 0 \
                    and app.config['TASK_OFFSET_INFO']:

                position2d_list_offset = []
                offset_x = 0
                offset_y = 0

                for key, value in app.config['TASK_OFFSET_INFO'].items():
                    crowd_task_name = key.split('_')
                    if len(crowd_task_name) == 3 and crowd_task_name[0].lower() == 'headcount' \
                            and crowd_task_name[1].lower() == 'task':
                        crowd_task_num = int(crowd_task_name[2])
                        if crowd_task_num == task_num:
                            offset_x = int(value['offset_x'])
                            offset_y = int(value['offset_y'])
                            break

                if offset_x >= 0 and offset_y >= 0:
                    for position2d in position2d_list:
                        if position2d:
                            position2d_offset = (position2d[0] + offset_x, position2d[1] + offset_y)
                            position2d_list_offset.append(position2d_offset)
                        else:
                            position2d_list_offset.append(position2d)

                return True, position2d_list_offset
        except Exception as err:
            logger.error('Error to set the offset to position2d.', err)
            return False, []


class CrowdDataParserFactory:
    @staticmethod
    def create_parser(crowd_type):
        crowd_type = crowd_type.split('_')[2]
        crowd_type = crowd_type[0] + crowd_type[1:].lower()
        class_name = f'{crowd_type}CrowdDataParser'
        try:
            parser = globals()[class_name]()
            return parser
        except Exception as e:
            logger.info(f'Failed to create instance of class {class_name}. {e}')
            return None
