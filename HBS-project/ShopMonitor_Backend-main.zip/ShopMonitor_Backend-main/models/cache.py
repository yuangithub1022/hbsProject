import threading
import time
from datetime import datetime, timedelta
import math
from threading import Lock
from functools import reduce

from models.logger import logger
from models.database import Database
from coordinate_lib import coordinate_lib


class Cache:
    def __init__(self, headcount_task_count=6, headcount_task_name=[],
                 segmentation_task_count=2, segmentation_task_name=[],
                 interval=1, app=None, heatmap=None):
        self._headcount_task_count = headcount_task_count
        self._headcount_task_name = headcount_task_name
        self._segmentation_task_count = segmentation_task_count
        self._segmentation_task_name = segmentation_task_name
        self._interval = interval
        self._app = app
        self._heatmap = heatmap
        self.lock = threading.Lock()

        # for cal vector
        self.persons_info_old = []
        self.persons_info_new = []
        self.update_ok = False

        # taskNum -> { count： int , personRect: list, personTrack: list, personVector: list, captureTime: datetime}
        self.safe_cache_headcount = {}
        # taskNum -> { count： int , captureTime: datetime}
        self.safe_cache_headcount_debug = []
        # taskNum -> { forward： int , reverse： int , captureTime: datetime}
        self.safe_cache_segmentation = {}

        self._make_safe_cache()

        self.transfer = coordinate_lib()

        self._loop_save_headcount()

    def _make_safe_cache(self):
        try:
            if self._headcount_task_count and self._headcount_task_name:
                for key in self._headcount_task_name:
                    now_time = datetime.now()
                    self.safe_cache_headcount[key] = {'count': 0, 'personRect': [], 'personTrack': [],
                                                      'personVector': [], 'captureTime': now_time}

            if self._segmentation_task_count and self._segmentation_task_name:
                for key in self._segmentation_task_name:
                    now_time = datetime.now()
                    self.safe_cache_segmentation[key] = {'forward': 0, 'reverse': 0, 'captureTime': now_time}
        except Exception as err:
            self.safe_cache_headcount = {}
            self.safe_cache_headcount_debug = {}
            logger.error('Error for make safe cache.', err)

    def _loop_save_headcount(self):
        self._thread = threading.Thread(target=self.loop_forever)
        self._thread.setDaemon(True)
        self._thread.start()

    def loop_forever(self):
        connect_error = False
        try:
            capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                        database_name=self._app.config['DATABASE_NAME'],
                                        table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                        table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                        table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        while True:
            try:
                if not connect_error:
                    positions_list = []
                    debug_count_info = []

                    a1_list = []
                    a2_list = []
                    b1_list = []
                    b2_list = []
                    c_list = []
                    d_list = []

                    headcount_info = self.safe_cache_headcount
                    if headcount_info:
                        for key, value in headcount_info.items():
                            if key == "175-A1":
                                for rect in value['personRect']:
                                    if not rect:
                                        a1_list.append([100000, 100000])
                                    else:
                                        a1_list.append([rect[0], rect[1]])
                            elif key == "175-A2":
                                for rect in value['personRect']:
                                    if not rect:
                                        a2_list.append([100000, 100000])
                                    else:
                                        a2_list.append([rect[0], rect[1]])
                            elif key == "175-B1":
                                for rect in value['personRect']:
                                    if not rect:
                                        b1_list.append([100000, 100000])
                                    else:
                                        b1_list.append([rect[0], rect[1]])
                            elif key == "175-B2":
                                for rect in value['personRect']:
                                    if not rect:
                                        b2_list.append([100000, 100000])
                                    else:
                                        b2_list.append([rect[0], rect[1]])
                            elif key == "175-C":
                                for rect in value['personRect']:
                                    if not rect:
                                        c_list.append([100000, 100000])
                                    else:
                                        c_list.append([rect[0], rect[1]])
                            elif key == "175-D":
                                for rect in value['personRect']:
                                    if not rect:
                                        d_list.append([100000, 100000])
                                    else:
                                        d_list.append([rect[0], rect[1]])

                        self.transfer.eliminate(a1_list, a2_list, b1_list, b2_list, c_list, d_list)

                        for i in range(len(a1_list)):
                            if a1_list[i][0] == 100000 and a1_list[i][0] == 100000:
                                a1_list[i] = None

                        for i in range(len(a2_list)):
                            if a2_list[i][0] == 100000 and a2_list[i][0] == 100000:
                                a2_list[i] = None

                        for i in range(len(b1_list)):
                            if b1_list[i][0] == 100000 and b1_list[i][0] == 100000:
                                b1_list[i] = None

                        for i in range(len(b2_list)):
                            if b2_list[i][0] == 100000 and b2_list[i][0] == 100000:
                                b2_list[i] = None

                        for i in range(len(c_list)):
                            if c_list[i][0] == 100000 and c_list[i][0] == 100000:
                                c_list[i] = None

                        for i in range(len(d_list)):
                            if d_list[i][0] == 100000 and d_list[i][0] == 100000:
                                d_list[i] = None

                        headcount_info["175-A1"]['personRect'] = a1_list
                        headcount_info["175-A2"]['personRect'] = a2_list
                        headcount_info["175-B1"]['personRect'] = b1_list
                        headcount_info["175-B2"]['personRect'] = b2_list
                        headcount_info["175-C"]['personRect'] = c_list
                        headcount_info["175-D"]['personRect'] = d_list

                        for key, value in headcount_info.items():
                            capture_time = value['captureTime']
                            now_time = datetime.now()
                            compare_time = now_time - capture_time
                            if compare_time.seconds < 3:
                                debug_count_info.append(str(key) + "_" + str(value['count']))

                                person_rect_list = value['personRect']
                                person_track_list = value['personTrack']
                                person_vector_list = value['personVector']
                                person_count = value['count']
                                if person_rect_list and person_track_list and person_count:
                                    for i in range(person_count):
                                        if person_rect_list[i] and person_rect_list[i][0] < 2000:
                                            positions_list.append({"trackId": key + "_" + str(person_track_list[i]),
                                                                   "x": person_rect_list[i][0],
                                                                   "y": person_rect_list[i][1],
                                                                   "vector": person_vector_list[i]})

                    self.persons_info_new = positions_list
                    self.safe_cache_headcount_debug = debug_count_info

                    if self.persons_info_old:
                        for person_info_old in self.persons_info_old:
                            for person_info_new in self.persons_info_new:
                                if person_info_new["trackId"] == person_info_old["trackId"]:
                                    vector = math.atan2((person_info_new["x"] - person_info_old["x"]),
                                                        (person_info_old["y"] - person_info_new["y"]))

                                    person_info_new["vector"] = vector
                                    break

                    self.update_ok = True
                    capture_database.add_socket_result(self.persons_info_new)

                    if self._heatmap:
                        self._heatmap.update_heat_np(headcount_info)
                else:
                    capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                                database_name=self._app.config['DATABASE_NAME'],
                                                table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                                table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                                table_name_segmentation=self._app.config[
                                                    'TABLE_NAME_SEGMENTATION_DATA'])
                    connect_error = False

            except Exception as err:
                connect_error = True
                logger.error('Connect to db for save headcount info error.', err)
                time.sleep(5)

            # capture_database.select_from_table_desc_10(table_name=self._app.config['TABLE_NAME_SOCKET_DATA'])
            time.sleep(1)
            self.persons_info_old = self.persons_info_new

    def headcount_task_add(self, task_name, count=0, personRect=[], personTrack=[]):
        try:
            task_name = str(task_name)
            count = int(count)

            if count == len(personRect):
                self.lock.acquire()

                self.safe_cache_headcount[task_name]['count'] = count
                self.safe_cache_headcount[task_name]['personRect'] = personRect
                self.safe_cache_headcount[task_name]['personTrack'] = personTrack
                self.safe_cache_headcount[task_name]['personVector'] = [0 for x in range(0, count)]
                self.safe_cache_headcount[task_name]['captureTime'] = datetime.now()
                self.lock.release()
                return True
            else:
                return False
        except Exception as err:
            logger.error('Error for add info to headcount cache.', err)
            self.lock.release()
            return False

    def segmentation_task_add(self, task_name, forward=0, reverse=0):
        try:
            task_name = str(task_name)
            self.lock.acquire()
            self.safe_cache_segmentation[task_name]['forward'] = forward
            self.safe_cache_segmentation[task_name]['reverse'] = reverse
            self.safe_cache_segmentation[task_name]['captureTime'] = datetime.now()
            self.lock.release()
            return True
        except Exception as err:
            self.lock.release()
            logger.error('Error for add info to segmentation cache.', err)
            return False

    def headcount_task_get(self):
        try:
            self.lock.acquire()
            headcount_info = self.persons_info_new
            self.lock.release()

            return headcount_info
        except Exception as err:
            logger.error('Error to get info to headcount cache.', err)
            self.lock.release()
            return False

    def headcount_task_debug_get(self):
        try:
            headcount_debug_info = self.safe_cache_headcount_debug

            return headcount_debug_info
        except Exception as err:
            logger.error('Error to get info to headcount cache.', err)
            return None
