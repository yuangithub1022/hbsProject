import threading
import time
from datetime import datetime, timedelta
import math
from threading import Lock
from functools import reduce
from queue import Queue, LifoQueue, PriorityQueue

from models.logger import logger
from models.database import Database
from coordinate_lib import coordinate_lib


class CacheQueue:
    def __init__(self, app=None, heatmap=None):
        self._app = app
        self._heatmap = heatmap
        self.lock = threading.Lock()

        self.transfer = coordinate_lib()

        self._task_name_list = []
        # for task_name in self._app.config["HEADCOUNT_TASK_NAME"]:
        #     self._task_name_list.append(task_name)

        self._task_name_tuple = ()
        # for index in range(len(self._task_name_list)):
        #     self._task_name_tuple += (Queue(maxsize=0),)

        self._headcount_queue_a1 = Queue(maxsize=0)
        self._headcount_queue_a2 = Queue(maxsize=0)
        self._headcount_queue_b1 = Queue(maxsize=0)
        self._headcount_queue_b2 = Queue(maxsize=0)
        self._headcount_queue_c = Queue(maxsize=0)
        self._headcount_queue_d = Queue(maxsize=0)

        self.update_ok = False

        self.test = (self._headcount_queue_a1, self._headcount_queue_a2, self._headcount_queue_b1,
                     self._headcount_queue_b2, self._headcount_queue_c, self._headcount_queue_d)

        # for cal vector
        self.persons_info_old = []
        self.persons_info_new = []

        self.safe_cache_headcount_debug = []

        self._loop_save_headcount()

    def _loop_save_headcount(self):
        self._thread = threading.Thread(target=self.loop_forever)
        self._thread.setDaemon(True)
        self._thread.start()

    def loop_forever(self):
        connect_error = False
        try:
            capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                        database_name=self._app.config['DATABASE_NAME'],
                                        table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                        table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                        table_name_segmentation=self._app.config['TABLE_NAME_SEGMENTATION_DATA'])
        except Exception as err:
            connect_error = True
            logger.error('Connect to db for save headcount info error.', err)

        while True:
            try:
                if not connect_error:
                    if not self._headcount_queue_a1.empty() and not self._headcount_queue_a2.empty() and\
                            not self._headcount_queue_b1.empty() and not self._headcount_queue_b2.empty() and\
                            not self._headcount_queue_c.empty() and not self._headcount_queue_d.empty():
                        # get headcount all task
                        tasks_info = [self._headcount_queue_a1.get(), self._headcount_queue_a2.get(),
                                      self._headcount_queue_b1.get(), self._headcount_queue_b2.get(),
                                      self._headcount_queue_c.get(), self._headcount_queue_d.get()]

                        positions_list = []
                        debug_count_info = []

                        a1_list = []
                        a2_list = []
                        b1_list = []
                        b2_list = []
                        c_list = []
                        d_list = []

                        if tasks_info:
                            for task_info in tasks_info:
                                if task_info["task_name"] == "175-A1":
                                    for rect in task_info['personRect']:
                                        if not rect:
                                            a1_list.append([100000, 100000])
                                        else:
                                            a1_list.append([rect[0], rect[1]])
                                elif task_info["task_name"] == "175-A2":
                                    for rect in task_info['personRect']:
                                        if not rect:
                                            a2_list.append([100000, 100000])
                                        else:
                                            a2_list.append([rect[0], rect[1]])
                                elif task_info["task_name"] == "175-B1":
                                    for rect in task_info['personRect']:
                                        if not rect:
                                            b1_list.append([100000, 100000])
                                        else:
                                            b1_list.append([rect[0], rect[1]])
                                elif task_info["task_name"] == "175-B2":
                                    for rect in task_info['personRect']:
                                        if not rect:
                                            b2_list.append([100000, 100000])
                                        else:
                                            b2_list.append([rect[0], rect[1]])
                                elif task_info["task_name"] == "175-C":
                                    for rect in task_info['personRect']:
                                        if not rect:
                                            c_list.append([100000, 100000])
                                        else:
                                            c_list.append([rect[0], rect[1]])
                                elif task_info["task_name"] == "175-D":
                                    for rect in task_info['personRect']:
                                        if not rect:
                                            d_list.append([100000, 100000])
                                        else:
                                            d_list.append([rect[0], rect[1]])

                            self.transfer.eliminate(a1_list, a2_list, b1_list, b2_list, c_list, d_list)

                            for i in range(len(a1_list)):
                                if a1_list[i][0] == 100000 and a1_list[i][0] == 100000:
                                    a1_list[i] = None

                            for i in range(len(a2_list)):
                                if a2_list[i][0] == 100000 and a2_list[i][0] == 100000:
                                    a2_list[i] = None

                            for i in range(len(b1_list)):
                                if b1_list[i][0] == 100000 and b1_list[i][0] == 100000:
                                    b1_list[i] = None

                            for i in range(len(b2_list)):
                                if b2_list[i][0] == 100000 and b2_list[i][0] == 100000:
                                    b2_list[i] = None

                            for i in range(len(c_list)):
                                if c_list[i][0] == 100000 and c_list[i][0] == 100000:
                                    c_list[i] = None

                            for i in range(len(d_list)):
                                if d_list[i][0] == 100000 and d_list[i][0] == 100000:
                                    d_list[i] = None

                            for task_info in tasks_info:
                                if task_info["task_name"] == "175-A1":
                                    task_info['personRect'] = a1_list
                                elif task_info["task_name"] == "175-A2":
                                    task_info['personRect'] = a2_list
                                elif task_info["task_name"] == "175-B1":
                                    task_info['personRect'] = b1_list
                                elif task_info["task_name"] == "175-B2":
                                    task_info['personRect'] = b2_list
                                elif task_info["task_name"] == "175-C":
                                    task_info['personRect'] = c_list
                                elif task_info["task_name"] == "175-D":
                                    task_info['personRect'] = d_list

                        for task_info in tasks_info:
                            task_name = task_info['task_name']
                            person_rect_list = task_info['personRect']
                            person_track_list = task_info['personTrack']
                            person_vector_list = task_info['personVector']
                            person_count = task_info['count']

                            debug_count_info.append(task_info['debugInfo'])

                            if person_rect_list and person_track_list and person_count:
                                for i in range(person_count):
                                    if person_rect_list[i]:
                                        positions_list.append({"trackId": task_name + "_" + str(person_track_list[i]),
                                                               "x": person_rect_list[i][0],
                                                               "y": person_rect_list[i][1],
                                                               "vector": person_vector_list[i]})

                                        positions_list.append({"trackId": task_name + "_" + str(person_count),
                                                               "x": person_rect_list[i][0],
                                                               "y": person_rect_list[i][1],
                                                               "vector": person_vector_list[i]})

                        self.persons_info_new = positions_list
                        self.safe_cache_headcount_debug = debug_count_info

                        if self.persons_info_old:
                            for person_info_old in self.persons_info_old:
                                for person_info_new in self.persons_info_new:
                                    if person_info_new["trackId"] == person_info_old["trackId"]:
                                        vector = math.atan2((person_info_new["x"] - person_info_old["x"]),
                                                            (person_info_old["y"] - person_info_new["y"]))

                                        person_info_new["vector"] = vector
                                        break

                        self.update_ok = True
                        capture_database.add_socket_result(self.persons_info_new)

                        self.persons_info_old = self.persons_info_new

                        self._heatmap.update_heat_np_queue(self.persons_info_new)
                else:
                    capture_database = Database(database_path=self._app.config['DATABASE_PATH'],
                                                database_name=self._app.config['DATABASE_NAME'],
                                                table_name_capture=self._app.config['TABLE_NAME_CAPTURE_DATA'],
                                                table_name_socket=self._app.config['TABLE_NAME_SOCKET_DATA'],
                                                table_name_segmentation=self._app.config[
                                                    'TABLE_NAME_SEGMENTATION_DATA'])
                    connect_error = False

            except Exception as err:
                connect_error = True
                logger.error('Connect to db for save headcount info error.', err)
                time.sleep(5)

            time.sleep(0.01)

    def headcount_task_add_queue(self, task_name, count=0, personRect=[], personTrack=[]):
        try:
            task_name = str(task_name)
            count = int(count)

            if count == len(personRect):
                dict_headcount = {'task_name': task_name,
                                  'count': count,
                                  'personRect': personRect,
                                  'personTrack': personTrack,
                                  'personVector': [0 for x in range(0, count)],
                                  'captureTime': datetime.now(),
                                  'debugInfo': str(task_name) + "_" + str(count)}

                if task_name == "175-A1":
                    self.test[0].put(dict_headcount)
                    self._headcount_queue_a1.put(dict_headcount)
                elif task_name == "175-A2":
                    self._headcount_queue_a2.put(dict_headcount)
                elif task_name == "175-B1":
                    self._headcount_queue_b1.put(dict_headcount)
                elif task_name == "175-B2":
                    self._headcount_queue_b2.put(dict_headcount)
                elif task_name == "175-C":
                    self._headcount_queue_c.put(dict_headcount)
                elif task_name == "175-D":
                    self._headcount_queue_d.put(dict_headcount)

                return True
            else:
                return False
        except Exception as err:
            logger.error('Error for add info to headcount cache.', err)
            self.lock.release()
            return False

    def headcount_task_get(self):
        try:
            self.lock.acquire()
            headcount_info = self.persons_info_new
            self.lock.release()

            return headcount_info
        except Exception as err:
            logger.error('Error to get info to headcount cache.', err)
            self.lock.release()
            return False

    def headcount_task_debug_get(self):
        try:
            headcount_debug_info = self.safe_cache_headcount_debug

            return headcount_debug_info
        except Exception as err:
            logger.error('Error to get info to headcount cache.', err)
            return None
