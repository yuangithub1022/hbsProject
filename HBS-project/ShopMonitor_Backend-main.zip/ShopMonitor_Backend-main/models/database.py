import os
import os.path as osp
import sqlite3
from datetime import datetime
import json

from models.logger import logger


class Database:
    def __init__(self, database_path="./crowd_db", database_name='crowd_shop_monitor.db',
                 table_name_capture="CAPTURE_DATA_TABLE", table_name_socket="SOCKET_DATA_TABLE",
                 table_name_segmentation="SEGMENTATION_DATA_TABLE", app=None):
        self._db_conn = None
        self._db_cursor = None
        self._db_path = database_path
        self._db_name = database_name
        self._table_name_capture = table_name_capture
        self._table_name_socket = table_name_socket
        self._table_name_segmentation = table_name_segmentation
        self._table_name_capture_time_check = "CAPTURE_TIME_DATA_TABLE"
        self._table_name_area_info_rank = "AREA_INFO_RANK_TABLE"
        self._table_name_retention_time_rank = "AVERAGE_RETENTION_TIME_TABLE"

        self._app = app
        self._task_headcount_info = []
        self._task_segmentation_info = []

        if self._app:
            if self._app.config['HEADCOUNT_TASK_INFO']:
                self._task_headcount_info = self._app.config['HEADCOUNT_TASK_INFO']

            if self._app.config['SEGMENTATION_TASK_INFO']:
                self._task_segmentation_info = self._app.config['SEGMENTATION_TASK_INFO']

        self._db_conn_init()

        # self.create_tables()
        # self.select_from_table_all(self._table_name_segmentation)

    def __del__(self):
        self._db_conn_close()
        logger.info(f'Close database:{self._db_name} success.')

    def add_capture_result(self, capture_data="", task_name=""):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                logger.waining(f'Cannot add result to table. database:{self._db_name} is not open.')
                return

        try:
            capture_data = str(capture_data)
            task_name = str(task_name)
            task_name_new = task_name.replace('-', '_')
            table_name = self._table_name_capture + '_' + task_name_new
        except Exception as err:
            logger.error(f'INSERT data error.', err)
            return

        try:
            self._db_cursor.execute("INSERT INTO %s VALUES(NULL,?,?);"
                                    % table_name, (capture_data, datetime.now()))
            self._db_conn.commit()
            logger.info(f'INSERT result to table:{table_name} success')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def add_capture_time_result(self, capture_data="", task_name="", task_type="", capture_time="",
                                upload_result_time="", received_time=""):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                logger.waining(f'Cannot add result to table. database:{self._db_name} is not open.')
                return

        try:
            capture_data = str(capture_data)
            task_name = str(task_name)
            task_name_new = task_name.replace('-', '_')
        except Exception as err:
            logger.error(f'INSERT data error.', err)
            return

        try:
            self._db_cursor.execute("INSERT INTO %s VALUES(NULL,?,?,?,?,?,?,?);"
                                    % self._table_name_capture_time_check, (capture_data, task_name_new, task_type,
                                                                            capture_time, upload_result_time,
                                                                            received_time, datetime.now()))
            self._db_conn.commit()
            logger.info(f'INSERT result to table:{self._table_name_capture_time_check} success')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def add_socket_result(self, socket_data=""):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                logger.waining(f'Cannot add result to table. database:{self._db_name} is not open.')
                return

        try:
            socket_data = str(socket_data)
        except Exception as err:
            logger.error(f'INSERT data error.', err)
            return

        try:
            self._db_cursor.execute("INSERT INTO %s VALUES(NULL,?,?);"
                                    % self._table_name_socket, (socket_data, datetime.now()))
            self._db_conn.commit()
            logger.info(f'INSERT result to table:{self._table_name_socket} success.')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'INSERT result to table error.', err)
            return

    def add_segmentation_result(self, forward_count=0, reverse_count=0, task_name=""):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                logger.waining(f'Cannot add result to table. database:{self._db_name} is not open.')
                return False

        try:
            forward_count = int(forward_count)
            reverse_count = int(reverse_count)
            task_name = str(task_name)
        except Exception as err:
            logger.error(f'INSERT data error.', err)
            return False

        try:
            self._db_cursor.execute("INSERT INTO %s VALUES(NULL,?,?,?,?);"
                                    % self._table_name_segmentation,
                                    (forward_count, reverse_count, task_name, datetime.now()))
            self._db_conn.commit()
            logger.info(f'INSERT result to table:{self._table_name_segmentation} success')
            return True
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return False

    def add_area_result(self, area_info="", area_rank=""):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                logger.waining(f'Cannot add result to table. database:{self._db_name} is not open.')
                return

        try:
            area_info = str(area_info)
            area_rank = str(area_rank)
        except Exception as err:
            logger.error(f'INSERT data error.', err)
            return

        try:
            self._db_cursor.execute("INSERT INTO %s VALUES(NULL,?,?,?);"
                                    % self._table_name_area_info_rank, (area_info, area_rank, datetime.now()))
            self._db_conn.commit()
            logger.info(f'INSERT result to table:{self._table_name_area_info_rank} success')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def add_retention_result(self, average_retention_time=""):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                logger.waining(f'Cannot add result to table. database:{self._db_name} is not open.')
                return

        try:
            average_retention_time = str(average_retention_time)
        except Exception as err:
            logger.error(f'INSERT data error.', err)
            return

        try:
            self._db_cursor.execute("INSERT INTO %s VALUES(NULL,?,?);"
                                    % self._table_name_retention_time_rank, (average_retention_time, datetime.now()))
            self._db_conn.commit()
            logger.info(f'INSERT result to table:{self._table_name_retention_time_rank} success')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute("select * from '%s'" % str(table_name))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} success.')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_today(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute("select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','+0 day') "
                                    "and "
                                    "CAPTURE_TIME<datetime('now','start of day','+1 day')" % str(table_name))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} success.')
            return results
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_yesterday(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute(
                "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "CAPTURE_TIME<datetime('now','start of day','-%s hour')"
                % (str(table_name), 24 - 10, 24 - 18))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} success.')
            return results
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_before(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute(
                "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "CAPTURE_TIME<datetime('now','start of day','-%s hour')"
                % (str(table_name), 48 - 10, 48 - 18))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} success.')
            return results
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_today_hour(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            data_today = []
            for i in range(10, 18):
                self._db_cursor.execute(
                    "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','+%s hour') "
                    "and "
                    "CAPTURE_TIME<datetime('now','start of day','+%s hour')" % (str(table_name), i, i + 1))
                count_hour = self._db_cursor.fetchall()

                count_sum_hour = 0
                if count_hour:
                    for task_item in count_hour:
                        count_sum_hour += task_item[1]

                data_today.append(count_sum_hour)

            # for count_hour in results_hour:
            logger.info(f'Select table:{str(table_name)} success.')
            return data_today

        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_today_for_retention(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_sum_list = []
            forward_sum_list = []
            reverse_sum_list = []

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','+%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','+%s hour')"
                % (str(self._table_name_socket), 10, 18))
            headcount_info = self._db_cursor.fetchall()

            if headcount_info:
                for task_item in headcount_info:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_sum_list.append(len(task_item_list))
                    else:
                        headcount_sum_list.append(0)

            self._db_cursor.execute(
                "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','+%s hour') "
                "and "
                "CAPTURE_TIME<datetime('now','start of day','+%s hour')"
                % (str(self._table_name_segmentation), 10, 18))
            count_info = self._db_cursor.fetchall()

            if count_info:
                for task_item in count_info:
                    forward_sum_list.append(int(task_item[1]))
                    reverse_sum_list.append(int(task_item[2]))

            return headcount_sum_list, forward_sum_list, reverse_sum_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_yesterday_for_retention(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_sum_list = []
            forward_sum_list = []
            reverse_sum_list = []

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','-%s hour')"
                % (str(self._table_name_socket), 24 - 10, 24 - 18))

            headcount_info = self._db_cursor.fetchall()

            if headcount_info:
                for task_item in headcount_info:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_sum_list.append(len(task_item_list))
                    else:
                        headcount_sum_list.append(0)

            self._db_cursor.execute(
                "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "CAPTURE_TIME<datetime('now','start of day','-%s hour')"
                % (str(self._table_name_segmentation), 24 - 10, 24 - 18))
            count_info = self._db_cursor.fetchall()

            if count_info:
                for task_item in count_info:
                    forward_sum_list.append(int(task_item[1]))
                    reverse_sum_list.append(int(task_item[2]))

            return headcount_sum_list, forward_sum_list, reverse_sum_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_before_for_retention(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_sum_list = []
            forward_sum_list = []
            reverse_sum_list = []

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','-%s hour')"
                % (str(self._table_name_socket), 48 - 10, 48 - 18))

            headcount_info = self._db_cursor.fetchall()

            if headcount_info:
                for task_item in headcount_info:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_sum_list.append(len(task_item_list))
                    else:
                        headcount_sum_list.append(0)

            self._db_cursor.execute(
                "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "CAPTURE_TIME<datetime('now','start of day','-%s hour')"
                % (str(self._table_name_segmentation), 48 - 10, 48 - 18))
            count_info = self._db_cursor.fetchall()

            if count_info:
                for task_item in count_info:
                    forward_sum_list.append(int(task_item[1]))
                    reverse_sum_list.append(int(task_item[2]))

            return headcount_sum_list, forward_sum_list, reverse_sum_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_today_for_heat(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_info_list = []

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','+%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','+%s hour')"
                % (str(self._table_name_socket), 10, 18))

            headcount_info = self._db_cursor.fetchall()

            if headcount_info:
                for task_item in headcount_info:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_info_list.append(task_item_list)

            return headcount_info_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_yesterday_for_heat(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_info_list = []

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','-%s hour')"
                % (str(self._table_name_socket), 24 - 10, 24 - 18))

            headcount_info = self._db_cursor.fetchall()

            if headcount_info:
                for task_item in headcount_info:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_info_list.append(task_item_list)

            return headcount_info_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_before_for_heat(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_info_list = []

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','-%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','-%s hour')"
                % (str(self._table_name_socket), 48 - 10, 48 - 18))

            headcount_info = self._db_cursor.fetchall()

            if headcount_info:
                for task_item in headcount_info:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_info_list.append(task_item_list)

            return headcount_info_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_today_hour_for_retention(self, start_time):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        try:
            headcount_sum_list = []
            forward_sum_list = []
            reverse_sum_list = []

            i = int(start_time)

            if i < 10 or i > 17:
                return

            self._db_cursor.execute(
                "select * from '%s' where SEND_TIME>=datetime('now','start of day','+%s hour') "
                "and "
                "SEND_TIME<datetime('now','start of day','+%s hour')"
                % (str(self._table_name_socket), i, i + 1))
            headcount_hour = self._db_cursor.fetchall()

            if headcount_hour:
                for task_item in headcount_hour:
                    test_item_replace = task_item[1].replace("\'", "\"")
                    task_item_list = json.loads(test_item_replace)
                    if task_item_list:
                        headcount_sum_list.append(len(task_item_list))
                    else:
                        headcount_sum_list.append(0)

            self._db_cursor.execute(
                "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','+%s hour') "
                "and "
                "CAPTURE_TIME<datetime('now','start of day','+%s hour')"
                % (str(self._table_name_segmentation), i, i + 1))
            count_hour = self._db_cursor.fetchall()

            if count_hour:
                for task_item in count_hour:
                    forward_sum_list.append(int(task_item[1]))
                    reverse_sum_list.append(int(task_item[2]))

            return headcount_sum_list, forward_sum_list, reverse_sum_list
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_yesterday_hour(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return [], [], []

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            data_yesterday = []
            for i in range(10, 18):
                self._db_cursor.execute(
                    "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','-%s hour') "
                    "and "
                    "CAPTURE_TIME<datetime('now','start of day','-%s hour')" % (str(table_name), 24-i, 24-i-1))
                count_hour = self._db_cursor.fetchall()

                count_sum_hour = 0
                if count_hour:
                    for task_item in count_hour:
                        count_sum_hour += task_item[1]

                data_yesterday.append(count_sum_hour)

            # for count_hour in results_hour:
            logger.info(f'Select table:{str(table_name)} success.')
            return data_yesterday

        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all_before_hour(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return [], [], []

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            data_before = []
            for i in range(10, 18):
                self._db_cursor.execute(
                    "select * from '%s' where CAPTURE_TIME>=datetime('now','start of day','-%s hour') "
                    "and "
                    "CAPTURE_TIME<datetime('now','start of day','-%s hour')" % (str(table_name), 48-i, 48-i-1))
                count_hour = self._db_cursor.fetchall()

                count_sum_hour = 0
                if count_hour:
                    for task_item in count_hour:
                        count_sum_hour += task_item[1]

                data_before.append(count_sum_hour)

            # for count_hour in results_hour:
            logger.info(f'Select table:{str(table_name)} success.')
            return data_before

        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_desc_10(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute("select * from '%s' order by id desc limit 10" % str(table_name))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} data:{results}')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_desc_1(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute("select * from '%s' order by id desc limit 1" % str(table_name))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} data:{results}')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def select_from_table_all(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot select table. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute("select * from '%s'" % str(table_name))
            results = self._db_cursor.fetchall()
            logger.info(f'Select table:{str(table_name)} success.')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Select table error.', err)
            return

    def _db_conn_init(self):
        self._make_db_dir(self._db_path)

        try:
            self._db_conn = sqlite3.connect(osp.join(self._db_path, self._db_name))
            self._db_cursor = self._db_conn.cursor()
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Opened database:{self._db_name} error.', err)
            return

        logger.info(f'Opened database:{self._db_name} success.')

    def _db_conn_close(self):
        try:
            if self._db_conn:
                self._db_conn.close()
                self._db_conn = None
            if self._db_cursor:
                self._db_cursor = None
        except Exception as err:
            logger.error(f'Close database error.', err)
            self._db_conn = None
            self._db_cursor = None

    def _check_db_opened(self):
        if not self._db_conn and not self._db_cursor:
            self._db_conn_init()
            if not self._db_conn and not self._db_cursor:
                return False

        return True

    def create_tables(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot create table. database:{self._db_name} is not open.')
            return

        try:
            # create tables if not exists
            if self._task_headcount_info:
                for task_name in self._task_headcount_info:
                    task_name_new = task_name.replace('-', '_')
                    table_name = self._table_name_capture + '_' + task_name_new
                    self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                                       ( ID            INTEGER PRIMARY KEY,
                                         CAPTURE_DATA  TEXT           NOT NULL,
                                         CAPTURE_TIME  TimeStamp      NOT NULL DEFAULT (datetime('now','localtime')));
                                         ''' % table_name)
                    self._db_conn.commit()

            if self._task_segmentation_info:
                for task_name in self._task_segmentation_info:
                    task_name_new = task_name.replace('-', '_')
                    table_name = self._table_name_capture + '_' + task_name_new
                    self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                                       ( ID            INTEGER PRIMARY KEY,
                                         CAPTURE_DATA  TEXT           NOT NULL,
                                         CAPTURE_TIME  TimeStamp      NOT NULL DEFAULT (datetime('now','localtime')));
                                         ''' % table_name)
                    self._db_conn.commit()

            # test for all task capture result
            # self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
            #        ( ID            INTEGER PRIMARY KEY,
            #          CAPTURE_DATA  TEXT                    NOT NULL,
            #          CAPTURE_TIME  TimeStamp               NOT NULL DEFAULT (datetime('now','localtime')));
            #          ''' % self._table_name_capture)
            # self._db_conn.commit()

            self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                    ( ID            INTEGER PRIMARY KEY,
                      SOCKET_DATA   TEXT                 NOT NULL,
                      SEND_TIME     TimeStamp            NOT NULL DEFAULT (datetime('now','localtime')));
                      ''' % self._table_name_socket)
            self._db_conn.commit()

            self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                    ( ID             INTEGER PRIMARY KEY,
                      FORWARD_COUNT  INT                   NOT NULL,
                      REVERSE_COUNT  INT                   NOT NULL,
                      TASK_NAME      TEXT                  NOT NULL,
                      CAPTURE_TIME   TimeStamp             NOT NULL DEFAULT (datetime('now','localtime')));
                      ''' % self._table_name_segmentation)

            self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                    ( ID             INTEGER PRIMARY KEY,
                      AREA_INFO      TEXT                 NOT NULL,
                      AREA_RANK      TEXT                 NOT NULL,
                      UPDATE_TIME    TimeStamp            NOT NULL DEFAULT (datetime('now','localtime')));
                      ''' % self._table_name_area_info_rank)

            self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                    ( ID                           INTEGER PRIMARY KEY,
                      AVERAGE_RETENTION_TIME       TEXT                 NOT NULL,
                      UPDATE_TIME                  TimeStamp            NOT NULL DEFAULT (datetime('now','localtime')));
                      ''' % self._table_name_retention_time_rank)

            # table for check time for test
            self._db_cursor.execute('''CREATE TABLE IF NOT EXISTS %s
                               ( ID            INTEGER PRIMARY KEY,
                                 CAPTURE_DATA  TEXT                    NOT NULL,
                                 TASK_NAME  TEXT                    NOT NULL,
                                 TASK_TYPE  TEXT                    NOT NULL,
                                 TIME_CAPTURE_TIME  TEXT                    NOT NULL,
                                 TIME_UPLOAD_RESULT_TIME  TEXT                    NOT NULL,
                                 TIME_RECEIVED_TIME  TEXT                    NOT NULL,
                                 UPDATE_TIME  TimeStamp             NOT NULL DEFAULT (datetime('now','localtime')));
                                 ''' % self._table_name_capture_time_check)

            self._db_conn.commit()

        except Exception as err:
            self._db_conn_close()
            logger.error(f'Create table error.', err)
            return

    def _get_tables(self):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot get tables. database:{self._db_name} is not open.')
            return

        try:
            self._db_cursor.execute("select name from sqlite_master where type='table' order by name")
            results = self._db_cursor.fetchall()
            logger.info(f'Get table list in database:{results}')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Get tables error.', err)
            return

    def _get_table_structure(self, table_name=""):
        is_opened = self._check_db_opened()
        if not is_opened:
            logger.waining(f'Cannot get table structure. database:{self._db_name} is not open.')
            return

        if not table_name:
            logger.waining(f'Not found table name.')
            return

        try:
            self._db_cursor.execute("PRAGMA table_info(%s)" % str(table_name))
            results = self._db_cursor.fetchall()
            logger.info(f'Get table:{str(table_name)} structure:{results}')
        except Exception as err:
            self._db_conn_close()
            logger.error(f'Get table structure error.', err)
            return

    @staticmethod
    def _make_db_dir(dir_name):
        try:
            if not osp.exists(dir_name):
                os.makedirs(dir_name, exist_ok=True)
            return
        except Exception as err:
            logger.error(f'Make database dir error. dir:{dir_name}', err)
            return
