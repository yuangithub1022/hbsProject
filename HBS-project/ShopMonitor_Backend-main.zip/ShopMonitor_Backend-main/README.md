# restful api server

## run for test

``` bash
# install pipenv depends
pipenv install

# enter pipenv shell
pipenv shell

# run serve
python server.py

```
# Information
About floders 
log : save log transfer from atlas500
panorama: save panorama image, file name is fid from atlas500 log
structure_2d: image of 2d room structure
result: output 2d room structure with person position

# References for functions in coordinate_lib.pyc
## 1. def foot_coordinate(self,y1, y2, x1, x2, isy=1080, ssy=3.2, ch=2.525, ca=math.pi/5, fl:2.8)     
   参数说明：      
　　　　（1）该人物的b-box的左上角顶点的坐标为(x1,y1), 右下角顶点的坐标为(x2,y2)。      
　　　　（2）其余参数说明等待补充，现在用上面的默认值即可（程序中已经指定默认值）。     
## 2. def coordinate_2D(x:int, y:int)    
   参数说明：            
　　　　x和y是上面foot_coordinate函数的输出。   
