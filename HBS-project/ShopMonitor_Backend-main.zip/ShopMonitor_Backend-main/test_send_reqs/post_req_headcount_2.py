# importing the requests library
import requests
import json
import time

# defining the api-endpoint
API_ENDPOINT = "http://localhost:4442/capture"

# data to be sent to api
with open('../test_jsons/area/headcount/Headcount_Task_2_2.json') as json_file:
    data = json.load(json_file)

# sending post request and saving response as response object
while True:
    r = requests.post(url=API_ENDPOINT, json=data)

    # # extracting response text
    print(f'The response is: {r.text}')

    time.sleep(1)

