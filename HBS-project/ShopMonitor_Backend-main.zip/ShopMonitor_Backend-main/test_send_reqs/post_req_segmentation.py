# importing the requests library
import requests
import json

# defining the api-endpoint
API_ENDPOINT = "http://localhost:4442/capture"
# API_ENDPOINT = "http://localhost:5011/upload"

# data to be sent to api
with open('../test_jsons/line/segmentation/Segmentation_Task_1_f10_r5.json') as json_file:
    data = json.load(json_file)

# with open('../test_jsons/line/segmentation/data18.json') as json_file:
#     data = json.load(json_file)


# sending post request and saving response as response object
r = requests.post(url=API_ENDPOINT, json=data)
# extracting response text
print(f'The response is: {r.text}')

