#!/bin/bash
#scp -P 10092 -r root@172.30.150.101:"/home/hbs/crowd/source" /var/lib/docker/crowd/transfer
#rm -rf /var/lib/docker/crowd/source/*
#mv /var/lib/docker/crowd/transfer/source/*  /var/lib/docker/crowd/source
/var/lib/docker/crowdStore/util.sh -c stop
docker rmi atlas_crowd_store:1.0.0
docker build -t atlas_crowd_store:1.0.0 /var/lib/docker/crowdStore/
/var/lib/docker/crowdStore/util.sh -c start
docker logs -f atlas_crowd_store