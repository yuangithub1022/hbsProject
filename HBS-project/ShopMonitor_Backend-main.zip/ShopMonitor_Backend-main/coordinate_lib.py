import numpy as np
import cv2
import math
import matplotlib.pyplot as plt
import base64

class coordinate_lib:

    def coordinate_2D_c1(self, x:int, y:int):
        
        M = [[-2.42452621e-01, -8.40813056e-01,  2.53375614e+03],
             [ 1.77056655e+00, 1.03388931e+00, -8.87453840e+02],
             [-1.05320916e-04,  3.83629836e-03,  1.00000000e+00]]

        temp = np.dot(M, [x,y,1]) # plus 1 to (x,y,1) is my fixed approach        

        coor_final = temp/temp[2]     

        if ((coor_final[0]<=777) & (coor_final[1]<=699)):
           return (int(coor_final[0]), int(coor_final[1]))
        else:
           return None

    def coordinate_2D_c2(self, x:int, y:int):
        
        M_left = [[ 3.93219383e-01,  4.00416097e+00, -1.08135337e+02],
                  [-8.78518167e-01,  4.72784948e-02,  2.13765040e+03],
                  [ 1.55797343e-03,  3.15183690e-03,  1.00000000e+00]]

        M_right = [[-5.19457440e-01,  1.96284673e+00,  2.85712351e+02],
                   [-6.42036875e-01,  1.72928411e-01,  9.86358028e+02],
                   [-4.98913950e-04,  1.75393713e-03,  1.00000000e+00]]

        if (x<=816):
            temp = np.dot(M_left, [x,y,1]) # plus 1 to (x,y,1) is my fixed approach        
        else:
            temp = np.dot(M_right, [x,y, 1]) # plus 1 to (x,y,1) is my fixed approach    

        coor_final = temp/temp[2]     

        if (  ((coor_final[0]>=560)&(coor_final[1]<=271)) | ((coor_final[0]>=777)&(271<=coor_final[1]<=430)) ):
           return (int(coor_final[0]), int(coor_final[1]))
        else:
           return None

    def coordinate_2D_c3(self, x:int, y:int):
        
        M_left = [[ 1.49279470e+00,  4.48940271e+00, -1.11925915e+03],
                  [-1.02053522e+00,  2.80507574e+00,  8.27493280e+02],
                  [ 8.55137058e-04,  4.13311168e-03,  1.00000000e+00]]

        M_right = [[-1.85646998e-01,  1.39960565e+00,  1.81365666e+02],
                   [-5.71778277e-01,  7.21799875e-01,  5.93596471e+02],
                   [-5.57690991e-04,  1.26889708e-03,  1.00000000e+00]]

        if (x<=894):
            temp = np.dot(M_left, [x,y,1]) # plus 1 to (x,y,1) is my fixed approach        
        else:
            temp = np.dot(M_right, [x,y,1]) # plus 1 to (x,y,1) is my fixed approach    

        coor_final = temp/temp[2]     

        if (((coor_final[0]>=560)&(coor_final[1]>=446)) | ((coor_final[0]>=777)&(271<=coor_final[1]<=446)) ):
           return (int(coor_final[0]), int(coor_final[1]))
        else:
           return None


#*******************************************************************************************************************************************************************
    #apart from b1, every one is b2 purely 
    def foot_coordinate_c1(self, y1:int, y2:int, x1:int, x2:int, y_intersect=1800, x_intersect=750, isy=1080, ssy=4.0, ch=2.0, ca=0.72, fl=2.8):   #ssy is in mm unit, 
            
            x_m = (x1+x2)/2
            y_m = (y1+y2)/2
            if ((x_m>=1746) & (y_m>=911)):
                x1=1768
                y1=934
                x2=1908
                y2=1068

            if (x_m<=973):
                coor_final = self.foot_coordinate_core(y1,y2,x1,x2,y_intersect,x_intersect,isy,ssy,ch,ca,fl)
                return (int(coor_final[0]), int(coor_final[1]))
            else:
                coor_final = self.foot_coordinate_core(y1,y2,x1,x2,y_intersect=1800, x_intersect=750, isy=1080, ssy=4.0, ch=2.0, ca=0.74, fl=2.8)
                return (int(coor_final[0]), int(coor_final[1]))



    def foot_coordinate_c2(self, y1:int, y2:int, x1:int, x2:int, y_intersect=1800, x_intersect=840, isy=1080, ssy=4.0, ch=1.4, ca=0.58, fl=2.8):   #ssy is in mm unit, 

            x_m = (x1+x2)/2
            if (x_m>=816):
                coor_final = self.foot_coordinate_core(y1,y2,x1,x2,y_intersect,x_intersect,isy,ssy,ch,ca,fl)
                return (int(coor_final[0]), int(coor_final[1]))
            else:
                coor_final = self.foot_coordinate_core(y1,y2,x1,x2,y_intersect=1800,x_intersect=1000,isy=1080,ssy=4.0,ch=1.7,ca=0.58,fl=2.8)
                return (int(coor_final[0]), int(coor_final[1]))


    def foot_coordinate_c3(self, y1:int, y2:int, x1:int, x2:int, y_intersect=1600, x_intersect=900, isy=1080, ssy=4.0, ch=1.5, ca=0.58, fl=2.8):   #ssy is in mm unit, 

            x_m = (x1+x2)/2
            if (x_m<=894):
                coor_final = self.foot_coordinate_core(y1,y2,x1,x2,y_intersect,x_intersect,isy,ssy,ch,ca,fl)
                return (int(coor_final[0]), int(coor_final[1]))
            else:
                coor_final = self.foot_coordinate_core(y1,y2,x1,x2,y_intersect=1600, x_intersect=810, isy=1080, ssy=4.0, ch=1.5, ca=0.58, fl=2.8)
                return (int(coor_final[0]), int(coor_final[1]))



    def foot_coordinate_core(self, y1:int, y2:int, x1:int, x2:int, y_intersect=2300, x_intersect=960, isy=1080, ssy=4.1, ch=2.0, ca=0.72, fl=2.8):   #ssy is in mm unit, 
        #ca is in pi unit, fl is in mm unit np_org.shape[0], 3.2, 2.5, math.pi/6, 2.8
            his = isy//2

            rat = float(abs(x2-x1)/abs(y2-y1))
            
            x_center = (x1+x2)/2.0
            y_center = (y1+y2)/2.0
            
            hs = 0.122 #0.35
            
            if 1.2>=rat>=1.10:
                hs = 0.120

            elif 0.90>=rat>=0.8:
                hs = 0.125

            if rat>1.2:
                hs = 0.118
            elif rat<0.80:
                hs = 0.133              

            #hs = -0.05*rat + 0.17
            
            if (x_intersect-x_center)!=0:
                slope_loc = float((y_intersect-y_center)/(x_intersect-x_center))

                x_drift = float(((y2-y1)/2.0)/slope_loc)

                x_drifted = x_center + x_drift 

                if x_drifted<x1:
                    x_drifted = x1
                elif x_drifted>x2:
                    x_drifted = x2

                y2_incre = 2*np.sqrt((x_drifted-x_center)*(x_drifted-x_center) + (y2-y1)*(y2-y1)/4.0)

                y2 = y1 + y2_incre

                y2 = float((y1 + y2)/2.0)

                m2= float((float(abs(his - y2)*ssy))/isy) #shorter one on fil
                m1= float((float(abs(his - y1)*ssy))/isy) #longer one on fil

                if m1<=m2 : 
                    m_shorter = m1 
                    m_longer = m2    
                elif m1>m2 : 
                    m_shorter = m2
                    m_longer = m1

                theta_smaller_li_inters_sen = math.atan(float(fl/m_longer))
                theta_larger_li_inters_sen = math.atan(float(fl/m_shorter))

                if (y1<=his)&(y2<=his):
                    theta_cross = float(theta_larger_li_inters_sen - theta_smaller_li_inters_sen)
                    theta_closer_li_inters_wal =float(math.pi - theta_smaller_li_inters_sen - ca - theta_cross)
                    flag = 1

                elif (y1>=his)&(y2>=his):    
                    theta_cross = float(theta_larger_li_inters_sen - theta_smaller_li_inters_sen)
                    theta_closer_li_inters_wal = float(theta_smaller_li_inters_sen - ca)
                    flag = -1

                else:
                    if (y1<his): 
                        y_up = y1
                        y_down = y2
                    else: 
                        y_up = y2
                        y_down = y1

                    m_up = float((float(abs(his - y_up)*ssy))/isy)
                    m_down = float((float(abs(his - y_down)*ssy))/isy)

                    theta_m_up = math.atan(float(m_up/fl))
                    theta_m_up_aja = float((math.pi/2.0) - theta_m_up)
                    theta_cross = float(math.pi- theta_smaller_li_inters_sen - theta_larger_li_inters_sen)
                    theta_closer_li_inters_wal = float(math.pi - theta_m_up_aja - ca - theta_cross)
                    flag = 0

                theta_closer_hor = float((math.pi/2.0) - theta_closer_li_inters_wal)
                theta_farther_hor = float(theta_closer_hor - theta_cross)
                dist_closer = float(ch/float(math.tan(theta_closer_hor)))
                dist_farther = float(ch/math.tan(theta_farther_hor))
                w = float(dist_farther - dist_closer)
                s = float((float(w*math.tan(theta_farther_hor))-hs)/(math.tan(theta_closer_hor) - math.tan(theta_farther_hor)))

                x = float(s*math.tan(theta_closer_hor))

                if (flag == 1):

                    theta_fot_li_inters_wal = math.atan((dist_closer - s)/ch)
                    theta_fot_li_inters_came = theta_fot_li_inters_wal + ca
                    if(theta_fot_li_inters_came <= math.pi/2): 
                        foot = float(fl/math.tan(theta_fot_li_inters_came))

                        foot_coor =  foot
                    else :
                        theta_temp = math.pi - theta_fot_li_inters_came
                        foot = float(fl/math.tan(theta_temp))

                        foot_coor =  - foot

                elif (flag == -1):
                    theta_fot_li_inters_wal = math.atan((dist_closer - s)/ch)
                    theta_fot_li_inters_clo = theta_closer_li_inters_wal - theta_fot_li_inters_wal
                    theta_fot_li_inters_sen = theta_smaller_li_inters_sen - theta_fot_li_inters_clo
                    foot = float(fl/math.tan(theta_fot_li_inters_sen))
                    foot_coor =  foot     

                elif (flag == 0):
                    theta_fot_li_inters_wal = math.atan((dist_closer - s)/ch)
                    theta_fot_li_inters_clo = theta_closer_li_inters_wal - theta_fot_li_inters_wal        
                    theta_down_li_inters_sen = math.atan(float(fl/m_down))
                    theta_fot_li_inters_sen = theta_down_li_inters_sen - theta_fot_li_inters_clo 
                    foot = float(fl/math.tan(theta_fot_li_inters_sen))
                    foot_coor =  foot              

                foot_coor_y_origin_image = his + float(foot_coor/ssy)*isy

                via = x_drift*(foot_coor_y_origin_image - y_center)/(y2_incre/2.0)
                
                h_diff = via*x_drift/(y2_incre/2.0)  #还有一种下面那种弧形做法

                foot_coor_y_drifted = foot_coor_y_origin_image - h_diff/1.5 #chuizhi做法

                foot_coor_x_drift = ((y2-y1)/1.5)*h_diff/x_drift

                foot_coor_x_drifted = x_center + foot_coor_x_drift #signal included in foot_coor_x_drift
                #foot_coor_x_drifted = x_center + via  #弧形做法
                #foot_coor_y_drifted = y_center + ((y2-y1))*via/(x_drifted-x_center)

            elif (x_intersect-x_center)==0:
                
                y2 = float((y1 + y2)/2.0)

                hs = 0.12

                m2= float((float(abs(his - y2)*ssy))/isy) #shorter one on fil
                m1= float((float(abs(his - y1)*ssy))/isy) #longer one on fil

                if m1<=m2 : 
                    m_shorter = m1 
                    m_longer = m2    
                elif m1>m2 : 
                    m_shorter = m2
                    m_longer = m1

                theta_smaller_li_inters_sen = math.atan(float(fl/m_longer))
                theta_larger_li_inters_sen = math.atan(float(fl/m_shorter))

                if (y1<=his)&(y2<=his):
                    theta_cross = float(theta_larger_li_inters_sen - theta_smaller_li_inters_sen)
                    theta_closer_li_inters_wal =float(math.pi - theta_smaller_li_inters_sen - ca - theta_cross)
                    flag = 1

                elif (y1>=his)&(y2>=his):    
                    theta_cross = float(theta_larger_li_inters_sen - theta_smaller_li_inters_sen)
                    theta_closer_li_inters_wal = float(theta_smaller_li_inters_sen - ca)
                    flag = -1

                else:
                    if (y1<his): 
                        y_up = y1
                        y_down = y2
                    else: 
                        y_up = y2
                        y_down = y1

                    m_up = float((float(abs(his - y_up)*ssy))/isy)
                    m_down = float((float(abs(his - y_down)*ssy))/isy)

                    theta_m_up = math.atan(float(m_up/fl))
                    theta_m_up_aja = float((math.pi/2.0) - theta_m_up)
                    theta_cross = float(math.pi- theta_smaller_li_inters_sen - theta_larger_li_inters_sen)
                    theta_closer_li_inters_wal = float(math.pi - theta_m_up_aja - ca - theta_cross)
                    flag = 0

                theta_closer_hor = float((math.pi/2.0) - theta_closer_li_inters_wal)
                theta_farther_hor = float(theta_closer_hor - theta_cross)
                dist_closer = float(ch/float(math.tan(theta_closer_hor)))
                dist_farther = float(ch/math.tan(theta_farther_hor))
                w = float(dist_farther - dist_closer)
                s = float((float(w*math.tan(theta_farther_hor))-hs)/(math.tan(theta_closer_hor) - math.tan(theta_farther_hor)))

                x = float(s*math.tan(theta_closer_hor))

                if (flag == 1):

                    theta_fot_li_inters_wal = math.atan((dist_closer - s)/ch)
                    theta_fot_li_inters_came = theta_fot_li_inters_wal + ca
                    if(theta_fot_li_inters_came <= math.pi/2): 
                        foot = float(fl/math.tan(theta_fot_li_inters_came))

                        foot_coor =  foot
                    else :
                        theta_temp = math.pi - theta_fot_li_inters_came
                        foot = float(fl/math.tan(theta_temp))

                        foot_coor =  - foot

                elif (flag == -1):
                    theta_fot_li_inters_wal = math.atan((dist_closer - s)/ch)
                    theta_fot_li_inters_clo = theta_closer_li_inters_wal - theta_fot_li_inters_wal
                    theta_fot_li_inters_sen = theta_smaller_li_inters_sen - theta_fot_li_inters_clo
                    foot = float(fl/math.tan(theta_fot_li_inters_sen))
                    foot_coor =  foot     

                elif (flag == 0):
                    theta_fot_li_inters_wal = math.atan((dist_closer - s)/ch)
                    theta_fot_li_inters_clo = theta_closer_li_inters_wal - theta_fot_li_inters_wal    #     
                    theta_down_li_inters_sen = math.atan(float(fl/m_down))
                    theta_fot_li_inters_sen = theta_down_li_inters_sen - theta_fot_li_inters_clo 
                    foot = float(fl/math.tan(theta_fot_li_inters_sen))
                    foot_coor =  foot              

                foot_coor_y_drifted = his + float(foot_coor/ssy)*isy

                foot_coor_x_drifted = float((x1+x2)/2)

            return (int(foot_coor_x_drifted), int(foot_coor_y_drifted))













    
#**********************************************************extra functions***************************************************************    
    def poly_bounce_back(self, vertex_array, point_obj):
        flag = np.zeros((len(vertex_array), 1))
        for i in range(len(vertex_array)):
            if i == (len(vertex_array)-1): 
                flag[i] = self.signal(vertex_array[i], vertex_array[0], vertex_array, point_obj)
            else:
                flag[i] = self.signal(vertex_array[i], vertex_array[i+1], vertex_array, point_obj)
                    
        if np.sum(flag)==(len(vertex_array)-2):
            for i in range(len(vertex_array)):
                if flag[i]==-1:
                    if (vertex_array[i+1 if i<(len(vertex_array)-1) else 0][0]-vertex_array[i][0])!=0:
                        slope = float((vertex_array[i+1 if i<(len(vertex_array)-1) else 0][1]-vertex_array[i][1])/(vertex_array[i+1 if i<(len(vertex_array)-1) else 0][0]-vertex_array[i][0]))
                        b = vertex_array[i][1] - vertex_array[i][0]*slope
                        
                        if slope!=0:
                            dairu_y = float((point_obj[1]-b)/slope)
                            dairu_x = slope*point_obj[0]+b
                            tx = (point_obj[0] + dairu_y)/2.0
                            ty = (point_obj[1] + dairu_x)/2.0
                            revise_x =  tx - (point_obj[0]-tx)/abs(point_obj[0]-tx)
                            revise_y =  ty - (point_obj[1]-ty)/abs(point_obj[1]-ty)                    
                            #revise_x = float((dairu_y + (point_obj[0] + dairu_y)/2.0)/2.0)
                            #revise_y = float((dairu_x + (point_obj[1] + dairu_x )/2.0)/2.0)
                        else:
                            tx = point_obj[0]
                            ty = vertex_array[i][1]
                            revise_x = tx
                            revise_y = ty - (point_obj[1]-ty)/abs(point_obj[1]-ty)         
                    else:
                        
                        tx = vertex_array[i][0]
                        ty = point_obj[1]
                        revise_x =  tx - (point_obj[0]-tx)/abs(point_obj[0]-tx)
                        revise_y =  ty                     

            return [revise_x, revise_y]
                    
        if np.sum(flag)==(len(vertex_array)-4):
            for i in range(len(vertex_array)):
                if (flag[i]==-1)&(flag[i+1 if i<(len(vertex_array)-1) else 0]==-1):
                    tx = vertex_array[i+1 if i<(len(vertex_array)-1) else 0][0]
                    ty = vertex_array[i+1 if i<(len(vertex_array)-1) else 0][1]
                    if ((point_obj[0]-tx)!=0)&((point_obj[1]-ty)!=0):
                        revise_x =  tx - (point_obj[0]-tx)/abs(point_obj[0]-tx)
                        revise_y =  ty - (point_obj[1]-ty)/abs(point_obj[1]-ty)
                    elif ((point_obj[0]-tx)==0)&((point_obj[1]-ty)!=0):
                        revise_x =  tx 
                        revise_y =  ty - (point_obj[1]-ty)/abs(point_obj[1]-ty)     
                    elif ((point_obj[0]-tx)!=0)&((point_obj[1]-ty)==0):
                        revise_x =  tx - (point_obj[0]-tx)/abs(point_obj[0]-tx)
                        revise_y =  ty
            return [revise_x, revise_y]
        if np.sum(flag)==len(vertex_array):
            return point_obj

    def poly_inner_or_outer(self, vertex_array, point_obj):
        flag = np.zeros((len(vertex_array), 1))
        for i in range(len(vertex_array)):
            if i == (len(vertex_array)-1): 
                flag[i] = self.signal(vertex_array[i], vertex_array[0], vertex_array, point_obj)
            else:
                flag[i] = self.signal(vertex_array[i], vertex_array[i+1], vertex_array, point_obj)
                    
        if np.sum(flag)==len(vertex_array):
            return 1
        else:
            return 0
        
    def signal(self, point1, point2, vertex_array, point_obj):
        
        if (point2[0]-point1[0])!=0:
            slope = float((point2[1]-point1[1])/(point2[0]-point1[0]))
            b = point1[1] - point1[0]*slope
            add_point_obj = slope*point_obj[0]+b-point_obj[1]
            if add_point_obj>0:
                add_point_obj = 1
            elif add_point_obj<0:
                add_point_obj = -1
            
            add_vertex = 0 
        
            for i in range(len(vertex_array)):
                if (vertex_array[i]!=point1)&(vertex_array[i]!=point2):
                        dairu = slope*vertex_array[i][0]+b-vertex_array[i][1]
                        if dairu>0:
                            add_vertex = add_vertex + 1
                        elif dairu<0:
                            add_vertex = add_vertex - 1
                        
            add = add_point_obj + add_vertex     
        
        else:
            add_point_obj = point_obj[0] - point1[0]
            if add_point_obj>0:
                add_point_obj = 1
            elif add_point_obj<0:
                add_point_obj = -1
                
            add_vertex = 0
            for i in range(len(vertex_array)):
                if (vertex_array[i][0]!=point1[0])&(vertex_array[i][0]!=point2[0]):
                    add_or_no = vertex_array[i][0] - point1[0]
                    if add_or_no>0:
                        add_vertex = add_vertex + 1
                    elif add_or_no<0:
                        add_vertex = add_vertex - 1
    
            add = add_point_obj + add_vertex


        if (len(vertex_array) - abs(add))==1:
            return 1
        else:
            return -1              

    def average_retention_time(self, inter_array, entry_array, quit_array):
        quit_minus  = 0
        entry_minus = 0
        minus_range = 0
        
        entry_len = len(entry_array)
        
        for i in range(minus_range):
            quit_minus = quit_minus + (i+1)*quit_array[i] 
        
        for i in range(minus_range):
            entry_minus = entry_minus + (i+1)*entry_array[entry_len-1-i] 
        
        gross_sigma = np.sum(inter_array) #headcount计测到的所有秒的人数
        
        start_num = inter_array[minus_range] #start计测时间点上的场内人数
            
        entry_start_num = entry_array[minus_range]
        
        gross_estimate = gross_sigma - quit_minus - entry_minus #掐头去尾剩的高价值人群
        
        entry_estimate = np.sum(entry_array[:(entry_len-minus_range)])
        quit_estimate = np.sum(quit_array[minus_range:])
        
        # 1) 放弃的计算方式 average = float((gross_estimate - quit_estimate*minus_range)/entry_estimate)
        # 2) 放弃的计算方式 average = gross_estimate/(entry_estimate + quit_estimate + start_num - entry_start_num)    # - entry_start_num
        if entry_estimate | start_num:
            average = (gross_estimate - entry_estimate - quit_estimate)/(entry_estimate + start_num)    # - entry_start_num
        else:
            average = np.count_nonzero(inter_array)
        average_hour = int(np.floor(average/3600))
        average_minute = int(np.floor((average - average_hour*3600)/60))
        average_second = float(average - average_hour*3600 - average_minute*60)
        
        if (average_hour<0) | (average_minute<0):
            average_hour = 0
            average_minute = 0

        return (average_hour, average_minute, average_second)

    def heat_array_update(self, ground_array, persons_list):
        for person in persons_list:
            y_coor = person[0]
            x_coor = person[1]
            ground_array[x_coor, y_coor] = float(ground_array[x_coor, y_coor] + 1.0)

        return ground_array
    
    def heat_picture(self, heat_array):
    
        kernel = np.array([[1, 1,  1],
                           [1, -4, 1],
                           [1, 1,  1]])
        
        for i in range(100):
            lap = cv2.filter2D(heat_array,-1,kernel,borderType=0)
            heat_array = heat_array + lap*2000*(12/1187)*(12/1187)
        fig = plt.figure(dpi=100)
        fig.set_size_inches(10.65,7.00)
        plt.xticks([])
        plt.yticks([])
        plt.axis("off")
        plt.subplots_adjust(top=1,bottom=0,left=0,right=1,hspace=0,wspace=0) #let axes disappear
        plt.imsave("heatmap.png", heat_array, cmap=plt.cm.jet, vmin=0, vmax=np.max(heat_array))

##################  
        heat_img = cv2.imread("heatmap.png")
        map_img = cv2.imread("./structure_2d/map.jpg",cv2.IMREAD_COLOR)

        heat_img = cv2.resize(heat_img , (map_img.shape[1], map_img.shape[0]))
        alpha = 0.1 # 设置覆盖图片的透明度
        res_img = cv2.addWeighted(heat_img, alpha, map_img, 1-alpha, 0) # 将热度图覆盖到原图
        cv2.imwrite('result.jpg', res_img) # 保存覆盖后的处理结果
        return self.NdarrayToBase64(res_img)

    def NdarrayToBase64(self, img):
        result, dst_data = cv2.imencode('.jpg', img)
        img_base64 = base64.b64encode(dst_data).decode('utf-8')

        return img_base64
    
    
    def eliminate_within_two(self,arr1,arr2):
        delete_list = []
        same_two_persons_list = []
        found_or_not = 0
        for i in range(len(arr1)):
            found_or_not = 0
            for j in range(len(arr2)):
                if (np.sqrt(np.square(arr1[i][0]-arr2[j][0]) + np.square(arr1[i][1]-arr2[j][1])))<=53:
                    #arr1[i][0] = int((arr1[i][0]+arr2[j][0])/2.0)
                    #arr1[i][1] = int((arr1[i][1]+arr2[j][1])/2.0)
                    delete_list.append(j)
                    same_person = [ arr1[i][0], arr1[i][1], arr2[j][0], arr2[j][1] ]
                    same_two_persons_list.append(same_person)
                    found_or_not = 1
                    break
            if found_or_not ==1:
                continue

        for i in range(len(arr2)):
            if(i in delete_list):
                #arr3.append(arr2[i])
                arr2[i][0] = 100000
                arr2[i][1] = 100000
        
        return same_two_persons_list

    def eliminate(self,c1,c2,c3):

        list1=self.eliminate_within_two(c1,c2)
        list2=self.eliminate_within_two(c2,c3)
        list3=self.eliminate_within_two(c1,c3)
        list_all = []
        list_all = list1 + list2 + list3
        return list_all
