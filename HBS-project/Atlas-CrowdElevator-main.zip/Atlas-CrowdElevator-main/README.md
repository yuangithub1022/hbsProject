# Atlas-CrowdElevator

# Run

```
go run .
```


## Tidy up dependencies

```
go mod tidy
```

## Read Dependency on linux

```
readelf -d test
```

## Testing

```
cd tests
go test
go test -bench .
```

## Build on Atlas
First upload code to medium machine
```
cd scripts
python upload_code.py
```

login to Atlas
```
cd /var/lib/docker
mkdir crowdElevator
cd crowdElevator
mkdir source
mkdir transfer
mkdir config
```
upload ./config.json to /var/lib/docker/crowdElevator/config
upload ./docker/Dockerfile to /var/lib/docker/crowdElevator
upload ./docker/util.sh to /var/lib/docker/crowdElevator
upload ./docker/deploy.sh to /var/lib/docker/crowdElevator
```
chmod +x deploy.sh
chmod +x util.sh
./deploy.sh
```
