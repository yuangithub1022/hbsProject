package main

import (
	"fmt"
	"log"
	"net/http"
	"runtime"
	"strconv"
	"time"

	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/logger"

	"github.com/gin-gonic/gin"
	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/cache"
	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/rs485"
)

func main() {
	// Load the Config file
	conf := GetConfig()

	// init the safeCache
	cache.Init(conf.NumFloors, conf.NumCameras, conf.Interval, conf.Pattern)

	// Add microseconds to logs
	log.SetFlags(log.LstdFlags | log.Lmicroseconds)

	// Start the gin server
	gin.SetMode(gin.ReleaseMode)
	router := gin.New()
	router.Use(gin.Recovery()) // Recovery middleware recovers from any panics and writes a 500 if there was one.

	// upload api
	router.POST("/upload", func(c *gin.Context) {
		// parse crowd data
		var postData crowdData
		if err := c.ShouldBindJSON(&postData); err != nil {
			errMsg := "Cannot parse json " + err.Error()
			logger.Error(errMsg)
			c.String(http.StatusBadRequest, errMsg)
			return
		}

		floor, err := strconv.Atoi(postData.ExtraInfo.Floor)
		if err != nil {
			errMsg := "Cannot parse postData.ExtraInfo.Floor " + err.Error()
			logger.Error(errMsg)
			c.String(http.StatusBadRequest, errMsg)
			return
		}

		cameraNo := postData.ExtraInfo.CameraNo

		count := -1
		crowdType := postData.CaptureResult.Crowd.Type

		if crowdType == "CROWD_TYPE_HEADCOUNT" {
			count = postData.CaptureResult.Crowd.Subclass.Headcount.Count
		} else if crowdType == "CROWD_TYPE_RETENTION" {
			count = postData.CaptureResult.Crowd.Subclass.Retention.Count
		} else if crowdType == "CROWD_TYPE_DENSITY" {
			count = postData.CaptureResult.Crowd.Subclass.Density.Percent
		} else if crowdType == "CROWD_TYPE_SEGMENTATION" {
			count = postData.CaptureResult.Crowd.Subclass.Segmentation.Forward +
				postData.CaptureResult.Crowd.Subclass.Segmentation.Reverse
		} else if crowdType == "CROWD_TYPE_INTRUSION" {
			count = 0
			for _, i := range postData.CaptureResult.Crowd.Subclass.Intrusion.Interests {
				count += i.Count
			}
		} else {
			errMsg := fmt.Sprintf("Invalid post data %+v\n", postData)
			logger.Error(errMsg)
			c.String(http.StatusBadRequest, errMsg)
			return
		}

		if count == -1 {
			errMsg := fmt.Sprintf("Invalid post data %+v\n", postData)
			logger.Error(errMsg)
			c.String(http.StatusBadRequest, errMsg)
			return
		}

		if count == 0 {
			logger.Warn(fmt.Sprintf("/upload: %v: Count is 0", crowdType))
		}

		currTime := time.Now()
		cache.Update(floor, cameraNo, count, currTime)

		c.String(http.StatusOK, "ok")
	})

	logger.Info(fmt.Sprintf("%v CPU cores are used.", runtime.GOMAXPROCS(4)))

	// listen to rs485 port
	r := rs485.NewRS485(conf.BaudRate, conf.Parity, conf.DataBits, conf.StopBits, conf.PortName, conf.WaitWrite)
	r.Listen()

	err := router.Run(":5014")
	if err != nil {
		logger.Fatal("Cannot start gin server " + err.Error())
	}

}
