package main

type crowdData struct {
	TaskID    string `json:"task_id"`
	ExtraInfo struct {
		// AtlasNum string `json:"atlas_num"`
		CameraNo string `json:"camera_no"`
		Floor    string `json:"floor"`
	} `json:"extra_info"`
	CaptureResult struct {
		Crowd struct {
			Type     string `json:"type"`
			Subclass struct {
				Headcount struct {
					Count int `json:"count"`
				} `json:"headcount"`
				Retention struct {
					Count int `json:"count"`
				} `json:"retention"`
				Density struct {
					Percent int `json:"percent"`
				} `json:"density"`
				Segmentation struct {
					Forward int `json:"forward"`
					Reverse int `json:"reverse"`
				} `json:"segmentation"`
				Intrusion struct {
					Interests []struct {
						Direction string `json:"direction"`
						Count     int    `json:"count"`
					} `json:"interests"`
				} `json:"intrusion"`
			} `json:"subclass"`
		} `json:"crowd"`
	} `json:"capture_result"`
}
