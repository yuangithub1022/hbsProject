package logger

import (
	"encoding/hex"
	"fmt"
	"log"
	"os"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"time"

	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/utils"
)

const (
	diff_time = 3600 * 24 * 7
)

var msgPre_Rec = make([]byte, 0, 194)
var msgPre_Send = make([]byte, 0, 194)

var lm = logMonitor{}
var (
	muxLog sync.Mutex
)

type logMonitor struct {
	logCache []string
}

func Info(s string) {
	res := "[Info]  " + s
	log.Println(res)
}

func Warn(s string) {
	res := "[Warn]  " + s
	log.Println(res)
}

func Error(s string) {
	res := "[Error] " + s
	log.Println(res)
}

func Fatal(s string) {
	res := "[Error] " + s
	log.Fatal(res)
}

func InfoAndSave(s string, msg []byte, flag string) {
	var num []int
	var value, output string
	var valueBIN = make([]int, 200, 200)
	var valueBINSlice = make([]int, 8)
	var currTime = time.Now()

	var msgPre = make([]byte, 0)
	var content = make([]byte, 0)

	baseDir := "/opt/store/logs"
	if runtime.GOOS == "windows" {
		baseDir = "./logs"
	}

	dirName := fmt.Sprintf("%s/%d-%02d-%02d", baseDir, currTime.Year(), currTime.Month(), currTime.Day())
	fileName := fmt.Sprintf("%s/%d-%02d-%02dT%02d-%02d.txt", dirName,
		currTime.Year(), currTime.Month(), currTime.Day(),
		currTime.Hour(), currTime.Hour()+1)

	if _, err := os.Stat(fileName); err != nil {
		if os.IsNotExist(err) {
			msgPre_Rec = make([]byte, 0, 194)
			msgPre_Send = make([]byte, 0, 194)
		}
	}

	if flag == "rec" {
		msgPre = msgPre_Rec
	} else if flag == "send" {
		msgPre = msgPre_Send
	}

	if len(msgPre) == 0 {
		res := "[Info]  " + s + hex.EncodeToString(msg)
		log.Println(res)
		write(res)

		if flag == "rec" {
			msgPre_Rec = make([]byte, 194, 194)
			for j := 0; j < len(msg); j++ {
				msgPre_Rec[j] = msg[j]
			}
		} else if flag == "send" {
			msgPre_Send = make([]byte, 194, 194)
			for j := 0; j < len(msg); j++ {
				msgPre_Send[j] = msg[j]
			}
		}

		return
	}

	if flag == "rec" || flag == "send" {
		resFirst := "[Info]  " + s + hex.EncodeToString(msg)
		log.Println(resFirst)

		if len(msg) == len(msgPre) {
			for i := 1; i < len(msg)-2; i++ {
				if msg[i] != msgPre[i] {
					num = append(num, i)
					content = append(content, msg[i])
				}
			}

			if len(num) == 0 {
				if flag == "rec" {
					for j := 0; j < len(msg); j++ {
						msgPre_Rec[j] = msg[j]
					}
				} else if flag == "send" {
					for j := 0; j < len(msg); j++ {
						msgPre_Send[j] = msg[j]
					}
				}
				return
			} else {
				for j := 0; j < len(num); j++ {
					valueBIN[num[j]-1] = 1
				}
	
				for j := 0; j < 25; j++ {
					valueBINSlice = valueBIN[8*j : 8*j+8]
					utils.Reverse(valueBINSlice)
					if len(utils.Btox(strings.Replace(strings.Trim(fmt.Sprint(valueBINSlice), "[]"), " ", "", -1))) == 1 {
						value += "0" + utils.Btox(strings.Replace(strings.Trim(fmt.Sprint(valueBINSlice), "[]"), " ", "", -1))
					} else {
						value += utils.Btox(strings.Replace(strings.Trim(fmt.Sprint(valueBINSlice), "[]"), " ", "", -1))
					}
	
				}
				output = value + " " + hex.EncodeToString(content)
				res := "[Info]  " + s + output
				// log.Println(res)
				write(res)

			}
		}
	}

	if flag == "rec" {
		for j := 0; j < len(msg); j++ {
			msgPre_Rec[j] = msg[j]
		}
	} else if flag == "send" {
		for j := 0; j < len(msg); j++ {
			msgPre_Send[j] = msg[j]
		}
	}
}

func ErrorAndSave(s string) {
	res := "[Error] " + s
	log.Println(res)
	write(res)
}

func Delet() error {
	muxLog.Lock()
	defer muxLog.Unlock()

	baseDirDelet := "/opt/store/logs"
	if runtime.GOOS == "windows" {
		baseDirDelet = "./logs"
	}
	err := os.RemoveAll(baseDirDelet)
	if err != nil {
		return err
	}

	return nil
}

func write(s string) {
	muxLog.Lock()
	defer muxLog.Unlock()

	currTime := time.Now()

	baseDir := "/opt/store/logs"
	if runtime.GOOS == "windows" {
		baseDir = "./logs"
	}

	// make dir if not existed
	_, err := os.Stat(baseDir)
	if os.IsNotExist(err) {
		err = os.MkdirAll(baseDir, 0777)
		if err != nil {
			Error(err.Error())
		}
	}

	// store current log in logCache
	timeStr := fmt.Sprintf("%d-%02d-%02d %02d:%02d:%02d.%09d",
		currTime.Year(), currTime.Month(), currTime.Day(),
		currTime.Hour(), currTime.Minute(), currTime.Second(), currTime.Nanosecond())
	currLogStr := fmt.Sprintf("%s %s\n", timeStr, s)
	lm.logCache = append(lm.logCache, currLogStr)

	// remove logs all seven days ago
	list, err := getDirList(baseDir)
	if err != nil {
		Error(err.Error())
	} else {
		for _, path := range list {
			if path == baseDir {
				continue
			}
			fmt.Printf("Delete log which is seven days ago %v !\r\n", path)
			os.RemoveAll(path)
		}
	}

	// write to disk every 1 record
	if len(lm.logCache) < 1 {
		return
	}

	// write to file
	go writeToFile(baseDir, currTime)
}

// get file list from dir
func getDirList(dirpath string) ([]string, error) {
	var dir_list []string
	now_time := time.Now().Unix()
	dir_err := filepath.Walk(dirpath,
		func(path string, f os.FileInfo, err error) error {
			if f == nil {
				return err
			}
			if f.IsDir() {
				// fmt.Println(path)
				file_time := f.ModTime().Unix()

				if (now_time - file_time) > diff_time {
					dir_list = append(dir_list, path)
				}
				return nil
			}
			return nil
		})
	return dir_list, dir_err
}

func writeToFile(baseDir string, currTime time.Time) {
	muxLog.Lock()
	defer muxLog.Unlock()
	// make a dir of date if not exists
	dirName := fmt.Sprintf("%s/%d-%02d-%02d", baseDir, currTime.Year(), currTime.Month(), currTime.Day())
	if _, err := os.Stat(dirName); err != nil {
		if os.IsNotExist(err) {
			err = os.MkdirAll(dirName, 0777)
			if err != nil {
				Error(err.Error())
			}
		} else {
			Error(err.Error())
		}
	}

	fileName := fmt.Sprintf("%s/%d-%02d-%02dT%02d-%02d.txt", dirName,
		currTime.Year(), currTime.Month(), currTime.Day(),
		currTime.Hour(), currTime.Hour()+1)

	f, err := os.OpenFile(fileName, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0777)
	if err != nil {
		Error(err.Error())

		lm.logCache = []string{}
		return
	}

	toWrite := strings.Join(lm.logCache, "")
	_, err = f.WriteString(toWrite)
	if err != nil {
		Error(err.Error())
	}
	lm.logCache = []string{}
	err = f.Close()
	if err != nil {
		Error(err.Error())
	}
}
