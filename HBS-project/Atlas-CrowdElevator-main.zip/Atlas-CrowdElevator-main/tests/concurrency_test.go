package tests

import (
	"bytes"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"strconv"
	"testing"
)

const (
	// url = "http://localhost:5013/upload"
	// url = "http://cloud.neusoft.co.jp/ce/"
	url        = "http://192.168.3.112:5014/upload"
	numFloors  = 1
	numCameras = 8
	count      = 2
)

func fakeUpload(floor int, cameraNo int, c chan int) {

	jsonStr := fmt.Sprintf(`{
		"task_id": "10002020072301240771801",
		"task_type": "TASK_TYPE_CROWD",
		"extra_info": {
			"camera_no": "%v",
			"floor": "%v"
		},
		"capture_time": "2020-07-22T17:31:55.362944113Z",
		"panorama": {
			"format": "IMAGE_JPEG",
			"data": null,
			"url": "41,55f5a9cd5c3218"
		},
		"capture_result": {
			"crowd": {
				"type": "CROWD_TYPE_INTRUSION",
				"subclass": {
					"intrusion": {
						"interests": [
							{
								"direction": "FORWARD",
								"count": %d,
								"persons": [
									{
										"portrait": {
											"format": "IMAGE_JPEG",
											"data": null,
											"url": "2,55f5aa6ea79876"
										},
										"rectangle": {
											"vertices": [
												{
													"x": 10,
													"y": 73
												},
												{
													"x": 92,
													"y": 158
												}
											]
										}
									}
								]
							}
						]
					}
				}
			}
		}
	}`, strconv.Itoa(cameraNo), strconv.Itoa(floor), count)

	jsonSlice := []byte(jsonStr)

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonSlice))
	if err != nil || req == nil {
		log.Println(err, req)
		c <- -1
		return
	}

	req.Header.Set("Content-Type", "application/json")

	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		log.Println(err)
		c <- -1
		return
	}

	_, err = ioutil.ReadAll(resp.Body)
	if err != nil {
		log.Println(err)
		c <- -1
		return
	}

	err = resp.Body.Close()
	if err != nil {
		log.Println(err)
		c <- -1
		return
	}
	c <- resp.StatusCode
}

func runNumRequests(numRequests int) (bool, int) {
	c := make(chan int)
	for floor := 1; floor <= numFloors; floor++ {
		for cameraNo := 1; cameraNo <= numCameras; cameraNo++ {
			go func(floor int, cameraNo int, c chan int) {
				fakeUpload(floor, cameraNo, c)
			}(floor, cameraNo, c)
		}
	}

	for i := 1; i <= numRequests; i++ {
		respCode := <-c
		if respCode != http.StatusOK {
			return false, respCode
		}
	}
	return true, http.StatusOK
}

func TestConcurrency(t *testing.T) {
	resp, respCode := runNumRequests(numFloors * numCameras)
	if !resp {
		t.Errorf("Expected %v. Got %v.\n", http.StatusOK, respCode)
	}
}

func BenchmarkConcurrency(b *testing.B) {
	for i := 0; i < b.N; i++ {
		log.Println(runNumRequests(numFloors * numCameras))
	}
}
