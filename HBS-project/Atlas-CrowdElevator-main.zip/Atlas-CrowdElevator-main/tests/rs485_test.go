package tests

import (
	"encoding/hex"
	"errors"
	"fmt"
	"io"
	"log"
	"testing"
	"time"

	"github.com/tarm/serial"
)

type RS485 struct {
	baudRate int
	parity   string
	dataBits int
	stopBits string
	portName string
	port     *serial.Port
}

func NewRS485(baudRate int, parity string, dataBits int, stopBits string, portName string) RS485 {
	return RS485{
		baudRate: baudRate,
		parity:   parity,
		dataBits: dataBits,
		stopBits: stopBits,
		portName: portName,
	}
}

func (r *RS485) Init(t *testing.T) {
	c := make(chan bool)

	// open port
	go r.Open(c)

	// keep reopening port if failed to open
	for {
		ok := <-c
		if ok {
			break
		} else {
			t.Error("Failed to open port")
			go func() {
				time.Sleep(1 * time.Second)
				r.Open(c)
			}()
		}
	}

	// keep sending
	go r.send(c)

	for {
		ok := <-c
		if ok {
			go func() {
				time.Sleep(160 * time.Millisecond)
				r.send(c)
			}()
		} else {
			t.Error("Failed")
			go func() {
				time.Sleep(1 * time.Second)
				r.Open(c)
			}()
		}

	}
}

func (r *RS485) getParity(p string) serial.Parity {
	if p == "N" {
		return serial.ParityNone
	} else if p == "E" {
		return serial.ParityEven
	} else if p == "O" {
		return serial.ParityOdd
	}
	log.Fatal("Fatal: parity should be N/E/O, got", p)
	return serial.ParityNone
}

func (r *RS485) getStopBits(s string) serial.StopBits {
	if s == "1" {
		return serial.Stop1
	} else if s == "1.5" {
		return serial.Stop1Half
	} else if s == "2" {
		return serial.Stop2
	}
	log.Fatal("Fatal: stop bits should be 1/1.5/2, got", s)
	return serial.Stop1
}

func (r *RS485) Open(c chan bool) {
	cfg := &serial.Config{
		Name:        r.portName,
		Baud:        r.baudRate,
		StopBits:    r.getStopBits(r.stopBits),
		Parity:      r.getParity(r.parity),
		Size:        byte(r.dataBits),
		ReadTimeout: 10 * time.Millisecond,
		//Size: 0,
	}
	log.Printf("%+v\n", cfg)

	port, err := serial.OpenPort(cfg)
	if err != nil {
		log.Println("open", err)
		c <- false
		return
	}
	r.port = port
	err = r.port.Flush()
	if err != nil {
		log.Println(err)
	}
	c <- true
}

func (r *RS485) Close() {
	err := (*r.port).Close()
	if err != nil {
		log.Println("Cannot close port", err)
	}
}

func (r *RS485) Receive() bool {
	buff := make([]byte, 194, 194)
	received := make([]byte, 0, 194)

	// reader := bufio.NewReader(r.port)
	// data, err := reader.ReadBytes('\n')

	// if err != nil {
	// 	// stops execution
	// 	log.Println(err)
	// 	return false
	// }
	for {
		n, err := (*r.port).Read(buff)
		if err != nil {
			log.Println("Read error", err)
			if errors.Is(err, io.EOF) {
				break
			}
			return false
		}
		received = append(received, buff[:n]...)
	}

	msg := fmt.Sprintf("Received %v bytes: %v", len(received), hex.EncodeToString(received))
	log.Println(msg)
	return true

	// success := r.send()
	// c <- success
}

func (r *RS485) send(c chan bool) {
	toSend := make([]byte, 194, 194)
	n, err := (*r.port).Write(toSend)
	if err != nil {
		errMsg := fmt.Sprintf("Error: %v", err)
		log.Println(errMsg)
		c <- false
		r.Close()
		return
	}

	buff := make([]byte, 194, 194)
	for {
		readBytes, err := (*r.port).Read(buff)
		if err != nil {
			if errors.Is(err, io.EOF) {
				break
			}
			log.Println(err)
			r.Close()
			c <- false
			return
		}
		if readBytes == 0 {
			break
		}
	}

	msg := fmt.Sprintf("Sent %v bytes: %v", n, hex.EncodeToString(toSend[:n]))
	log.Println(msg)
	success := r.Receive()
	c <- success
}

func TestRS485(t *testing.T) {
	ts := time.Now()
	r := NewRS485(38400, "E", 8, "1", "/dev/ttyUSB0")

	go r.Init(t)
	for {
		if time.Now().Sub(ts).Seconds() >= 10.0 {
			break
		}
	}
}
