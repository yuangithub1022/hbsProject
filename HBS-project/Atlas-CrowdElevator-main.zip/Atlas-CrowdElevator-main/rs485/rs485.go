package rs485

import (
	"errors"
	"fmt"
	"io"
	"os/exec"
	"time"

	"github.com/tarm/serial"
	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/cache"
	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/logger"
)

type rs485 struct {
	baudRate  int
	parity    string
	dataBits  int
	stopBits  string
	portName  string
	port      *serial.Port
	waitWrite int
}

func NewRS485(baudRate int, parity string, dataBits int, stopBits string, portName string, waitWrite int) *rs485 {
	return &rs485{
		baudRate:  baudRate,
		parity:    parity,
		dataBits:  dataBits,
		stopBits:  stopBits,
		portName:  portName,
		waitWrite: waitWrite,
	}
}

func (r *rs485) Listen() {
	go r.initPort()
}

func (r *rs485) initPort() {
	c := make(chan bool)

	// set to read mode first
	r.setLowElectricityLevel()

	// open port
	go r.open(c)

	// keep reopening port if failed to open
	for {
		ok := <-c
		if ok {
			break
		}

		go func() {
			time.Sleep(1 * time.Second)
			r.open(c)
		}()
	}

	// keep receiving
	go r.receive(c)

	for {
		ok := <-c
		// keep receiving if ok
		if ok {
			go func() {
				time.Sleep(10 * time.Millisecond)
				r.receive(c)
			}()
			// keep reopening port if not ok
		} else {
			go func() {
				time.Sleep(1 * time.Second)
				r.open(c)
			}()
		}
	}
}

func (r *rs485) getParity(p string) serial.Parity {
	if p == "N" {
		return serial.ParityNone
	} else if p == "E" {
		return serial.ParityEven
	} else if p == "O" {
		return serial.ParityOdd
	}
	logger.Fatal("Parity should be N/E/O, got " + p)
	return serial.ParityNone
}

func (r *rs485) getStopBits(s string) serial.StopBits {
	if s == "1" {
		return serial.Stop1
	} else if s == "1.5" {
		return serial.Stop1Half
	} else if s == "2" {
		return serial.Stop2
	}
	logger.Fatal("Stop bits should be 1/1.5/2, got " + s)
	return serial.Stop1
}

func (r *rs485) open(c chan bool) {
	cfg := serial.Config{
		Name:        r.portName,
		Baud:        r.baudRate,
		StopBits:    r.getStopBits(r.stopBits),
		Parity:      r.getParity(r.parity),
		Size:        byte(r.dataBits),
		ReadTimeout: 10 * time.Millisecond,
	}
	logger.Info(fmt.Sprintf("Opening %+v", cfg))

	port, err := serial.OpenPort(&cfg)
	if err != nil {
		logger.Error("open " + err.Error())
		c <- false
		return
	}
	err = port.Flush()
	if err != nil {
		logger.Error("Error flush: " + err.Error())
		c <- false
		return
	}
	r.port = port
	c <- true
}

func (r *rs485) close() {
	err := (*r.port).Close()
	if err != nil {
		logger.Error("Cannot close port " + err.Error())
	}
}

func (r *rs485) setHighElectricityLevel() {
	_, err := exec.Command("./my_memctrl_app", "1", "0x1F0000f4", "4", "0x00001d00").Output()
	if err != nil {
		logger.ErrorAndSave(err.Error())
	}
	_, err = exec.Command("./my_memctrl_app", "1", "0x12140400", "4", "0x00000010").Output()
	if err != nil {
		logger.ErrorAndSave(err.Error())
	}
	_, err = exec.Command("./my_memctrl_app", "1", "0x12140040", "4", "0x00000010").Output()
	if err != nil {
		logger.ErrorAndSave(err.Error())
	}
	//device := "/dev/ctrl_iomem"
	//
	//fd, err := syscall.open(device, syscall.O_RDWR|syscall.O_SYNC, 0777)
	//if err != nil {
	//	log.Print(err.Error(), "\n")
	//	return
	//}
	//
	//sizeLong := 4
	//
	//buffer := []byte{0x00, 0x00, 0x1d, 0x00}
	//
	//for i := 0; i < len(buffer); i++ {
	//	_, err = syscall.Pwrite(fd, []byte{buffer[i]}, int64(0x1F0000f4+sizeLong*(i+1)))
	//	if err != nil {
	//		log.Print(err.Error(), "\n")
	//	}
	//}
	//
	//buffer = []byte{0x00, 0x00, 0x00, 0x10}
	//for i := 0; i < len(buffer); i++ {
	//	_, err = syscall.Pwrite(fd, []byte{buffer[i]}, int64(0x12140400+sizeLong*(i+1)))
	//	if err != nil {
	//		log.Print(err.Error(), "\n")
	//	}
	//}
	//
	//buffer = []byte{0x00, 0x00, 0x00, 0x10}
	//for i := 0; i < len(buffer); i++ {
	//	_, err = syscall.Pwrite(fd, []byte{buffer[i]}, int64(0x12140040+sizeLong*(i+1)))
	//	if err != nil {
	//		log.Print(err.Error(), "\n")
	//	}
	//}
	//
	//err = syscall.close(fd)
	//
	//if err != nil {
	//	log.Print(err.Error(), "\n")
	//}
}

func (r *rs485) setLowElectricityLevel() {
	_, err := exec.Command("./my_memctrl_app", "1", "0x1F0000f4", "4", "0x00001d02").Output()
	if err != nil {
		logger.ErrorAndSave(err.Error())
	}
	_, err = exec.Command("./my_memctrl_app", "1", "0x12140400", "4", "0x00000000").Output()
	if err != nil {
		logger.ErrorAndSave(err.Error())
	}
	_, err = exec.Command("./my_memctrl_app", "1", "0x12140040", "4", "0x00000000").Output()
	if err != nil {
		logger.ErrorAndSave(err.Error())
	}

	//device := "/dev/ctrl_iomem"
	//
	//fd, err := syscall.open(device, syscall.O_RDWR|syscall.O_SYNC, 0777)
	//if err != nil {
	//	log.Print(err.Error(), "\n")
	//	return
	//}

	//sizeLong := 4
	//
	//buffer := []byte{0x00, 0x00, 0x1d, 0x02}
	//for i := 0; i < len(buffer); i++ {
	//	_, err = syscall.Pwrite(fd, []byte{buffer[i]}, int64(0x1F0000f4+sizeLong*(i+1)))
	//	if err != nil {
	//		log.Print(err.Error(), "\n")
	//	}
	//}
	//
	//buffer = []byte{0x00, 0x00, 0x00, 0x00}
	//for i := 0; i < len(buffer); i++ {
	//	_, err = syscall.Pwrite(fd, []byte{buffer[i]}, int64(0x12140400+sizeLong*(i+1)))
	//	if err != nil {
	//		log.Print(err.Error(), "\n")
	//	}
	//}
	//
	//buffer = []byte{0x00, 0x00, 0x00, 0x00}
	//for i := 0; i < len(buffer); i++ {
	//	_, err = syscall.Pwrite(fd, []byte{buffer[i]}, int64(0x12140040+sizeLong*(i+1)))
	//	if err != nil {
	//		log.Print(err.Error(), "\n")
	//	}
	//}
	//
	//err = syscall.close(fd)
	//
	//if err != nil {
	//	log.Print(err.Error(), "\n")
	//}
}

func (r *rs485) receive(c chan bool) {
	// buff for receiving at most 194 bytes
	buff := make([]byte, 194, 194)

	// keep receiving and sending util something goes wrong
	for {
		received := make([]byte, 0, 194)
		// receive until 194byte over or EOF
		for {
			n, err := (*r.port).Read(buff)

			if err != nil {
				if errors.Is(err, io.EOF) {
					break
				}
				logger.ErrorAndSave("Read error " + err.Error())
				r.close()
				c <- false
				return
			}
			received = append(received, buff[:n]...)

			if len(received) >= 194 {
				break
			}
		}

		// if nothing received, wait for 0.001s and continue
		if len(received) == 0 {
			time.Sleep(1 * time.Millisecond)
			continue
		}

		if len(received) != 194 {
			logger.Error("date lenth is not 194.")
			buffToClear := make([]byte, 194, 194)

			for {
				_, err := (*r.port).Read(buffToClear)
				if err != nil {
					break
				}
			}
			time.Sleep(1 * time.Millisecond)
			continue
		}

		if len(received) < 2 {
			logger.Error("date lenth less than 2.")
			time.Sleep(1 * time.Millisecond)
			continue
		}

		if received[0] != 0xD7 {
			logger.Error("error date : head is not D7.")
			buffToClear := make([]byte, 194, 194)

			for {
				_, err := (*r.port).Read(buffToClear)
				if err != nil {
					break
				}
			}

			time.Sleep(1 * time.Millisecond)
			continue
		}

		logger.InfoAndSave(fmt.Sprintf("Received %v bytes: ", len(received)), received, "rec")

		// send response back
		r.setHighElectricityLevel()
		err := r.send(received[len(received)-2])
		r.setLowElectricityLevel()

		if err != nil {
			logger.ErrorAndSave(err.Error())
			r.close()
			c <- false
			return
		}

		time.Sleep(1 * time.Millisecond)
	}
}

func (r *rs485) send(healthByte byte) error {
	toSend, err := cache.GetData(healthByte)
	if err != nil {
		return err
	}

	// dont send if it is empty
	if len(toSend) == 0 {
		logger.Info("First start nothing to send")
		return nil
	}

	var n int
	n, err = (*r.port).Write(toSend)
	if err != nil {
		return errors.New(fmt.Sprintf("Error sending: %v", err))
	}

	logger.InfoAndSave(fmt.Sprintf("Sent %v bytes:", n), toSend[:n], "send")

	// wait for send date completely
	waitTime := r.waitWrite
	time.Sleep(time.Duration(waitTime) * time.Millisecond)
	return nil
}
