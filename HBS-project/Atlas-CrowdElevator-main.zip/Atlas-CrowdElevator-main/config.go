package main

import (
	"encoding/json"
	"io/ioutil"
	"runtime"

	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/logger"
)

type Config struct {
	BaudRate   int
	Parity     string
	DataBits   int
	StopBits   string
	PortName   string
	NumFloors  int
	NumCameras int
	Interval   int
	Pattern    int
	WaitWrite  int
}

func defaultConfig() Config {
	return Config{
		BaudRate:   38400,
		Parity:     "E",
		DataBits:   8,
		StopBits:   "1",
		PortName:   "/dev/ttyAMA3",
		NumFloors:  64,
		NumCameras: 4,
		Interval:   1,
		Pattern:    1,
		WaitWrite:  60,
	}
}

func GetConfig() Config {
	fileConf := defaultConfig()

	// read file
	configFileName := "config.json"
	if runtime.GOOS != "windows" {
		configFileName = "/var/config/config.json"
	} // todo: check environment variable instead : for example: PROD, DEBUG

	// read config.json
	data, err := ioutil.ReadFile(configFileName)
	if err != nil {
		logger.Error(err.Error())
		return fileConf
	}

	// unmarshall to data
	err = json.Unmarshal(data, &fileConf)
	if err != nil {
		logger.Fatal(err.Error())
	}

	// check parameters
	if fileConf.NumFloors < 1 || fileConf.NumFloors > 64 {
		logger.Error("NumFloors out of range [1 - 64], set to 64")
		fileConf.NumFloors = 64
	}

	if fileConf.NumCameras < 1 || fileConf.NumCameras > 6 {
		logger.Error("NumFloors out of range [1 - 6], set to 6")
		fileConf.NumCameras = 6
	}

	if fileConf.Interval < 1 {
		logger.Error("Interval less than 1 second, set to 1")
		fileConf.Interval = 1
	}

	if fileConf.Pattern != 1 && fileConf.Pattern != 2 {
		logger.Error("Pattern is not 1 or 2, set to 1")
		fileConf.Pattern = 1
	}

	return fileConf
}
