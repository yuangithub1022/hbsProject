package cache

import (
	"errors"
	"fmt"
	"strconv"
	"sync"
	"time"

	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/logger"
)

var (
	sc       *safeCache
	mux      sync.Mutex
	lastsend []byte = make([]byte, 194)
)

const (
	FirstTime = -1
	Sent      = -2
)

// taskInfo is task info with count and capture time
type taskInfo struct {
	count       int
	captureTime time.Time
}

// safeCache is safeCache with mutex
type safeCache struct {
	v          map[int]map[string]*taskInfo // floor -> cameraNo -> info
	numFloors  int
	numCameras int
	interval   int
	pattern    int
	prevData   []byte
}

func Init(numFloors int, numCameras int, interval int, pattern int) {
	sc = &safeCache{
		v:          map[int]map[string]*taskInfo{},
		numFloors:  numFloors,
		numCameras: numCameras,
		interval:   interval,
		pattern:    pattern,
	}

	// init safeCache
	for floor := 1; floor <= numFloors; floor++ {
		sc.v[floor] = map[string]*taskInfo{}
		for cameraNo := 1; cameraNo <= numCameras; cameraNo++ {
			sc.v[floor][strconv.Itoa(cameraNo)] = &taskInfo{
				count:       FirstTime,
				captureTime: time.Now(),
			}
		}
	}

	sc.prevData = initSentBytes()
}

func Update(floor int, cameraNo string, count int, captureTime time.Time) {
	mux.Lock()
	defer mux.Unlock()

	if floor < 1 || floor > sc.numFloors {
		logger.Warn(fmt.Sprintf("Floor %v out of range. Configured range: [1 - %v]", floor, sc.numFloors))
		return
	}

	taskMap := sc.v[floor]

	cn, err := strconv.Atoi(cameraNo)
	if err != nil {
		logger.Error(err.Error())
		return
	}

	if cn < 1 || cn > sc.numCameras {
		logger.Warn(fmt.Sprintf("cameraNo %v out of range. Configured range: [1 - %v]", cameraNo, sc.numCameras))
		return
	}

	taskMap[cameraNo].count = count
	taskMap[cameraNo].captureTime = captureTime

	logger.Info(fmt.Sprintf("%v people updated in Floor %v, Camera %v", count, floor, cameraNo))

}

func Clear() {
	mux.Lock()

	for floor := 1; floor <= sc.numFloors; floor++ {
		for cameraNo := 1; cameraNo <= sc.numCameras; cameraNo++ {
			sc.v[floor][strconv.Itoa(cameraNo)].count = -1
		}
	}
	logger.Info("Cache deleted")
	mux.Unlock()
}

func initSentBytes() []byte {
	res := make([]byte, 194)
	res[0] = 0xD7
	return res
}

func setFloorsToSent(floorsToClear map[int]bool) {
	for floor := range floorsToClear {
		for cameraNo := 1; cameraNo <= sc.numCameras; cameraNo++ {
			sc.v[floor][strconv.Itoa(cameraNo)].count = Sent
		}
	}
}

func newHealthByte(b byte) byte {
	if b < 255 {
		return b + 1
	} else {
		return 0
	}
}

// calc Check sum algorithm
func calcChecksum(data []byte) byte {
	var (
		sum    uint8
		length int = len(data)
	)

	// set all to sent
	for index := 1; index <= length; index++ {
		sum += uint8(data[index-1])
	}

	return byte(sum)
}

func GetData(healthByte byte) ([]byte, error) {
	if sc.pattern == 1 {
		return getDataPattern1(healthByte)
	} else if sc.pattern == 2 {
		return getDataPattern2(healthByte)
	} else {
		errMsg := fmt.Sprintf("Pattern is %v", sc.pattern)
		logger.Fatal(errMsg)
		return nil, errors.New(errMsg)
	}
}

func getDataPattern1(healthByte byte) ([]byte, error) {
	/*
		only send data when all updated
	*/
	// mutex lock and unlock
	mux.Lock()
	defer mux.Unlock()

	res := initSentBytes()

	for floor := 1; floor <= sc.numFloors; floor++ {
		// get task map by floor
		taskMap, ok := sc.v[floor]
		if !ok {
			return []byte{}, errors.New(fmt.Sprintf("Floor %v not initialized", floor))
		}

		// init floor count and ok flag
		floorCount := 0
		okFlag := 0x20

		// traverse current floor's camera
		for cameraNo := 1; cameraNo <= sc.numCameras; cameraNo++ {
			// get task info
			taskInfo, ok := taskMap[strconv.Itoa(cameraNo)]
			if !ok {
				return []byte{}, errors.New(fmt.Sprintf("cameraNo %v not initialized.", cameraNo))
			}

			timeDiff := time.Now().Sub(taskInfo.captureTime)

			// if one camera fails, then status of this floor is not ok
			if timeDiff.Seconds() > float64(sc.interval) {
				floorCount, okFlag = 0, 0
				break
			}

			// if last updated time is within interval
			if timeDiff.Seconds() <= float64(sc.interval) {
				if taskInfo.count == FirstTime {
					return []byte{}, nil
				} else if taskInfo.count == Sent {
					if len(lastsend) < 2 {
						return []byte{}, errors.New(fmt.Sprintf("date lenth less than 2."))
					}
					lastsend[len(lastsend)-2] = healthByte

					data := lastsend[:len(lastsend)-1]
					lastsend[len(lastsend)-1] = calcChecksum(data)
					return lastsend, nil
				}
			}

			floorCount += taskInfo.count
		}

		if floorCount > 255 {
			floorCount = 255
		}

		res[2*floor-1] = byte(floorCount)
		res[2*floor] = byte(okFlag)
	}

	// set all to sent
	for floor := 1; floor <= sc.numFloors; floor++ {
		for cameraNo := 1; cameraNo <= sc.numCameras; cameraNo++ {
			sc.v[floor][strconv.Itoa(cameraNo)].count = Sent
		}
	}

	if len(res) < 2 {
		return []byte{}, errors.New(fmt.Sprintf("date lenth less than 2."))
	}

	//  health check 仕様変更 (2020/12/14)
	//	変更前：health check　+ 1
	//	変更後：health check インクリメントをせずに、そのまま返却
	res[len(res)-2] = healthByte

	//	161~191データを0x00で埋め込む
	for basket := 161; basket <= 191; basket++ {
		res[basket] = 0x00
	}

	// check sum
	data := res[:len(res)-1]
	res[len(res)-1] = calcChecksum(data)

	// save last send data
	lastsend = res

	return res, nil

}

func getDataPattern2(healthByte byte) ([]byte, error) {
	/*
		send data when data of a floor is collected
	*/
	// mutex lock and unlock
	mux.Lock()
	defer mux.Unlock()

	res := initSentBytes()

	// init
	oneFloorCollected := false
	floorsToClear := map[int]bool{}

	for floor := 1; floor <= sc.numFloors; floor++ {
		// get task map by floor
		taskMap, ok := sc.v[floor]
		if !ok {
			return []byte{}, errors.New(fmt.Sprintf("Floor %v not initialized", floor))
		}

		// init floor count and ok flag
		floorCount := 0
		okFlag := 0x20
		sendPrevious := false

		for cameraNo := 1; cameraNo <= sc.numCameras; cameraNo++ {
			// get taskInfo
			taskInfo, ok := taskMap[strconv.Itoa(cameraNo)]
			if !ok {
				return []byte{}, errors.New(fmt.Sprintf("cameraNo %v not initialized.", cameraNo))
			}

			timeDiff := time.Now().Sub(taskInfo.captureTime)

			// if one camera fails, then status of this floor is not ok
			if timeDiff.Seconds() > float64(sc.interval) {
				floorCount, okFlag = 0, 0
				break
			}

			// if last updated time is within interval
			if timeDiff.Seconds() <= float64(sc.interval) {
				if taskInfo.count == FirstTime || taskInfo.count == Sent {
					// this floor is waiting for new data, send previous
					sendPrevious = true
					break
				}
			}

			floorCount += taskInfo.count
		}

		if floorCount > 255 {
			floorCount = 255
		}

		// 0    1   2    3    4   5    6
		// 0xd7 5, 0x20, 5, 0x20, 5, 0x20, 5, 0x20
		if !sendPrevious {
			res[2*floor-1] = byte(floorCount)
			res[2*floor] = byte(okFlag)
			floorsToClear[floor] = true
			oneFloorCollected = true
		} else {
			res[2*floor-1] = sc.prevData[2*floor-1]
			res[2*floor] = sc.prevData[2*floor]
		}
	}

	if len(res) < 2 {
		return []byte{}, errors.New(fmt.Sprintf("date lenth less than 2."))
	}

	// update floors to sent
	setFloorsToSent(floorsToClear)

	//  health check 仕様変更 (2020/12/14)
	//	変更前：health check　+ 1
	//	変更後：health check インクリメントをせずに、そのまま返却
	res[len(res)-2] = healthByte

	//	161~191データを0x00で埋め込む
	for basket := 161; basket <= 191; basket++ {
		res[basket] = 0x00
	}

	// check sum
	data := res[:len(res)-1]
	res[len(res)-1] = calcChecksum(data)

	if !oneFloorCollected {
		sc.prevData[192] = healthByte
		datatemp := sc.prevData[:193]
		sc.prevData[len(res)-1] = calcChecksum(datatemp)
		return sc.prevData, nil
	}

	// update prevData
	sc.prevData = res

	return res, nil
}
