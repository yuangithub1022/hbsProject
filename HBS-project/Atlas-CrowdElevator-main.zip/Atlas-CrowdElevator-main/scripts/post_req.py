# importing the requests library
import asyncio
from concurrent.futures import ThreadPoolExecutor
import requests
import json
import warnings


import logging


class Logger:
    instance = None

    def __init__(self):
        if not Logger.instance:
            fmt = "%(asctime)s %(levelname)s %(name)s : %(message)s"
            logging.basicConfig(format=fmt)
            Logger.instance = logging.getLogger('Atlas')
            Logger.instance.setLevel(logging.DEBUG)


Logger()
logger = Logger.instance

warnings.filterwarnings('ignore', message='Unverified HTTPS request')

# defining the api-endpoint
# API_ENDPOINT = "http://172.30.1.190:18888/upload"
API_ENDPOINT = "http://localhost:18888/upload"
# data to be sent to api
with open('../test_jsons/line/intrusion/data62.json') as json_file:
    data = json.load(json_file)


def fake_upload_call(session):
    logger.info('start---------------------')
    with session.post(API_ENDPOINT, json=data, timeout=15, verify=False) as response:
        return response
    

async def fake_upload_calls():
    with ThreadPoolExecutor(max_workers=10) as executor:
        with requests.Session() as session:
            loop = asyncio.get_event_loop()
            tasks = [
                loop.run_in_executor(
                    executor,
                    fake_upload_call,
                    *(session,)
                )
                for _ in range(1)
            ]
            for response in await asyncio.gather(*tasks):
                logger.info(response.content)
                logger.info('end---------------------')


def main():
    loop = asyncio.get_event_loop()
    future = asyncio.ensure_future(fake_upload_calls())
    loop.run_until_complete(future)


if __name__ == '__main__':
    main()
