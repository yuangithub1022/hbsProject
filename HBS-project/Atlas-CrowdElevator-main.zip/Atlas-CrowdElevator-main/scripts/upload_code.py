import paramiko
import glob
import os
import ntpath

machine = 'neu'
if machine == 'huawei':
    global_user_name = 'huawei'
    global_password = 'neusoftjapan'
else:
    global_user_name = 'root'
    global_password = 'NEVS0FT_12#$'


class MySFTPClient(paramiko.SFTPClient):
    def put_dir(self, source, target):
        """ Uploads the contents of the source directory to the target path. The
            target directory needs to exists. All subdirectories in source are
            created under target.
        """
        for item in os.listdir(source):
            if os.path.isfile(os.path.join(source, item)):
                self.put(os.path.join(source, item), f'{target}/{item}')
            else:
                self.mkdir(f'{target}/{item}', ignore_existing=True)
                self.put_dir(os.path.join(source, item), f'{target}/{item}')

    def mkdir(self, path, mode=511, ignore_existing=False):
        """ Augments mkdir by adding an option to not fail if the folder exists  """
        try:
            super(MySFTPClient, self).mkdir(path, mode)
        except IOError:
            if ignore_existing:
                pass
            else:
                raise


def upload_files(host, port, ftp_dir, local_dir, file_names):
    # Open a transport
    transport = paramiko.Transport((host, port))

    # Auth
    username,password = global_user_name, global_password
    transport.connect(None, username, password)

    # Go!
    sftp = paramiko.SFTPClient.from_transport(transport)

    # Upload
    for file_name in file_names:
        filepath = f'{ftp_dir}{file_name}'
        localpath = f'{local_dir}{file_name}'
        sftp.put(localpath, filepath)

    # Close
    if sftp:
        sftp.close()
    if transport:
        transport.close()


def upload_dir(host, port, ftp_dir, local_dir):
    # Open a transport
    transport = paramiko.Transport((host, port))

    # Auth
    username,password = global_user_name, global_password
    transport.connect(None, username, password)

    # Go!
    sftp = MySFTPClient.from_transport(transport)

    # Upload
    sftp.put_dir(local_dir, ftp_dir)

    # Close
    if sftp:
        sftp.close()
    if transport:
        transport.close()


if __name__ == "__main__":
    project_dir = 'C:\\Users\\datsm\\Desktop\\projects\\Atlas-CrowdElevator\\'
    os.chdir("..")
    file_names = glob.glob(f'*.go')
    file_names.append('go.mod')
    # file_names.append('go.sum')

    file_names.append('my_memctrl_app')
    print(file_names)

    if machine == 'huawei':
        upload_files("124.219.161.88", 21622, '/home/hbs/crowdElevator/source/',
                     project_dir, file_names)
    elif machine == 'neu':
        upload_files("cloud.neusoft.co.jp", 10092, '/home/hbs/crowdElevator/source/',
                     project_dir, file_names)

    dirs = [x[0] for x in os.walk('.')]

    for d in dirs:
        if d.startswith('.\.git') or d.startswith('.\.idea') or d.startswith('.\\tests') or d == '.':
            continue
        go_files = glob.glob(f'{d}\*.go')
        if not go_files:
            continue
        go_files = [ntpath.basename(f) for f in go_files]

        print(d, go_files)
        if machine == 'huawei':
            upload_files("124.219.161.88", 21622, f'/home/hbs/crowdElevator/source/{d[2:]}/',
                         project_dir + d[2:] + '\\', go_files)
        elif machine == 'neu':
            upload_files("cloud.neusoft.co.jp", 10092, f'/home/hbs/crowdElevator/source/{d[2:]}/',
                         project_dir + d[2:] + '\\', go_files)



