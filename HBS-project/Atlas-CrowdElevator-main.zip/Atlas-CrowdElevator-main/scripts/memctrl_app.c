#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <ctype.h>
#include <string.h>

static int fd = -1;
static const char dev[]="/dev/ctrl_iomem";


static int atoul(char *str, int * pulValue)
{
	int ulResult=0;

	while (*str)
	{
		if (isdigit((int)*str))
		{
			if ((ulResult<429496729) || ((ulResult==429496729) && (*str<'6')))
			{
				ulResult = ulResult*10 + (*str)-48;
			}
			else
			{
				*pulValue = ulResult;
				return -1;
			}
		}
		else
		{
			*pulValue=ulResult;
			return -1;
		}
		str++;
	}
	*pulValue=ulResult;
	return 0;
}

#define ASC2NUM(ch) (ch - '0')
#define HEXASC2NUM(ch) (ch - 'A' + 10)

static int  atoulx(char *str, int * pulValue)
{
	int   ulResult=0;
	char ch;

	while (*str)
	{
		ch=toupper(*str);
		if (isdigit(ch) || ((ch >= 'A') && (ch <= 'F' )))
		{
			if (ulResult < 0x10000000)
			{
				ulResult = (ulResult << 4) + ((ch<='9')?(ASC2NUM(ch)):(HEXASC2NUM(ch)));
			}
			else
			{
				*pulValue=ulResult;
				return -1;
			}
		}
		else
		{
			*pulValue=ulResult;
			return -1;
		}
		str++;
	}

	*pulValue=ulResult;
	return 0;
}

static int  StrToNumber(char *str , int * pulValue)
{
	if ( *str == '0' && (*(str+1) == 'x' || *(str+1) == 'X') )
	{
		if (*(str+2) == '\0')
		{
			return -1;
		}
		else
		{
			return atoulx(str+2,pulValue);
		}
	}
	else
	{
		return atoul(str,pulValue);
	}
}


int main(int argc , char* argv[])
{
	int len = 0;
	unsigned int phy_address;
	int wr = -1;
	int ret = -1;
	int var = 0;
	int cnt = 0;
	char *buf = NULL;
	// ./my_memctrl_app 1 0x1F0000f4 4 0x00001d00
	if (argc < 4)
	{
		printf("usage: %s<read(0) or write(1)> <address> <length> [value]. sample: %s 0 0x80040000 0x100\n", argv[0], argv[0]);
		return -1;
	}

	if (StrToNumber(argv[3], &len) != 0)
	{
		printf("usage: length format error\n");
		return -1;
	}
	
	if (StrToNumber(argv[2], (int *)&phy_address) != 0)
	{
		printf("usage: phy_address format error\n");
		return -1;
	}
	
	if (StrToNumber(argv[1], &wr) != 0 || (wr != 0 &&  wr != 1))
	{
		printf("usage: wr format error\n");
		return -1;
	}

	if(wr == 1 && StrToNumber(argv[4], (int *)&var) != 0)
	{
		printf("usage: write value error\n");
		return -1;
	}

	fd = open (dev, O_RDWR | O_SYNC);
	if (fd < 0)
	{
		printf("device open error!\n");
		return -1;
	}
	

	buf = malloc(len + sizeof(long));
	if(buf)
	{
		memset(buf, var, len + sizeof(long));
		// buffer address is equal to phy_address
		*(unsigned long *) buf = phy_address;
	}
	else
	{
		printf("malloc error");
		return -1;
	}
	
	printf("phy_address is 0x%ulx, lenth  is %d, wr flag is %d, var is %d\n",phy_address, len, wr, var);

	if(wr == 0)
	{
		ret = read(fd, buf, len);
		
		if( ret != 0)
		{
			printf("read error");
			free(buf);
			return -1;
			
		}
		
		for(cnt = 0; cnt < len; cnt++)
		{
			printf("read result-byte %d is: %d\n", cnt, *(buf + sizeof(long) + cnt));
		}
	}
	else
	{
		for(cnt = 0; cnt < len; cnt++)
                {
                        *(buf + sizeof(long) + cnt) = *((char *)&var + cnt);
                        printf("write byte %d: %d\n", cnt, *(buf + sizeof(long) + cnt));
                }

		
		ret = write(fd, buf, len);
		
		if( ret != 0)
		{
			printf("write error");
			free(buf);
			return -1;
			
		}
	}
	
	free(buf);
	close(fd);

	return 0;
}
