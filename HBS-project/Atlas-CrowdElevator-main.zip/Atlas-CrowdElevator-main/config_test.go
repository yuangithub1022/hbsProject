package main

import (
	"fmt"
	"iot.neusoft.co.jp/iot/Atlas-CrowdElevator/logger"
	"testing"
)

func TestGetConfig(t *testing.T) {
	c := GetConfig()
	logger.Info(fmt.Sprintf("%v", c))
}
